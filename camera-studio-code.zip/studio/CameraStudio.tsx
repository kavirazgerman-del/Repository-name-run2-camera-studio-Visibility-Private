import React from "react";
import { useCreatePost, useGetCommunities, useGetMusicTracks, useGetCreativeChallengeReuse, getGetCreativeChallengeReuseQueryKey, useGetMusicTrack, getGetMusicTrackQueryKey, useGetPost, getGetPostQueryKey, useCreateAiFilterRemake, useCreateAiFilterMoodMatch, type MusicTrack, type AiFilterConfig, type AiFilterRemakeInputStyle } from "@workspace/api-client-react";
import { useUpload } from "@workspace/object-storage-web";
import { UploadScanOverlay } from "@/components/upload/UploadScanOverlay";
import { VoiceResonanceBar } from "@/components/ui/VoiceResonanceBar";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ContentDisclosureFields } from "@/components/post/ContentDisclosureFields";
import { ChallengeShareSheet } from "@/components/post/ChallengeShareSheet";
import { type DisclosureKind } from "@/lib/disclosure";
import {
  X, Zap, ZapOff, RotateCcw, Timer, Settings2, CloudRain,
  Sparkles, Layers, Type, Box, Heart, ShieldCheck, Flag,
  Camera, Square, Download, ChevronLeft, ChevronDown, ChevronUp, Loader2, Video,
  ImagePlus, ShoppingBag, Brush, Undo2, Trash2, Plus, Music, Images, Check,
  Mic, MicOff,
  Film, PenTool, StickyNote, Aperture, Archive,
  Sliders, Sun, Eye, Save, Play, Pause, Scissors, Copy, Redo2, Grid3x3,
  Volume2, Maximize2, Minimize2, SkipBack, SkipForward, Wand2, Users,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { EffectsPanel } from "./panels/EffectsPanel";
import { BackgroundsPanel, type AIBackground } from "./panels/AIPanel";
import { AIDirectorPanel } from "./panels/AIDirectorPanel";
import {
  EXPERIENCES, makeExperienceState, type ExperienceState,
} from "./ExperienceRenderer";
import { BrandLogo, PremiumGate } from "@/components/brand/BrandEgg";
import { useMembership } from "@/lib/MembershipContext";
import {
  INK_BRUSHES, renderInk, renderInkStatic, beginStroke, makeText,
  type InkElement, type InkStroke, type InkText, type BrushId, type AnchorMode,
} from "./ink";
import { CANVAS_BACKGROUNDS, drawCanvasBackground, type CanvasBgId } from "./backgrounds";
import { renderAiConfigFilter, aiConfigGradeCss } from "./aiConfigFilter";
import { VideoEditor } from "./VideoEditor";
import { FancyInkComposer, type FancyInkComposerHandle } from "@/components/fancy-notes/FancyInkComposer";
import filterBase from "@/assets/studio-hero-1.png";
import {
  exportSegments, exportSlideshow, probeBlob, extForMime, totalTrimmedDuration, pickRecorderMime,
  type VideoSegment, type MusicFitMode,
} from "./videoExport";
import { cleanClipVoice, VoiceCleanupError } from "./voiceCleanup";
import { MusicSheet } from "./MusicSheet";
import { AddMediaSheet } from "./AddMediaSheet";
import { mediaSrc } from "@/components/post/PostMedia";
import { suggestMusic } from "./musicMatch";
import {
  NeonPatriotTracker, DEFAULT_NEON_PATRIOT_PARAMS, renderNeonPatriot,
  NP_LEVELS, NP_STRETCHES,
  type NeonPatriotParams, type NeonPatriotTracking, type NPLevel3, type NPStretch,
} from "./neonPatriot";
import {
  DEFAULT_BEAUTY_X_PARAMS, BX_PRESETS, BX_LEVELS, renderBeautyX,
  type BeautyXParams, type BXLevel,
} from "./beautyX";
import {
  DEFAULT_SOLARGRAPH_PARAMS, renderSolargraph,
  type SolargraphParams,
} from "./solargraph";
import {
  DEFAULT_CARNIVAL_PARAMS, CARNIVAL_STYLES, renderCarnival,
  type CarnivalParams, type CarnivalStyle,
} from "./carnival";
import {
  NeonMoodTracker, NeonMoodSegmenter, renderNeonMood,
  DEFAULT_NEON_MOOD_PARAMS, NM_GLOW_LEVELS,
  type NeonMoodParams, type NMGlow, type NeonMoodTracking,
} from "./neonMood";
import { renderCaricatureBase } from "./caricature";
import { renderMascot } from "./mascot";
import { StudioPoseTracker, readPose, type PoseSnapshot } from "./poseTracking";
import { type PoseAngles } from "./poseAngles";
import {
  saveDraft, getDraft, deleteDraft, countDrafts,
  serializeSegments, hydrateSegments, firstFrameDataUrl, newDraftId,
  DRAFT_SCHEMA_VERSION, MAX_DRAFTS, type StudioDraft,
} from "./drafts";
import { DraftsPanel } from "./DraftsPanel";

// Posted videos may be up to 3 minutes 45 seconds long (enforced
// authoritatively server-side).
const MAX_VIDEO_SEC = 225;

// Whether Canvas2D `ctx.filter` is supported (Safari 17+, Chrome, Firefox). When
// true we can BAKE CSS colour grades into the canvas pixel buffer so they survive
// captureStream()/toDataURL(). When false we fall back to preview-only style.filter
// (older Safari): the grade still shows live but can't be captured.
const CANVAS_FILTER_SUPPORTED = (() => {
  try {
    if (typeof document === "undefined") return false;
    const ctx = document.createElement("canvas").getContext("2d");
    if (!ctx) return false;
    ctx.filter = "blur(1px)";
    return ctx.filter === "blur(1px)";
  } catch {
    return false;
  }
})();

// ── Canvas filter particle type ────────────────────────────────────────────────
interface CvParticle {
  x: number; y: number; vx: number; vy: number;
  life: number; r: number; color: string;
}

// ── Neon Rain dedicated controls ───────────────────────────────────────────────
// Neon Rain is a premium canvas filter with its own control set: Intensity scales
// the WHOLE effect, Rain/Glow are 3-step, and Lens droplets toggles a lens layer.
// Passed into the (module-level) canvas fn via compositeFrame since it can't close
// over component refs.
type NeonRainLevel = "low" | "med" | "high";
interface NeonRainParams {
  intensity: number; // 0..100 — overall strength (density + glow + overlays + grade)
  rainAmount: NeonRainLevel;
  glowStrength: NeonRainLevel;
  lensDroplets: boolean;
}
const DEFAULT_NEON_RAIN_PARAMS: NeonRainParams = {
  intensity: 70, rainAmount: "med", glowStrength: "med", lensDroplets: true,
};
const NEON_RAIN_LEVELS: { id: NeonRainLevel; label: string }[] = [
  { id: "low", label: "Low" }, { id: "med", label: "Med" }, { id: "high", label: "High" },
];
// Neon Rain wet-glass / neon-city sprite field. The bokeh (distant out-of-focus
// neon city lights) and the wet-glass droplet beads are STATIC — rain on glass
// doesn't dance — so we render them ONCE into offscreen canvases and blit them
// each frame (fast + flicker-free). Built lazily on first use so there's no
// import-time DOM access; only the falling rain streaks animate.
const nrRng = (seed: number) => {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let x = s;
    x = Math.imul(x ^ (x >>> 15), x | 1);
    x ^= x + Math.imul(x ^ (x >>> 7), x | 61);
    return ((x ^ (x >>> 14)) >>> 0) / 4294967296;
  };
};
const nrOffscreen = (w: number, h: number) => {
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  return c;
};
const nrRoundRect = (c: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) => {
  c.beginPath();
  c.moveTo(x + r, y);
  c.arcTo(x + w, y, x + w, y + h, r);
  c.arcTo(x + w, y + h, x, y + h, r);
  c.arcTo(x, y + h, x, y, r);
  c.arcTo(x, y, x + w, y, r);
  c.closePath();
};
type NeonGlassSprites = { bokeh: HTMLCanvasElement; beads: HTMLCanvasElement; drops: HTMLCanvasElement };
const neonGlassSpriteCache = new Map<string, NeonGlassSprites>();
const getNeonGlassSprites = (w: number, h: number): NeonGlassSprites => {
  const cacheKey = `${w}x${h}`;
  const cached = neonGlassSpriteCache.get(cacheKey);
  if (cached) return cached;
  const COLS: [number, number, number][] = [
    [255, 79, 216], [232, 121, 249], [255, 94, 168],
    [34, 211, 238], [56, 189, 248], [59, 130, 246], [168, 85, 247],
  ];
  // Neon city bokeh — right-biased clusters of out-of-focus coloured light, then
  // softened to read as distant lights through a rain-streaked window.
  const bk = nrOffscreen(w, h);
  const bc = bk.getContext("2d")!;
  bc.globalCompositeOperation = "screen";
  const rnd = nrRng(99119);
  const disc = (x: number, y: number, r: number, col: [number, number, number], a: number, core: boolean) => {
    const g = bc.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, `rgba(${col[0]},${col[1]},${col[2]},${Math.min(1, a)})`);
    g.addColorStop(0.4, `rgba(${col[0]},${col[1]},${col[2]},${a * 0.45})`);
    g.addColorStop(1, `rgba(${col[0]},${col[1]},${col[2]},0)`);
    bc.fillStyle = g; bc.beginPath(); bc.arc(x, y, r, 0, Math.PI * 2); bc.fill();
    if (core) {
      const g2 = bc.createRadialGradient(x, y, 0, x, y, r * 0.42);
      g2.addColorStop(0, `rgba(255,255,255,${a * 0.85})`);
      g2.addColorStop(1, "rgba(255,255,255,0)");
      bc.fillStyle = g2; bc.beginPath(); bc.arc(x, y, r * 0.42, 0, Math.PI * 2); bc.fill();
    }
  };
  for (let i = 0; i < 92; i++) {
    const y = rnd() * h;
    const x = rnd() < 0.74 ? (0.5 + rnd() * 0.5) * w : rnd() * w;
    const u = rnd();
    const r = u < 0.6 ? 3 + rnd() * 9 : u < 0.9 ? 12 + rnd() * 16 : 28 + rnd() * 28;
    disc(x, y, r, COLS[(rnd() * COLS.length) | 0], 0.34 + rnd() * 0.55, r > 16 && rnd() < 0.7);
  }
  // Dense neon "column" sub-cluster (right-centre, like the reference cityscape).
  for (let i = 0; i < 28; i++) {
    const x = (0.64 + rnd() * 0.24) * w, y = (0.26 + rnd() * 0.52) * h;
    const u = rnd();
    const r = u < 0.7 ? 4 + rnd() * 9 : 12 + rnd() * 15;
    disc(x, y, r, COLS[(rnd() * COLS.length) | 0], 0.42 + rnd() * 0.5, r > 13 && rnd() < 0.6);
  }
  // Vertical neon "window/sign" bars clustered on the right.
  for (let i = 0; i < 10; i++) {
    const x = (0.6 + rnd() * 0.34) * w, y = (0.12 + rnd() * 0.62) * h;
    const bw = 4 + rnd() * 7, bh = 16 + rnd() * 52;
    const col = COLS[(rnd() * COLS.length) | 0], a = 0.4 + rnd() * 0.5;
    const g = bc.createLinearGradient(x, y - bh / 2, x, y + bh / 2);
    g.addColorStop(0, `rgba(${col[0]},${col[1]},${col[2]},0)`);
    g.addColorStop(0.5, `rgba(${col[0]},${col[1]},${col[2]},${a})`);
    g.addColorStop(1, `rgba(${col[0]},${col[1]},${col[2]},0)`);
    bc.fillStyle = g; nrRoundRect(bc, x - bw / 2, y - bh / 2, bw, bh, bw / 2); bc.fill();
  }
  const bokeh = nrOffscreen(w, h);
  const bokehCtx = bokeh.getContext("2d")!;
  bokehCtx.filter = "blur(3px)"; bokehCtx.drawImage(bk, 0, 0); bokehCtx.filter = "none";
  // Wet-glass droplet beads — full-frame refractive specks with crisp top-left
  // highlights (a faint cool body + bright catch-light reads as a water bead).
  const beadField = (count: number, minR: number, maxR: number, seed: number, bodyA: number, hiA: number) => {
    const cvb = nrOffscreen(w, h);
    const c = cvb.getContext("2d")!;
    const r2 = nrRng(seed);
    for (let i = 0; i < count; i++) {
      const x = r2() * w, y = r2() * h, r = minR + r2() * (maxR - minR);
      const body = c.createRadialGradient(x, y, 0, x, y, r);
      body.addColorStop(0, `rgba(170,200,235,${bodyA * (0.7 + r2() * 0.6)})`);
      body.addColorStop(0.65, `rgba(110,150,205,${bodyA * 0.4})`);
      body.addColorStop(1, "rgba(110,150,205,0)");
      c.fillStyle = body; c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fill();
      const hr = r * 0.5, hx = x - r * 0.3, hy = y - r * 0.3;
      const hl = c.createRadialGradient(hx, hy, 0, hx, hy, hr);
      hl.addColorStop(0, `rgba(240,250,255,${hiA * (0.7 + r2() * 0.5)})`);
      hl.addColorStop(1, "rgba(240,250,255,0)");
      c.fillStyle = hl; c.beginPath(); c.arc(hx, hy, hr, 0, Math.PI * 2); c.fill();
    }
    return cvb;
  };
  const beads = beadField(255, 1.4, 5.8, 5503, 0.17, 0.62);
  const drops = beadField(48, 7, 21, 7717, 0.22, 0.72);
  const sprites: NeonGlassSprites = { bokeh, beads, drops };
  neonGlassSpriteCache.set(cacheKey, sprites);
  return sprites;
};

// ── Filters (some have canvas overlays for animation/depth/distortion) ─────────
type FilterId = "none"|"neonrain"|"neonpatriot"|"beautyx"|"solargraph"|"carnival"|"neonmood"|"caricature"|"mascot"|"aiconfig"|"golden"|"cinematic"|"noir"|"vintage"|"electric"|"film"|"bw";
// Filters that consume the shared body-pose tracker. This is the single registration
// point that spins the PoseLandmarker up (see the pose-tracker lifecycle effect) and
// routes per-frame pose data through the compositor seam. Intentionally EMPTY today —
// this task ships reusable pose INFRASTRUCTURE, not an end-user filter; a future
// pose-aware consumer adds its id here. The live pipeline is exercised standalone via
// the unlisted /pose-tracker-preview route.
const POSE_AWARE_FILTERS = new Set<FilterId>();
// Argument bundle passed to a filter's canvas() overlay by compositeFrame. A
// discriminated union so each premium filter receives exactly what it needs at
// capture time without leaking component refs into the module-level FILTERS table.
type FilterCanvasArg =
  | { kind: "neonrain"; rain: NeonRainParams }
  | { kind: "neonpatriot"; patriot: NeonPatriotParams; tracking: NeonPatriotTracking | null; vw: number; vh: number; mirror: boolean }
  | { kind: "beautyx"; beauty: BeautyXParams; tracking: NeonPatriotTracking | null; vw: number; vh: number; mirror: boolean }
  | { kind: "solargraph"; solar: SolargraphParams }
  | { kind: "carnival"; carnival: CarnivalParams; tracking: NeonPatriotTracking | null; vw: number; vh: number; mirror: boolean }
  | { kind: "neonmood"; mood: NeonMoodParams; tracking: NeonMoodTracking | null; vw: number; vh: number; mirror: boolean }
  | { kind: "mascot"; mask: HTMLCanvasElement | null; scratchCtx: CanvasRenderingContext2D | null; tracking: NeonPatriotTracking | null; vw: number; vh: number; mirror: boolean; intensity: number }
  | { kind: "aiconfig"; config: AiFilterConfig; intensity: number }
  | { kind: "pose"; pose: PoseSnapshot | null; angles: PoseAngles | null; vw: number; vh: number; mirror: boolean };
interface FilterDef {
  id: FilterId; label: string; swatch: string; css: string;
  canvas?: (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number, p: CvParticle[], arg?: FilterCanvasArg) => void;
}

const FILTERS: FilterDef[] = [
  { id: "none", label: "Original", swatch: "linear-gradient(135deg,#374151,#111827)", css: "" },

  // ── Neon Rain — rain-on-glass neon-city look (no zoom/crop; layered canvas) ────
  // Stacked layers baked by compositeFrame: cool-shadow grade · neon-city bokeh ·
  // parallax rain streaks · wet-floor sheen · full-frame wet-glass beads · lens
  // droplets · vignette. The static glass/bokeh fields are pre-rendered once (see
  // getNeonGlassSprites) and blitted; only the rain streaks animate. Every knob is
  // driven by NeonRainParams — Intensity scales the WHOLE effect, not just the grade.
  { id: "neonrain", label: "Neon Rain", swatch: "linear-gradient(135deg,#22d3ee,#3b82f6,#a855f7)",
    css: "brightness(0.86) contrast(1.18) saturate(1.28) hue-rotate(-6deg)",
    canvas(ctx, w, h, frame, p, arg) {
      const pr = arg?.kind === "neonrain" ? arg.rain : DEFAULT_NEON_RAIN_PARAMS;
      const t = Math.max(0, Math.min(1, pr.intensity / 100));        // overall strength 0..1
      const target = { low: 100, med: 160, high: 240 }[pr.rainAmount];
      const TARGET = Math.round(target * t);                         // intensity thins → 0 at 0%
      const GLOW = { low: 0.7, med: 1, high: 1.35 }[pr.glowStrength];
      const beadMul = { low: 0.55, med: 0.82, high: 1 }[pr.rainAmount]; // wet-glass density
      const S = getNeonGlassSprites(w, h);
      const palette = ["#22d3ee", "#38bdf8", "#3b82f6", "#a855f7", "#e879f9"];

      // 1) Cool-shadow grade — deepen the neon-night shadows (multiply).
      ctx.save();
      ctx.globalCompositeOperation = "multiply";
      ctx.globalAlpha = 0.42 * t;
      const cool = ctx.createLinearGradient(0, 0, 0, h);
      cool.addColorStop(0, "rgba(5,10,24,0.55)");
      cool.addColorStop(1, "rgba(4,8,18,1)");
      ctx.fillStyle = cool; ctx.fillRect(0, 0, w, h);
      ctx.restore();

      // 2) Neon-city bokeh — pre-rendered distant out-of-focus lights (screen blit).
      ctx.save();
      ctx.globalCompositeOperation = "screen";
      ctx.globalAlpha = Math.min(1, 0.95 * GLOW * t);
      ctx.drawImage(S.bokeh, 0, 0, w, h);
      ctx.restore();

      // 3) Parallax rain — subtle falling streaks (the wet glass now dominates).
      ctx.save();
      const spawn = Math.max(2, Math.round(TARGET / 22));
      const need = Math.min(spawn, TARGET - p.length);
      for (let i = 0; i < need; i++) {
        const d = Math.random(); // depth: 0 = far, 1 = near
        p.push({
          x: Math.random(),
          y: -0.05 - Math.random() * 0.4,
          vx: -0.0008 - d * 0.0016,
          vy: 0.012 + d * 0.034,
          life: d,
          r: 0.5 + d * 1.9,
          color: palette[Math.floor(Math.random() * palette.length)],
        });
      }
      for (let i = p.length - 1; i >= 0; i--) {
        const s = p[i];
        s.x += s.vx; s.y += s.vy;
        if (s.y > 1.15 || p.length > TARGET + 40) p.splice(i, 1);
      }
      // Far drops first so near drops layer on top — sells the depth.
      p.sort((a, b) => a.life - b.life);
      ctx.lineCap = "round";
      const rainA = t * 0.62; // restrained — beads/bokeh carry the look
      for (let i = 0; i < p.length; i++) {
        const s = p[i];
        const d = s.life;
        const len = 0.04 + d * 0.1;
        const x1 = s.x * w, y1 = s.y * h;
        const x2 = x1 - s.vx * w * 6, y2 = y1 - len * h; // slight diagonal
        const a = (0.1 + d * 0.42) * rainA;
        if (d < 0.42) {
          // Far layer: cheap flat streak (no glow/gradient) — keeps mobile smooth.
          ctx.globalAlpha = a;
          ctx.strokeStyle = s.color;
          ctx.lineWidth = s.r;
          ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
        } else {
          // Near layer: wide soft glow + bright gradient core.
          ctx.globalAlpha = a * 0.5 * GLOW;
          ctx.strokeStyle = s.color;
          ctx.lineWidth = s.r * 2.4 * GLOW;
          ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
          const g = ctx.createLinearGradient(x1, y1, x2, y2);
          g.addColorStop(0, "rgba(255,255,255," + Math.min(1, a + 0.3) + ")");
          g.addColorStop(0.25, s.color);
          g.addColorStop(1, "rgba(0,0,0,0)");
          ctx.globalAlpha = a;
          ctx.strokeStyle = g;
          ctx.lineWidth = s.r;
          ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
        }
      }
      ctx.restore();

      // 4) Wet-floor reflection — pulsing neon sheen on the ground (screen).
      ctx.save();
      ctx.globalCompositeOperation = "screen";
      ctx.globalAlpha = (0.05 + 0.03 * Math.sin(frame * 0.08)) * t;
      const floor = ctx.createLinearGradient(0, h, 0, h * 0.84);
      floor.addColorStop(0, "rgba(34,211,238,0.6)");
      floor.addColorStop(0.5, "rgba(168,85,247,0.28)");
      floor.addColorStop(1, "rgba(34,211,238,0)");
      ctx.fillStyle = floor; ctx.fillRect(0, h * 0.84, w, h * 0.16);
      ctx.restore();

      // 5) Wet-glass micro beads — full-frame refractive specks on the glass (screen).
      ctx.save();
      ctx.globalCompositeOperation = "screen";
      ctx.globalAlpha = Math.min(1, beadMul * t);
      ctx.drawImage(S.beads, 0, 0, w, h);
      ctx.restore();

      // 6) Lens droplets — bigger foreground refractive drops (toggle, screen blit).
      if (pr.lensDroplets) {
        ctx.save();
        ctx.globalCompositeOperation = "screen";
        ctx.globalAlpha = Math.min(1, 0.9 * t);
        ctx.drawImage(S.drops, 0, 0, w, h);
        ctx.restore();
      }

      // 6) Vignette — cinematic elliptical edge falloff.
      ctx.save();
      ctx.globalAlpha = t;
      ctx.translate(w / 2, h / 2);
      ctx.scale(w / 2, h / 2);
      const vg = ctx.createRadialGradient(0, 0, 0, 0, 0, 1);
      vg.addColorStop(0.45, "rgba(2,6,15,0)");
      vg.addColorStop(0.78, "rgba(2,6,15,0.35)");
      vg.addColorStop(1, "rgba(0,0,0,0.58)");
      ctx.fillStyle = vg; ctx.fillRect(-1, -1, 2, 2);
      ctx.restore();

      // Leave the context fully clean so later stacked filters + Motion Ink draw true.
      ctx.globalAlpha = 1;
      ctx.filter = "none";
      ctx.shadowBlur = 0;
      ctx.globalCompositeOperation = "source-over";
    },
  },

  // ── Neon Patriot — face-tracked glowing flag overlay (MediaPipe + WebGL2) ──
  // The heavy lifting lives in ./neonPatriot.ts. This entry is overlay-only (no
  // base CSS grade): compositeFrame passes the tracking snapshot + params, and the
  // renderer blits its transparent output into the bake buffer. No zoom/crop.
  { id: "neonpatriot", label: "Neon Patriot", swatch: "linear-gradient(135deg,#ff4d4d,#f8fafc,#3b6fff)",
    css: "",
    canvas(ctx, w, h, frame, p, arg) {
      if (arg?.kind !== "neonpatriot" || !arg.tracking) return;
      renderNeonPatriot(ctx, w, h, arg.tracking, arg.vw, arg.vh, arg.mirror, arg.patriot);
    },
  },

  // ── Carnival Vibes — face-tracked glam: beautified face + headdress + jewels ───
  // The heavy lifting lives in ./carnival.ts. Overlay-only (no base CSS grade): the
  // renderer FIRST bakes a whole-face beautification pass (it reuses the Beauty X
  // WebGL pass via the shared buildBeautyXUniforms, blitted into the frame BEFORE any
  // decoration), then a dark/bronze wash, then landmark-anchored decorations (rainbow
  // feathers / ornate jewelled tiara / dense face gems / makeup / glitter / sparkle)
  // straight into the bake buffer so the whole look survives photo + video capture.
  // Carnival also runs its OWN compositor-rate landmark smoothing (shared tracker
  // untouched) for steadier jewels. Auto-activates on face detect.
  { id: "carnival", label: "Carnival", swatch: "linear-gradient(135deg,#19e0d0,#ff36c4,#f6c945)",
    css: "saturate(1.1) contrast(1.03) brightness(1.02)",
    canvas(ctx, w, h, frame, p, arg) {
      if (arg?.kind !== "carnival" || !arg.tracking) return;
      renderCarnival(ctx, w, h, frame, p, arg.tracking, arg.vw, arg.vh, arg.mirror, arg.carnival);
    },
  },

  // ── Neon Mood Caricature — mood-driven neon line-art over up to TWO faces ──────
  // The heavy lifting lives in ./neonMood. Overlay-only here (no base CSS grade):
  // compositeFrame passes a snapshot from the DEDICATED NeonMoodTracker (2 faces +
  // blendshapes → per-face mood) and the renderer blits its transparent neon output
  // into the bake buffer (survives photo+video capture). The OPTIONAL auto-black
  // "neon studio" background (Glow = High) is NOT an overlay — it replaces the base
  // pixels and is handled in compositeFrame's base-draw section, not here.
  { id: "neonmood", label: "Neon Mood", swatch: "linear-gradient(135deg,#39ff14,#ff4fd8,#27a8ff)",
    css: "",
    canvas(ctx, w, h, frame, p, arg) {
      if (arg?.kind !== "neonmood") return;
      renderNeonMood(ctx, w, h, arg.tracking, arg.vw, arg.vh, arg.mirror, arg.mood);
    },
  },

  // ── Caricature — instant funhouse "big head / small body" whole-figure warp ─────
  // The heavy lifting lives in ./caricature.ts. This is a BASE-SWAP, not an overlay:
  // compositeFrame calls renderCaricatureBase INSTEAD of drawVideoCover (so the warp
  // bakes + the CSS grade still applies), so this entry has NO canvas() — needsCanvas
  // is forced on separately. The swatch/label drive the picker only.
  { id: "caricature", label: "Caricature", swatch: "linear-gradient(135deg,#ff9f1c,#ff4d6d,#7b2ff7)", css: "" },

  // ── Mascot — live full-body AR puppet costume (green/purple) ────────────────────
  // The heavy lifting lives in ./mascot.ts. Overlay-only (drawn after the base into
  // the bake buffer so it survives capture): compositeFrame passes the person mask +
  // scratch ctx + face tracking and the renderer recolours the silhouette + drops
  // googly eyes/mouth on the face.
  { id: "mascot", label: "Mascot", swatch: "linear-gradient(135deg,#3aa80f,#7b2ff7,#9d4edd)",
    css: "",
    canvas(ctx, w, h, frame, p, arg) {
      if (arg?.kind !== "mascot") return;
      renderMascot(ctx, w, h, frame, arg.mask, arg.scratchCtx, arg.tracking, arg.vw, arg.vh, arg.mirror, arg.intensity);
    },
  },

  // ── Beauty X ("zeroG Beauty") — face-aware beautify + cosmic/underwater FX ──────
  // The heavy lifting lives in ./beautyX.ts (+ ./beautyXGL.ts WebGL2 processor). This
  // entry is overlay-only (no base CSS grade): compositeFrame passes the tracking
  // snapshot + params; the renderer reads the already-drawn bake frame as a texture,
  // beautifies it in a separate WebGL canvas, blits it back, then layers the cosmic
  // atmosphere — so the whole effect BAKES into photo/video. No zoom/crop.
  { id: "beautyx", label: "Beauty X", swatch: "linear-gradient(135deg,#7be8ff,#6f7bff,#b96bff)",
    css: "",
    canvas(ctx, w, h, frame, p, arg) {
      if (arg?.kind !== "beautyx") return;
      renderBeautyX(ctx, w, h, frame, p, arg.tracking, arg.vw, arg.vh, arg.mirror, arg.beauty);
    },
  },

  // ── Solargraph — long-exposure solargraphy grade + arc streaks + halation + grain ─
  // The heavy lifting lives in ./solargraph.ts (+ ./solargraphGL.ts WebGL2 processor).
  // Overlay-only (no base CSS grade): the renderer reads the already-drawn bake frame
  // as a texture, applies a luma gradient-map through the amber/prussian palette plus
  // halation in a separate WebGL canvas, blits it back, then layers arc streaks + film
  // grain — so the whole look BAKES into photo/video. No face tracking, no zoom/crop.
  { id: "solargraph", label: "Solargraph", swatch: "linear-gradient(180deg,#1A2E4A,#8B3A00 55%,#C06400 80%,#F5DFAA)",
    css: "",
    canvas(ctx, w, h, frame, p, arg) {
      if (arg?.kind !== "solargraph") return;
      renderSolargraph(ctx, w, h, frame, p, arg.solar);
    },
  },

  // ── AI Creative Director — a config-driven generated look ──────────────────
  // The grade is injected separately into the activeCss/gradeCssRef path (so it
  // bakes via ctx.filter, like every CSS grade); this entry draws only the
  // generated overlay layers. The active config + intensity arrive via the
  // discriminated FilterCanvasArg, set from aiConfigRef in compositeFrame.
  { id: "aiconfig", label: "AI Look", swatch: "linear-gradient(135deg,#7c3aed,#ec4899,#f59e0b)",
    css: "",
    canvas(ctx, w, h, frame, _p, arg) {
      if (arg?.kind !== "aiconfig") return;
      renderAiConfigFilter(ctx, w, h, frame, arg.config, arg.intensity);
    },
  },

  // ── Golden Hour — warm sun-soaked grade ───────────────────────────────────
  { id: "golden", label: "Golden Hour", swatch: "linear-gradient(135deg,#f6b94a,#ff8a5b,#ff4fd8)",
    css: "sepia(0.45) saturate(1.8) brightness(1.1) contrast(1.05)" },

  // ── Cinematic — cool teal-shadow contrast ─────────────────────────────────
  { id: "cinematic", label: "Cinematic", swatch: "linear-gradient(135deg,#0b1220,#22c7f2,#b44cff)",
    css: "contrast(1.25) brightness(0.9) saturate(1.1)" },

  // ── Noir — high-contrast monochrome ───────────────────────────────────────
  { id: "noir", label: "Noir", swatch: "linear-gradient(135deg,#1b1b1b,#4b4b4b,#0a0a0a)",
    css: "grayscale(1) contrast(1.5) brightness(0.85)" },

  // ── Vintage — faded warm film wash ────────────────────────────────────────
  { id: "vintage", label: "Vintage", swatch: "linear-gradient(135deg,#c9a36a,#9c6b3f,#5d3b22)",
    css: "sepia(0.4) contrast(1.1) saturate(1.3) brightness(1.02) hue-rotate(-10deg)" },

  // ── Electric — punchy saturated neon ──────────────────────────────────────
  { id: "electric", label: "Electric", swatch: "linear-gradient(135deg,#22c7f2,#4f46e5,#b44cff)",
    css: "saturate(1.9) contrast(1.2) brightness(1.05) hue-rotate(8deg)" },

  // ── Film — soft desaturated stock ─────────────────────────────────────────
  { id: "film", label: "Film", swatch: "linear-gradient(135deg,#d8cbb0,#8a7f66,#3b362b)",
    css: "contrast(1.1) brightness(1.03) saturate(0.92) sepia(0.12)" },

  // ── Black & White — clean grayscale ───────────────────────────────────────
  { id: "bw", label: "Black & White", swatch: "linear-gradient(135deg,#fafafa,#9a9a9a,#1a1a1a)",
    css: "grayscale(1) contrast(1.12) brightness(1.02)" },
];

// ── Right tool rail ───────────────────────────────────────────────────────────
type ToolId = "effects" | "filters" | "beauty" | "draw" | "backgrounds" | "convo" | "market" | "aidirector" | "voice";
const TOOLS: { id: ToolId; icon: React.ElementType; label: string }[] = [
  { id: "effects", icon: Layers,       label: "Effects" },
  { id: "filters", icon: Sparkles,     label: "Filters" },
  { id: "beauty",  icon: Heart,        label: "Beauty"  },
  { id: "draw",    icon: Brush,        label: "Draw"    },
  { id: "backgrounds", icon: Images,   label: "Backgrounds" },
  { id: "convo",   icon: ShieldCheck,  label: "Convo"   },
  { id: "market",  icon: ShoppingBag,  label: "Market"  },
];

// ── Motion Ink (time- & space-anchored drawing + glow text) ────────────────────
// The brush palette, lifetimes, and the rendering engine live in ./ink.ts — the
// studio only owns the capture/compositing wiring below.
const INK_LIFETIMES: { id: string; label: string; sub: string; life: number }[] = [
  { id: "flash",   label: "Flash",   sub: "1.2s", life: 1.2 },
  { id: "hold",    label: "Hold",    sub: "4s",   life: 4 },
  { id: "persist", label: "Persist", sub: "\u221e", life: Infinity },
];

// A translucent amber + jade marble grade — the premium "Century Egg" look.
const CENTURY_EGG_CSS = "sepia(0.32) saturate(1.65) hue-rotate(18deg) contrast(1.06) brightness(1.05)";

// Scale a CSS filter string toward/away from neutral by an intensity `t` (0..1).
// brightness/contrast/saturate/opacity are neutral at 1; sepia/grayscale/invert/
// blur/hue-rotate are neutral at 0. Each function's value is lerped from neutral
// to its full value by `t`, preserving units (deg/px). Drives the Filters
// intensity slider so the active grade scales in both preview and baked capture.
function scaleFilterCss(css: string, t: number): string {
  if (!css) return css;
  const k = Math.max(0, Math.min(1, t));
  return css.replace(/([a-z-]+)\(([^)]+)\)/gi, (_m, fn: string, raw: string) => {
    const num = parseFloat(raw);
    if (Number.isNaN(num)) return `${fn}(${raw})`;
    const unit = raw.trim().replace(/^[-0-9.]+/, "");
    const neutral = /^(brightness|contrast|saturate|opacity)$/i.test(fn) ? 1 : 0;
    const scaled = neutral + (num - neutral) * k;
    const rounded = Math.round(scaled * 1000) / 1000;
    return `${fn}(${rounded}${unit})`;
  });
}

// Map a viewport pointer position to 1280×720 canvas space (object-fit:cover math)
function viewportToCanvas(clientX: number, clientY: number, rect: DOMRect) {
  const cw = 1280, ch = 720;
  const scale = Math.max(rect.width / cw, rect.height / ch);
  const dispW = cw * scale, dispH = ch * scale;
  const offX = (rect.width - dispW) / 2;
  const offY = (rect.height - dispH) / 2;
  return {
    x: (clientX - rect.left - offX) / scale,
    y: (clientY - rect.top - offY) / scale,
  };
}

type StudioMode = "photo" | "video" | "story" | "slides";

// Per-photo hold time for slideshows, and how many photos one slideshow allows
// (kept well under the 5-min cap: 30 × 3s = 90s).
const SLIDE_SEC = 3;
// 75 × SLIDE_SEC(3s) = 225s = MAX_VIDEO_SEC, so a slideshow can run as long as a
// video (R5). Kept in lockstep with the server's mediaItems .max(75) cap.
const MAX_SLIDES = 75;

// One-time upload-ownership acknowledgment (R4) — remembered per device. The ack
// now happens inline in the Add-media sheet (the Browse tap), same key as before.
const UPLOAD_ACK_KEY = "r2c_studio_upload_ack";
// Progressive tool disclosure — remembered per device.
const RAIL_EXPANDED_KEY = "r2c_studio_rail_full";

// ── Canvas helpers ─────────────────────────────────────────────────────────────
// Draw video with object-fit:cover math (no stretching regardless of aspect ratio)
function drawVideoCover(
  ctx: CanvasRenderingContext2D, video: HTMLVideoElement,
  cw: number, ch: number, mirror: boolean,
) {
  const vw = video.videoWidth || cw;
  const vh = video.videoHeight || ch;
  const scale = Math.max(cw / vw, ch / vh);
  const sw = vw * scale, sh = vh * scale;
  const ox = (cw - sw) / 2, oy = (ch - sh) / 2;
  ctx.save();
  ctx.beginPath(); ctx.rect(0, 0, cw, ch); ctx.clip();
  if (mirror) { ctx.translate(cw, 0); ctx.scale(-1, 1); }
  ctx.drawImage(video, ox, oy, sw, sh);
  ctx.restore();
}

// Neon Mood "neon studio" base — person-on-black. Draw the framed video into the
// offscreen personCtx, keep only the segmented subject (mask alpha via destination-in),
// then place that over pure black on the bake canvas. Video + mask use IDENTICAL cover
// params so they stay aligned. Mirrors NeonMoodPreview's drawStudio so the integrated
// look matches the reference 1:1. Caller guarantees a ready mask + a face is present;
// otherwise it falls back to the normal base draw (real background).
function drawNeonMoodStudioBase(
  ctx: CanvasRenderingContext2D, personCtx: CanvasRenderingContext2D,
  video: HTMLVideoElement, mask: HTMLCanvasElement,
  cw: number, ch: number, mirror: boolean,
) {
  const vw = video.videoWidth || cw;
  const vh = video.videoHeight || ch;
  const scale = Math.max(cw / vw, ch / vh);
  const sw = vw * scale, sh = vh * scale;
  const ox = (cw - sw) / 2, oy = (ch - sh) / 2;
  personCtx.clearRect(0, 0, cw, ch);
  personCtx.save();
  personCtx.beginPath(); personCtx.rect(0, 0, cw, ch); personCtx.clip();
  if (mirror) { personCtx.translate(cw, 0); personCtx.scale(-1, 1); }
  personCtx.drawImage(video, ox, oy, sw, sh);
  personCtx.globalCompositeOperation = "destination-in";
  personCtx.imageSmoothingEnabled = true;
  personCtx.drawImage(mask, ox, oy, sw, sh);
  personCtx.restore();
  personCtx.globalCompositeOperation = "source-over";
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, cw, ch);
  ctx.drawImage(personCtx.canvas, 0, 0);
}

// Persistent off-screen canvas for green-screen (no re-allocation per frame)
let _gsCanvas: HTMLCanvasElement | null = null;
let _gsCtx: CanvasRenderingContext2D | null = null;
function getGsCtx(w: number, h: number): CanvasRenderingContext2D {
  if (!_gsCanvas || _gsCanvas.width !== w || _gsCanvas.height !== h) {
    _gsCanvas = document.createElement("canvas");
    _gsCanvas.width = w; _gsCanvas.height = h;
    _gsCtx = _gsCanvas.getContext("2d", { willReadFrequently: true });
  }
  return _gsCtx!;
}

// ── Green-screen compositor ────────────────────────────────────────────────────
function applyGreenScreen(
  ctx: CanvasRenderingContext2D, video: HTMLVideoElement,
  w: number, h: number, threshold: number, mirror: boolean,
) {
  const offCtx = getGsCtx(w, h);
  offCtx.clearRect(0, 0, w, h);
  drawVideoCover(offCtx, video, w, h, mirror);
  const imgData = offCtx.getImageData(0, 0, w, h);
  const d = imgData.data;
  for (let i = 0; i < d.length; i += 4) {
    if (d[i+1] > threshold && d[i+1] > d[i] * 1.3 && d[i+1] > d[i+2] * 1.3) d[i+3] = 0;
  }
  offCtx.putImageData(imgData, 0, 0);
  ctx.drawImage(_gsCanvas!, 0, 0);
}

// ── Subject tracker (motion-centroid) ──────────────────────────────────────────
// Tiny, dependency-free, on-device tracker for the Motion Ink "Subject" anchor — no
// ML model, no network, works on iOS Safari. Tuning lives here.
const TRK_W = 80, TRK_H = 45;   // low-res sample grid (cheap getImageData)
const TRK_HZ = 14;              // max detections/sec (protects recording perf)
const TRK_MARGIN = 3;           // ignore frame-edge cells (border noise / background)
const TRK_DIFF = 18;            // per-pixel luma delta that counts as motion (0..255)
const TRK_MIN_CELLS = 6;        // need at least this much motion to trust a centroid
const TRK_MAX_FRAC = 0.6;       // >60% of cells moving ⇒ camera shake/pan ⇒ reject
const TRK_SMOOTH = 0.28;        // EMA toward the new centroid (lower = smoother)

let _trkCanvas: HTMLCanvasElement | null = null;
let _trkCtx: CanvasRenderingContext2D | null = null;
function getTrackCtx(w: number, h: number): CanvasRenderingContext2D {
  if (!_trkCanvas || _trkCanvas.width !== w || _trkCanvas.height !== h) {
    _trkCanvas = document.createElement("canvas");
    _trkCanvas.width = w; _trkCanvas.height = h;
    _trkCtx = _trkCanvas.getContext("2d", { willReadFrequently: true });
  }
  return _trkCtx!;
}

// ── Props ─────────────────────────────────────────────────────────────────────
interface Props { onClose: () => void; challengeId?: number; preselectMusicTrackId?: number; duetOfPostId?: number; }

export function CameraStudio({ onClose, challengeId, preselectMusicTrackId, duetOfPostId }: Props) {
  // Camera
  const [started, setStarted] = React.useState(false);
  const [recording, setRecording] = React.useState(false);
  const [countdown, setCountdown] = React.useState<number | null>(null);
  const [duration, setDuration] = React.useState(0);
  const [permissionError, setPermissionError] = React.useState<string | null>(null);
  const [mirror, setMirror] = React.useState(true);
  const [facingMode, setFacingMode] = React.useState<"user" | "environment">("user");
  // Source: live camera (default) vs a blank drawing canvas (no getUserMedia).
  const [source, setSource] = React.useState<"camera" | "canvas">("camera");
  const [canvasBg, setCanvasBg] = React.useState<CanvasBgId>(CANVAS_BACKGROUNDS[0].id);
  const [flash, setFlash] = React.useState(false);
  const [flashActive, setFlashActive] = React.useState(false);
  // One recording = one segment. Multiple segments splice together, and each can
  // be trimmed; publish() re-renders them into a single video (see videoExport.ts).
  const [segments, setSegments] = React.useState<VideoSegment[]>([]);
  const segmentsRef = React.useRef<VideoSegment[]>([]);
  React.useEffect(() => { segmentsRef.current = segments; }, [segments]);
  const [photoUrl, setPhotoUrl] = React.useState<string | null>(null);
  // Set while the trim/splice export renders the final video before upload.
  const [exporting, setExporting] = React.useState(false);
  const [exportProgress, setExportProgress] = React.useState(0);

  // UI
  const [studioMode, setStudioMode] = React.useState<StudioMode>("video");
  // Chosen clip length (seconds) picked before recording; null = no limit.
  // Recording auto-stops once `duration` reaches this.
  const [maxDuration, setMaxDuration] = React.useState<number | null>(null);
  const [activeTool, setActiveTool] = React.useState<ToolId | null>(null);
  // Default look: Original / no filter (single-select via the desktop filter row;
  // the array still supports the legacy stack flyout). Picking a filter applies a
  // CSS grade live on the <video> element — no preview crop/zoom change.
  const [filterStack, setFilterStack] = React.useState<FilterId[]>([]);
  // Active filter strength (0..100); scales the grade CSS (see stackCss). Neon Rain
  // also reads this as its "Intensity" so the knob scales its whole canvas effect.
  const [filterIntensity, setFilterIntensity] = React.useState(100);
  // Neon Rain's dedicated controls (rain amount / glow / lens droplets). Intensity
  // is sourced from filterIntensity above; this state holds the rest.
  const [neonRainParams, setNeonRainParams] = React.useState<NeonRainParams>(DEFAULT_NEON_RAIN_PARAMS);
  const [neonPatriotParams, setNeonPatriotParams] = React.useState<NeonPatriotParams>(DEFAULT_NEON_PATRIOT_PARAMS);
  const [carnivalParams, setCarnivalParams] = React.useState<CarnivalParams>(DEFAULT_CARNIVAL_PARAMS);
  // Neon Mood Caricature dedicated controls (Mood Lock / Glow / Line Thickness /
  // Caricature). Intensity is sourced from filterIntensity above (the shared Filters
  // knob scales the whole effect); this state holds the rest.
  const [neonMoodParams, setNeonMoodParams] = React.useState<NeonMoodParams>(DEFAULT_NEON_MOOD_PARAMS);
  // Beauty X ("zeroG Beauty") dedicated controls. Intensity is sourced from
  // filterIntensity above (the shared Filters knob scales the whole effect); this
  // state holds the rest (per-feature sliders, preset level, atmosphere toggles).
  const [beautyXParams, setBeautyXParams] = React.useState<BeautyXParams>(DEFAULT_BEAUTY_X_PARAMS);
  // Solargraph params (intensity merged from the shared Filters slider). No face
  // tracking — a global grade + sky overlays, all baked into photo/video.
  const [solargraphParams, setSolargraphParams] = React.useState<SolargraphParams>(DEFAULT_SOLARGRAPH_PARAMS);
  // The active AI Creative Director look (null until a generated package is
  // applied). Its grade flows through activeCss/gradeCssRef (so it bakes) and its
  // overlays draw via the "aiconfig" FILTERS entry. Intensity uses filterIntensity.
  const [aiFilterConfig, setAiFilterConfig] = React.useState<AiFilterConfig | null>(null);
  // Desktop editor "creative mode" tab → mapped onto studioMode/source so every
  // existing capture handler keeps working unchanged.
  const [creativeMode, setCreativeMode] = React.useState<"photo" | "video" | "slideshow" | "canvas" | "fancynotes">("video");
  // Presentational editor chrome (mockup parity; no effect on capture).
  const [previewMode, setPreviewMode] = React.useState(false);
  // Frameless "Expand" preview — hides the secondary editor chrome (mode tabs,
  // tool strip, filter row, timeline) so the stage fills the screen. The capture
  // orb / action bar stays reachable so capture + publish still work while expanded.
  const [expanded, setExpanded] = React.useState(false);
  // "Add media" sheet — the single modern entry for importing device photos/videos.
  const [mediaSheetOpen, setMediaSheetOpen] = React.useState(false);
  // One-time ownership acknowledgment (R4) — read once, flipped by the sheet's Browse tap.
  const [uploadAcked, setUploadAcked] = React.useState(() => {
    try { return localStorage.getItem(UPLOAD_ACK_KEY) === "1"; } catch { return false; }
  });
  // Simple rail by default; "More tools" expands the fuller creative suite.
  const [railExpanded, setRailExpanded] = React.useState(() => {
    try { return localStorage.getItem(RAIL_EXPANDED_KEY) === "1"; } catch { return false; }
  });
  const [gridOn, setGridOn] = React.useState(false);
  const [publishing, setPublishing] = React.useState(false);
  const [postTitle, setPostTitle] = React.useState("");
  const [postBody, setPostBody] = React.useState("");
  const [communityId, setCommunityId] = React.useState("none");
  // Creator-chosen audience: who can see the post. Merged with the community
  // choice into ONE "Post to" select — picking a community forces 'general'
  // (community access rules govern those), picking an audience clears the
  // community. Enforced server-side; this is just the picker state.
  const [audience, setAudience] = React.useState<"general" | "chasers" | "private">("general");
  const postTo = communityId !== "none" ? communityId : audience;
  const handlePostToChange = React.useCallback((v: string) => {
    if (v === "general" || v === "chasers" || v === "private") {
      setAudience(v);
      setCommunityId("none");
    } else {
      setCommunityId(v);
      setAudience("general");
    }
  }, []);
  // Required content disclosure — creator-declared, never inferred. Blocks publish.
  const [disclosedKind, setDisclosedKind] = React.useState<DisclosureKind | null>(null);
  const [paidPromotion, setPaidPromotion] = React.useState(false);

  // AI Filter Challenge (#109). aiExperienceId is the numeric AI Creative Director
  // experience id (= CreativeJob.id) the applied look came from — the seed the
  // server needs to START a challenge. joinChallengeId is set when this studio was
  // opened to REUSE an existing challenge; the two are mutually exclusive.
  const [aiExperienceId, setAiExperienceId] = React.useState<number | null>(null);
  const [startChallengeOn, setStartChallengeOn] = React.useState(false);
  const [challengePrompt, setChallengePrompt] = React.useState("");
  const [joinChallengeId, setJoinChallengeId] = React.useState<number | null>(null);
  const [reuseCreator, setReuseCreator] = React.useState<string | null>(null);
  // Set after publishing a STARTED challenge → opens the share-to-unlock sheet.
  const [shareSheet, setShareSheet] = React.useState<{ challengeId: number; postId: number } | null>(null);
  const startedChallengeRef = React.useRef(false);
  const reuseAppliedRef = React.useRef(false);

  // Drafts — saved locally (IndexedDB). currentDraftIdRef tracks a saved/resumed
  // draft so re-saving updates it in place and a successful publish auto-clears it.
  const [draftsOpen, setDraftsOpen] = React.useState(false);
  const [draftCount, setDraftCount] = React.useState(0);
  const [savingDraft, setSavingDraft] = React.useState(false);
  const currentDraftIdRef = React.useRef<string | null>(null);

  // Soundtrack (baked into the exported video on publish; see videoExport.ts).
  const [musicTrackId, setMusicTrackId] = React.useState<number | null>(null);
  const [musicFitMode, setMusicFitMode] = React.useState<MusicFitMode>("loop");
  const [musicSheetOpen, setMusicSheetOpen] = React.useState(false);
  // Music selection mode drives auto-matching (R3):
  //  • "none"   — nothing chosen yet; the auto-match effect may fill it in.
  //  • "auto"   — currently showing the song matched to the active look; re-matches
  //               automatically when the filter/effect (suggestion) changes.
  //  • "manual" — the user picked, generated, cleared, or reused a track; locked.
  const [musicSelMode, setMusicSelMode] = React.useState<"none" | "auto" | "manual">("none");
  // Replace the filmed clip's own audio with only the chosen soundtrack (mutes the
  // preview and drops the clip audio from the export mix). See videoExport muteClipAudio.
  // Defaults ON so a recorded clip's original sound (which may contain music the
  // creator has no rights to) is automatically replaced by an auto-matched platform
  // track. Creators who own their audio (e.g. their own voice) can switch it back off.
  const [muteVideoAudio, setMuteVideoAudio] = React.useState(true);
  // Independent levels for the final export mix so the creator can balance their
  // own content/video audio against the platform soundtrack. 1 = full, 0 = silent.
  const [contentVolume, setContentVolume] = React.useState(1);
  const [musicVolume, setMusicVolume] = React.useState(0.7);

  // Derivative-reuse consent (opt-in, per the app's safety-first posture). These
  // let OTHER creators reuse this post's sound / duet with its video. Default off;
  // only offered on video/slideshow (sound) and video (duet) at publish time.
  const [allowSoundReuse, setAllowSoundReuse] = React.useState(false);
  const [allowDuet, setAllowDuet] = React.useState(false);

  // Frameless immersive display — a per-post choice offered only to premium/pro
  // creators (the server re-gates by effective tier). Makes the post render
  // edge-to-edge in the fullscreen viewer instead of inside the neon frame.
  const { level: membershipLevel } = useMembership();
  const canFrameless = membershipLevel === "premium" || membershipLevel === "pro";
  const [frameless, setFrameless] = React.useState(false);

  // Live mic mute during recording. We flip the audio track's `enabled` flag
  // (rather than stopping it) so the MediaRecorder keeps a stable track but
  // captures silence. The ref mirrors the state so startCamera — which re-acquires
  // the stream — can re-apply the choice without a stale closure.
  const [isMicMuted, setIsMicMuted] = React.useState(false);
  const isMicMutedRef = React.useRef(false);

  // ── Voice / live audio (ALL tiers) ──────────────────────────────────────────
  // Everyone gets a live voice controller: a background-noise reducer (mapped to
  // the browser's built-in voice isolation) and a "voice level" boost applied
  // through a WebAudio graph so a soft speaker can be lifted over ambient noise
  // while filming. The processed track is only substituted into the recording
  // when the boost is actually in use (level !== 1) so the default capture path
  // stays byte-for-byte unchanged (no regression on the common case / iOS).
  const [noiseReduction, setNoiseReduction] = React.useState(true);
  const noiseReductionRef = React.useRef(true);
  const [voiceBoost, setVoiceBoost] = React.useState(1); // 1 = off … 2.5 = max lift
  const voiceBoostRef = React.useRef(1);
  const [micLevel, setMicLevel] = React.useState(0); // 0..1 live meter reading
  // AI voice cleanup (optional post-record pass). We keep the decoded, cleaned
  // AudioBuffer per segment id in a ref (buffers are large and don't need to drive
  // renders) and mirror just the set of cleaned ids in state for the UI. When
  // enabled at publish time these buffers replace each clip's own audio in export.
  const voiceCleanRef = React.useRef<Map<string, AudioBuffer>>(new Map());
  const [voiceCleanIds, setVoiceCleanIds] = React.useState<Set<string>>(new Set());
  const [voiceCleanBusy, setVoiceCleanBusy] = React.useState(false);
  const [voiceCleanEnabled, setVoiceCleanEnabled] = React.useState(false);
  const [voiceCleanError, setVoiceCleanError] = React.useState<string | null>(null);
  const audioCtxRef = React.useRef<AudioContext | null>(null);
  const micSourceRef = React.useRef<MediaStreamAudioSourceNode | null>(null);
  const micGainRef = React.useRef<GainNode | null>(null);
  const micCompRef = React.useRef<DynamicsCompressorNode | null>(null);
  const micDestRef = React.useRef<MediaStreamAudioDestinationNode | null>(null);
  const micAnalyserRef = React.useRef<AnalyserNode | null>(null);
  const micMeterRafRef = React.useRef<number>(0);

  // Drop cleaned-voice buffers for segments that no longer exist (deleted or
  // re-recorded → new id), so stale audio can never be mixed into a later export.
  React.useEffect(() => {
    const live = new Set(segments.map((s) => s.id));
    let changed = false;
    for (const id of Array.from(voiceCleanRef.current.keys())) {
      if (!live.has(id)) {
        voiceCleanRef.current.delete(id);
        changed = true;
      }
    }
    if (changed) {
      setVoiceCleanIds(new Set(voiceCleanRef.current.keys()));
    }
  }, [segments]);

  // Whether every current clip already has a cleaned-voice buffer ready.
  const voiceAllCleaned =
    segments.length > 0 && segments.every((s) => voiceCleanIds.has(s.id));

  // Run the AI voice-cleanup pass over each clip that doesn't already have one,
  // sequentially (the server route is rate-limited and each clip is a separate
  // upload). Results are cached per segment id so re-running is cheap.
  const runVoiceCleanup = React.useCallback(async () => {
    if (voiceCleanBusy) return;
    if (segments.length === 0) {
      setVoiceCleanError("Record a clip first, then clean up the voice.");
      return;
    }
    setVoiceCleanBusy(true);
    setVoiceCleanError(null);
    try {
      for (const seg of segments) {
        if (voiceCleanRef.current.has(seg.id)) continue;
        const buffer = await cleanClipVoice(seg.blob);
        voiceCleanRef.current.set(seg.id, buffer);
        setVoiceCleanIds(new Set(voiceCleanRef.current.keys()));
      }
      setVoiceCleanEnabled(true);
      toast.success("Voice cleaned up — background noise removed.");
    } catch (e) {
      const msg =
        e instanceof VoiceCleanupError
          ? e.message
          : "Couldn't clean up the voice. Please try again.";
      setVoiceCleanError(msg);
    } finally {
      setVoiceCleanBusy(false);
    }
  }, [segments, voiceCleanBusy]);

  // Photo slideshow: captured stills (data URLs) rendered to a video on publish.
  const [slides, setSlides] = React.useState<string[]>([]);

  // Effects / Backgrounds
  const [activeExperienceId, setActiveExperienceId] = React.useState<string | null>(null);
  const [aiBg, setAIBg] = React.useState<AIBackground | null>(null);
  const [gsThreshold, setGsThreshold] = React.useState(70);
  const [marketFilterCss, setMarketFilterCss] = React.useState<string | null>(null);
  const [marketFilterLabel, setMarketFilterLabel] = React.useState<string | null>(null);
  const experienceStateRef = React.useRef<ExperienceState>(makeExperienceState());
  const filterParticlesRef = React.useRef<Record<string, CvParticle[]>>({});

  // Motion Ink — brush + glow-text engine (see ./ink.ts)
  const [inkBrush, setInkBrush] = React.useState<BrushId>("neon");
  const [inkSize, setInkSize] = React.useState(7);
  const [inkFont, setInkFont] = React.useState(64);
  const [inkGlow, setInkGlow] = React.useState(18);
  const [inkLife, setInkLife] = React.useState<number>(Infinity); // Persist by default
  const [inkDrawOn, setInkDrawOn] = React.useState(false);
  const [inkAnchor, setInkAnchor] = React.useState<AnchorMode>("frame");
  const [inkSubTool, setInkSubTool] = React.useState<"brush" | "text">("brush");
  const [inkTextValue, setInkTextValue] = React.useState("");
  const [inkCount, setInkCount] = React.useState(0);
  const [drawMinimized, setDrawMinimized] = React.useState(false);
  const inkRef = React.useRef<InkElement[]>([]);
  const currentStrokeRef = React.useRef<InkStroke | null>(null);
  const drawingRef = React.useRef(false);
  // Monotonic studio clock (seconds) so ink replays at the time it was drawn.
  const studioClockRef = React.useRef(0);

  // Refs
  const videoRef = React.useRef<HTMLVideoElement>(null);
  const canvasRef = React.useRef<HTMLCanvasElement>(null);
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const fancyRef = React.useRef<FancyInkComposerHandle>(null);
  const streamRef = React.useRef<MediaStream | null>(null);
  const recorderRef = React.useRef<MediaRecorder | null>(null);
  const chunksRef = React.useRef<Blob[]>([]);
  const rafRef = React.useRef<number>(0);
  const durTimerRef = React.useRef<ReturnType<typeof setInterval> | null>(null);
  // Wall-clock start of the current recording — a reliable fallback duration when
  // probeBlob can't read the blob (iOS Safari) so we never discard the clip.
  const recStartRef = React.useRef<number>(0);
  const frameRef = React.useRef(0);
  // Stable refs for canvas loop
  const mirrorRef = React.useRef(true);
  const facingModeRef = React.useRef<"user" | "environment">("user");
  const sourceRef = React.useRef<"camera" | "canvas">("camera");
  const canvasBgRef = React.useRef<string>(CANVAS_BACKGROUNDS[0].id);
  const gsRef = React.useRef(70);
  const aiBgRef = React.useRef<AIBackground | null>(null);
  const expIdRef = React.useRef<string | null>(null);
  const marketCssRef = React.useRef<string | null>(null);
  const filterStackRef = React.useRef<FilterDef[]>([]);
  // Combined CSS colour grade (market/experience/stack + beauty) baked into the
  // canvas buffer by compositeFrame so it survives capture. Kept in a ref so the
  // rAF loop reads the latest value without re-subscribing.
  const gradeCssRef = React.useRef<string>("");
  // Latest Neon Rain params for the rAF compositor (intensity merged from the shared
  // Filters slider so the knob scales the whole canvas effect at capture time too).
  const neonRainParamsRef = React.useRef<NeonRainParams>(DEFAULT_NEON_RAIN_PARAMS);
  // Neon Patriot params (intensity merged from the shared Filters slider) + the
  // async MediaPipe face tracker. Ref-held so the rAF compositor reads the latest
  // without re-subscribing, and the tracker lifecycle stays off the hot path.
  const neonPatriotParamsRef = React.useRef<NeonPatriotParams>(DEFAULT_NEON_PATRIOT_PARAMS);
  const carnivalParamsRef = React.useRef<CarnivalParams>(DEFAULT_CARNIVAL_PARAMS);
  // Neon Mood params (intensity merged from the shared Filters slider) + its OWN
  // dedicated async stack: a 2-face+blendshape tracker and an optional person-on-black
  // segmenter (Glow = High). Kept SEPARATE from the shared NeonPatriotTracker above so
  // the differing tracking shape never bleeds into the other face filters. The
  // person/personCtx canvases are the offscreen scratch buffer for the studio bg swap.
  const neonMoodParamsRef = React.useRef<NeonMoodParams>(DEFAULT_NEON_MOOD_PARAMS);
  const neonMoodTrackerRef = React.useRef<NeonMoodTracker | null>(null);
  const neonMoodSegmenterRef = React.useRef<NeonMoodSegmenter | null>(null);
  const neonMoodPersonCanvasRef = React.useRef<HTMLCanvasElement | null>(null);
  const neonMoodPersonCtxRef = React.useRef<CanvasRenderingContext2D | null>(null);
  // Mascot — its OWN person segmenter (reuses NeonMoodSegmenter's selfie model) +
  // scratch canvas for the green-creature recolour. The face anchors (googly eyes /
  // mouth) reuse the shared faceTrackerRef below (single-select keeps them exclusive).
  const mascotSegmenterRef = React.useRef<NeonMoodSegmenter | null>(null);
  const mascotPersonCanvasRef = React.useRef<HTMLCanvasElement | null>(null);
  const mascotPersonCtxRef = React.useRef<CanvasRenderingContext2D | null>(null);
  // Beauty X params (intensity merged from the shared Filters slider). Shares the
  // single face tracker below with Neon Patriot (only one filter is active at a time).
  const beautyXParamsRef = React.useRef<BeautyXParams>(DEFAULT_BEAUTY_X_PARAMS);
  const solargraphParamsRef = React.useRef<SolargraphParams>(DEFAULT_SOLARGRAPH_PARAMS);
  // The active AI Creative Director look. Held in a ref for the rAF compositor so
  // the overlay layers read the latest config without re-subscribing.
  const aiConfigRef = React.useRef<AiFilterConfig | null>(null);
  // Shared Filters slider value, ref-mirrored for the rAF compositor (the AI look
  // scales its overlays by this at capture time, like every other canvas filter).
  const filterIntensityRef = React.useRef(100);
  const faceTrackerRef = React.useRef<NeonPatriotTracker | null>(null);
  // Body-pose tracker (reusable studio pose infrastructure). Shares the face tracker's
  // lifecycle contract but drives a PoseLandmarker; started only while a pose-aware
  // consumer is active (see POSE_AWARE_FILTERS + the pose-tracker lifecycle effect).
  const poseTrackerRef = React.useRef<StudioPoseTracker | null>(null);
  // Subject tracking (Motion Ink "Subject" anchor): smoothed normalized centre of
  // motion, in the SAME mirrored/cover space the ink is drawn in. null until locked.
  const subjectRef = React.useRef<{ x: number; y: number } | null>(null);
  const trackPrevRef = React.useRef<Uint8ClampedArray | null>(null);
  const trackTimeRef = React.useRef(0);
  const inkAnchorRef = React.useRef<AnchorMode>("frame");
  const subjectHintRef = React.useRef(false);

  React.useEffect(() => { mirrorRef.current = mirror; }, [mirror]);
  React.useEffect(() => { facingModeRef.current = facingMode; }, [facingMode]);
  React.useEffect(() => { sourceRef.current = source; }, [source]);
  // Live voice controls: push the boost into the running gain node, and re-apply
  // the noise-reduction choice to the live track without re-acquiring the camera.
  React.useEffect(() => { voiceBoostRef.current = voiceBoost; if (micGainRef.current) micGainRef.current.gain.value = voiceBoost; }, [voiceBoost]);
  React.useEffect(() => {
    noiseReductionRef.current = noiseReduction;
    streamRef.current?.getAudioTracks().forEach(t => { void t.applyConstraints(micAudioConstraints()).catch(() => {}); });
  }, [noiseReduction]);
  // Release the audio graph + context when the studio unmounts.
  React.useEffect(() => () => {
    teardownMicGraph();
    try { void audioCtxRef.current?.close(); } catch { /* ignore */ }
    audioCtxRef.current = null;
  }, []);
  React.useEffect(() => { inkAnchorRef.current = inkAnchor; }, [inkAnchor]);
  // A stored subject centre is only valid for the current camera + mirror (mirror
  // flips the X axis, switching camera/source changes the scene). Drop the lock so
  // the tracker re-acquires instead of jumping to a stale point.
  React.useEffect(() => { subjectRef.current = null; trackPrevRef.current = null; }, [source, facingMode, mirror]);
  React.useEffect(() => { canvasBgRef.current = canvasBg; }, [canvasBg]);
  React.useEffect(() => { gsRef.current = gsThreshold; }, [gsThreshold]);
  React.useEffect(() => { aiBgRef.current = aiBg; }, [aiBg]);
  React.useEffect(() => { expIdRef.current = activeExperienceId; }, [activeExperienceId]);
  React.useEffect(() => { marketCssRef.current = marketFilterCss; }, [marketFilterCss]);
  React.useEffect(() => {
    neonRainParamsRef.current = { ...neonRainParams, intensity: filterIntensity };
  }, [neonRainParams, filterIntensity]);
  React.useEffect(() => {
    neonPatriotParamsRef.current = { ...neonPatriotParams, intensity: filterIntensity };
  }, [neonPatriotParams, filterIntensity]);
  React.useEffect(() => {
    beautyXParamsRef.current = { ...beautyXParams, intensity: filterIntensity };
  }, [beautyXParams, filterIntensity]);
  React.useEffect(() => {
    solargraphParamsRef.current = { ...solargraphParams, intensity: filterIntensity };
  }, [solargraphParams, filterIntensity]);
  React.useEffect(() => {
    carnivalParamsRef.current = { ...carnivalParams, intensity: filterIntensity };
  }, [carnivalParams, filterIntensity]);
  React.useEffect(() => {
    neonMoodParamsRef.current = { ...neonMoodParams, intensity: filterIntensity };
  }, [neonMoodParams, filterIntensity]);
  // Mood Lock freezes each face's detected mood — push it onto the live tracker the
  // instant it toggles (the tracker reads its own mutable .moodLock field, not params).
  React.useEffect(() => {
    if (neonMoodTrackerRef.current) neonMoodTrackerRef.current.moodLock = neonMoodParams.moodLock;
  }, [neonMoodParams.moodLock]);
  React.useEffect(() => {
    aiConfigRef.current = aiFilterConfig;
  }, [aiFilterConfig]);
  React.useEffect(() => {
    filterIntensityRef.current = filterIntensity;
  }, [filterIntensity]);
  React.useEffect(() => {
    const defs = filterStack
      .map(id => FILTERS.find(f => f.id === id))
      .filter(Boolean) as FilterDef[];
    filterStackRef.current = defs;
    // Drop particle buffers for filters no longer in the stack, but keep the
    // buffers for ones that remain so their animation stays continuous when a
    // layer is added or reordered.
    const ids = new Set(defs.map(d => d.id));
    for (const key of Object.keys(filterParticlesRef.current)) {
      if (!ids.has(key as FilterId)) delete filterParticlesRef.current[key];
    }
    // Loop lifecycle is owned solely by the [needsCanvas, started] effect — this
    // effect only keeps refs/particle buffers in sync. (Previously it computed its
    // own "stillNeedsCanvas" which excluded market/experience/beauty grades and so
    // tore down the compositor for CSS-only filters, dropping them from capture.)
  }, [filterStack]);

  // API
  const queryClient = useQueryClient();
  const { data: communities } = useGetCommunities({ query: { queryKey: ["/api/communities"] } });
  const { data: musicData, isLoading: musicLoading } = useGetMusicTracks({ query: { queryKey: ["/api/music-tracks"] } });
  // OpenAI photo-remake of the captured still (fairground caricature / mascot). The
  // result URL is shown alongside the original so the user can save/publish either.
  // Errors surface as a toast. The dedicated Daily AI Challenge lives on its own page
  // now; this is the standalone caricature/mascot remake for the live-AR filters.
  const aiRemake = useCreateAiFilterRemake();
  const [remakeUrl, setRemakeUrl] = React.useState<string | null>(null);

  // Tracks generated on-demand this session (not part of the curated GET). They
  // must be merged so the picker shows them AND so selectedTrack resolves their
  // audioUrl for baking into the export.
  const [customTracks, setCustomTracks] = React.useState<MusicTrack[]>([]);
  const curatedTracks: MusicTrack[] = musicData?.tracks ?? [];
  const curatedMoods: Record<string, MusicTrack[]> = musicData?.moods ?? {};
  const musicTracks: MusicTrack[] = React.useMemo(
    () => [...customTracks, ...curatedTracks],
    [customTracks, curatedTracks],
  );
  const musicMoods: Record<string, MusicTrack[]> = React.useMemo(
    () => (customTracks.length ? { custom: customTracks, ...curatedMoods } : curatedMoods),
    [customTracks, curatedMoods],
  );
  const selectedTrack = musicTracks.find(t => t.id === musicTrackId) ?? null;

  // AI music match — the vision API reads the captured photo's (or first
  // slide's) emotion and answers with a track-library mood; we then pick a
  // track in that mood. Photo/slide sources only (both are data URLs already);
  // clips keep the deterministic caption/look suggestion.
  const aiMoodMatch = useCreateAiFilterMoodMatch();
  const handleAiMoodMatch = React.useCallback(async () => {
    const src = photoUrl ?? slides[0] ?? null;
    if (!src || aiMoodMatch.isPending) return;
    try {
      const res = await aiMoodMatch.mutateAsync({ data: { image: src } });
      const inMood = musicTracks.filter((t) => t.mood === res.mood);
      if (inMood.length === 0) {
        toast.info(`AI read the photo as "${res.mood}", but there's no ${res.mood} track yet.`);
        return;
      }
      // Random pick within the mood so retrying offers variety.
      const pick = inMood[Math.floor(Math.random() * inMood.length)];
      setMusicTrackId(pick.id);
      setMusicSelMode("manual");
      toast.success(`AI matched your photo: ${pick.title} (${res.mood})`);
    } catch (err: any) {
      toast.error(err?.message ?? "Couldn't match a mood right now.");
    }
  }, [photoUrl, slides, aiMoodMatch, musicTracks]);

  // Add a freshly generated track to the list and select it immediately.
  const handleTrackGenerated = React.useCallback((track: MusicTrack) => {
    setCustomTracks(prev => [track, ...prev.filter(t => t.id !== track.id)]);
    setMusicTrackId(track.id);
    setMusicSelMode("manual");
  }, []);
  const { mutate: createPost, isPending } = useCreatePost({
    mutation: {
      onSuccess: (post: any) => {
        toast.success("Published! 🎬");
        // The post is live — discard the draft it came from so it can't be re-posted.
        if (currentDraftIdRef.current) {
          deleteDraft(currentDraftIdRef.current).catch(() => {});
          currentDraftIdRef.current = null;
        }
        queryClient.invalidateQueries({ queryKey: ["/api/feed"] });
        // If this post STARTED a challenge, keep the studio mounted behind the
        // share-to-unlock sheet (public reuse only unlocks after a verified share).
        const newChallengeId = post?.challengeId ?? null;
        if (startedChallengeRef.current && newChallengeId && post?.id) {
          startedChallengeRef.current = false;
          setPublishing(false);
          setShareSheet({ challengeId: newChallengeId, postId: post.id });
        } else {
          onClose();
        }
      },
      onError: (err: any) => toast.error(err?.message ?? "Failed to publish."),
    },
  });
  const { uploadFile, isUploading, scanStatus, error: scanError, resetScan } = useUpload({
    onError: (err) => toast.error(err.message || "Upload failed."),
  });

  const refreshDraftCount = React.useCallback(() => {
    countDrafts().then(setDraftCount).catch(() => {});
  }, []);
  React.useEffect(() => { refreshDraftCount(); }, [refreshDraftCount]);

  // Rip-a-sound — when opened from a post's "Use this sound", fetch that track and
  // preselect it once. The rip endpoint already re-validated the source's reuse
  // consent + visibility server-side; here we only load the resulting track.
  const ripAppliedRef = React.useRef(false);
  const preselectTrack = useGetMusicTrack(preselectMusicTrackId ?? 0, {
    query: {
      queryKey: getGetMusicTrackQueryKey(preselectMusicTrackId ?? 0),
      enabled: !!preselectMusicTrackId,
      retry: false,
    },
  });
  React.useEffect(() => {
    if (!preselectMusicTrackId || ripAppliedRef.current) return;
    if (preselectTrack.isError) {
      ripAppliedRef.current = true;
      toast.error("That sound isn't available to reuse right now.");
      return;
    }
    const t = preselectTrack.data;
    if (!t) return;
    ripAppliedRef.current = true;
    handleTrackGenerated(t as MusicTrack);
  }, [preselectMusicTrackId, preselectTrack.data, preselectTrack.isError, handleTrackGenerated]);

  // Duet mode — fetch the source post so we can show its video as a timing
  // reference while recording. Eligibility + the actual side-by-side compose are
  // re-checked/performed SERVER-SIDE by id (see /storage/video/duet-compose).
  const duetSource = useGetPost(duetOfPostId ?? 0, {
    query: {
      queryKey: getGetPostQueryKey(duetOfPostId ?? 0),
      enabled: !!duetOfPostId,
      retry: false,
    },
  });
  const duetSourceSrc = duetOfPostId ? mediaSrc((duetSource.data as any)?.videoUrl) : null;

  // Reuse mode (#109) — when opened with a challengeId, preload the creator's
  // gated filter config + music. The reuse gate is enforced SERVER-SIDE; on any
  // error we fail closed (no joinChallengeId set → the post won't join).
  const reuse = useGetCreativeChallengeReuse(challengeId ?? 0, {
    query: {
      queryKey: getGetCreativeChallengeReuseQueryKey(challengeId ?? 0),
      enabled: !!challengeId,
      retry: false,
    },
  });
  React.useEffect(() => {
    if (!challengeId || reuseAppliedRef.current) return;
    if (reuse.isError) {
      reuseAppliedRef.current = true;
      toast.error("This challenge filter isn't available to reuse right now.");
      return;
    }
    const payload = reuse.data;
    if (!payload) return;
    reuseAppliedRef.current = true;
    applyAiConfigFilter(payload.filterConfig);
    setJoinChallengeId(payload.challengeId);
    setReuseCreator(payload.creatorUsername);
    if (payload.music) {
      handleTrackGenerated({
        id: payload.music.trackId,
        slug: `challenge-${payload.challengeId}`,
        title: payload.music.title,
        mood: payload.music.mood ?? "auto",
        tags: ["challenge"],
        durationSec: payload.music.durationSec ?? null,
        audioUrl: payload.music.audioUrl,
        isCurated: false,
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [challengeId, reuse.data, reuse.isError]);

  // ── Derived ─────────────────────────────────────────────────────────────────
  const [beautyFilterId, setBeautyFilterId] = React.useState<string | null>(null);

  const BEAUTY_PRESETS: Record<string, string> = {
    smooth:  "brightness(1.04) saturate(0.8) contrast(0.88)",
    brighten:"brightness(1.18) saturate(1.06) contrast(0.95)",
    lips:    "saturate(1.5) hue-rotate(345deg) contrast(1.06) brightness(1.03)",
    eyes:    "contrast(1.22) brightness(1.06) saturate(1.12)",
    blush:   "sepia(0.22) saturate(1.65) hue-rotate(330deg) brightness(1.05)",
    glow:    "brightness(1.12) saturate(1.3) contrast(1.05)",
  };

  const activeExp = EXPERIENCES.find(e => e.id === activeExperienceId) ?? null;
  // Filters are layered: every selected filter contributes, in selection order,
  // so the CSS grades and canvas overlays stack to build depth.
  const selectedFilterDefs = filterStack
    .map(id => FILTERS.find(f => f.id === id))
    .filter(Boolean) as FilterDef[];
  const stackCss = selectedFilterDefs
    .map(d => scaleFilterCss(d.css, filterIntensity / 100))
    .filter(Boolean)
    .join(" ");
  const baseFilterCss = marketFilterCss ?? activeExp?.filterCss ?? stackCss;
  const beautyCss = beautyFilterId ? BEAUTY_PRESETS[beautyFilterId] : "";
  // The AI look's colour grade is dynamic (not a static FILTERS.css entry), so it
  // joins the bake path here, scaled by the shared Filters intensity slider. The
  // "aiconfig" FILTERS entry contributes only its overlays (css: "").
  const aiGradeCss = (filterStack[0] === "aiconfig" && aiFilterConfig)
    ? aiConfigGradeCss(aiFilterConfig, filterIntensity / 100)
    : "";
  const activeCss = [baseFilterCss, aiGradeCss, beautyCss].filter(Boolean).join(" ");
  // Keep the baked-grade ref current for the rAF compositor loop.
  React.useEffect(() => { gradeCssRef.current = activeCss; }, [activeCss]);
  const isDrawTool = activeTool === "draw";
  const isCanvasSource = source === "canvas";
  // A pure CSS grade (market/experience/stack/beauty, no canvas overlay) is shown
  // LIVE via style.filter on the <video> element, so the preview keeps the raw
  // camera framing — picking a filter never crops/zooms the subject. It only needs
  // the canvas compositor at CAPTURE time, where compositeFrame bakes it via
  // ctx.filter so it survives captureStream()/toDataURL(). On browsers without
  // Canvas2D filter support we can't bake, so we never route a grade through it.
  const canBakeCssGrade = CANVAS_FILTER_SUPPORTED && !!activeCss;
  // Live-preview compositor: only for sources/overlays that genuinely need pixel
  // compositing (blank canvas, AI bg, experiences, canvas-overlay filters like
  // Neon Rain, drawing, Motion Ink). A plain CSS grade is intentionally EXCLUDED
  // so selecting a filter never switches the preview path — that path switch was
  // the root of the "filters only zoom into the face" report.
  // Caricature is a base-swap (no FILTERS.canvas() entry), so it must force the
  // canvas pipeline on explicitly — otherwise the rAF compositor never starts.
  const caricatureActive = filterStack.includes("caricature");
  const needsCanvas = !!(isCanvasSource || aiBg || activeExperienceId || selectedFilterDefs.some(d => d.canvas) || caricatureActive || isDrawTool || inkCount > 0);
  // Capture/record compositor: same as above, but ALSO bakes a pure CSS grade so
  // the chosen look lands in the photo/recording even though the live preview ran
  // the grade on the <video> element.
  const needsCanvasForCapture = needsCanvas || canBakeCssGrade;
  // Editing/preview state: a captured photo, one+ recorded video segments, or a
  // set of slideshow stills, and not currently back in the camera capturing more.
  const hasResult = (!!photoUrl || segments.length > 0 || slides.length > 0) && !started;
  const totalVideoSec = totalTrimmedDuration(segments);
  const videoOverLimit = totalVideoSec > MAX_VIDEO_SEC + 1;

  // Music applies to EVERYTHING the studio can publish. Clips and slideshows
  // bake the track into the exported video; a still photo can't bake, so its
  // track rides the post as musicTrackId and the immersive viewer plays it
  // (same persistent-audio path text posts already use).
  const musicEligible = !!photoUrl || segments.length > 0 || slides.length > 0;
  // Deterministic suggestion from caption/title + the chosen look.
  const musicSuggestion = React.useMemo(
    () =>
      suggestMusic(musicTracks, {
        text: `${postTitle} ${postBody}`,
        filterIds: filterStack,
        experienceId: activeExperienceId,
      }),
    [musicTracks, postTitle, postBody, filterStack, activeExperienceId],
  );
  // Auto-match a soundtrack to the active look by default (R3), for video AND
  // slideshows. Runs whenever eligibility or the suggestion changes (e.g. the user
  // switches filters), so the matching song follows the look. A manual pick, clear,
  // generate, or reuse (musicSelMode === "manual") locks the choice and stops this.
  React.useEffect(() => {
    if (!musicEligible || musicSelMode === "manual" || !musicSuggestion) return;
    if (musicTrackId !== musicSuggestion.track.id) setMusicTrackId(musicSuggestion.track.id);
    setMusicSelMode("auto");
  }, [musicEligible, musicSelMode, musicSuggestion, musicTrackId]);

  // ── Camera ───────────────────────────────────────────────────────────────────
  // Apply the current mic-mute choice to the live stream's audio tracks. Toggling
  // `enabled` keeps the recorder's track stable while it captures silence.
  function applyMicEnabled(muted: boolean) {
    streamRef.current?.getAudioTracks().forEach((t) => { t.enabled = !muted; });
  }
  function toggleMic() {
    const next = !isMicMutedRef.current;
    isMicMutedRef.current = next;
    setIsMicMuted(next);
    applyMicEnabled(next);
  }

  // Audio constraints for the mic request — the noise reducer maps to the browser's
  // built-in voice isolation (noise suppression + echo cancel + auto gain).
  function micAudioConstraints(): MediaTrackConstraints {
    const on = noiseReductionRef.current;
    return { noiseSuppression: on, echoCancellation: on, autoGainControl: on };
  }

  // Drive the live level meter from an analyser tap. Quick attack / slow decay so
  // the bars feel responsive but don't flicker. Throttled to spare React.
  function startMicMeter() {
    cancelAnimationFrame(micMeterRafRef.current);
    const an = micAnalyserRef.current;
    if (!an) return;
    const buf = new Uint8Array(an.fftSize);
    let last = 0;
    const tick = () => {
      const a = micAnalyserRef.current;
      if (!a) return;
      a.getByteTimeDomainData(buf);
      let sum = 0;
      for (let i = 0; i < buf.length; i++) { const v = (buf[i] - 128) / 128; sum += v * v; }
      const rms = Math.sqrt(sum / buf.length);
      const now = performance.now();
      if (now - last > 60) { last = now; setMicLevel(prev => Math.max(rms, prev * 0.7)); }
      micMeterRafRef.current = requestAnimationFrame(tick);
    };
    micMeterRafRef.current = requestAnimationFrame(tick);
  }

  function teardownMicGraph() {
    cancelAnimationFrame(micMeterRafRef.current);
    try { micSourceRef.current?.disconnect(); } catch { /* ignore */ }
    try { micGainRef.current?.disconnect(); } catch { /* ignore */ }
    try { micCompRef.current?.disconnect(); } catch { /* ignore */ }
    try { micAnalyserRef.current?.disconnect(); } catch { /* ignore */ }
    micSourceRef.current = null;
    micGainRef.current = null;
    micCompRef.current = null;
    micAnalyserRef.current = null;
    micDestRef.current = null;
    setMicLevel(0);
  }

  // Build (or rebuild) the WebAudio graph for a freshly acquired stream:
  //   source → gain → compressor → MediaStreamDestination   (the recordable path)
  //   source → analyser                                      (the live meter tap)
  // We NEVER connect to ctx.destination — routing the mic to the speakers while
  // filming would cause howling feedback.
  function setupMicGraph(stream: MediaStream) {
    try {
      teardownMicGraph();
      const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Ctx) return;
      const ctx = audioCtxRef.current ?? new Ctx();
      audioCtxRef.current = ctx;
      if (ctx.state === "suspended") void ctx.resume();
      const source = ctx.createMediaStreamSource(stream);
      const gain = ctx.createGain();
      gain.gain.value = voiceBoostRef.current;
      // Gentle compression tames peaks when the voice is boosted so a loud syllable
      // doesn't clip; near-transparent at boost = 1.
      const comp = ctx.createDynamicsCompressor();
      comp.threshold.value = -24; comp.knee.value = 30; comp.ratio.value = 3;
      comp.attack.value = 0.003; comp.release.value = 0.25;
      const dest = ctx.createMediaStreamDestination();
      source.connect(gain); gain.connect(comp); comp.connect(dest);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 512;
      source.connect(analyser);
      micSourceRef.current = source;
      micGainRef.current = gain;
      micCompRef.current = comp;
      micDestRef.current = dest;
      micAnalyserRef.current = analyser;
      startMicMeter();
    } catch { /* metering/boost are best-effort; raw capture still works */ }
  }

  // Only feed the boosted/processed track into the recorder when the creator
  // actually raised their voice level — otherwise use the raw track (unchanged).
  function useProcessedAudio(): boolean {
    return voiceBoostRef.current !== 1 && !!micDestRef.current;
  }
  function recordingAudioTracks(): MediaStreamTrack[] {
    if (useProcessedAudio()) {
      const t = micDestRef.current!.stream.getAudioTracks();
      if (t.length) return t;
    }
    return streamRef.current?.getAudioTracks() ?? [];
  }

  async function startCamera(mode?: "user" | "environment") {
    setPermissionError(null);
    const fm = mode ?? facingModeRef.current;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: fm },
        audio: micAudioConstraints(),
      });
      streamRef.current = stream;
      // Honor an in-effect mic mute on the freshly acquired stream.
      applyMicEnabled(isMicMutedRef.current);
      // Wire the live voice graph (level meter + optional boost) for this stream.
      setupMicGraph(stream);
      if (videoRef.current) { videoRef.current.srcObject = stream; await videoRef.current.play(); }
      setStarted(true);
    } catch (err: any) {
      setPermissionError(
        err.name === "NotAllowedError"
          ? "Camera permission denied. Please allow access and try again."
          : `Camera error: ${err.message}`
      );
    }
  }

  async function switchCamera() {
    const next: "user" | "environment" = facingModeRef.current === "user" ? "environment" : "user";
    // Auto-mirror: front camera mirrors naturally, back camera shouldn't
    const nextMirror = next === "user";
    facingModeRef.current = next;
    setFacingMode(next);
    mirrorRef.current = nextMirror;
    setMirror(nextMirror);
    if (started) {
      streamRef.current?.getTracks().forEach(t => t.stop());
      streamRef.current = null;
      await startCamera(next);
    }
  }

  function stopCamera() {
    streamRef.current?.getTracks().forEach(t => t.stop());
    streamRef.current = null;
    teardownMicGraph();
    cancelAnimationFrame(rafRef.current);
    if (durTimerRef.current) clearInterval(durTimerRef.current);
  }

  // Switch between the live camera and a blank drawing canvas. Canvas mode never
  // requests camera permission, so it works even when the camera was denied.
  async function selectSource(next: "camera" | "canvas") {
    if (next === source) return;
    if (next === "canvas") {
      // Tear down any live stream and let the compositor take over.
      setPermissionError(null);
      streamRef.current?.getTracks().forEach(t => t.stop());
      streamRef.current = null;
      teardownMicGraph();
      sourceRef.current = "canvas";
      setSource("canvas");
      // The blank canvas is immediately "live" — the rAF loop (started below via
      // the needsCanvas/started effect) keeps it updating.
      setStarted(true);
    } else {
      sourceRef.current = "camera";
      setSource("camera");
      streamRef.current?.getTracks().forEach(t => t.stop());
      streamRef.current = null;
      setStarted(false);
      await startCamera();
    }
  }

  // ── Canvas loop ──────────────────────────────────────────────────────────────
  // Monotonic seconds since the studio clock first ticked — drives Motion Ink so
  // each element appears at the time it was drawn (and replays in the recording).
  function nowSec() {
    if (!studioClockRef.current) studioClockRef.current = performance.now();
    return (performance.now() - studioClockRef.current) / 1000;
  }

  // ── Subject tracker ───────────────────────────────────────────────────────────
  // Each throttled tick: downscale the live camera into a tiny buffer (SAME mirrored
  // cover space as the ink), diff it against the previous tiny frame, and take the
  // motion-weighted centroid as the subject's position. Smoothed; holds its last
  // position when the subject is still; rejects whole-frame motion (camera shake/pan).
  function updateSubjectTracker(nowMs: number) {
    const video = videoRef.current;
    if (!video || video.readyState < 2) return;
    if (nowMs - trackTimeRef.current < 1000 / TRK_HZ) return;
    trackTimeRef.current = nowMs;

    const offCtx = getTrackCtx(TRK_W, TRK_H);
    offCtx.clearRect(0, 0, TRK_W, TRK_H);
    drawVideoCover(offCtx, video, TRK_W, TRK_H, mirrorRef.current);
    const data = offCtx.getImageData(0, 0, TRK_W, TRK_H).data;

    const n = TRK_W * TRK_H;
    const cur = new Uint8ClampedArray(n);
    for (let i = 0, p = 0; i < data.length; i += 4, p++) {
      cur[p] = (data[i] * 77 + data[i + 1] * 150 + data[i + 2] * 29) >> 8;
    }
    const prev = trackPrevRef.current;
    trackPrevRef.current = cur;
    if (!prev || prev.length !== n) return;          // need a baseline frame first

    let sx = 0, sy = 0, sw = 0, moving = 0;
    for (let y = TRK_MARGIN; y < TRK_H - TRK_MARGIN; y++) {
      for (let x = TRK_MARGIN; x < TRK_W - TRK_MARGIN; x++) {
        const idx = y * TRK_W + x;
        const d = Math.abs(cur[idx] - prev[idx]);
        if (d > TRK_DIFF) { sx += x * d; sy += y * d; sw += d; moving++; }
      }
    }
    const region = (TRK_W - 2 * TRK_MARGIN) * (TRK_H - 2 * TRK_MARGIN);
    if (moving < TRK_MIN_CELLS || sw === 0) return;  // too still → hold last centre
    if (moving > region * TRK_MAX_FRAC) return;      // global motion → reject

    const cx = sx / sw / TRK_W;
    const cy = sy / sw / TRK_H;
    const prevC = subjectRef.current;
    subjectRef.current = prevC
      ? { x: prevC.x + (cx - prevC.x) * TRK_SMOOTH, y: prevC.y + (cy - prevC.y) * TRK_SMOOTH }
      : { x: cx, y: cy };
  }

  // Offset (px) that translates a subject-anchored ink element from where it was
  // drawn, following the subject's movement since its anchor was captured.
  function getSubjectOffset(anchorPt: { x: number; y: number }) {
    const c = subjectRef.current;
    if (!c) return { dx: 0, dy: 0 };
    return { dx: (c.x - anchorPt.x) * 1280, dy: (c.y - anchorPt.y) * 720 };
  }

  // Composite one full frame (video + experience + filter + Motion Ink).
  // Shared by the RAF loop and the photo shutter so captures always bake the latest state.
  function compositeFrame(ctx: CanvasRenderingContext2D, opts?: { staticInk?: boolean }) {
    const video = videoRef.current;
    const bg = aiBgRef.current;
    const exp = expIdRef.current ? EXPERIENCES.find(e => e.id === expIdRef.current) : null;
    ctx.clearRect(0, 0, 1280, 720);
    // Bake the CSS colour grade (market/experience/stack/beauty) onto the BASE
    // content layer only, via Canvas2D ctx.filter, so it survives capture (a
    // style.filter on the element is preview-only and invisible to
    // captureStream/toDataURL). Overlays + Motion Ink draw ungraded on top.
    const grade = CANVAS_FILTER_SUPPORTED && gradeCssRef.current ? gradeCssRef.current : "none";
    ctx.filter = grade;
    if (sourceRef.current === "canvas") {
      // Blank-canvas source — paint the chosen background, no camera involved.
      // Skip the camera-only experience/filter FX so the page stays clean; Motion
      // Ink still composites identically below.
      drawCanvasBackground(ctx, canvasBgRef.current, 1280, 720);
    } else {
      if (bg) {
        // Draw AI background gradient
        const grad = ctx.createLinearGradient(0, 0, 1280, 720);
        const cols = bg.gradient.match(/#[0-9a-f]{6}/gi) ?? ["#000", "#111"];
        cols.forEach((c, i) => grad.addColorStop(i / Math.max(cols.length - 1, 1), c));
        ctx.fillStyle = grad; ctx.fillRect(0, 0, 1280, 720);
        // Draw video on top with proper cover scaling (green screen if enabled)
        if (video) applyGreenScreen(ctx, video, 1280, 720, gsRef.current, mirrorRef.current);
      } else {
        // Neon Mood "neon studio" auto-black background — REPLACES the base video with
        // the segmented subject on pure black. This is a BASE-pixel swap (not an
        // overlay), so it lives here (before overlays + before ctx.filter reset) and
        // bakes into photo/video capture. Gated to exactly the preview's conditions:
        // active + enabled + intensity > 0 + Glow = High + a face present + a ready mask
        // + the offscreen scratch ctx. Any miss → the normal plain-video draw (real bg).
        const mood = neonMoodParamsRef.current;
        const moodOn = filterStackRef.current.some(f => f.id === "neonmood");
        const studioOn = moodOn && mood.enabled && mood.intensity > 0 && mood.glow === "high";
        const mask = studioOn ? (neonMoodSegmenterRef.current?.getMaskCanvas() ?? null) : null;
        const personCtx = neonMoodPersonCtxRef.current;
        const hasFace = (neonMoodTrackerRef.current?.getTracking().faces.length ?? 0) > 0;
        // Caricature is ALSO a base-swap (funhouse warp drawn instead of the plain
        // video) — it takes precedence and draws the whole figure exaggerated. It
        // draws its own plain-cover fallback internally, so no extra else is needed.
        const caricatureOn = filterStackRef.current.some(f => f.id === "caricature");
        if (caricatureOn && video) {
          renderCaricatureBase(
            ctx, video, 1280, 720, mirrorRef.current,
            faceTrackerRef.current?.getTracking() ?? null,
            video.videoWidth || 1280, video.videoHeight || 720,
            filterIntensityRef.current / 100,
          );
        } else if (video && mask && hasFace && personCtx) {
          drawNeonMoodStudioBase(ctx, personCtx, video, mask, 1280, 720, mirrorRef.current);
        } else if (video) {
          // Plain video — use cover scaling so no stretching on any aspect ratio
          drawVideoCover(ctx, video, 1280, 720, mirrorRef.current);
        }
      }
    }
    // Reset so overlays/ink are drawn at full fidelity (not double-graded).
    ctx.filter = "none";
    if (sourceRef.current !== "canvas") {
      // Experience overlay (AR worlds, Visual Styles, etc.)
      if (exp) exp.render(ctx, 1280, 720, frameRef.current, experienceStateRef.current);
      // Canvas-powered filter overlays — drawn in selection order so stacked
      // filters build visible depth. Each layer keeps its own particle buffer.
      for (const fDef of filterStackRef.current) {
        if (fDef.canvas) {
          const buf = (filterParticlesRef.current[fDef.id] ||= []);
          let arg: FilterCanvasArg | undefined;
          if (fDef.id === "neonrain") {
            arg = { kind: "neonrain", rain: neonRainParamsRef.current };
          } else if (fDef.id === "neonpatriot") {
            const v = videoRef.current;
            arg = {
              kind: "neonpatriot",
              patriot: neonPatriotParamsRef.current,
              tracking: faceTrackerRef.current?.getTracking() ?? null,
              vw: v?.videoWidth || 1280, vh: v?.videoHeight || 720,
              mirror: mirrorRef.current,
            };
          } else if (fDef.id === "beautyx") {
            const v = videoRef.current;
            arg = {
              kind: "beautyx",
              beauty: beautyXParamsRef.current,
              tracking: faceTrackerRef.current?.getTracking() ?? null,
              vw: v?.videoWidth || 1280, vh: v?.videoHeight || 720,
              mirror: mirrorRef.current,
            };
          } else if (fDef.id === "solargraph") {
            arg = { kind: "solargraph", solar: solargraphParamsRef.current };
          } else if (fDef.id === "carnival") {
            const v = videoRef.current;
            arg = {
              kind: "carnival",
              carnival: carnivalParamsRef.current,
              tracking: faceTrackerRef.current?.getTracking() ?? null,
              vw: v?.videoWidth || 1280, vh: v?.videoHeight || 720,
              mirror: mirrorRef.current,
            };
          } else if (fDef.id === "neonmood") {
            const v = videoRef.current;
            arg = {
              kind: "neonmood",
              mood: neonMoodParamsRef.current,
              tracking: neonMoodTrackerRef.current?.getTracking() ?? null,
              vw: v?.videoWidth || 1280, vh: v?.videoHeight || 720,
              mirror: mirrorRef.current,
            };
          } else if (fDef.id === "mascot") {
            const v = videoRef.current;
            arg = {
              kind: "mascot",
              mask: mascotSegmenterRef.current?.getMaskCanvas() ?? null,
              scratchCtx: mascotPersonCtxRef.current,
              tracking: faceTrackerRef.current?.getTracking() ?? null,
              vw: v?.videoWidth || 1280, vh: v?.videoHeight || 720,
              mirror: mirrorRef.current,
              intensity: filterIntensityRef.current / 100,
            };
          } else if (fDef.id === "aiconfig") {
            const cfg = aiConfigRef.current;
            if (cfg) arg = { kind: "aiconfig", config: cfg, intensity: filterIntensityRef.current / 100 };
          } else if (POSE_AWARE_FILTERS.has(fDef.id)) {
            // Same seam the face landmarks flow through: hand the pose-aware consumer
            // the latest smoothed snapshot + precomputed limb angles (both null when no
            // usable pose), via the shared readPose accessor.
            const v = videoRef.current;
            const frame = readPose(poseTrackerRef.current);
            arg = {
              kind: "pose",
              pose: frame.snapshot,
              angles: frame.angles,
              vw: v?.videoWidth || 1280, vh: v?.videoHeight || 720,
              mirror: mirrorRef.current,
            };
          }
          fDef.canvas(ctx, 1280, 720, frameRef.current, buf, arg);
        }
      }
    }
    // Motion Ink (always on top) — time/space-anchored strokes + glow text, baked
    // into the same canvas the recorder/photo capture from. Stills render every
    // element fully; live/video replays each element at the moment it was drawn.
    const elements = currentStrokeRef.current
      ? [...inkRef.current, currentStrokeRef.current]
      : inkRef.current;
    if (opts?.staticInk) {
      renderInkStatic(ctx, 1280, 720, elements);
    } else {
      // Only run the tracker when something actually anchors to the subject (Subject
      // selected, or a placed element uses it) and we're on the live camera. Frame
      // anchoring (the default) never touches the tracker.
      const wantsSubject = sourceRef.current === "camera" &&
        (inkAnchorRef.current === "subject" || elements.some(e => e.anchor === "subject"));
      if (wantsSubject) updateSubjectTracker(performance.now());
      else trackPrevRef.current = null;
      renderInk(ctx, nowSec(), 1280, 720, elements, wantsSubject ? getSubjectOffset : undefined);
    }
  }

  function startCanvasLoop() {
    cancelAnimationFrame(rafRef.current);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d", { willReadFrequently: true })!;
    canvas.width = 1280; canvas.height = 720;
    frameRef.current = 0;
    function draw() {
      frameRef.current++;
      compositeFrame(ctx);
      rafRef.current = requestAnimationFrame(draw);
    }
    draw();
  }

  React.useEffect(() => {
    if (started) {
      if (needsCanvas) startCanvasLoop();
      else cancelAnimationFrame(rafRef.current);
    }
  }, [needsCanvas, started]);

  React.useEffect(() => {
    if (started && needsCanvas) startCanvasLoop();
    experienceStateRef.current = makeExperienceState();
  }, [activeExperienceId]);

  // Face-tracker lifecycle — runs ONLY while a face-aware filter (Neon Patriot OR
  // Beauty X) is active on a live camera. The two filters share ONE MediaPipe tracker
  // (single-select means only one is active at a time). Async MediaPipe writes
  // landmarks to the tracker ref which the rAF compositor reads; this effect never
  // starts a second rAF or draws anything.
  const faceFilterActive = filterStack.includes("neonpatriot") || filterStack.includes("beautyx") || filterStack.includes("carnival") || filterStack.includes("caricature") || filterStack.includes("mascot");
  React.useEffect(() => {
    if (!faceFilterActive || !started || source !== "camera") {
      faceTrackerRef.current?.dispose();
      faceTrackerRef.current = null;
      return;
    }
    const video = videoRef.current;
    if (!video) return;
    const tracker = new NeonPatriotTracker(video);
    faceTrackerRef.current = tracker;
    void tracker.start();
    return () => { tracker.dispose(); faceTrackerRef.current = null; };
  }, [faceFilterActive, started, source]);

  // Body-pose-tracker lifecycle — mirrors the face-tracker effect but drives the shared
  // PoseLandmarker. Runs ONLY while a pose-aware consumer is active on a live camera, so
  // MediaPipe's pose model never spins up otherwise. Async detection writes the snapshot
  // the rAF compositor reads via readPose(); this effect starts no second rAF and draws
  // nothing. (No pose-aware filter ships yet, so this stays dormant until one is added.)
  const poseFilterActive = filterStack.some((id) => POSE_AWARE_FILTERS.has(id));
  React.useEffect(() => {
    if (!poseFilterActive || !started || source !== "camera") {
      poseTrackerRef.current?.dispose();
      poseTrackerRef.current = null;
      return;
    }
    const video = videoRef.current;
    if (!video) return;
    const tracker = new StudioPoseTracker(video);
    poseTrackerRef.current = tracker;
    void tracker.start();
    return () => { tracker.dispose(); poseTrackerRef.current = null; };
  }, [poseFilterActive, started, source]);

  // Neon Mood lifecycle — kept SEPARATE from the shared NeonPatriotTracker above.
  // Neon Mood needs its OWN tracker (2 faces + blendshapes → per-face mood), so it
  // never reuses faceTrackerRef. Only one face filter is active at a time, so the two
  // trackers never run together. The rAF compositor reads neonMoodTrackerRef.
  const neonMoodActive = filterStack.includes("neonmood");
  React.useEffect(() => {
    if (!neonMoodActive || !started || source !== "camera") {
      neonMoodTrackerRef.current?.dispose();
      neonMoodTrackerRef.current = null;
      return;
    }
    const video = videoRef.current;
    if (!video) return;
    const tracker = new NeonMoodTracker(video);
    tracker.moodLock = neonMoodParamsRef.current.moodLock;
    neonMoodTrackerRef.current = tracker;
    void tracker.start();
    return () => { tracker.dispose(); neonMoodTrackerRef.current = null; };
  }, [neonMoodActive, started, source]);

  // Neon Mood auto-black "neon studio" background segmenter — only spun up while the
  // filter is active AND the background swap is actually requested (enabled +
  // intensity > 0 + Glow = High). Dropping glow below High / disabling / 0 intensity
  // tears the model down immediately so it never runs on the hot path needlessly. The
  // compositor falls back to the real background whenever the mask isn't ready.
  const neonMoodStudioRequested =
    neonMoodActive && neonMoodParams.enabled && filterIntensity > 0 &&
    neonMoodParams.glow === "high" && started && source === "camera";
  React.useEffect(() => {
    if (!neonMoodStudioRequested) {
      neonMoodSegmenterRef.current?.dispose();
      neonMoodSegmenterRef.current = null;
      neonMoodPersonCanvasRef.current = null;
      neonMoodPersonCtxRef.current = null;
      return;
    }
    const video = videoRef.current;
    if (!video) return;
    // Offscreen scratch buffer for the person-on-black composite (sized to the bake
    // canvas, 1280×720) — reused each frame so we never allocate on the hot path.
    const personCanvas = document.createElement("canvas");
    personCanvas.width = 1280; personCanvas.height = 720;
    neonMoodPersonCanvasRef.current = personCanvas;
    neonMoodPersonCtxRef.current = personCanvas.getContext("2d");
    const segmenter = new NeonMoodSegmenter(video);
    neonMoodSegmenterRef.current = segmenter;
    void segmenter.start();
    return () => {
      segmenter.dispose();
      neonMoodSegmenterRef.current = null;
      neonMoodPersonCanvasRef.current = null;
      neonMoodPersonCtxRef.current = null;
    };
  }, [neonMoodStudioRequested]);

  // Mascot person segmenter — runs whenever the Mascot filter is live on a camera.
  // Reuses NeonMoodSegmenter's selfie model; its mask drives the green-creature
  // recolour. The face anchors (googly eyes/mouth) come from the shared faceTracker
  // started by the faceFilterActive effect above (Mascot is in that gate). Falls
  // back to a plain frame whenever the mask isn't ready yet.
  const mascotActive = filterStack.includes("mascot");
  React.useEffect(() => {
    if (!mascotActive || !started || source !== "camera") {
      mascotSegmenterRef.current?.dispose();
      mascotSegmenterRef.current = null;
      mascotPersonCanvasRef.current = null;
      mascotPersonCtxRef.current = null;
      return;
    }
    const video = videoRef.current;
    if (!video) return;
    const personCanvas = document.createElement("canvas");
    personCanvas.width = 1280; personCanvas.height = 720;
    mascotPersonCanvasRef.current = personCanvas;
    mascotPersonCtxRef.current = personCanvas.getContext("2d");
    const segmenter = new NeonMoodSegmenter(video);
    mascotSegmenterRef.current = segmenter;
    void segmenter.start();
    return () => {
      segmenter.dispose();
      mascotSegmenterRef.current = null;
      mascotPersonCanvasRef.current = null;
      mascotPersonCtxRef.current = null;
    };
  }, [mascotActive, started, source]);

  // Re-expand the Draw panel each time the tool is (re)opened.
  React.useEffect(() => { if (activeTool === "draw") setDrawMinimized(false); }, [activeTool]);

  // ── Canvas tap ───────────────────────────────────────────────────────────────
  function handleViewportTap(e: React.MouseEvent<HTMLElement>) {
    if (isDrawTool) return;          // drawing handled by pointer events
    if (!activeExp?.onTap) return;
    const rect = e.currentTarget.getBoundingClientRect();
    activeExp.onTap(
      (e.clientX - rect.left) / rect.width,
      (e.clientY - rect.top) / rect.height,
      experienceStateRef.current,
    );
  }

  // ── Motion Ink pointer handlers ───────────────────────────────────────────────
  // Convert a pointer event to a normalized 0..1 ink point (object-fit:cover math).
  function inkPoint(e: React.PointerEvent<HTMLElement>) {
    const rect = e.currentTarget.getBoundingClientRect();
    const c = viewportToCanvas(e.clientX, e.clientY, rect);
    return { x: c.x / 1280, y: c.y / 720 };
  }

  // Snapshot the subject's tracked position so new ink can follow it. Until the
  // tracker has locked we return undefined (the ink then holds its spot) and nudge
  // the user once to move so it can find them.
  function subjectAnchorPt(): { x: number; y: number } | undefined {
    const c = subjectRef.current;
    if (c) return { ...c };
    if (!subjectHintRef.current) {
      subjectHintRef.current = true;
      toast.message("Move around a little so tracking can lock onto you.");
    }
    return undefined;
  }

  function handleDrawDown(e: React.PointerEvent<HTMLElement>) {
    if (!isDrawTool || !started || hasResult) return;
    const first = inkPoint(e);

    // Glow Text — tap to drop the pending text at the tapped point.
    if (inkSubTool === "text") {
      const text = inkTextValue.trim();
      if (!text) { toast.message("Type your glow text first, then tap to place it."); return; }
      inkRef.current.push(makeText({
        text, x: first.x, y: first.y, fontPx: inkFont, brushId: inkBrush,
        glow: inkGlow, start: nowSec(), life: inkLife, anchor: inkAnchor,
        drawOn: inkDrawOn, anchorPt: inkAnchor === "subject" ? subjectAnchorPt() : undefined,
      }));
      setInkCount(inkRef.current.length);
      return;
    }

    // Brush stroke
    e.currentTarget.setPointerCapture(e.pointerId);
    currentStrokeRef.current = beginStroke({
      brushId: inkBrush, size: inkSize, glow: inkGlow, start: nowSec(), life: inkLife,
      anchor: inkAnchor, drawOn: inkDrawOn, first,
      anchorPt: inkAnchor === "subject" ? subjectAnchorPt() : undefined,
    });
    drawingRef.current = true;
    // Free the whole screen the moment a stroke begins.
    setDrawMinimized(true);
  }
  function handleDrawMove(e: React.PointerEvent<HTMLElement>) {
    if (!drawingRef.current || !currentStrokeRef.current) return;
    const pt = inkPoint(e);
    const pts = currentStrokeRef.current.pts;
    const last = pts[pts.length - 1];
    // Decimate: skip points closer than ~2px (canvas space) to keep strokes light
    if (last) {
      const dx = (pt.x - last.x) * 1280, dy = (pt.y - last.y) * 720;
      if (dx * dx + dy * dy < 4) return;
    }
    pts.push(pt);
  }
  function handleDrawUp() {
    if (!drawingRef.current) return;
    drawingRef.current = false;
    const s = currentStrokeRef.current;
    currentStrokeRef.current = null;
    if (s && s.pts.length) {
      inkRef.current.push(s);
      setInkCount(inkRef.current.length);
    }
  }
  function undoInk() {
    inkRef.current.pop();
    setInkCount(inkRef.current.length);
  }
  function clearInk() {
    inkRef.current = [];
    currentStrokeRef.current = null;
    setInkCount(0);
  }

  // ── Recording ────────────────────────────────────────────────────────────────
  function startCountdown() {
    setCountdown(3);
    const tick = (n: number) => setTimeout(() => {
      setCountdown(n - 1);
      if (n - 1 === 0) { setCountdown(null); beginRecording(); }
      else tick(n - 1);
    }, 1000);
    tick(3);
  }

  function beginRecording() {
    chunksRef.current = []; setDuration(0);
    // When a grade or overlay must be baked, record the canvas. For a pure CSS
    // grade the live preview runs on the <video> element so the rAF loop may not
    // be running — start it here so the recorded canvas is sized and painting the
    // graded frames before we capture its stream.
    // Resume the audio graph inside the record gesture (iOS suspends it otherwise)
    // so a boosted voice track produces samples.
    if (audioCtxRef.current?.state === "suspended") void audioCtxRef.current.resume();
    const stream = needsCanvasForCapture
      ? (() => { startCanvasLoop(); const cs = canvasRef.current!.captureStream(30); recordingAudioTracks().forEach(t => cs.addTrack(t)); return cs; })()
      : (useProcessedAudio()
          ? (() => { const s = new MediaStream(); streamRef.current!.getVideoTracks().forEach(t => s.addTrack(t)); recordingAudioTracks().forEach(t => s.addTrack(t)); return s; })()
          : streamRef.current!);
    // Pick a container the browser actually supports. iOS Safari has no webm
    // recorder and only offers mp4 — hardcoding webm produced unreadable blobs
    // ("Couldn't load that clip"). pickRecorderMime() prefers webm, falls back
    // to mp4, and returns "" when nothing matches (let the browser decide).
    const mime = pickRecorderMime();
    let rec: MediaRecorder;
    try {
      rec = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
    } catch {
      rec = new MediaRecorder(stream);
    }
    rec.ondataavailable = e => { if (e.data.size > 0) chunksRef.current.push(e.data); };
    rec.onstop = () => {
      const type = chunksRef.current[0]?.type || rec.mimeType || mime || "video/webm";
      const blob = new Blob(chunksRef.current, { type });
      const elapsed = recStartRef.current ? (performance.now() - recStartRef.current) / 1000 : 0;
      void addSegment(blob, elapsed);
    };
    rec.start(100); recorderRef.current = rec; setRecording(true);
    recStartRef.current = performance.now();
    durTimerRef.current = setInterval(() => setDuration(d => d + 1), 1000);
  }

  function stopRecording() {
    recorderRef.current?.stop(); setRecording(false);
    if (durTimerRef.current) clearInterval(durTimerRef.current);
    cancelAnimationFrame(rafRef.current);
    stopCamera(); setStarted(false);
  }

  function takePhoto() {
    if (flash) { setFlashActive(true); setTimeout(() => setFlashActive(false), 300); }
    if (needsCanvasForCapture && canvasRef.current) {
      // Bake one final composite so the grade + latest stroke land in the photo.
      // For a CSS-only grade the canvas isn't sized yet (its preview runs on the
      // <video> element), so size it to the capture buffer before compositing.
      const cv = canvasRef.current;
      cv.width = 1280; cv.height = 720;
      const ctx = cv.getContext("2d", { willReadFrequently: true });
      if (ctx) compositeFrame(ctx, { staticInk: true });
      setPhotoUrl(cv.toDataURL("image/jpeg", 0.92));
    } else {
      const c = document.createElement("canvas");
      const v = videoRef.current!;
      c.width = v.videoWidth || 1280; c.height = v.videoHeight || 720;
      const ctx = c.getContext("2d")!;
      if (mirror) { ctx.translate(c.width, 0); ctx.scale(-1, 1); }
      ctx.drawImage(v, 0, 0);
      setPhotoUrl(c.toDataURL("image/jpeg", 0.92));
    }
    stopCamera(); setStarted(false);
  }

  // Capture one frame INTO the slideshow set and keep the camera running so the
  // user can keep shooting. Mirrors takePhoto's frame grab (canvas-composited
  // when filters/effects are active, raw video otherwise).
  function captureSlide() {
    if (slides.length >= MAX_SLIDES) {
      toast.error(`Slideshows are capped at ${MAX_SLIDES} photos.`);
      return;
    }
    if (flash) { setFlashActive(true); setTimeout(() => setFlashActive(false), 300); }
    let url: string | null = null;
    if (needsCanvasForCapture && canvasRef.current) {
      const cv = canvasRef.current;
      cv.width = 1280; cv.height = 720;
      const ctx = cv.getContext("2d", { willReadFrequently: true });
      if (ctx) compositeFrame(ctx, { staticInk: true });
      url = cv.toDataURL("image/jpeg", 0.92);
    } else if (videoRef.current) {
      const c = document.createElement("canvas");
      const v = videoRef.current;
      c.width = v.videoWidth || 1280; c.height = v.videoHeight || 720;
      const ctx = c.getContext("2d")!;
      if (mirror) { ctx.translate(c.width, 0); ctx.scale(-1, 1); }
      ctx.drawImage(v, 0, 0);
      url = c.toDataURL("image/jpeg", 0.92);
    }
    if (url) setSlides(prev => [...prev, url!]);
  }

  // Finish the slideshow capture session and move to the preview/publish state.
  function finishSlides() {
    stopCamera();
    setStarted(false);
  }

  // Turn a finished recording into a segment so clips can be spliced together.
  // `timedDuration` is the wall-clock recording length — our fallback when
  // probeBlob can't read the blob's metadata (common on iOS Safari). We only
  // discard the clip if we have NO usable duration from either source, so a probe
  // hiccup never silently throws away a real recording.
  async function addSegment(blob: Blob, timedDuration = 0) {
    const url = URL.createObjectURL(blob);
    if (blob.size === 0) {
      URL.revokeObjectURL(url);
      toast.error("That recording came out empty. Please try recording it again.");
      return;
    }
    let meta = { duration: 0, width: 0, height: 0 };
    try {
      meta = await probeBlob(url);
    } catch {
      // Probe failed — fall through to the timed-duration fallback below.
    }
    const duration =
      Number.isFinite(meta.duration) && meta.duration > 0
        ? meta.duration
        : timedDuration;
    if (!(duration > 0)) {
      URL.revokeObjectURL(url);
      toast.error("Couldn't load that clip. Please try recording it again.");
      return;
    }
    setSegments(prev => [
      ...prev,
      {
        id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
        blob,
        url,
        mimeType: blob.type || "video/webm",
        duration,
        trimStart: 0,
        trimEnd: duration,
        // Real pixel dims are read from the <video> at edit/export time; these are
        // advisory, so default to 16:9 when the probe couldn't report them.
        width: meta.width || 1280,
        height: meta.height || 720,
      },
    ]);
  }

  // Record one more clip to splice onto the end. Blank-canvas mode has no camera
  // to re-tap, so just resume the compositor; otherwise re-open the camera.
  function addClip() {
    if (sourceRef.current === "canvas") setStarted(true);
    else void startCamera();
  }

  function retake() {
    segmentsRef.current.forEach(s => URL.revokeObjectURL(s.url));
    setSegments([]); setPhotoUrl(null); setSlides([]);
    setDuration(0); setPublishing(false);
    setMusicTrackId(null); setMusicSelMode("none"); setMusicSheetOpen(false);
    setCustomTracks([]);
    clearInk();
    studioClockRef.current = 0;
    // Blank-canvas mode has no camera to re-tap — resume the compositor loop.
    if (sourceRef.current === "canvas") setStarted(true);
  }

  async function download() {
    if (photoUrl) {
      const a = document.createElement("a");
      a.href = photoUrl; a.download = `r2tc-${Date.now()}.jpg`; a.click();
      return;
    }
    if (segments.length === 0) return;
    try {
      setExporting(true); setExportProgress(0);
      const blob = await exportSegments(segments, { onProgress: setExportProgress });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = `r2tc-${Date.now()}.${extForMime(blob.type)}`; a.click();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
    } catch (err: any) {
      toast.error(err?.message ?? "Couldn't save the video.");
    } finally {
      setExporting(false); setExportProgress(0);
    }
  }

  // The OpenAI photo-remake style, derived from the active filter. Only the two
  // supported styles are offered; anything else returns null so the remake button hides.
  function remakeStyleForToday(): AiFilterRemakeInputStyle | null {
    const active = filterStack[0];
    if (active === "caricature") return "fairground_caricature";
    if (active === "mascot") return "mascot_reference";
    return null;
  }

  // Send the captured still to OpenAI for a fairground-caricature / mascot remake and
  // surface the returned app-served URL. The original stays available; the user picks
  // which to save or publish. Errors (quota, moderation) surface as a toast.
  async function generateAiRemake() {
    if (!photoUrl) return;
    const style = remakeStyleForToday();
    if (!style) return;
    try {
      setRemakeUrl(null);
      const res = await aiRemake.mutateAsync({
        data: {
          image: photoUrl,
          style,
        },
      });
      setRemakeUrl(res.imageUrl);
      toast.success("AI remake ready!");
    } catch (err: any) {
      toast.error(err?.message ?? "Couldn't generate the AI remake. Try again later.");
    }
  }

  // Swap the captured still for the AI remake so Save/Publish/draft all use it.
  function useRemakeAsPhoto() {
    if (remakeUrl) { setPhotoUrl(remakeUrl); setRemakeUrl(null); }
  }

  // Ask the server to composite this duet: it resolves the source by id, re-checks
  // duet eligibility, hstacks source-left + our clip-right, and returns the final
  // video's object path. Same-origin cookie auth (no header needed on web).
  async function composeDuetOnServer(sourcePostId: number, capturedVideoPath: string): Promise<string> {
    const res = await fetch("/api/storage/video/duet-compose", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sourcePostId, capturedVideoPath }),
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      throw new Error(data.error || "We couldn't build this duet.");
    }
    const { objectPath } = (await res.json()) as { objectPath: string };
    return objectPath;
  }

  async function publish() {
    if (segments.length > 0 && totalTrimmedDuration(segments) > MAX_VIDEO_SEC + 1) {
      toast.error("Your video is over 3 minutes 45 seconds. Trim it down before publishing.");
      return;
    }
    // A duet must be a recorded video (we composite the raw clip with the source).
    if (duetOfPostId && segments.length === 0) {
      toast.error("Record your side of the duet before publishing.");
      return;
    }
    // Required content disclosure — block publishing until the creator declares
    // what kind of content this is. Re-open the publish sheet so they can fix it.
    if (!disclosedKind) {
      toast.error("Choose what kind of content this is before publishing.");
      setPublishing(true);
      return;
    }
    const meta = [
      activeExp ? `Experience: ${activeExp.label}` : null,
      selectedFilterDefs.length > 0 && !marketFilterCss
        ? `Filters: ${selectedFilterDefs.map(d => d.label).join(" → ")}`
        : null,
      marketFilterLabel ? `Filter: ${marketFilterLabel}` : null,
      aiBg ? `Background: ${aiBg.label}` : null,
    ].filter(Boolean).join(" · ");
    // Glow text is user content baked into the frame — fold it into the body so it
    // passes through the server's existing moderation pass (which scans title+body).
    const inkText = inkRef.current
      .filter((el): el is InkText => el.type === "text")
      .map(el => el.text.trim())
      .filter(Boolean)
      .join(" ");

    // Soundtrack is mixed into the exported video at render time (the feed plays the
    // baked video, so no feed-side change is needed). Baking only applies to
    // video/slideshow — photo posts carry the track by id instead (below).
    const music =
      (segments.length > 0 || slides.length > 0) && selectedTrack
        ? { url: selectedTrack.audioUrl, fitMode: musicFitMode, volume: musicVolume }
        : undefined;

    // The captured photo/video only exists locally (a data:/blob: URL). Upload it
    // to object storage first, then post the resulting object path so the feed can
    // serve it back to everyone.
    let imageObjectPath: string | undefined;
    let videoObjectPath: string | undefined;
    const mediaItems: { kind: "image"; url: string; position: number }[] = [];
    const isSlideshow = !photoUrl && segments.length === 0 && slides.length > 0;
    try {
      if (photoUrl) {
        const blob = await (await fetch(photoUrl)).blob();
        const file = new File([blob], `r2tc-${Date.now()}.jpg`, {
          type: blob.type || "image/jpeg",
        });
        const up = await uploadFile(file);
        if (!up) return; // error already surfaced by useUpload
        imageObjectPath = up.objectPath;
      } else if (isSlideshow) {
        // Render the stills into a single video (with baked music) + a poster.
        let finalBlob: Blob;
        let posterDataUrl: string;
        try {
          setExporting(true); setExportProgress(0);
          const out = await exportSlideshow(slides, {
            music,
            perSlideSec: SLIDE_SEC,
            maxSeconds: MAX_VIDEO_SEC,
            onProgress: setExportProgress,
          });
          finalBlob = out.blob;
          posterDataUrl = out.posterDataUrl;
        } finally {
          setExporting(false);
        }
        const ext = extForMime(finalBlob.type);
        const vfile = new File([finalBlob], `r2tc-${Date.now()}.${ext}`, {
          type: finalBlob.type || "video/webm",
        });
        const vup = await uploadFile(vfile);
        if (!vup) return;
        videoObjectPath = vup.objectPath;
        // Poster thumbnail for the feed tile.
        try {
          const pblob = await (await fetch(posterDataUrl)).blob();
          const pfile = new File([pblob], `r2tc-${Date.now()}-poster.jpg`, { type: "image/jpeg" });
          const pup = await uploadFile(pfile);
          if (pup) imageObjectPath = pup.objectPath;
        } catch { /* poster is best-effort */ }
        // Upload the source stills so the originals are preserved (server re-verifies).
        for (let i = 0; i < slides.length; i++) {
          const sblob = await (await fetch(slides[i])).blob();
          const sfile = new File([sblob], `r2tc-${Date.now()}-slide${i}.jpg`, { type: "image/jpeg" });
          const sup = await uploadFile(sfile);
          if (sup) mediaItems.push({ kind: "image", url: sup.objectPath, position: i });
        }
      } else if (segments.length > 0) {
        // Re-render the trimmed clips into one spliced video before uploading.
        let finalBlob: Blob;
        try {
          setExporting(true); setExportProgress(0);
          finalBlob = await exportSegments(segments, { onProgress: setExportProgress, music, muteClipAudio: muteVideoAudio, contentVolume, voiceOverrides: (voiceCleanEnabled && !muteVideoAudio) ? voiceCleanRef.current : undefined });
          // Sanity-check the rendered length before upload (server enforces it too).
          try {
            const purl = URL.createObjectURL(finalBlob);
            const info = await probeBlob(purl);
            URL.revokeObjectURL(purl);
            if (info.duration > MAX_VIDEO_SEC + 1.5) {
              toast.error("The combined video came out over 3 minutes 45 seconds. Trim a clip and try again.");
              return;
            }
          } catch { /* couldn't read it — let the server make the call */ }
        } finally {
          setExporting(false);
        }
        const ext = extForMime(finalBlob.type);
        const file = new File([finalBlob], `r2tc-${Date.now()}.${ext}`, {
          type: finalBlob.type || "video/webm",
        });
        const up = await uploadFile(file);
        if (!up) return;
        videoObjectPath = up.objectPath;
      }
    } catch (err: any) {
      toast.error(err?.message ?? "Couldn't prepare your media.");
      return;
    }

    // Duet — hand the raw recorded clip + the source post id to the server, which
    // composites the two side-by-side (source resolved + re-gated by id) and returns
    // the finished video we actually publish in place of the raw clip.
    if (duetOfPostId) {
      if (!videoObjectPath) {
        toast.error("Record your side of the duet before publishing.");
        return;
      }
      try {
        setExporting(true); setExportProgress(0);
        videoObjectPath = await composeDuetOnServer(duetOfPostId, videoObjectPath);
      } catch (err: any) {
        toast.error(err?.message ?? "We couldn't build this duet.");
        return;
      } finally {
        setExporting(false);
      }
    }

    const contentType = photoUrl ? "image" : isSlideshow ? "slideshow" : "video";
    // AI Filter Challenge wiring (#109). A post may EITHER join an existing
    // challenge (reuse mode) OR start a new one from the applied AI Director look —
    // never both. The reuse gate + start eligibility are re-checked server-side.
    const startingChallenge =
      !joinChallengeId && startChallengeOn && !!aiExperienceId && challengePrompt.trim().length > 0;
    startedChallengeRef.current = startingChallenge;
    createPost({
      data: {
        contentType,
        disclosedContentKind: disclosedKind,
        containsPaidPromotion: paidPromotion,
        title: postTitle || undefined,
        body: [postBody, meta ? `[${meta}]` : null, inkText || null].filter(Boolean).join("\n\n") || undefined,
        videoUrl: videoObjectPath,
        imageUrl: imageObjectPath,
        communityId: communityId !== "none" ? Number(communityId) : undefined,
        // Audience only applies to non-community posts (server coerces anyway).
        audience: communityId !== "none" ? undefined : audience,
        // Send the track for EVERY post type — baked media keeps it as
        // attribution, photo posts NEED it (the viewer plays it live). This is
        // how a ripped "Use this sound" track survives a photo post.
        musicTrackId: musicEligible && selectedTrack ? selectedTrack.id : undefined,
        musicFitMode: musicEligible && selectedTrack ? musicFitMode : undefined,
        mediaItems: mediaItems.length > 0 ? mediaItems : undefined,
        joinChallengeId: joinChallengeId ?? undefined,
        startChallenge: startingChallenge
          ? { experienceId: aiExperienceId!, prompt: challengePrompt.trim() }
          : undefined,
        // Derivative-reuse consent — only meaningful on the media type that can be
        // reused; opt-in and false by default (server also defaults these false).
        allowSoundReuse:
          (contentType === "video" || contentType === "slideshow") && allowSoundReuse
            ? true
            : undefined,
        allowDuet: contentType === "video" && allowDuet ? true : undefined,
        duetOfPostId: duetOfPostId ?? undefined,
        // Frameless immersive display — premium/pro only (server re-checks tier).
        frameless: canFrameless && frameless ? true : undefined,
      },
    });
  }

  // ── Drafts (local-only) ───────────────────────────────────────────────────────
  // Persist the in-progress post — captured media + every look/config + Motion Ink —
  // to IndexedDB so the user can leave and pick up exactly where they left off.
  // Re-saving a resumed/saved draft updates it in place.
  async function handleSaveDraft() {
    if (recording) { toast.error("Stop recording before saving a draft."); return; }
    if (exporting) { toast("Hang on — your video is still exporting."); return; }
    if (!photoUrl && segments.length === 0 && slides.length === 0) {
      toast("Capture or import something first to save it as a draft.");
      return;
    }
    setSavingDraft(true);
    try {
      const id = currentDraftIdRef.current ?? newDraftId();
      const now = Date.now();
      const serializedSegs = serializeSegments(segmentsRef.current);
      // Best-effort thumbnail for the drafts list (null is fine — the list falls back
      // to a kind icon).
      let thumb: string | null = photoUrl ?? slides[0] ?? null;
      if (!thumb && serializedSegs.length > 0) {
        thumb = await firstFrameDataUrl(serializedSegs[0].blob, serializedSegs[0].trimStart);
      }
      const draft: StudioDraft = {
        id,
        schemaVersion: DRAFT_SCHEMA_VERSION,
        createdAt: now,
        updatedAt: now,
        photoUrl,
        slides,
        segments: serializedSegs,
        creativeMode,
        studioMode,
        source,
        canvasBg,
        maxDuration,
        duration,
        postTitle,
        postBody,
        communityId,
        audience,
        disclosedKind,
        paidPromotion,
        musicTrackId,
        musicFitMode,
        muteVideoAudio,
        contentVolume,
        musicVolume,
        customTracks,
        filterStack,
        filterIntensity,
        marketFilterCss,
        marketFilterLabel,
        aiBg,
        gsThreshold,
        activeExperienceId,
        neonRainParams,
        neonPatriotParams,
        beautyXParams,
        solargraphParams,
        carnivalParams,
        neonMoodParams,
        ink: inkRef.current,
        inkAnchor,
        inkBrush,
        inkSize,
        inkFont,
        inkGlow,
        inkLife,
      };
      if (currentDraftIdRef.current == null && draftCount >= MAX_DRAFTS) {
        toast("You've saved a lot of drafts — consider clearing a few from the Drafts list.");
      }
      await saveDraft(draft, thumb);
      currentDraftIdRef.current = id;
      refreshDraftCount();
      toast.success("Draft saved.");
    } catch (err: any) {
      toast.error(err?.message ?? "Couldn't save this draft.");
    } finally {
      setSavingDraft(false);
    }
  }

  // Restore a saved draft back into the studio, landing on the captured RESULT (not
  // the live camera) so the user can keep editing or publish straight away.
  async function handleResume(id: string) {
    let draft: StudioDraft | null;
    try {
      draft = await getDraft(id);
    } catch {
      toast.error("Couldn't open that draft.");
      return;
    }
    if (!draft) {
      toast.error("That draft couldn't be found.");
      setDraftsOpen(false);
      refreshDraftCount();
      return;
    }
    // Tear down any live capture and release the CURRENT segments' object URLs before
    // replacing them — avoids a blob leak and stops the live camera covering the result.
    // A recording may be in flight: MediaRecorder.stop() fires onstop ASYNC, which would
    // append the interrupted clip onto the draft we're about to restore. Neutralize the
    // recorder (drop its handlers + chunks + timers) so that dangling clip is discarded.
    if (recorderRef.current) {
      try {
        recorderRef.current.onstop = null;
        recorderRef.current.ondataavailable = null;
        if (recorderRef.current.state !== "inactive") recorderRef.current.stop();
      } catch { /* ignore */ }
      recorderRef.current = null;
    }
    chunksRef.current = [];
    if (durTimerRef.current) { clearInterval(durTimerRef.current); durTimerRef.current = null; }
    cancelAnimationFrame(rafRef.current);
    stopCamera();
    setStarted(false);
    setRecording(false);
    setPublishing(false);
    setExporting(false);
    setActiveTool(null);
    setDrawMinimized(false);
    setInkDrawOn(false);
    segmentsRef.current.forEach(s => URL.revokeObjectURL(s.url));

    // Media — rehydrate fresh object URLs for stored segment blobs.
    setPhotoUrl(draft.photoUrl);
    setSlides(draft.slides);
    const hydrated = hydrateSegments(draft.segments);
    segmentsRef.current = hydrated;
    setSegments(hydrated);

    // Mode / config (compositor refs are kept in sync by their own effects).
    setCreativeMode(draft.creativeMode as typeof creativeMode);
    setStudioMode(draft.studioMode as StudioMode);
    setSource(draft.source);
    sourceRef.current = draft.source;
    setCanvasBg(draft.canvasBg as CanvasBgId);
    setMaxDuration(draft.maxDuration);
    setDuration(draft.duration);

    // Post fields
    setPostTitle(draft.postTitle);
    setPostBody(draft.postBody);
    setCommunityId(draft.communityId);
    // Backward compat: drafts saved before the audience picker default to general.
    setAudience((draft.audience as "general" | "chasers" | "private") ?? "general");
    setDisclosedKind(draft.disclosedKind);
    setPaidPromotion(draft.paidPromotion);

    // Music — best-effort. Restore custom tracks so a custom selection can resolve;
    // publish() guards on the track existing, so a stale id just bakes no music.
    setCustomTracks(draft.customTracks ?? []);
    setMusicTrackId(draft.musicTrackId);
    setMusicSelMode(draft.musicTrackId != null ? "manual" : "none");
    setMusicFitMode(draft.musicFitMode);
    setMuteVideoAudio(draft.muteVideoAudio ?? true);
    setContentVolume(draft.contentVolume ?? 1);
    setMusicVolume(draft.musicVolume ?? 0.7);

    // Filters / effects
    setFilterStack(draft.filterStack as FilterId[]);
    setFilterIntensity(draft.filterIntensity);
    setMarketFilterCss(draft.marketFilterCss);
    setMarketFilterLabel(draft.marketFilterLabel);
    setAIBg(draft.aiBg);
    setGsThreshold(draft.gsThreshold);
    setActiveExperienceId(draft.activeExperienceId);
    setNeonRainParams(draft.neonRainParams as NeonRainParams);
    setNeonPatriotParams(draft.neonPatriotParams);
    setBeautyXParams(draft.beautyXParams);
    setSolargraphParams(draft.solargraphParams);
    if (draft.carnivalParams) setCarnivalParams(draft.carnivalParams);
    if (draft.neonMoodParams) setNeonMoodParams(draft.neonMoodParams);
    experienceStateRef.current = makeExperienceState();

    // Motion Ink
    inkRef.current = draft.ink ?? [];
    currentStrokeRef.current = null;
    drawingRef.current = false;
    studioClockRef.current = 0;
    setInkCount(inkRef.current.length);
    setInkAnchor(draft.inkAnchor);
    setInkBrush(draft.inkBrush);
    setInkSize(draft.inkSize);
    setInkFont(draft.inkFont);
    setInkGlow(draft.inkGlow);
    setInkLife(Number.isFinite(draft.inkLife) ? draft.inkLife : Infinity);

    currentDraftIdRef.current = draft.id;
    setDraftsOpen(false);
    toast.success("Draft restored.");
  }

  React.useEffect(() => () => {
    stopCamera();
    segmentsRef.current.forEach(s => URL.revokeObjectURL(s.url));
  }, []);

  // Auto-stop recording once the chosen length is reached.
  React.useEffect(() => {
    if (recording && maxDuration != null && duration >= maxDuration) stopRecording();
  }, [recording, duration, maxDuration]);

  const fmtTime = (s: number) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;

  // ── Tool toggle ───────────────────────────────────────────────────────────────
  function toggleTool(id: ToolId) {
    setActiveTool(prev => prev === id ? null : id);
  }

  // ── Filter stack (layered filters) ────────────────────────────────────────────
  // Filters stack in selection order; tapping a selected one removes it. Choosing
  // "Original" (or Clear all) empties the stack. Selecting a built-in filter clears
  // any marketplace filter so the two color systems don't fight each other.
  function toggleFilter(id: FilterId) {
    setMarketFilterCss(null);
    setMarketFilterLabel(null);
    if (id === "none") { setFilterStack([]); return; }
    setFilterStack(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id],
    );
  }

  // Reorder a layer: dir -1 applies it earlier (lower in the stack), +1 later
  // (higher, painted on top).
  function moveFilter(index: number, dir: -1 | 1) {
    setFilterStack(prev => {
      const j = index + dir;
      if (j < 0 || j >= prev.length) return prev;
      const next = [...prev];
      [next[index], next[j]] = [next[j], next[index]];
      return next;
    });
  }

  // ── Editor: creative-mode tabs ──────────────────────────────────────────────────
  // Map the desktop "creative mode" onto the underlying capture primitives so all
  // existing handlers keep working. Video/Slide Show use the live camera; Canvas
  // Art uses the blank-canvas compositor; Fancy Notes mounts the standalone
  // composer over the stage (self-contained, no camera).
  function selectMode(mode: "photo" | "video" | "slideshow" | "canvas" | "fancynotes") {
    setCreativeMode(mode);
    setActiveTool(null);
    if (mode === "photo") { setStudioMode("photo"); if (source !== "camera") selectSource("camera"); }
    else if (mode === "video") { setStudioMode("video"); if (source !== "camera") selectSource("camera"); }
    else if (mode === "slideshow") { setStudioMode("slides"); if (source !== "camera") selectSource("camera"); }
    else if (mode === "canvas") { setStudioMode("photo"); if (source !== "canvas") selectSource("canvas"); }
    // fancynotes: leave capture primitives untouched.
  }

  // Single-select a filter (desktop filter row): replace the stack with just this
  // id (or clear it for "Original") and drop any marketplace grade.
  function selectFilter(id: FilterId) {
    setMarketFilterCss(null);
    setMarketFilterLabel(null);
    // Neon Rain ships with its own spec defaults — seed them (incl. intensity 70)
    // when switching TO it from another look, so it always lands premium first try.
    if (id === "neonrain" && filterStack[0] !== "neonrain") {
      setFilterIntensity(DEFAULT_NEON_RAIN_PARAMS.intensity);
      setNeonRainParams(DEFAULT_NEON_RAIN_PARAMS);
    }
    // Neon Patriot likewise seeds its spec defaults (incl. intensity 80) on switch-in.
    if (id === "neonpatriot" && filterStack[0] !== "neonpatriot") {
      setFilterIntensity(DEFAULT_NEON_PATRIOT_PARAMS.intensity);
      setNeonPatriotParams(DEFAULT_NEON_PATRIOT_PARAMS);
    }
    // Beauty X seeds its spec defaults (Extreme preset, intensity 100) on switch-in.
    if (id === "beautyx" && filterStack[0] !== "beautyx") {
      setFilterIntensity(DEFAULT_BEAUTY_X_PARAMS.intensity);
      setBeautyXParams(DEFAULT_BEAUTY_X_PARAMS);
    }
    // Solargraph seeds its spec defaults (intensity 100) on switch-in.
    if (id === "solargraph" && filterStack[0] !== "solargraph") {
      setFilterIntensity(DEFAULT_SOLARGRAPH_PARAMS.intensity);
      setSolargraphParams(DEFAULT_SOLARGRAPH_PARAMS);
    }
    // Carnival seeds its spec defaults (Festival look, intensity 85) on switch-in.
    if (id === "carnival" && filterStack[0] !== "carnival") {
      setFilterIntensity(DEFAULT_CARNIVAL_PARAMS.intensity);
      setCarnivalParams(DEFAULT_CARNIVAL_PARAMS);
    }
    // Neon Mood seeds its spec defaults (Bold caricature, High glow, intensity 85)
    // on switch-in, so it always lands premium first try.
    if (id === "neonmood" && filterStack[0] !== "neonmood") {
      setFilterIntensity(DEFAULT_NEON_MOOD_PARAMS.intensity);
      setNeonMoodParams(DEFAULT_NEON_MOOD_PARAMS);
    }
    // Caricature + Mascot seed a strong-but-not-extreme intensity on switch-in so
    // the exaggeration / costume reads instantly without the user touching the slider.
    if (id === "caricature" && filterStack[0] !== "caricature") {
      setFilterIntensity(70);
    }
    if (id === "mascot" && filterStack[0] !== "mascot") {
      setFilterIntensity(85);
    }
    // The AI look lands at full strength on switch-in (the generated config is
    // already clamped to a safe, balanced range server-side).
    if (id === "aiconfig" && filterStack[0] !== "aiconfig") {
      setFilterIntensity(100);
    }
    setFilterStack(id === "none" ? [] : [id]);
  }

  // Apply a generated creative package's filter: store the config and activate the
  // "aiconfig" look. Called by the AI Creative Director panel once a job is ready.
  function applyAiConfigFilter(config: AiFilterConfig) {
    setAiFilterConfig(config);
    selectFilter("aiconfig");
  }

  // Reset Neon Rain's controls (and its intensity) back to the spec defaults.
  function resetNeonRain() {
    setFilterIntensity(DEFAULT_NEON_RAIN_PARAMS.intensity);
    setNeonRainParams(DEFAULT_NEON_RAIN_PARAMS);
  }

  // Reset Neon Patriot's controls (and its intensity) back to the spec defaults.
  function resetNeonPatriot() {
    setFilterIntensity(DEFAULT_NEON_PATRIOT_PARAMS.intensity);
    setNeonPatriotParams(DEFAULT_NEON_PATRIOT_PARAMS);
  }

  // Reset Beauty X's controls (and its intensity) back to the spec defaults.
  function resetBeautyX() {
    setFilterIntensity(DEFAULT_BEAUTY_X_PARAMS.intensity);
    setBeautyXParams(DEFAULT_BEAUTY_X_PARAMS);
  }
  // Apply a Beauty Level preset bundle (keeps intensity + the two toggles as-is).
  function applyBeautyXLevel(level: BXLevel) {
    setBeautyXParams(prev => ({ ...prev, level, ...BX_PRESETS[level] }));
  }

  // Reset Solargraph's controls (and its intensity) back to the spec defaults.
  function resetSolargraph() {
    setFilterIntensity(DEFAULT_SOLARGRAPH_PARAMS.intensity);
    setSolargraphParams(DEFAULT_SOLARGRAPH_PARAMS);
  }

  // Reset Carnival's controls (and its intensity) back to the spec defaults.
  function resetCarnival() {
    setFilterIntensity(DEFAULT_CARNIVAL_PARAMS.intensity);
    setCarnivalParams(DEFAULT_CARNIVAL_PARAMS);
  }

  // Reset Neon Mood's controls (and its intensity) back to the spec defaults.
  function resetNeonMood() {
    setFilterIntensity(DEFAULT_NEON_MOOD_PARAMS.intensity);
    setNeonMoodParams(DEFAULT_NEON_MOOD_PARAMS);
  }

  // Media entry — the Add-media sheet fronts every import (plain-language rules,
  // the one-time ownership ack (R4) and a replace warning) before the OS picker
  // opens or files are dropped.
  function openMediaPicker() { setMediaSheetOpen(true); }
  function ackUpload() {
    if (uploadAcked) return;
    try { localStorage.setItem(UPLOAD_ACK_KEY, "1"); } catch { /* ignore */ }
    setUploadAcked(true);
  }
  function browseDevice() { ackUpload(); fileInputRef.current?.click(); }
  function handleSheetFiles(files: File[]) { ackUpload(); void importFiles(files); }

  const readImageAsDataUrl = (file: File) =>
    new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => (typeof reader.result === "string" ? resolve(reader.result) : reject(new Error("bad-image")));
      reader.onerror = () => reject(new Error("read-image"));
      reader.readAsDataURL(file);
    });

  // Downscale an imported photo before storing it as a slide. Each slide is kept as
  // a data URL, so a big slideshow (up to MAX_SLIDES=75) of full-res iPhone photos
  // would be hundreds of MB and can crash mobile Safari. Cap the longest edge (well
  // above the 1080×1350 export canvas) and re-encode as JPEG. Falls back to the raw
  // data URL if the image can't be decoded/encoded.
  const readImageDownscaledDataUrl = async (file: File, maxEdge = 1600): Promise<string> => {
    const raw = await readImageAsDataUrl(file);
    try {
      const img = await new Promise<HTMLImageElement>((resolve, reject) => {
        const el = new Image();
        el.onload = () => resolve(el);
        el.onerror = () => reject(new Error("decode-image"));
        el.src = raw;
      });
      const scale = Math.min(1, maxEdge / Math.max(img.naturalWidth, img.naturalHeight));
      if (scale >= 1) return raw; // already small enough — keep original bytes
      const w = Math.max(1, Math.round(img.naturalWidth * scale));
      const h = Math.max(1, Math.round(img.naturalHeight * scale));
      const canvas = document.createElement("canvas");
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext("2d");
      if (!ctx) return raw;
      ctx.drawImage(img, 0, 0, w, h);
      return canvas.toDataURL("image/jpeg", 0.82);
    } catch {
      return raw;
    }
  };

  // Media import — bring existing photos/videos into the editor through the SAME
  // pipeline as captured media (R2/R6). Rules: only images or a video (never mixed,
  // never several videos). ONE image → photo; MANY images → a slideshow. Everything
  // then flows through publish() unchanged.
  async function importMedia(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    e.target.value = "";
    await importFiles(files);
  }

  // Shared import pipeline — fed by the hidden OS picker AND the Add-media sheet's
  // drag & drop. Everything downstream (photo / slides / addSegment) is unchanged.
  async function importFiles(files: File[]) {
    setMediaSheetOpen(false);
    if (files.length === 0) return;

    const images = files.filter(f => f.type.startsWith("image/"));
    const videos = files.filter(f => f.type.startsWith("video/"));
    const others = files.length - images.length - videos.length;

    // R6 — only photos or videos may be uploaded.
    if (images.length === 0 && videos.length === 0) {
      toast.error("Pick photos or a video — other file types aren't supported.");
      return;
    }
    if (others > 0) toast("Skipped files that weren't a photo or video.");
    if (images.length > 0 && videos.length > 0) {
      toast.error("Upload photos OR a video — not both in one post.");
      return;
    }
    if (videos.length > 1) {
      toast.error("Add one video at a time. Import clips one by one, then splice them.");
      return;
    }

    // Leave any live capture and clear ALL prior results (revoking old segment
    // blobs) so the import REPLACES — never appends to — whatever was there.
    if (started) { stopCamera(); setStarted(false); }
    segmentsRef.current.forEach(s => URL.revokeObjectURL(s.url));
    setSegments([]); setSlides([]); setPhotoUrl(null);

    if (videos.length === 1) {
      setCreativeMode("video");
      await addSegment(videos[0]);
      return;
    }

    // A single image → a photo post (previously this incorrectly set video mode).
    if (images.length === 1) {
      setCreativeMode("photo");
      try {
        setPhotoUrl(await readImageAsDataUrl(images[0]));
      } catch {
        toast.error("Couldn't read that image.");
      }
      return;
    }

    // Multiple images → a slideshow (R2). Cap to MAX_SLIDES — the same ceiling as an
    // in-studio slideshow — so the exported duration stays within the video cap (R5).
    const capped = images.slice(0, MAX_SLIDES);
    try {
      // Decode + downscale sequentially so peak memory stays ~one photo at a time —
      // a parallel Promise.all would spike many full-res decodes and risk an iOS crash.
      const urls: string[] = [];
      for (const f of capped) urls.push(await readImageDownscaledDataUrl(f));
      setSlides(urls);
      setCreativeMode("slideshow");
      if (images.length > MAX_SLIDES) {
        toast(`Added the first ${MAX_SLIDES} photos — that's the slideshow limit.`);
      }
    } catch {
      toast.error("Couldn't read one of those images.");
    }
  }


  // ── Render ────────────────────────────────────────────────────────────────────
  // Desktop editor shell — re-skins the studio in place. ALL capture state, refs,
  // handlers and the <video>/<canvas> compositor below are unchanged; only the JSX
  // chrome wrapping them is new.
  const PANEL_BG = "rgba(12,18,32,.78)";
  const PANEL_BORDER = "1px solid rgba(120,160,255,.18)";
  const cardStyle: React.CSSProperties = {
    background: PANEL_BG, border: PANEL_BORDER,
    backdropFilter: "blur(18px)", WebkitBackdropFilter: "blur(18px)",
  };
  const isFancy = creativeMode === "fancynotes";

  const MODES = [
    { id: "photo",      label: "Photo",       icon: Camera },
    { id: "video",      label: "Video",       icon: Video },
    { id: "slideshow",  label: "Slide Show",  icon: Images },
    { id: "canvas",     label: "Canvas Art",  icon: PenTool },
    { id: "fancynotes", label: "Fancy Notes", icon: StickyNote },
  ] as const;

  // Primary capture action — contextual to the active creative mode. Also wired to
  // the left "Capture" tool and the glowing action-bar orb.
  const handlePrimaryCapture = () => {
    if (isFancy) return;
    if (creativeMode === "photo") {
      if (!started) { startCamera(); return; }
      takePhoto();
      return;
    }
    if (creativeMode === "canvas") {
      if (!started) { selectSource("canvas"); return; }
      takePhoto();
      return;
    }
    if (creativeMode === "slideshow") {
      if (!started) { startCamera(); return; }
      captureSlide();
      return;
    }
    // video
    if (!started) { startCamera(); return; }
    if (recording) { stopRecording(); return; }
    startCountdown();
  };

  // Studio tiering — Free gets a curated, less-overwhelming rail; premium/pro get
  // the "fuller studio" (the advanced creative tools). The universal Voice, Volume
  // and Audio controls stay available to EVERYONE. Locked tools stay VISIBLE as a
  // discoverable upsell but prompt an upgrade instead of opening their panel.
  const studioPremiumTools = new Set(["aidirector", "effects", "backgrounds"]);
  const promptStudioUpgrade = (label: string) => {
    toast.info(`${label} is part of the Premium studio`, {
      description: "Upgrade to unlock the fuller creative suite.",
    });
  };
  const LEFT_TOOLS: { id: string; icon: React.ElementType; label: string; onClick: () => void; active?: boolean; locked?: boolean }[] = [
    { id: "capture",  icon: Aperture,    label: "Capture",  onClick: handlePrimaryCapture, active: started && !isFancy },
    { id: "media",    icon: ImagePlus,   label: "Media",    onClick: () => openMediaPicker() },
    { id: "audio",    icon: Music,       label: "Audio",    onClick: () => setMusicSheetOpen(true) },
    { id: "voice",    icon: Mic,         label: "Voice",    onClick: () => setActiveTool("voice"), active: activeTool === "voice" },
    { id: "text",     icon: Type,        label: "Text",     onClick: () => { setActiveTool("draw"); setInkSubTool("text"); setDrawMinimized(false); }, active: activeTool === "draw" && inkSubTool === "text" },
    { id: "draw",     icon: Brush,       label: "Draw",     onClick: () => { setActiveTool("draw"); setInkSubTool("brush"); setDrawMinimized(false); }, active: activeTool === "draw" && inkSubTool === "brush" },
    { id: "aidirector", icon: Wand2,     label: "AI Director", onClick: () => setActiveTool("aidirector"), active: activeTool === "aidirector" },
    { id: "effects",  icon: Layers,      label: "Effects",  onClick: () => setActiveTool("effects"), active: activeTool === "effects" },
    { id: "filters",  icon: Sparkles,    label: "Filters",  onClick: () => setActiveTool("filters"), active: activeTool === "filters" },
    { id: "backgrounds", icon: Images,   label: "Backgrounds", onClick: () => setActiveTool("backgrounds"), active: activeTool === "backgrounds" },
  ].map(t =>
    membershipLevel === "free" && studioPremiumTools.has(t.id) ? { ...t, locked: true } : t
  );
  // Progressive disclosure — the default rail keeps the core six; "More tools"
  // reveals the fuller suite (Voice, AI Director, Effects, Backgrounds — the
  // premium-locked upsell tools live behind it, badged ✦).
  const SIMPLE_TOOLS = new Set(["capture", "media", "audio", "text", "draw", "filters"]);
  const visibleTools = railExpanded ? LEFT_TOOLS : LEFT_TOOLS.filter(t => SIMPLE_TOOLS.has(t.id));
  const toggleRail = () => setRailExpanded(v => {
    const next = !v;
    try { localStorage.setItem(RAIL_EXPANDED_KEY, next ? "1" : "0"); } catch { /* ignore */ }
    return next;
  });

  // Graded filter thumbnail — the hero frame with the (intensity-scaled) grade so
  // previews read true, mirroring how the grade bakes into capture.
  const renderFilterThumb = (f: FilterDef, scaled: boolean) => (
    <div className="relative w-full h-full overflow-hidden" style={{ borderRadius: 12, background: f.swatch }}>
      <img
        src={filterBase}
        alt={f.label}
        className="w-full h-full object-cover"
        style={{ filter: scaled ? scaleFilterCss(f.css, filterIntensity / 100) : (f.css || "none") }}
        draggable={false}
      />
      {f.id === "neonrain" && (
        <span aria-hidden className="absolute inset-0 pointer-events-none"
          style={{
            backgroundImage:
              "repeating-linear-gradient(104deg, rgba(190,235,255,.6) 0 1px, transparent 1px 7px), repeating-linear-gradient(101deg, rgba(120,180,255,.4) 0 1px, transparent 1px 11px)",
            mixBlendMode: "screen",
            animation: "r2cNeonRainThumb .7s linear infinite",
          }} />
      )}
      {f.id === "neonpatriot" && (
        <>
          <span aria-hidden className="absolute inset-0 pointer-events-none"
            style={{
              backgroundImage:
                "repeating-linear-gradient(0deg, rgba(226,59,78,.6) 0 12%, rgba(248,250,252,.5) 12% 22%), linear-gradient(120deg, rgba(59,111,255,.6), transparent 60%)",
              mixBlendMode: "screen",
              animation: "r2cNeonPatriotThumb 1.2s ease-in-out infinite",
            }} />
          <span aria-hidden className="absolute inset-0 pointer-events-none"
            style={{ boxShadow: "inset 0 0 14px rgba(226,59,78,.55), inset 0 0 22px rgba(59,111,255,.45)" }} />
        </>
      )}
      {f.id === "beautyx" && (
        <>
          <span aria-hidden className="absolute inset-0 pointer-events-none"
            style={{
              background:
                "radial-gradient(120% 80% at 50% 18%, rgba(123,232,255,.5), transparent 60%), radial-gradient(90% 70% at 50% 100%, rgba(111,123,255,.45), transparent 60%)",
              mixBlendMode: "screen",
              animation: "r2cBeautyXThumb 2.4s ease-in-out infinite",
            }} />
          <span aria-hidden className="absolute inset-0 pointer-events-none"
            style={{
              backgroundImage:
                "radial-gradient(circle at 28% 72%, rgba(190,240,255,.9) 0 1.5px, transparent 2px), radial-gradient(circle at 62% 58%, rgba(190,240,255,.8) 0 1.2px, transparent 2px), radial-gradient(circle at 46% 40%, rgba(200,245,255,.85) 0 1.6px, transparent 2px)",
              mixBlendMode: "screen",
              animation: "r2cBeautyXBubbles 3.2s linear infinite",
            }} />
          <span aria-hidden className="absolute inset-0 pointer-events-none"
            style={{ boxShadow: "inset 0 0 16px rgba(123,232,255,.5), inset 0 0 26px rgba(111,123,255,.4)" }} />
        </>
      )}
      {f.id === "solargraph" && (
        <>
          <span aria-hidden className="absolute inset-0 pointer-events-none"
            style={{
              background:
                "linear-gradient(180deg, rgba(26,46,74,.9) 0%, rgba(139,58,0,.45) 45%, rgba(192,100,0,.5) 72%, rgba(245,223,170,.35) 100%)",
              mixBlendMode: "overlay",
            }} />
          <span aria-hidden className="absolute inset-0 pointer-events-none"
            style={{
              background: "radial-gradient(70% 55% at 50% 96%, rgba(245,223,170,.6), transparent 70%)",
              mixBlendMode: "screen",
              animation: "r2cSolargraphGlow 3s ease-in-out infinite",
            }} />
          <span aria-hidden className="absolute inset-0 pointer-events-none"
            style={{
              backgroundImage:
                "repeating-linear-gradient(6deg, rgba(245,223,170,.45) 0 1px, transparent 1px 11px)",
              WebkitMaskImage: "linear-gradient(180deg, #000 0%, transparent 55%)",
              maskImage: "linear-gradient(180deg, #000 0%, transparent 55%)",
              mixBlendMode: "screen",
              animation: "r2cSolargraphArc 5s linear infinite",
            }} />
        </>
      )}
      {f.id === "carnival" && (
        <>
          {/* Feather crown arc fanning from the top + festive teal/magenta glow. */}
          <span aria-hidden className="absolute inset-0 pointer-events-none"
            style={{
              backgroundImage:
                "conic-gradient(from 270deg at 50% 4%, rgba(25,224,208,.7) 0deg, rgba(255,54,196,.7) 60deg, rgba(246,201,69,.7) 120deg, transparent 150deg, transparent 210deg, rgba(25,224,208,.7) 240deg, rgba(255,54,196,.7) 300deg, rgba(246,201,69,.7) 360deg)",
              WebkitMaskImage: "linear-gradient(180deg, #000 0%, transparent 48%)",
              maskImage: "linear-gradient(180deg, #000 0%, transparent 48%)",
              mixBlendMode: "screen",
              animation: "r2cCarnivalThumb 2.6s ease-in-out infinite",
            }} />
          {/* Gold tiara band hint just under the crown. */}
          <span aria-hidden className="absolute inset-0 pointer-events-none"
            style={{
              background: "radial-gradient(120% 18% at 50% 30%, rgba(246,201,69,.85), transparent 70%)",
              mixBlendMode: "screen",
            }} />
          {/* Sparkly face-gem specks across the brow/cheeks. */}
          <span aria-hidden className="absolute inset-0 pointer-events-none"
            style={{
              backgroundImage:
                "radial-gradient(circle at 38% 46%, rgba(25,224,208,.95) 0 1.4px, transparent 2px), radial-gradient(circle at 62% 46%, rgba(25,224,208,.95) 0 1.4px, transparent 2px), radial-gradient(circle at 50% 40%, rgba(255,54,196,.95) 0 1.6px, transparent 2px), radial-gradient(circle at 30% 60%, rgba(255,54,196,.85) 0 1.3px, transparent 2px), radial-gradient(circle at 70% 60%, rgba(246,201,69,.9) 0 1.3px, transparent 2px)",
              mixBlendMode: "screen",
              animation: "r2cCarnivalGems 1.8s ease-in-out infinite",
            }} />
        </>
      )}
    </div>
  );

  // Segmented Low/Med/High control used by the Neon Rain panel.
  const renderNeonSeg = (label: string, value: NeonRainLevel, onChange: (v: NeonRainLevel) => void) => (
    <div className="flex items-center justify-between gap-2">
      <span className="text-[11px] font-semibold" style={{ color: "#A9B8CA" }}>{label}</span>
      <div className="flex rounded-full overflow-hidden" style={{ border: "1px solid rgba(120,160,255,.22)" }}>
        {NEON_RAIN_LEVELS.map(lv => {
          const sel = value === lv.id;
          return (
            <button key={lv.id} type="button" onClick={() => onChange(lv.id)}
              className="px-2.5 h-6 text-[10px] font-bold transition-colors"
              style={{ background: sel ? "#22C7F2" : "transparent", color: sel ? "#06121f" : "#A9B8CA" }}>
              {lv.label}
            </button>
          );
        })}
      </div>
    </div>
  );

  // Neon Rain dedicated controls (rain amount / glow / lens droplets / reset / original).
  const renderNeonRainControls = () => (
    <div className="flex flex-col gap-2.5" style={{ minWidth: 170 }}>
      <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide" style={{ color: "#22C7F2" }}>
        <CloudRain className="w-3.5 h-3.5" /> Neon Rain
      </div>
      {renderNeonSeg("Rain", neonRainParams.rainAmount, v => setNeonRainParams(p => ({ ...p, rainAmount: v })))}
      {renderNeonSeg("Glow", neonRainParams.glowStrength, v => setNeonRainParams(p => ({ ...p, glowStrength: v })))}
      <div className="flex items-center justify-between gap-2">
        <span className="text-[11px] font-semibold" style={{ color: "#A9B8CA" }}>Lens droplets</span>
        <button type="button" aria-pressed={neonRainParams.lensDroplets}
          onClick={() => setNeonRainParams(p => ({ ...p, lensDroplets: !p.lensDroplets }))}
          className="relative h-5 w-9 rounded-full transition-colors shrink-0"
          style={{ background: neonRainParams.lensDroplets ? "#22C7F2" : "rgba(255,255,255,.14)" }}>
          <span className="absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all"
            style={{ left: neonRainParams.lensDroplets ? 18 : 2 }} />
        </button>
      </div>
      <div className="flex items-center gap-2">
        <button type="button" onClick={resetNeonRain}
          className="flex items-center gap-1 px-2.5 h-7 rounded-full text-[11px] font-semibold"
          style={{ background: "rgba(255,255,255,.06)", color: "#A9B8CA", border: "1px solid rgba(255,255,255,.12)" }}>
          <RotateCcw className="w-3 h-3" /> Reset
        </button>
        <button type="button" onClick={() => selectFilter("none")}
          className="flex items-center gap-1 px-2.5 h-7 rounded-full text-[11px] font-semibold"
          style={{ background: "rgba(255,255,255,.06)", color: "#A9B8CA", border: "1px solid rgba(255,255,255,.12)" }}>
          Original
        </button>
      </div>
    </div>
  );

  // Generic Low/Med/High (or stretch) segmented control for the Neon Patriot panel.
  function renderNPSeg<T extends string>(
    label: string, opts: { id: T; label: string }[], value: T, onChange: (v: T) => void,
  ) {
    return (
      <div className="flex items-center justify-between gap-2">
        <span className="text-[11px] font-semibold" style={{ color: "#A9B8CA" }}>{label}</span>
        <div className="flex rounded-full overflow-hidden" style={{ border: "1px solid rgba(226,59,78,.3)" }}>
          {opts.map(o => {
            const sel = value === o.id;
            return (
              <button key={o.id} type="button" onClick={() => onChange(o.id)}
                className="px-2.5 h-6 text-[10px] font-bold transition-colors"
                style={{ background: sel ? "#E23B4E" : "transparent", color: sel ? "#fff" : "#A9B8CA" }}>
                {o.label}
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  // Neon Patriot dedicated controls (glow / translucency / flag stretch / reset / original).
  // Intensity is the shared Filters slider (seeded to 80 on switch-in), mirroring Neon Rain.
  const renderNeonPatriotControls = () => (
    <div className="flex flex-col gap-2.5" style={{ minWidth: 170 }}>
      <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide" style={{ color: "#E23B4E" }}>
        <Flag className="w-3.5 h-3.5" /> Neon Patriot
      </div>
      {renderNPSeg("Glow", NP_LEVELS, neonPatriotParams.glow, v => setNeonPatriotParams(p => ({ ...p, glow: v })))}
      {renderNPSeg("Translucency", NP_LEVELS, neonPatriotParams.translucency, v => setNeonPatriotParams(p => ({ ...p, translucency: v })))}
      {renderNPSeg("Flag stretch", NP_STRETCHES, neonPatriotParams.stretch, v => setNeonPatriotParams(p => ({ ...p, stretch: v })))}
      <div className="flex items-center gap-2">
        <button type="button" onClick={resetNeonPatriot}
          className="flex items-center gap-1 px-2.5 h-7 rounded-full text-[11px] font-semibold"
          style={{ background: "rgba(255,255,255,.06)", color: "#A9B8CA", border: "1px solid rgba(255,255,255,.12)" }}>
          <RotateCcw className="w-3 h-3" /> Reset
        </button>
        <button type="button" onClick={() => selectFilter("none")}
          className="flex items-center gap-1 px-2.5 h-7 rounded-full text-[11px] font-semibold"
          style={{ background: "rgba(255,255,255,.06)", color: "#A9B8CA", border: "1px solid rgba(255,255,255,.12)" }}>
          Original
        </button>
      </div>
    </div>
  );

  // ── Beauty X controls (compact slider rail + mobile strip) ──────────────────────
  const BX_CYAN = "#7be8ff";
  const renderBXSlider = (label: string, value: number, onChange: (v: number) => void) => (
    <div className="flex flex-col gap-0.5">
      <div className="flex items-center justify-between text-[10px] font-semibold" style={{ color: "#A9B8CA" }}>
        <span>{label}</span><span style={{ color: BX_CYAN }}>{value}</span>
      </div>
      <input type="range" min={0} max={100} step={1} value={value}
        onChange={e => onChange(Number(e.target.value))}
        className="w-full" style={{ accentColor: BX_CYAN, height: 4 }} />
    </div>
  );
  const renderBXSeg = (label: string, value: BXLevel, onChange: (v: BXLevel) => void) => (
    <div className="flex items-center justify-between gap-2">
      <span className="text-[11px] font-semibold" style={{ color: "#A9B8CA" }}>{label}</span>
      <div className="flex rounded-full overflow-hidden" style={{ border: "1px solid rgba(123,232,255,.3)" }}>
        {BX_LEVELS.map(o => {
          const sel = value === o.id;
          return (
            <button key={o.id} type="button" onClick={() => onChange(o.id)}
              className="px-2.5 h-6 text-[10px] font-bold transition-colors"
              style={{ background: sel ? BX_CYAN : "transparent", color: sel ? "#06121f" : "#A9B8CA" }}>
              {o.label}
            </button>
          );
        })}
      </div>
    </div>
  );
  const renderBXToggle = (label: string, value: boolean, onChange: () => void) => (
    <div className="flex items-center justify-between gap-2">
      <span className="text-[11px] font-semibold" style={{ color: "#A9B8CA" }}>{label}</span>
      <button type="button" aria-pressed={value} onClick={onChange}
        className="relative h-5 w-9 rounded-full transition-colors shrink-0"
        style={{ background: value ? BX_CYAN : "rgba(255,255,255,.14)" }}>
        <span className="absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all" style={{ left: value ? 18 : 2 }} />
      </button>
    </div>
  );
  // Beauty X dedicated controls (Beauty Level presets + every feature slider +
  // Bubbles/Light Rays toggles + Reset/Original). Intensity is the shared Filters
  // slider (seeded to 100 on switch-in), mirroring Neon Rain / Neon Patriot.
  const set = (patch: Partial<BeautyXParams>) => setBeautyXParams(p => ({ ...p, ...patch }));
  const renderBeautyXControls = () => (
    <div className="flex flex-col gap-2" style={{ minWidth: 196, maxWidth: 236 }}>
      <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide" style={{ color: BX_CYAN }}>
        <Sparkles className="w-3.5 h-3.5" /> Beauty X
      </div>
      {renderBXSeg("Beauty Level", beautyXParams.level, applyBeautyXLevel)}
      <div className="flex flex-col gap-1.5 pr-1" style={{ maxHeight: 196, overflowY: "auto" }}>
        {renderBXSlider("Skin Smoothing", beautyXParams.skinSmooth, v => set({ skinSmooth: v }))}
        {renderBXSlider("Skin Brightness", beautyXParams.skinBright, v => set({ skinBright: v }))}
        {renderBXSlider("Tone Evenness", beautyXParams.skinEven, v => set({ skinEven: v }))}
        {renderBXSlider("Face Slimming", beautyXParams.faceSlim, v => set({ faceSlim: v }))}
        {renderBXSlider("Eye Enlargement", beautyXParams.eyeEnlarge, v => set({ eyeEnlarge: v }))}
        {renderBXSlider("Eye Brightness", beautyXParams.eyeBright, v => set({ eyeBright: v }))}
        {renderBXSlider("Teeth Whitening", beautyXParams.teethWhiten, v => set({ teethWhiten: v }))}
        {renderBXSlider("Sharpness", beautyXParams.sharpness, v => set({ sharpness: v }))}
        {renderBXSlider("Glow", beautyXParams.glow, v => set({ glow: v }))}
        {renderBXSlider("Hair Float", beautyXParams.hairFloat, v => set({ hairFloat: v }))}
        {renderBXSlider("Hair Volume", beautyXParams.hairVolume, v => set({ hairVolume: v }))}
        {renderBXSlider("Underwater FX", beautyXParams.underwaterFx, v => set({ underwaterFx: v }))}
      </div>
      {renderBXToggle("Bubbles", beautyXParams.bubbles, () => set({ bubbles: !beautyXParams.bubbles }))}
      {renderBXToggle("Light Rays", beautyXParams.lightRays, () => set({ lightRays: !beautyXParams.lightRays }))}
      <div className="flex items-center gap-2">
        <button type="button" onClick={resetBeautyX}
          className="flex items-center gap-1 px-2.5 h-7 rounded-full text-[11px] font-semibold"
          style={{ background: "rgba(255,255,255,.06)", color: "#A9B8CA", border: "1px solid rgba(255,255,255,.12)" }}>
          <RotateCcw className="w-3 h-3" /> Reset
        </button>
        <button type="button" onClick={() => selectFilter("none")}
          className="flex items-center gap-1 px-2.5 h-7 rounded-full text-[11px] font-semibold"
          style={{ background: "rgba(255,255,255,.06)", color: "#A9B8CA", border: "1px solid rgba(255,255,255,.12)" }}>
          Original
        </button>
      </div>
    </div>
  );

  // ── Solargraph controls (compact slider rail + mobile strip) ────────────────────
  const SG_AMBER = "#C06400";
  const renderSGSlider = (label: string, value: number, onChange: (v: number) => void) => (
    <div className="flex flex-col gap-0.5">
      <div className="flex items-center justify-between text-[10px] font-semibold" style={{ color: "#C9B79A" }}>
        <span>{label}</span><span style={{ color: SG_AMBER }}>{value}</span>
      </div>
      <input type="range" min={0} max={100} step={1} value={value}
        onChange={e => onChange(Number(e.target.value))}
        className="w-full" style={{ accentColor: SG_AMBER, height: 4 }} />
    </div>
  );
  const renderSGToggle = (label: string, value: boolean, onChange: () => void) => (
    <div className="flex items-center justify-between gap-2">
      <span className="text-[11px] font-semibold" style={{ color: "#C9B79A" }}>{label}</span>
      <button type="button" aria-pressed={value} onClick={onChange}
        className="relative h-5 w-9 rounded-full transition-colors shrink-0"
        style={{ background: value ? SG_AMBER : "rgba(255,255,255,.14)" }}>
        <span className="absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all" style={{ left: value ? 18 : 2 }} />
      </button>
    </div>
  );
  // Solargraph dedicated controls — Color Grade / Blue Bleed / Halation / Arc Streaks
  // / Film Grain sliders + Arc Streaks & Film Grain toggles + Reset/Original. Intensity
  // is the shared Filters slider (seeded to 100 on switch-in), mirroring Beauty X.
  const setSG = (patch: Partial<SolargraphParams>) => setSolargraphParams(p => ({ ...p, ...patch }));
  const renderSolargraphControls = () => (
    <div className="flex flex-col gap-2" style={{ minWidth: 196, maxWidth: 236 }}>
      <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide" style={{ color: SG_AMBER }}>
        <Sun className="w-3.5 h-3.5" /> Solargraph
      </div>
      <div className="flex flex-col gap-1.5 pr-1" style={{ maxHeight: 196, overflowY: "auto" }}>
        {renderSGSlider("Color Grade", solargraphParams.grade, v => setSG({ grade: v }))}
        {renderSGSlider("Blue Bleed", solargraphParams.blueBleed, v => setSG({ blueBleed: v }))}
        {renderSGSlider("Halation", solargraphParams.halation, v => setSG({ halation: v }))}
        {renderSGSlider("Arc Streaks", solargraphParams.arcStreaks, v => setSG({ arcStreaks: v }))}
        {renderSGSlider("Film Grain", solargraphParams.grain, v => setSG({ grain: v }))}
      </div>
      {renderSGToggle("Arc Streaks", solargraphParams.arcsOn, () => setSG({ arcsOn: !solargraphParams.arcsOn }))}
      {renderSGToggle("Film Grain", solargraphParams.grainOn, () => setSG({ grainOn: !solargraphParams.grainOn }))}
      <div className="flex items-center gap-2">
        <button type="button" onClick={resetSolargraph}
          className="flex items-center gap-1 px-2.5 h-7 rounded-full text-[11px] font-semibold"
          style={{ background: "rgba(255,255,255,.06)", color: "#C9B79A", border: "1px solid rgba(255,255,255,.12)" }}>
          <RotateCcw className="w-3 h-3" /> Reset
        </button>
        <button type="button" onClick={() => selectFilter("none")}
          className="flex items-center gap-1 px-2.5 h-7 rounded-full text-[11px] font-semibold"
          style={{ background: "rgba(255,255,255,.06)", color: "#C9B79A", border: "1px solid rgba(255,255,255,.12)" }}>
          Original
        </button>
      </div>
    </div>
  );

  // Carnival dedicated controls — Style preset (Elegant / Festival / Full Glam) +
  // Reset/Original. Intensity is the shared Filters slider (seeded to 85 on
  // switch-in); the feathers/gems/makeup auto-appear the instant a face is detected.
  const CV_MAGENTA = "#ff36c4";
  const renderCarnivalStyleSeg = () => (
    <div className="flex items-center justify-between gap-2">
      <span className="text-[11px] font-semibold" style={{ color: "#A9B8CA" }}>Style</span>
      <div className="flex rounded-full overflow-hidden" style={{ border: "1px solid rgba(255,54,196,.3)" }}>
        {CARNIVAL_STYLES.map(o => {
          const sel = carnivalParams.style === o.id;
          return (
            <button key={o.id} type="button" onClick={() => setCarnivalParams(p => ({ ...p, style: o.id as CarnivalStyle }))}
              className="px-2.5 h-6 text-[10px] font-bold transition-colors"
              style={{ background: sel ? CV_MAGENTA : "transparent", color: sel ? "#fff" : "#A9B8CA" }}>
              {o.label}
            </button>
          );
        })}
      </div>
    </div>
  );
  const renderCarnivalControls = () => (
    <div className="flex flex-col gap-2.5" style={{ minWidth: 188 }}>
      <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide" style={{ color: CV_MAGENTA }}>
        <Sparkles className="w-3.5 h-3.5" /> Carnival
      </div>
      {renderCarnivalStyleSeg()}
      <div className="flex items-center gap-2">
        <button type="button" onClick={resetCarnival}
          className="flex items-center gap-1 px-2.5 h-7 rounded-full text-[11px] font-semibold"
          style={{ background: "rgba(255,255,255,.06)", color: "#A9B8CA", border: "1px solid rgba(255,255,255,.12)" }}>
          <RotateCcw className="w-3 h-3" /> Reset
        </button>
        <button type="button" onClick={() => selectFilter("none")}
          className="flex items-center gap-1 px-2.5 h-7 rounded-full text-[11px] font-semibold"
          style={{ background: "rgba(255,255,255,.06)", color: "#A9B8CA", border: "1px solid rgba(255,255,255,.12)" }}>
          Original
        </button>
      </div>
    </div>
  );

  // ── Neon Mood controls — On/Off, Mood Lock, Glow (Low/Med/High), Line Thickness
  // + Caricature sliders, Reset/Original. Intensity is the shared Filters slider
  // (seeded to 85 on switch-in). Glow = High ALSO turns on the auto-black neon-studio
  // background (segmentation-gated; bakes into photo/video capture).
  const NM_GREEN = "#39ff14";
  const setNM = (patch: Partial<NeonMoodParams>) => setNeonMoodParams(p => ({ ...p, ...patch }));
  const renderNMSlider = (label: string, value: number, onChange: (v: number) => void) => (
    <div className="flex flex-col gap-0.5">
      <div className="flex items-center justify-between text-[10px] font-semibold" style={{ color: "#BFE8B0" }}>
        <span>{label}</span><span style={{ color: NM_GREEN }}>{value}</span>
      </div>
      <input type="range" min={0} max={100} step={1} value={value}
        onChange={e => onChange(Number(e.target.value))}
        className="w-full" style={{ accentColor: NM_GREEN, height: 4 }} />
    </div>
  );
  const renderNMToggle = (label: string, value: boolean, onChange: () => void) => (
    <div className="flex items-center justify-between gap-2">
      <span className="text-[11px] font-semibold" style={{ color: "#BFE8B0" }}>{label}</span>
      <button type="button" aria-pressed={value} onClick={onChange}
        className="relative h-5 w-9 rounded-full transition-colors shrink-0"
        style={{ background: value ? NM_GREEN : "rgba(255,255,255,.14)" }}>
        <span className="absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all" style={{ left: value ? 18 : 2 }} />
      </button>
    </div>
  );
  const renderNMGlowSeg = () => (
    <div className="flex items-center justify-between gap-2">
      <span className="text-[11px] font-semibold" style={{ color: "#BFE8B0" }}>Glow</span>
      <div className="flex rounded-full overflow-hidden" style={{ border: "1px solid rgba(57,255,20,.3)" }}>
        {NM_GLOW_LEVELS.map(o => {
          const sel = neonMoodParams.glow === o.id;
          return (
            <button key={o.id} type="button" onClick={() => setNM({ glow: o.id })}
              className="px-2.5 h-6 text-[10px] font-bold transition-colors"
              style={{ background: sel ? NM_GREEN : "transparent", color: sel ? "#04140a" : "#BFE8B0" }}>
              {o.label}
            </button>
          );
        })}
      </div>
    </div>
  );
  const renderNeonMoodControls = () => (
    <div className="flex flex-col gap-2" style={{ minWidth: 196, maxWidth: 236 }}>
      <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide" style={{ color: NM_GREEN }}>
        <Sparkles className="w-3.5 h-3.5" /> Neon Mood
      </div>
      {renderNMToggle("Effect", neonMoodParams.enabled, () => setNM({ enabled: !neonMoodParams.enabled }))}
      {renderNMToggle("Mood Lock", neonMoodParams.moodLock, () => setNM({ moodLock: !neonMoodParams.moodLock }))}
      {renderNMGlowSeg()}
      <div className="flex flex-col gap-1.5 pr-1">
        {renderNMSlider("Line Thickness", neonMoodParams.lineThickness, v => setNM({ lineThickness: v }))}
        {renderNMSlider("Caricature", neonMoodParams.caricature, v => setNM({ caricature: v }))}
      </div>
      <p className="text-[9px] leading-tight" style={{ color: "#7FA876" }}>
        Glow = High adds an auto-black neon studio background.
      </p>
      <div className="flex items-center gap-2">
        <button type="button" onClick={resetNeonMood}
          className="flex items-center gap-1 px-2.5 h-7 rounded-full text-[11px] font-semibold"
          style={{ background: "rgba(255,255,255,.06)", color: "#BFE8B0", border: "1px solid rgba(255,255,255,.12)" }}>
          <RotateCcw className="w-3 h-3" /> Reset
        </button>
        <button type="button" onClick={() => selectFilter("none")}
          className="flex items-center gap-1 px-2.5 h-7 rounded-full text-[11px] font-semibold"
          style={{ background: "rgba(255,255,255,.06)", color: "#BFE8B0", border: "1px solid rgba(255,255,255,.12)" }}>
          Original
        </button>
      </div>
    </div>
  );

  const activeFilterId: FilterId = (filterStack[0] ?? "none") as FilterId;

  return (
    <div
      className="r2c-editor r2c-luxstudio r2c-lux-grain relative w-full h-full overflow-hidden select-none flex flex-col"
      style={{ background: "#040814", color: "#F8FAFC", paddingBottom: "env(safe-area-inset-bottom, 0px)" }}
    >
      <UploadScanOverlay scanStatus={scanStatus} error={scanError} onDismiss={resetScan} />
      <style>{`@keyframes r2cNeonRainThumb{0%{background-position:0 0,0 0}100%{background-position:0 26px,-8px 34px}}@keyframes r2cNeonPatriotThumb{0%,100%{opacity:.55;filter:saturate(1)}50%{opacity:.95;filter:saturate(1.45)}}@keyframes r2cBeautyXThumb{0%,100%{opacity:.6;filter:saturate(1) hue-rotate(0deg)}50%{opacity:1;filter:saturate(1.4) hue-rotate(18deg)}}@keyframes r2cBeautyXBubbles{0%{background-position:0 0,0 0,0 0;opacity:.35}50%{opacity:.9}100%{background-position:0 -90px,0 -130px,0 -110px;opacity:.35}}@keyframes r2cSolargraphGlow{0%,100%{opacity:.5}50%{opacity:.95}}@keyframes r2cSolargraphArc{0%{background-position:0 0}100%{background-position:42px 0}}@keyframes r2cCarnivalThumb{0%,100%{opacity:.6;filter:saturate(1)}50%{opacity:1;filter:saturate(1.5)}}@keyframes r2cCarnivalGems{0%,100%{opacity:.45}50%{opacity:1}}`}</style>
      {/* Hidden picker for the Media tool */}
      <input ref={fileInputRef} type="file" accept="image/*,video/*" multiple hidden onChange={importMedia} />

      {/* Add media — modern import entry (rules up front, one-time ownership ack,
          replace warning, desktop drag & drop). Files flow into importFiles(). */}
      <AddMediaSheet
        open={mediaSheetOpen}
        onClose={() => setMediaSheetOpen(false)}
        hasContent={segments.length > 0 || slides.length > 0 || !!photoUrl}
        needsAck={!uploadAcked}
        maxSlides={MAX_SLIDES}
        onBrowse={browseDevice}
        onFiles={handleSheetFiles}
      />

      {/* ── TOP HEADER ─────────────────────────────────────────────────────────── */}
      {/* Decluttered: the logo IS the way home (tap → close studio); the only other
          header control is Drafts. Expand moved onto the stage; safe-area padding
          keeps everything clear of the iPhone status bar (fixed overlay = no
          document flow, so it must pad env() itself). */}
      <div className="r2c-luxstudio-scrim-top md:hidden pointer-events-none absolute inset-x-0 top-0 z-30 h-36" />
      {/* pointer-events-none on the bar (it floats over the viewfinder on mobile —
          a solid full-width bar would eat stage taps); re-enabled per control. */}
      <header
        className="r2c-luxstudio-header pointer-events-none flex items-center justify-between gap-3 px-4 sm:px-6 shrink-0"
        style={{
          paddingTop: "env(safe-area-inset-top, 0px)",
          minHeight: "calc(3.5rem + env(safe-area-inset-top, 0px))",
        }}
      >
        <div className="pointer-events-auto flex items-center gap-3 min-w-0">
          {/* BrandLogo is itself a button (premium-egg logic lives inside);
              onActivate is its designed route-home hook — tap = close studio. */}
          <BrandLogo size={28} onActivate={onClose} />
        </div>
        {/* Centered lux wordmark — pure branding, never intercepts taps */}
        <div className="pointer-events-none flex flex-col items-center">
          <span className="text-[9px] font-semibold uppercase tracking-[0.32em]" style={{ color: "#6a82a1" }}>
            Camera
          </span>
          <span className="r2c-serif-display italic text-[17px] leading-tight" style={{ color: "#f0f4f8" }}>
            Studio
          </span>
        </div>
        <div className="pointer-events-auto flex items-center gap-2">
          <button
            onClick={() => setDraftsOpen(true)}
            className="r2c-luxstudio-glass relative flex items-center gap-1.5 h-9 px-3 rounded-full text-xs font-medium transition-colors hover:brightness-125"
            style={{ color: "#9aaec5" }}
          >
            <Archive className="w-3.5 h-3.5" /> Drafts
            {draftCount > 0 && (
              <span
                className="min-w-[16px] h-[16px] px-1 rounded-full text-[9px] font-bold flex items-center justify-center"
                style={{ background: "linear-gradient(135deg,#30bbed,#1a65d1)", color: "#04070f" }}
              >
                {draftCount}
              </span>
            )}
          </button>
        </div>
      </header>

      {/* ── MODE TABS ──────────────────────────────────────────────────────────── */}
      <nav className={`${expanded ? "hidden " : "hidden md:flex "}items-center gap-2 px-3 sm:px-6 py-2.5 shrink-0 overflow-x-auto scrollbar-none z-20`}
        style={{ borderBottom: PANEL_BORDER }}>
        {MODES.map(m => {
          const on = creativeMode === m.id;
          const Icon = m.icon;
          return (
            <button
              key={m.id}
              onClick={() => selectMode(m.id)}
              className="flex items-center gap-2 h-9 px-4 rounded-full text-sm font-semibold whitespace-nowrap transition-all"
              style={on
                ? { background: "linear-gradient(135deg,#30bbed,#1a65d1)", color: "#ffffff", boxShadow: "0 6px 22px rgba(26,101,209,.4)" }
                : { ...cardStyle, color: "#A9B8CA" }}
            >
              <Icon className="w-4 h-4" /> {m.label}
            </button>
          );
        })}
      </nav>

      {/* ── MOBILE TOOL RAIL (floating lux glass; left toolbar collapses below md).
          The capture tool is omitted here — on mobile the record orb IS capture. */}
      <div className={`${expanded ? "hidden " : ""}md:hidden r2c-luxstudio-rail flex flex-col items-center gap-2`}>
        {visibleTools.filter(t => t.id !== "capture").map(t => {
          const Icon = t.icon;
          return (
            <button
              key={t.id}
              onClick={t.locked ? () => promptStudioUpgrade(t.label) : t.onClick}
              data-active={t.active ? "true" : undefined}
              className="r2c-luxstudio-glass r2c-luxstudio-tool flex h-[52px] w-[52px] shrink-0 flex-col items-center justify-center gap-0.5 rounded-2xl px-1"
              style={t.active ? undefined : { color: "#9aaec5", opacity: t.locked ? 0.6 : 1 }}
            >
              <Icon className="w-[18px] h-[18px]" />
              <span className="max-w-full truncate text-[8px] font-semibold leading-none">
                {t.label}{t.locked ? " 🔒" : ""}
              </span>
            </button>
          );
        })}
        <button
          onClick={toggleRail}
          className="flex h-[52px] w-[52px] shrink-0 flex-col items-center justify-center gap-0.5 rounded-2xl text-[8px] font-semibold"
          style={{ border: "1px dashed rgba(120,160,255,.35)", color: "#30bbed", background: "rgba(8,14,28,.45)" }}
        >
          {railExpanded ? <ChevronUp className="w-[18px] h-[18px]" /> : <ChevronDown className="w-[18px] h-[18px]" />}
          {railExpanded ? "Less" : "More ✦"}
        </button>
      </div>

      {/* ── BODY: toolbar · stage · inspector ──────────────────────────────────── */}
      <div className="flex-1 min-h-0 flex">

        {/* LEFT TOOLBAR */}
        <aside className="hidden md:flex flex-col items-center gap-1.5 py-4 px-2 shrink-0 overflow-y-auto scrollbar-none"
          style={{ width: 86, borderRight: PANEL_BORDER }}>
          {visibleTools.map(t => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                onClick={t.locked ? () => promptStudioUpgrade(t.label) : t.onClick}
                className="relative w-full flex flex-col items-center gap-1 py-2.5 rounded-2xl text-[10px] font-semibold transition-all"
                style={t.active
                  ? { background: "rgba(34,199,242,.14)", border: "1px solid rgba(34,199,242,.5)", color: "#22C7F2" }
                  : { border: "1px solid transparent", color: "#A9B8CA", opacity: t.locked ? 0.6 : 1 }}
              >
                <Icon className="w-5 h-5" />
                {t.label}
                {t.locked && <span className="absolute top-1 right-1.5 text-[9px] leading-none">🔒</span>}
              </button>
            );
          })}
          <button
            onClick={toggleRail}
            className="relative w-full flex flex-col items-center gap-1 py-2.5 rounded-2xl text-[10px] font-semibold transition-all hover:brightness-125"
            style={{ border: "1px dashed rgba(120,160,255,.3)", color: "#22C7F2" }}
          >
            {railExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
            {railExpanded ? "Less" : "More ✦"}
          </button>
        </aside>

        {/* CENTER COLUMN */}
        <main className="flex-1 min-w-0 flex flex-col p-0 gap-0 md:p-2 md:gap-2 overflow-y-auto">

          {/* STAGE — full-bleed frameless compositor (R1). Fills the available
              height edge-to-edge; the neon frame / 16:9 letterbox were removed so
              the preview is easy to see. All inner overlays stay absolute inset-0. */}
          <div className="relative flex-1 min-h-[50vh]">
            <div
              className="relative w-full h-full overflow-hidden"
              style={{
                background: "#04070E",
              }}
            >
              {/* Camera viewport (kept verbatim: same refs + tap/draw handlers) */}
              <div
                className="r2c-studio-stage absolute inset-0"
                onClick={handleViewportTap}
                onPointerDown={handleDrawDown}
                onPointerMove={handleDrawMove}
                onPointerUp={handleDrawUp}
                onPointerCancel={handleDrawUp}
                style={{
                  cursor: isDrawTool ? "crosshair" : (activeExp?.onTap ? "crosshair" : "default"),
                  touchAction: isDrawTool ? "none" : undefined,
                }}
              >
                {/* Live video */}
                <video
                  ref={videoRef}
                  autoPlay muted playsInline
                  className={cn(
                    "absolute inset-0 w-full h-full object-cover",
                    mirror && !needsCanvas ? "[transform:scaleX(-1)]" : ""
                  )}
                  style={{ filter: activeCss, display: (needsCanvas || hasResult) ? "none" : "block" }}
                />

                {/* Canvas compositor (grade baked by compositeFrame) */}
                <canvas
                  ref={canvasRef}
                  className="absolute inset-0 w-full h-full object-cover"
                  style={{ filter: CANVAS_FILTER_SUPPORTED ? "none" : activeCss, display: (needsCanvas && started && !hasResult) ? "block" : "none" }}
                />

                {/* Photo result */}
                {photoUrl && (
                  <img src={photoUrl} alt="capture"
                    className="absolute inset-0 w-full h-full object-cover"
                    style={{ filter: CANVAS_FILTER_SUPPORTED ? "none" : activeCss }}
                  />
                )}

                {/* AI remake result — shown over the photo with use/dismiss actions. */}
                {photoUrl && remakeUrl && (
                  <div className="absolute inset-0 flex flex-col bg-black/70 backdrop-blur-sm">
                    <div className="flex items-center justify-between px-3 py-2">
                      <span className="flex items-center gap-1.5 text-xs font-bold text-white">
                        <Wand2 className="w-4 h-4" /> AI remake
                      </span>
                      <button onClick={() => setRemakeUrl(null)} className="w-7 h-7 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-white/20" title="Dismiss">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="flex-1 min-h-0 px-3 pb-2">
                      <img src={remakeUrl} alt="AI remake" className="w-full h-full object-contain rounded-xl" />
                    </div>
                    <div className="flex justify-center gap-2 px-3 pb-3">
                      <button onClick={useRemakeAsPhoto} className="r2c-luxstudio-publish flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold">
                        Use this
                      </button>
                      <button onClick={() => setRemakeUrl(null)} className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold text-white" style={{ background: "rgba(255,255,255,.12)" }}>
                        Keep original
                      </button>
                    </div>
                  </div>
                )}

                {/* Slideshow preview */}
                {hasResult && !photoUrl && segments.length === 0 && slides.length > 0 && (
                  <div className="absolute inset-x-0 top-0 bottom-0 overflow-y-auto p-3">
                    <div className="flex items-center gap-2 mb-2 text-white/80">
                      <Images className="w-4 h-4" />
                      <span className="text-xs font-semibold">{slides.length} photo{slides.length === 1 ? "" : "s"} · ~{Math.round(slides.length * SLIDE_SEC)}s slideshow</span>
                    </div>
                    <div className="grid grid-cols-4 gap-1.5">
                      {slides.map((s, i) => (
                        <div key={i} className="relative aspect-square rounded-lg overflow-hidden border border-white/10">
                          <img src={s} alt={`slide ${i + 1}`} className="w-full h-full object-cover" />
                          <span className="absolute top-0.5 left-0.5 px-1 rounded bg-black/60 text-white text-[9px] font-bold">{i + 1}</span>
                          <button
                            onClick={() => setSlides(prev => prev.filter((_, j) => j !== i))}
                            className="absolute top-0.5 right-0.5 w-5 h-5 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-red-500"
                            title="Remove"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Video editor (trim / splice) */}
                {hasResult && !photoUrl && segments.length > 0 && (
                  <div className="absolute inset-0">
                    <VideoEditor
                      segments={segments}
                      onChange={setSegments}
                      onAddClip={addClip}
                      maxSeconds={MAX_VIDEO_SEC}
                      muteAudio={muteVideoAudio}
                    />
                  </div>
                )}

                {/* Not-started placeholder */}
                {!started && !hasResult && !isFancy && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 text-center px-6">
                    <div className="w-16 h-16 rounded-full flex items-center justify-center"
                      style={{ background: "rgba(34,199,242,.1)", border: "1px solid rgba(34,199,242,.35)" }}>
                      {creativeMode === "canvas" ? <PenTool className="w-7 h-7" style={{ color: "#22C7F2" }} /> : <Camera className="w-7 h-7" style={{ color: "#22C7F2" }} />}
                    </div>
                    <p className="text-sm font-medium" style={{ color: "#A9B8CA" }}>
                      {creativeMode === "canvas" ? "Tap Capture to open the drawing canvas" : creativeMode === "slideshow" ? "Tap Capture to start the slideshow" : "Tap Capture to start the camera"}
                    </p>
                    {creativeMode !== "canvas" && (
                      <button
                        onClick={openMediaPicker}
                        className="flex items-center gap-2 h-9 px-4 rounded-full text-sm font-semibold transition-all hover:brightness-125"
                        style={{ background: "rgba(34,199,242,.12)", border: "1px solid rgba(34,199,242,.4)", color: "#22C7F2" }}
                      >
                        <ImagePlus className="w-4 h-4" /> Add from device
                      </button>
                    )}
                    {activeExp && (
                      <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 border border-white/20">
                        <span className="text-lg">{activeExp.previewEmoji}</span>
                        <span className="text-xs text-white font-medium">{activeExp.label} ready</span>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Fancy Notes — self-contained composer over the stage */}
              {isFancy && (
                <FancyInkComposer ref={fancyRef} className="absolute inset-0 w-full h-full" />
              )}

              {/* Rule-of-thirds grid */}
              {gridOn && !isFancy && (
                <div className="absolute inset-0 pointer-events-none z-[15]" style={{
                  backgroundImage: "linear-gradient(rgba(255,255,255,.16) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.16) 1px,transparent 1px)",
                  backgroundSize: "33.333% 33.333%",
                }} />
              )}

              {/* Flash overlay */}
              {flashActive && <div className="absolute inset-0 bg-white z-30 pointer-events-none animate-fade-out" />}

              {/* Countdown */}
              {countdown !== null && (
                <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/40 pointer-events-none">
                  <span key={countdown} className="text-8xl font-black text-white"
                    style={{ textShadow: "0 0 40px rgba(255,255,255,0.6)", animation: "countPop 0.9s ease-out forwards" }}>
                    {countdown === 0 ? "●" : countdown}
                  </span>
                </div>
              )}

              {/* Stage overlays (hidden in Fancy Notes / result review) */}
              {!isFancy && !hasResult && (
                <>
                  {/* TL — resolution (lux chip; mobile sits below the floating header) */}
                  <div className="r2c-luxstudio-reschip r2c-luxstudio-glass absolute z-20 flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wide"
                    style={{ color: "#9aaec5" }}>
                    <span style={{ color: "#30bbed" }}>●</span> 1080p · 60fps
                  </div>

                  {/* Expand + flash + camera — left column under the res chip on
                      mobile (lux layout), top-right row on md+ */}
                  <div className="r2c-luxstudio-stagechips absolute z-20 flex gap-2">
                    <button
                      onClick={() => setExpanded(v => !v)}
                      aria-label={expanded ? "Exit full-screen preview" : "Full-screen preview"}
                      className="w-9 h-9 rounded-full flex items-center justify-center transition-all"
                      style={{ ...cardStyle, color: "#F8FAFC" }}
                    >
                      {expanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                    </button>
                    <button
                      onClick={() => setFlash(v => !v)}
                      aria-label="Flash"
                      className="w-9 h-9 rounded-full flex items-center justify-center transition-all"
                      style={flash ? { background: "#F6B94A", color: "#06101F" } : { ...cardStyle, color: "#F8FAFC" }}
                    >
                      {flash ? <Zap className="w-4 h-4" /> : <ZapOff className="w-4 h-4" />}
                    </button>
                    {!isCanvasSource && (
                      <button
                        onClick={switchCamera}
                        aria-label="Switch camera"
                        title={facingMode === "user" ? "Switch to back camera" : "Switch to front camera"}
                        className="relative w-9 h-9 rounded-full flex items-center justify-center transition-all active:scale-90"
                        style={{ ...cardStyle, color: "#F8FAFC" }}
                      >
                        <RotateCcw className="w-4 h-4" />
                        <span className={cn(
                          "absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border border-black text-[7px] font-black flex items-center justify-center",
                          facingMode === "user" ? "bg-blue-400" : "bg-orange-400"
                        )}>
                          {facingMode === "user" ? "F" : "B"}
                        </span>
                      </button>
                    )}
                  </div>

                  {/* BC — timer (raised above the floating deck on mobile) */}
                  <div className="r2c-luxstudio-timer r2c-luxstudio-glass absolute left-1/2 -translate-x-1/2 z-30 flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold font-mono">
                    {recording && <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />}
                    <span style={{ color: recording ? "#FF4FD8" : "#A9B8CA" }}>
                      {fmtTime(recording ? duration : 0)}{maxDuration != null ? ` / ${fmtTime(maxDuration)}` : ""}
                    </span>
                  </div>

                </>
              )}

              {/* Slide Show capture controls — count + Done (finishSlides) */}
              {creativeMode === "slideshow" && started && !hasResult && (
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 translate-y-[64px] z-30 flex items-center gap-2 px-2.5 py-2 rounded-2xl"
                  style={{ background: "rgba(7,13,24,.82)", border: PANEL_BORDER, backdropFilter: "blur(18px)" }}>
                  <span className="px-1.5 text-[11px] font-semibold" style={{ color: "#A9B8CA" }}>
                    {slides.length} / {MAX_SLIDES} photos
                  </span>
                  <button
                    onClick={finishSlides}
                    disabled={slides.length === 0}
                    className="r2c-luxstudio-publish flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold disabled:opacity-40"
                  >
                    <Check className="w-4 h-4" /> Done
                  </button>
                </div>
              )}

              {/* Permission error */}
              {permissionError && !started && !hasResult && (
                <div className="r2c-luxstudio-raised absolute left-4 right-4 z-30 flex items-start gap-2 bg-red-900/80 backdrop-blur-sm border border-red-500/40 rounded-2xl p-3 text-xs text-red-200">
                  <span className="text-lg leading-none">⚠</span>
                  {permissionError}
                </div>
              )}

              {/* Result actions (after capture) */}
              {hasResult && !publishing && (
                <div className="r2c-luxstudio-raised absolute left-1/2 -translate-x-1/2 z-30 flex flex-wrap justify-center max-w-[calc(100%-16px)] gap-2 px-2.5 py-2 rounded-2xl"
                  style={{ background: "rgba(7,13,24,.82)", border: PANEL_BORDER, backdropFilter: "blur(18px)" }}>
                  {!photoUrl && (
                    <button onClick={addClip} className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold" style={{ background: "rgba(255,255,255,.08)" }}>
                      <Plus className="w-4 h-4" /> Add clip
                    </button>
                  )}
                  <button onClick={retake} className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold" style={{ background: "rgba(255,255,255,.08)" }}>
                    <RotateCcw className="w-4 h-4" /> {photoUrl ? "Retake" : "Start over"}
                  </button>
                  {photoUrl && (
                    <button onClick={download} className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold" style={{ background: "rgba(255,255,255,.08)" }}>
                      <Download className="w-4 h-4" /> Save
                    </button>
                  )}
                  {photoUrl && remakeStyleForToday() && (
                    <button
                      onClick={generateAiRemake}
                      disabled={aiRemake.isPending}
                      className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold disabled:opacity-60"
                      style={{ background: "linear-gradient(135deg,#ff9f1c,#ff4d6d,#7b2ff7)", color: "#0b0f1c" }}
                    >
                      {aiRemake.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
                      {aiRemake.isPending ? "Remaking…" : "AI remake"}
                    </button>
                  )}
                  <button onClick={handleSaveDraft} disabled={savingDraft} className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold disabled:opacity-50" style={{ background: "rgba(255,255,255,.08)" }}>
                    {savingDraft ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} Save draft
                  </button>
                  <button
                    onClick={() => setPublishing(true)}
                    disabled={!photoUrl && slides.length === 0 && (segments.length === 0 || videoOverLimit)}
                    className="r2c-luxstudio-publish flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold disabled:opacity-50"
                  >
                    <Video className="w-4 h-4" /> Publish
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* TIMELINE (desktop) */}
          <div className={`${expanded ? "hidden" : "hidden lg:block"} rounded-[18px] p-3`} style={cardStyle}>
            <div className="flex items-center justify-between mb-2.5">
              <div className="flex items-center gap-1.5">
                <button onClick={undoInk} disabled={inkCount === 0} aria-label="Undo"
                  className="w-8 h-8 rounded-lg flex items-center justify-center disabled:opacity-30" style={{ background: "rgba(255,255,255,.06)" }}>
                  <Undo2 className="w-4 h-4" />
                </button>
                <button onClick={() => toast("Nothing to redo.")} aria-label="Redo"
                  className="w-8 h-8 rounded-lg flex items-center justify-center opacity-40" style={{ background: "rgba(255,255,255,.06)" }}>
                  <Redo2 className="w-4 h-4" />
                </button>
                <span className="mx-1 h-5 w-px" style={{ background: "rgba(120,160,255,.2)" }} />
                <button
                  onClick={handlePrimaryCapture}
                  aria-label={recording ? "Stop" : "Play"}
                  className="w-9 h-9 rounded-full flex items-center justify-center"
                  style={{ background: "linear-gradient(135deg,#30bbed,#1a65d1)", color: "#ffffff" }}
                >
                  {recording ? <Square className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                </button>
              </div>
              <div className="flex items-center gap-1.5">
                <button onClick={() => toast("Use the editor on the stage to split clips.")} className="flex items-center gap-1.5 px-2.5 h-8 rounded-lg text-[11px] font-medium" style={{ background: "rgba(255,255,255,.06)" }}>
                  <Scissors className="w-3.5 h-3.5" /> Split
                </button>
                <button onClick={retake} disabled={!hasResult} className="flex items-center gap-1.5 px-2.5 h-8 rounded-lg text-[11px] font-medium disabled:opacity-30" style={{ background: "rgba(255,255,255,.06)" }}>
                  <Trash2 className="w-3.5 h-3.5" /> Delete
                </button>
                <button onClick={addClip} disabled={photoUrl !== null || !hasResult} className="flex items-center gap-1.5 px-2.5 h-8 rounded-lg text-[11px] font-medium disabled:opacity-30" style={{ background: "rgba(255,255,255,.06)" }}>
                  <Copy className="w-3.5 h-3.5" /> Duplicate
                </button>
              </div>
            </div>
            {/* track lanes (presentational) */}
            <div className="space-y-1.5">
              {[
                { label: "Video", icon: Film,    color: "#22C7F2" },
                { label: "Audio", icon: Volume2, color: "#B44CFF" },
                { label: "Text",  icon: Type,    color: "#FF4FD8" },
              ].map(tk => {
                const Icon = tk.icon;
                return (
                  <div key={tk.label} className="flex items-center gap-2">
                    <div className="flex items-center gap-1.5 w-16 shrink-0 text-[10px] font-semibold" style={{ color: "#A9B8CA" }}>
                      <Icon className="w-3.5 h-3.5" style={{ color: tk.color }} /> {tk.label}
                    </div>
                    <div className="flex-1 h-7 rounded-lg overflow-hidden" style={{ background: "rgba(255,255,255,.04)", border: "1px solid rgba(120,160,255,.1)" }}>
                      {tk.label === "Video" && (segments.length > 0 || photoUrl || slides.length > 0) && (
                        <div className="h-full rounded-lg" style={{ width: "62%", background: `linear-gradient(90deg,${tk.color}55,${tk.color}22)`, border: `1px solid ${tk.color}66` }} />
                      )}
                      {tk.label === "Audio" && selectedTrack && (
                        <div className="h-full rounded-lg" style={{ width: "100%", background: `linear-gradient(90deg,${tk.color}55,${tk.color}22)`, border: `1px solid ${tk.color}66` }} />
                      )}
                      {tk.label === "Text" && inkCount > 0 && (
                        <div className="h-full rounded-lg" style={{ width: "40%", background: `linear-gradient(90deg,${tk.color}55,${tk.color}22)`, border: `1px solid ${tk.color}66` }} />
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* FILTER ROW — floating carousel over the viewfinder on mobile, card on md+ */}
          {!isFancy && !expanded && (
            <div className="r2c-luxstudio-filterrow">
              <div className="flex items-center gap-3 overflow-x-auto scrollbar-none px-4 md:px-0">
                {FILTERS.map(f => {
                  const on = activeFilterId === f.id && !marketFilterCss;
                  return (
                    <button key={f.id} onClick={() => selectFilter(f.id)} className="flex flex-col items-center gap-1.5 shrink-0">
                      <div className="relative transition-all"
                        style={{
                          width: 54, height: 54, borderRadius: 14, padding: 2,
                          background: on ? "#30bbed" : "rgba(255,255,255,.06)",
                          boxShadow: on ? "0 0 14px rgba(48,187,237,.45)" : "none",
                        }}>
                        {f.id === "none"
                          ? <div className="w-full h-full rounded-[11px] flex items-center justify-center text-[9px] font-bold" style={{ background: "#0B1322", color: "#A9B8CA" }}>RAW</div>
                          : renderFilterThumb(f, true)}
                        {on && f.id !== "none" && (
                          <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full flex items-center justify-center" style={{ background: "#22C7F2", boxShadow: "0 0 6px rgba(34,199,242,.85)" }}>
                            <Check className="w-3 h-3 text-black" strokeWidth={3} />
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] font-semibold whitespace-nowrap" style={{ color: on ? "#F8FAFC" : "#A9B8CA" }}>{f.label}</span>
                    </button>
                  );
                })}

                {/* Intensity */}
                <div className="hidden sm:flex flex-col gap-1 pl-3 ml-1 shrink-0" style={{ borderLeft: "1px solid rgba(120,160,255,.18)", minWidth: 150 }}>
                  <div className="flex items-center justify-between text-[10px] font-semibold uppercase tracking-wide" style={{ color: "#A9B8CA" }}>
                    <span className="flex items-center gap-1"><Sliders className="w-3 h-3" /> Intensity</span>
                    <span>{filterIntensity}%</span>
                  </div>
                  <input
                    type="range" min={0} max={100} step={1}
                    value={filterIntensity}
                    onChange={e => setFilterIntensity(Number(e.target.value))}
                    disabled={activeFilterId === "none"}
                    className="w-full"
                    style={{ accentColor: "#22C7F2" }}
                  />
                </div>

                {activeFilterId === "neonrain" && !marketFilterCss && (
                  <div className="hidden sm:flex flex-col gap-1.5 pl-3 ml-1 shrink-0" style={{ borderLeft: "1px solid rgba(120,160,255,.18)" }}>
                    {renderNeonRainControls()}
                  </div>
                )}

                {activeFilterId === "neonpatriot" && !marketFilterCss && (
                  <div className="hidden sm:flex flex-col gap-1.5 pl-3 ml-1 shrink-0" style={{ borderLeft: "1px solid rgba(226,59,78,.22)" }}>
                    {renderNeonPatriotControls()}
                  </div>
                )}

                {activeFilterId === "beautyx" && !marketFilterCss && (
                  <div className="hidden sm:flex flex-col gap-1.5 pl-3 ml-1 shrink-0" style={{ borderLeft: "1px solid rgba(123,232,255,.22)" }}>
                    {renderBeautyXControls()}
                  </div>
                )}

                {activeFilterId === "solargraph" && !marketFilterCss && (
                  <div className="hidden sm:flex flex-col gap-1.5 pl-3 ml-1 shrink-0" style={{ borderLeft: "1px solid rgba(192,100,0,.28)" }}>
                    {renderSolargraphControls()}
                  </div>
                )}

                {activeFilterId === "carnival" && !marketFilterCss && (
                  <div className="hidden sm:flex flex-col gap-1.5 pl-3 ml-1 shrink-0" style={{ borderLeft: "1px solid rgba(255,54,196,.28)" }}>
                    {renderCarnivalControls()}
                  </div>
                )}

                {activeFilterId === "neonmood" && !marketFilterCss && (
                  <div className="hidden sm:flex flex-col gap-1.5 pl-3 ml-1 shrink-0" style={{ borderLeft: "1px solid rgba(57,255,20,.28)" }}>
                    {renderNeonMoodControls()}
                  </div>
                )}

                <button onClick={() => setActiveTool("filters")} className="flex items-center gap-1.5 shrink-0 px-3 h-9 rounded-full text-xs font-semibold ml-1"
                  style={{ background: "rgba(34,199,242,.12)", border: "1px solid rgba(34,199,242,.4)", color: "#22C7F2" }}>
                  <Sliders className="w-3.5 h-3.5" /> Edit Filter
                </button>
              </div>
            </div>
          )}

          {/* ACTION BAR — floating capture deck on mobile (Eye · lux orb · Publish),
              in-flow glass card on md+. Same handlers as before. */}
          <div className="r2c-luxstudio-actionbar flex items-center justify-between gap-3 px-6 md:px-3">
            <button onClick={() => setPreviewMode(v => !v)}
              className="r2c-luxstudio-glass flex items-center justify-center gap-1.5 h-11 w-11 sm:w-auto sm:px-4 rounded-full text-sm font-semibold transition-all"
              style={previewMode ? { color: "#30bbed", borderColor: "rgba(48,187,237,.55)", boxShadow: "0 0 14px rgba(48,187,237,.45)" } : { color: "#F8FAFC" }}>
              <Eye className="w-[18px] h-[18px]" /> <span className="hidden sm:inline">Preview</span>
            </button>

            {/* lux record orb — conic ring + breathing glow (reduce-motion gated in CSS) */}
            {!isFancy ? (
              <button
                onClick={handlePrimaryCapture}
                aria-label="Capture"
                data-recording={recording ? "true" : undefined}
                className="r2c-luxstudio-orb active:scale-95 transition-transform"
              >
                <span className="orb-glow" aria-hidden />
                <span className="orb-ring" aria-hidden />
                <span className="orb-core">
                  {recording
                    ? <Square className="w-6 h-6" fill="currentColor" />
                    : (started
                        ? (creativeMode === "video" ? null : <Aperture className="w-7 h-7" />)
                        : <Camera className="w-7 h-7" />)}
                </span>
              </button>
            ) : (
              <div className="flex items-center gap-2 text-xs font-medium" style={{ color: "#A9B8CA" }}>
                <StickyNote className="w-4 h-4" style={{ color: "#FF4FD8" }} /> Fancy Notes scratch pad
              </div>
            )}

            <div className="flex items-center gap-2">
              <button
                onClick={() => hasResult ? setPublishing(true) : toast("Capture something first to publish.")}
                className="r2c-luxstudio-publish flex items-center gap-1.5 h-11 px-5 rounded-full text-sm">
                Publish
              </button>
            </div>
          </div>
        </main>

        {/* RIGHT INSPECTOR */}
        <aside className="hidden xl:flex flex-col gap-3 p-4 shrink-0 overflow-y-auto scrollbar-none"
          style={{ width: 312, borderLeft: PANEL_BORDER }}>

          {/* VIDEO card */}
          <section className="rounded-[18px] p-3.5" style={cardStyle}>
            <p className="text-[10px] font-bold tracking-[.2em] uppercase mb-3" style={{ color: "#22C7F2" }}>Video</p>
            <div className="flex items-center justify-between mb-3 text-xs" style={{ color: "#A9B8CA" }}>
              <span>Resolution</span><span className="font-semibold" style={{ color: "#F8FAFC" }}>1280 × 720</span>
            </div>
            <div className="grid grid-cols-3 gap-2 mb-3">
              {[
                { label: "Mirror", icon: RotateCcw, on: mirror,   onClick: () => setMirror(v => !v) },
                { label: "Grid",   icon: Grid3x3,   on: gridOn,   onClick: () => setGridOn(v => !v) },
                { label: "Flash",  icon: Zap,       on: flash,    onClick: () => setFlash(v => !v) },
                { label: "Mic",    icon: isMicMuted ? MicOff : Mic, on: !isMicMuted, onClick: toggleMic },
                { label: "Flip",   icon: SkipForward, on: facingMode === "environment", onClick: switchCamera },
                { label: "HD",     icon: Maximize2, on: true, onClick: () => toast("Exports at 720p.") },
              ].map(c => {
                const Icon = c.icon;
                return (
                  <button key={c.label} onClick={c.onClick}
                    className="flex flex-col items-center gap-1 py-2 rounded-xl text-[10px] font-semibold transition-all"
                    style={c.on ? { background: "rgba(34,199,242,.14)", border: "1px solid rgba(34,199,242,.45)", color: "#22C7F2" } : { background: "rgba(255,255,255,.05)", color: "#A9B8CA" }}>
                    <Icon className="w-4 h-4" /> {c.label}
                  </button>
                );
              })}
            </div>
            <div className="mb-1.5 text-[10px] font-bold uppercase tracking-wide" style={{ color: "#A9B8CA" }}>Length</div>
            <div className="flex items-center gap-1 mb-3">
              {([15, 30, 60, null] as const).map(v => (
                <button key={v ?? "inf"} onClick={() => setMaxDuration(v)}
                  className="flex-1 py-1.5 rounded-lg text-[11px] font-semibold transition-all"
                  style={maxDuration === v ? { background: "#22C7F2", color: "#06101F" } : { background: "rgba(255,255,255,.05)", color: "#A9B8CA" }}>
                  {v === null ? "∞" : `${v}s`}
                </button>
              ))}
            </div>
          </section>

          {/* AUDIO card */}
          <section className="rounded-[18px] p-3.5" style={cardStyle}>
            <p className="text-[10px] font-bold tracking-[.2em] uppercase mb-3" style={{ color: "#B44CFF" }}>Audio</p>
            <button onClick={() => setMusicSheetOpen(true)}
              className="w-full flex items-center gap-3 p-2.5 rounded-xl text-left transition-all hover:brightness-125"
              style={{ background: "rgba(255,255,255,.05)" }}>
              <div className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0"
                style={{ background: "linear-gradient(135deg,rgba(180,76,255,.4),rgba(34,199,242,.3))" }}>
                <Music className="w-4 h-4" />
              </div>
              <div className="min-w-0 flex-1">
                {selectedTrack
                  ? <><p className="text-sm font-semibold truncate">{selectedTrack.title}</p><p className="text-[11px] capitalize truncate" style={{ color: "#A9B8CA" }}>{selectedTrack.mood} · {musicFitMode}</p></>
                  : <><p className="text-sm font-semibold">Add music</p><p className="text-[11px] truncate" style={{ color: "#A9B8CA" }}>{musicLoading ? "Loading tracks…" : "Browse moods"}</p></>}
              </div>
              <ChevronUp className="w-4 h-4 shrink-0" style={{ color: "#A9B8CA" }} />
            </button>
            <button onClick={() => setMuteVideoAudio(v => !v)}
              className="w-full flex items-center justify-between mt-2.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all"
              style={muteVideoAudio ? { background: "rgba(255,79,216,.14)", border: "1px solid rgba(255,79,216,.45)", color: "#FF4FD8" } : { background: "rgba(255,255,255,.05)", color: "#A9B8CA" }}>
              <span className="flex items-center gap-2">{muteVideoAudio ? <MicOff className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />} Replace original sound</span>
              <span>{muteVideoAudio ? "On" : "Off"}</span>
            </button>
            <p className="mt-1.5 text-[11px] leading-snug" style={{ color: "#6b7a90" }}>
              {muteVideoAudio
                ? "On by default — your clip's original sound is swapped for the platform track above, so you never post music you don't have rights to. Turn off only if you own the audio (like your own voice)."
                : "Your clip's original sound will play. Keep this off only if you own that audio — posting music you don't have rights to isn't allowed."}
            </p>
          </section>

          {/* PROJECT card */}
          <section className="rounded-[18px] p-3.5" style={cardStyle}>
            <p className="text-[10px] font-bold tracking-[.2em] uppercase mb-3" style={{ color: "#F6B94A" }}>Project</p>
            <Input placeholder="Title…" value={postTitle} onChange={e => setPostTitle(e.target.value)}
              className="mb-2 bg-white/5 border-white/10 text-white placeholder:text-white/40" />
            <Textarea placeholder="Caption…" value={postBody} onChange={e => setPostBody(e.target.value)}
              className="mb-2 min-h-[60px] resize-none text-sm bg-white/5 border-white/10 text-white placeholder:text-white/40" />
            <Select value={postTo} onValueChange={handlePostToChange}>
              <SelectTrigger className="bg-white/5 border-white/10 text-white"><SelectValue placeholder="General feed" /></SelectTrigger>
              {/* The studio lives in a z-[100] fullscreen portal — portalled
                  dropdown content must sit ABOVE it or it opens invisibly. */}
              <SelectContent className="z-[120]">
                <SelectItem value="general">General feed</SelectItem>
                <SelectItem value="chasers">Chasers only</SelectItem>
                <SelectItem value="private">Private (only me)</SelectItem>
                {(communities ?? []).map(c => <SelectItem key={c.id} value={String(c.id)}>c/{c.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <div className="mt-2">
              <ContentDisclosureFields
                variant="dark"
                kind={disclosedKind}
                onKindChange={setDisclosedKind}
                containsPaidPromotion={paidPromotion}
                onPaidPromotionChange={setPaidPromotion}
              />
            </div>
            <div className="flex items-center justify-between mt-3 pt-3 text-[11px]" style={{ borderTop: "1px solid rgba(120,160,255,.15)", color: "#A9B8CA" }}>
              <span>Mode</span><span className="font-semibold capitalize" style={{ color: "#F8FAFC" }}>{creativeMode === "fancynotes" ? "Fancy Notes" : creativeMode === "slideshow" ? "Slide Show" : creativeMode === "canvas" ? "Canvas Art" : creativeMode === "photo" ? "Photo" : "Video"}</span>
            </div>
          </section>
        </aside>
      </div>

      {/* ── MOBILE LUX DECK: bottom scrim + serif mode strip (approved LuxStudio
          layout — the mode tabs live at the very bottom of the viewfinder). */}
      <div className="r2c-luxstudio-scrim-bottom md:hidden pointer-events-none absolute inset-x-0 bottom-0 z-20 h-[300px]" />
      {!expanded && (
        <div className="r2c-luxstudio-modestrip md:hidden absolute inset-x-0 z-30 flex items-center justify-center gap-4">
          {MODES.map(m => {
            const on = creativeMode === m.id;
            return (
              <button key={m.id} onClick={() => selectMode(m.id)} className="relative flex flex-col items-center whitespace-nowrap py-1">
                <span
                  className={on ? "r2c-serif-display italic text-[13px]" : "text-[11px] font-medium"}
                  style={{ color: on ? "#30bbed" : "#6a82a1" }}
                >
                  {m.label}
                </span>
                {on && <span className="absolute -bottom-0.5 h-1 w-1 rounded-full" style={{ background: "#30bbed", boxShadow: "0 0 6px rgba(48,187,237,.6)" }} />}
              </button>
            );
          })}
        </div>
      )}

      {/* ── TOOL FLYOUT ────────────────────────────────────────────────────────── */}
      {/* Hidden while Draw is minimized so the whole canvas is free to draw on. */}
      {activeTool && !(isDrawTool && drawMinimized) && (
        <>
          {/* scrim (click to close; skip for draw so pointer reaches the canvas) */}
          {activeTool !== "draw" && <div className="absolute inset-0 z-40" onClick={() => setActiveTool(null)} />}
          <div
            className="absolute z-50 left-0 right-0 bottom-0 md:left-[94px] md:right-auto md:top-[112px] md:bottom-4 md:w-[360px] rounded-t-[24px] md:rounded-[20px] flex flex-col"
            style={{ background: "rgba(10,16,28,.94)", border: PANEL_BORDER, backdropFilter: "blur(22px)", WebkitBackdropFilter: "blur(22px)" }}
          >
            <div className="flex items-center justify-between px-4 py-3 shrink-0" style={{ borderBottom: PANEL_BORDER }}>
              <span className="font-bold text-base">
                {activeTool === "filters" && "Filters"}
                {activeTool === "aidirector" && "AI Creative Director ✦"}
                {activeTool === "effects" && "Effects"}
                {activeTool === "backgrounds" && "Backgrounds"}
                {activeTool === "draw" && "Illuminate ✦ Draw"}
                {activeTool === "beauty" && "Beauty"}
                {activeTool === "convo" && "Conversation Effects"}
                {activeTool === "voice" && "Voice ✦ Audio"}
              </span>
              <div className="flex items-center gap-2">
                {isDrawTool && (
                  <button onClick={() => setDrawMinimized(true)} aria-label="Minimize"
                    className="h-7 px-2.5 rounded-full flex items-center gap-1 text-[11px] font-medium" style={{ background: "rgba(255,255,255,.08)", color: "#A9B8CA" }}>
                    <ChevronDown className="w-4 h-4" /> Minimize
                  </button>
                )}
                <button onClick={() => setActiveTool(null)} aria-label="Close"
                  className="w-7 h-7 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,.08)" }}>
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="px-4 py-4 overflow-y-auto max-h-[55vh] md:max-h-none">
              {/* FILTERS — single-select grid + intensity + premium grade */}
              {activeTool === "filters" && (
                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-2.5">
                    {FILTERS.map(f => {
                      const on = activeFilterId === f.id && !marketFilterCss;
                      return (
                        <button key={f.id} onClick={() => selectFilter(f.id)} className="flex flex-col items-center gap-1.5">
                          <div className="relative w-full transition-all" style={{
                            aspectRatio: "1", borderRadius: 14, padding: 2,
                            background: on ? "#30bbed" : "rgba(255,255,255,.06)",
                            boxShadow: on ? "0 0 14px rgba(48,187,237,.45)" : "none",
                          }}>
                            {f.id === "none"
                              ? <div className="w-full h-full rounded-[11px] flex items-center justify-center text-[10px] font-bold" style={{ background: "#0B1322", color: "#A9B8CA" }}>RAW</div>
                              : renderFilterThumb(f, true)}
                            {on && (
                              <span className="absolute top-1 right-1 w-4 h-4 rounded-full flex items-center justify-center" style={{ background: "#22C7F2", boxShadow: "0 0 6px rgba(34,199,242,.85)" }}>
                                <Check className="w-3 h-3 text-black" strokeWidth={3} />
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] font-semibold" style={{ color: on ? "#F8FAFC" : "#A9B8CA" }}>{f.label}</span>
                        </button>
                      );
                    })}
                  </div>

                  <div>
                    <div className="flex items-center justify-between text-[11px] font-semibold uppercase tracking-wide mb-1.5" style={{ color: "#A9B8CA" }}>
                      <span className="flex items-center gap-1.5"><Sun className="w-3.5 h-3.5" /> Intensity</span>
                      <span>{filterIntensity}%</span>
                    </div>
                    <input type="range" min={0} max={100} step={1} value={filterIntensity}
                      onChange={e => setFilterIntensity(Number(e.target.value))}
                      disabled={activeFilterId === "none"}
                      className="w-full" style={{ accentColor: "#22C7F2" }} />
                  </div>

                  {activeFilterId === "neonrain" && !marketFilterCss && (
                    <div className="rounded-2xl p-3" style={{ background: "rgba(34,199,242,.06)", border: "1px solid rgba(34,199,242,.22)" }}>
                      {renderNeonRainControls()}
                    </div>
                  )}

                  {activeFilterId === "neonpatriot" && !marketFilterCss && (
                    <div className="rounded-2xl p-3" style={{ background: "rgba(226,59,78,.06)", border: "1px solid rgba(226,59,78,.22)" }}>
                      {renderNeonPatriotControls()}
                    </div>
                  )}

                  {activeFilterId === "beautyx" && !marketFilterCss && (
                    <div className="rounded-2xl p-3" style={{ background: "rgba(123,232,255,.06)", border: "1px solid rgba(123,232,255,.22)" }}>
                      {renderBeautyXControls()}
                    </div>
                  )}

                  {activeFilterId === "solargraph" && !marketFilterCss && (
                    <div className="rounded-2xl p-3" style={{ background: "rgba(192,100,0,.06)", border: "1px solid rgba(192,100,0,.22)" }}>
                      {renderSolargraphControls()}
                    </div>
                  )}

                  {activeFilterId === "carnival" && !marketFilterCss && (
                    <div className="rounded-2xl p-3" style={{ background: "rgba(255,54,196,.06)", border: "1px solid rgba(255,54,196,.22)" }}>
                      {renderCarnivalControls()}
                    </div>
                  )}

                  {activeFilterId === "neonmood" && !marketFilterCss && (
                    <div className="rounded-2xl p-3" style={{ background: "rgba(57,255,20,.06)", border: "1px solid rgba(57,255,20,.22)" }}>
                      {renderNeonMoodControls()}
                    </div>
                  )}

                  {/* Premium "Century Egg" grade — unlock via the hidden logo egg. */}
                  <PremiumGate
                    feature="filter.centuryEgg"
                    fallback={
                      <div className="flex items-center gap-3 rounded-2xl border border-amber-400/20 bg-amber-400/[0.04] p-3">
                        <div className="w-10 h-10 flex-shrink-0 rounded-xl" style={{ background: "conic-gradient(from 140deg,#3b2f1a,#7c6a3a,#1f2e1f,#3b2f1a)", filter: "blur(0.3px)" }} />
                        <div className="flex-1 min-w-0">
                          <p className="text-amber-200/90 text-sm font-semibold flex items-center gap-1.5">Century Egg <span className="text-[10px]">✦ Premium</span></p>
                          <p className="text-white/45 text-[11px] leading-tight">Locked — discover the hidden logo to unlock.</p>
                        </div>
                        <span className="text-white/30 text-lg">🔒</span>
                      </div>
                    }
                  >
                    {(() => {
                      const isOn = marketFilterCss === CENTURY_EGG_CSS;
                      return (
                        <button
                          onClick={() => {
                            if (isOn) { setMarketFilterCss(null); setMarketFilterLabel(null); }
                            else { setMarketFilterCss(CENTURY_EGG_CSS); setMarketFilterLabel("Century Egg"); setFilterStack([]); }
                          }}
                          className={cn("w-full flex items-center gap-3 rounded-2xl border p-3 transition-all text-left", isOn ? "border-amber-300 bg-amber-300/10" : "border-amber-400/25 hover:border-amber-300/50")}
                        >
                          <div className="w-10 h-10 flex-shrink-0 rounded-xl" style={{ background: "conic-gradient(from 140deg,#4a3a1c,#caa44e,#26402a,#4a3a1c)" }} />
                          <div className="flex-1 min-w-0">
                            <p className="text-amber-100 text-sm font-semibold flex items-center gap-1.5">Century Egg <span className="text-[10px]">✦ Premium</span></p>
                            <p className="text-white/50 text-[11px] leading-tight">Translucent amber &amp; jade marble grade.</p>
                          </div>
                          {isOn && <span className="text-[10px] font-bold text-black bg-amber-200 rounded-full px-2 py-0.5">ON</span>}
                        </button>
                      );
                    })()}
                  </PremiumGate>
                </div>
              )}

              {activeTool === "voice" && (
                <div className="space-y-4">
                  <p className="text-xs leading-relaxed" style={{ color: "#A9B8CA" }}>
                    Fine-tune how your voice is captured. Everyone gets these controls.
                  </p>

                  {/* Live mic level */}
                  <div className="rounded-2xl p-3.5" style={{ background: "rgba(255,255,255,.05)" }}>
                    <div className="flex items-center justify-between mb-2.5">
                      <span className="text-[11px] font-bold uppercase tracking-wide" style={{ color: "#A9B8CA" }}>Mic level</span>
                      <span className="text-[11px]" style={{ color: started && source === "camera" ? "#22C7F2" : "#6b7a90" }}>
                        {started && source === "camera" ? "Live" : "Start the camera to test"}
                      </span>
                    </div>
                    <VoiceResonanceBar
                      tier={micLevel > 0.32 ? "luminary" : micLevel > 0.18 ? "conversationalist" : micLevel > 0.07 ? "contributor" : "listener"}
                      showLabel={false}
                    />
                  </div>

                  {/* Reduce background noise (browser voice isolation) */}
                  <button onClick={() => setNoiseReduction(v => !v)}
                    className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-semibold transition-all"
                    style={noiseReduction ? { background: "rgba(34,199,242,.14)", border: "1px solid rgba(34,199,242,.45)", color: "#22C7F2" } : { background: "rgba(255,255,255,.05)", color: "#A9B8CA" }}>
                    <span className="flex items-center gap-2"><ShieldCheck className="w-4 h-4" /> Reduce background noise</span>
                    <span>{noiseReduction ? "On" : "Off"}</span>
                  </button>

                  {/* Voice level (live boost) */}
                  <div className="rounded-2xl p-3.5" style={{ background: "rgba(255,255,255,.05)" }}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="flex items-center gap-2 text-sm font-semibold text-white"><Volume2 className="w-4 h-4" style={{ color: "#B44CFF" }} /> Voice level</span>
                      <span className="text-xs font-mono" style={{ color: "#A9B8CA" }}>{voiceBoost === 1 ? "Normal" : `+${Math.round((voiceBoost - 1) * 100)}%`}</span>
                    </div>
                    <input type="range" min={1} max={2.5} step={0.1} value={voiceBoost}
                      onChange={e => setVoiceBoost(parseFloat(e.target.value))}
                      aria-label="Voice level"
                      className="w-full accent-[#B44CFF]" />
                    <p className="mt-1.5 text-[11px]" style={{ color: "#6b7a90" }}>Lift a soft voice over ambient noise while filming.</p>
                  </div>

                  {/* AI voice cleanup (optional post-record pass) */}
                  <div className="rounded-2xl p-3.5" style={{ background: "rgba(180,76,255,.08)", border: "1px solid rgba(180,76,255,.28)" }}>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="flex items-center gap-2 text-sm font-semibold text-white"><Sparkles className="w-4 h-4" style={{ color: "#B44CFF" }} /> AI voice cleanup</span>
                      {voiceAllCleaned && !voiceCleanBusy && (
                        <span className="text-[11px] font-semibold" style={{ color: "#22C7F2" }}>Ready</span>
                      )}
                    </div>
                    <p className="text-[11px] leading-relaxed mb-3" style={{ color: "#A9B8CA" }}>
                      Strip background noise from your finished clips with an AI pass. Applied when you publish.
                    </p>
                    <button
                      onClick={runVoiceCleanup}
                      disabled={voiceCleanBusy || segments.length === 0 || muteVideoAudio}
                      className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl text-sm font-semibold transition-all disabled:opacity-40"
                      style={{ background: "rgba(180,76,255,.16)", border: "1px solid rgba(180,76,255,.45)", color: "#B44CFF" }}>
                      {voiceCleanBusy ? (
                        <><Loader2 className="w-4 h-4 animate-spin" /> Cleaning up…</>
                      ) : voiceAllCleaned ? (
                        <><Sparkles className="w-4 h-4" /> Clean up again</>
                      ) : (
                        <><Sparkles className="w-4 h-4" /> Clean up my voice</>
                      )}
                    </button>
                    {segments.length === 0 && (
                      <p className="mt-2 text-[11px]" style={{ color: "#6b7a90" }}>Record a clip first.</p>
                    )}
                    {muteVideoAudio && (
                      <p className="mt-2 text-[11px]" style={{ color: "#6b7a90" }}>Turn off "Replace original sound" to clean up the voice.</p>
                    )}
                    {voiceCleanError && (
                      <p className="mt-2 text-[11px]" style={{ color: "#FF6B6B" }}>{voiceCleanError}</p>
                    )}
                    {voiceCleanEnabled && !voiceAllCleaned && !voiceCleanBusy && !muteVideoAudio && (
                      <p className="mt-2 text-[11px]" style={{ color: "#FFB84C" }}>A newer clip isn't cleaned yet — tap "Clean up my voice" to include it.</p>
                    )}
                    {voiceCleanIds.size > 0 && !voiceCleanBusy && !muteVideoAudio && (
                      <button
                        onClick={() => setVoiceCleanEnabled(v => !v)}
                        className="mt-2.5 w-full flex items-center justify-between px-3 py-2 rounded-xl text-[13px] font-semibold transition-all"
                        style={voiceCleanEnabled ? { background: "rgba(34,199,242,.14)", border: "1px solid rgba(34,199,242,.45)", color: "#22C7F2" } : { background: "rgba(255,255,255,.05)", color: "#A9B8CA" }}>
                        <span>Use cleaned voice on publish</span>
                        <span>{voiceCleanEnabled ? "On" : "Off"}</span>
                      </button>
                    )}
                  </div>
                </div>
              )}

              {activeTool === "aidirector" && (
                <div className="[--tw-text-opacity:1] [color:white]">
                  <AIDirectorPanel
                    onApply={(config, _title, music, experienceId) => {
                      applyAiConfigFilter(config);
                      // Remember which generation produced this look so the publish
                      // sheet can offer to start an AI Filter Challenge from it.
                      setAiExperienceId(experienceId);
                      // The composed soundtrack is already same-origin (served from
                      // /api/storage) so it plays AND decodes for baking — map it to
                      // the studio's MusicTrack shape and select it like any custom track.
                      if (music) {
                        handleTrackGenerated({
                          id: music.trackId,
                          slug: `aidir-${music.trackId}`,
                          title: music.title,
                          mood: music.mood ?? "auto",
                          tags: ["ai-director"],
                          durationSec: music.durationSec ?? null,
                          audioUrl: music.audioUrl,
                          isCurated: false,
                        });
                      }
                      setActiveTool(null);
                    }}
                    appliedName={aiFilterConfig?.name ?? null}
                  />
                </div>
              )}

              {activeTool === "effects" && (
                <div className="[--tw-text-opacity:1] [color:white]">
                  <EffectsPanel activeExperienceId={activeExperienceId} onActivate={setActiveExperienceId} />
                </div>
              )}

              {activeTool === "backgrounds" && (
                <div className="[--tw-text-opacity:1] [color:white]">
                  <BackgroundsPanel
                    selectedBg={aiBg}
                    onSelectBg={setAIBg}
                    gsThreshold={gsThreshold}
                    onGsThreshold={setGsThreshold}
                  />
                </div>
              )}

              {activeTool === "draw" && (() => {
                const activeBrush = INK_BRUSHES.find(b => b.id === inkBrush) ?? INK_BRUSHES[0];
                const swatch = activeBrush.color === "rainbow"
                  ? "conic-gradient(from 0deg,#ff5b5b,#f5c453,#46e0ff,#2d8cff,#a855f7,#ff5b5b)"
                  : activeBrush.color;
                return (
                <div className="space-y-4">
                  <div className="rounded-2xl p-3.5 text-center" style={{ background: "linear-gradient(135deg,#0b1120,#111827)", border: "1px solid rgba(45,140,255,0.33)" }}>
                    <p className="text-white font-display font-bold text-sm flex items-center justify-center gap-1.5"><Sparkles className="w-4 h-4 text-sky-300" /> Motion Ink</p>
                    <p className="text-white/50 text-[11px] mt-1 leading-relaxed">Ink and glow text are anchored in time &amp; space — they fade, persist, or draw themselves, and bake right into your photo &amp; video.</p>
                  </div>

                  <div>
                    <p className="text-white/40 text-[10px] uppercase tracking-widest mb-2">Source</p>
                    <div className="grid grid-cols-2 gap-2">
                      <button onClick={() => selectSource("camera")} className={cn("rounded-2xl border px-3 py-2.5 flex items-center justify-center gap-2 text-sm font-semibold transition-all", source === "camera" ? "border-white bg-white/10 text-white" : "border-white/10 text-white/70 hover:border-white/30")}>
                        <Camera className="w-4 h-4" /> Camera
                      </button>
                      <button onClick={() => selectSource("canvas")} className={cn("rounded-2xl border px-3 py-2.5 flex items-center justify-center gap-2 text-sm font-semibold transition-all", source === "canvas" ? "border-white bg-white/10 text-white" : "border-white/10 text-white/70 hover:border-white/30")}>
                        <Box className="w-4 h-4" /> Canvas
                      </button>
                    </div>
                  </div>

                  {source === "canvas" && (
                    <div>
                      <p className="text-white/40 text-[10px] uppercase tracking-widest mb-2">Background</p>
                      <div className="grid grid-cols-4 gap-2">
                        {CANVAS_BACKGROUNDS.map(b => {
                          const sel = canvasBg === b.id;
                          return (
                            <button key={b.id} onClick={() => setCanvasBg(b.id)} className={cn("flex flex-col items-center gap-1.5 p-1.5 rounded-2xl border transition-all", sel ? "border-white bg-white/10" : "border-white/10 hover:border-white/30")}>
                              <span className="w-full aspect-square rounded-xl border border-white/15" style={{ background: b.swatch }} />
                              <span className={cn("text-[9px] font-medium text-center leading-tight", sel ? "text-white" : "text-white/60")}>{b.label}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-2">
                    <button onClick={() => setInkSubTool("brush")} className={cn("rounded-2xl border px-3 py-2.5 flex items-center justify-center gap-2 text-sm font-semibold transition-all", inkSubTool === "brush" ? "border-white bg-white/10 text-white" : "border-white/10 text-white/70 hover:border-white/30")}>
                      <Brush className="w-4 h-4" /> Brush
                    </button>
                    <button onClick={() => setInkSubTool("text")} className={cn("rounded-2xl border px-3 py-2.5 flex items-center justify-center gap-2 text-sm font-semibold transition-all", inkSubTool === "text" ? "border-white bg-white/10 text-white" : "border-white/10 text-white/70 hover:border-white/30")}>
                      <Type className="w-4 h-4" /> Glow Text
                    </button>
                  </div>

                  <div>
                    <p className="text-white/40 text-[10px] uppercase tracking-widest mb-2">Brush</p>
                    <div className="grid grid-cols-5 gap-2">
                      {INK_BRUSHES.map(b => {
                        const sel = inkBrush === b.id;
                        const bg = b.color === "rainbow" ? "conic-gradient(from 0deg,#ff5b5b,#f5c453,#46e0ff,#2d8cff,#a855f7,#ff5b5b)" : b.color;
                        return (
                          <button key={b.id} onClick={() => setInkBrush(b.id)} aria-label={b.label} className="flex flex-col items-center gap-1">
                            <span className="aspect-square w-full rounded-full transition-transform" style={{ background: bg, boxShadow: sel ? `0 0 12px ${b.color === "rainbow" ? "#46e0ff" : b.color}, 0 0 4px #fff` : "0 0 6px rgba(255,255,255,0.25)", border: sel ? "2px solid #fff" : "2px solid rgba(255,255,255,0.15)", transform: sel ? "scale(1.08)" : "scale(1)" }} />
                            <span className={cn("text-[9px]", sel ? "text-white" : "text-white/50")}>{b.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {inkSubTool === "text" && (
                    <div>
                      <p className="text-white/40 text-[10px] uppercase tracking-widest mb-1.5">Your Text</p>
                      <Input value={inkTextValue} onChange={e => setInkTextValue(e.target.value)} placeholder="Type, then tap the camera to place" maxLength={60} className="bg-black/40 border-white/15 text-white placeholder:text-white/30" />
                      <p className="text-white/40 text-[11px] mt-1.5">Tap anywhere on the camera to drop your glowing text.</p>
                    </div>
                  )}

                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <p className="text-white/40 text-[10px] uppercase tracking-widest">{inkSubTool === "text" ? "Text Size" : "Brush Size"}</p>
                      <span className="text-white/60 text-xs">{inkSubTool === "text" ? `${inkFont}px` : `${inkSize}px`}</span>
                    </div>
                    {inkSubTool === "text" ? (
                      <input type="range" min={24} max={160} step={2} value={inkFont} onChange={e => setInkFont(Number(e.target.value))} className="w-full accent-white" />
                    ) : (
                      <input type="range" min={2} max={28} step={1} value={inkSize} onChange={e => setInkSize(Number(e.target.value))} className="w-full accent-white" />
                    )}
                    <div className="mt-2 h-10 rounded-xl bg-black/40 border border-white/10 flex items-center justify-center overflow-hidden">
                      <div style={{ width: `${Math.min(inkSize * 4, 180)}px`, height: `${inkSize}px`, borderRadius: 999, background: swatch, boxShadow: `0 0 ${inkSize + 8}px ${activeBrush.color === "rainbow" ? "#46e0ff" : activeBrush.color}` }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <p className="text-white/40 text-[10px] uppercase tracking-widest">Glow</p>
                      <span className="text-white/60 text-xs">{inkGlow}px</span>
                    </div>
                    <input type="range" min={0} max={40} step={1} value={inkGlow} onChange={e => setInkGlow(Number(e.target.value))} className="w-full accent-white" />
                  </div>

                  <div>
                    <p className="text-white/40 text-[10px] uppercase tracking-widest mb-2">Lifetime</p>
                    <div className="grid grid-cols-3 gap-2">
                      {INK_LIFETIMES.map(l => {
                        const sel = inkLife === l.life;
                        return (
                          <button key={l.id} onClick={() => setInkLife(l.life)} className={cn("rounded-xl border px-2 py-2 text-center transition-all", sel ? "border-white bg-white/10" : "border-white/10 hover:border-white/30")}>
                            <p className={cn("text-xs font-semibold", sel ? "text-white" : "text-white/70")}>{l.label}</p>
                            <p className="text-white/40 text-[10px] leading-tight mt-0.5">{l.sub}</p>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <p className="text-white/40 text-[10px] uppercase tracking-widest mb-2">Anchor</p>
                      <div className="grid grid-cols-2 gap-1.5">
                        {(["frame", "subject"] as AnchorMode[]).map(a => {
                          const sel = inkAnchor === a;
                          return (
                            <button key={a} onClick={() => setInkAnchor(a)} className={cn("rounded-xl border px-2 py-2 text-xs font-semibold capitalize transition-all", sel ? "border-white bg-white/10 text-white" : "border-white/10 text-white/70 hover:border-white/30")}>{a}</button>
                          );
                        })}
                      </div>
                    </div>
                    <button onClick={() => setInkDrawOn(v => !v)} className="rounded-2xl border px-3 py-2 text-left transition-all flex flex-col justify-center" style={{ borderColor: inkDrawOn ? "rgba(255,255,255,0.45)" : "rgba(255,255,255,0.1)", background: inkDrawOn ? "rgba(255,255,255,0.12)" : "rgba(255,255,255,0.04)" }}>
                      <p className="text-white text-sm font-medium flex items-center gap-1.5">Draw-on {inkDrawOn && <span className="text-[10px] font-bold text-black bg-white rounded-full px-1.5">ON</span>}</p>
                      <p className="text-white/50 text-[11px] leading-tight">Reveals itself as it plays.</p>
                    </button>
                  </div>
                  {inkAnchor === "subject" && (
                    <p className="text-white/40 text-[11px] -mt-2">Subject anchor follows your movement — move a little so it can lock onto you. If it loses you, it holds your last spot.</p>
                  )}

                  <div className="grid grid-cols-2 gap-2">
                    <Button variant="outline" onClick={undoInk} disabled={inkCount === 0} className="bg-white/5 border-white/15 text-white hover:bg-white/10 disabled:opacity-40">
                      <Undo2 className="w-4 h-4 mr-1.5" /> Undo
                    </Button>
                    <Button variant="outline" onClick={clearInk} disabled={inkCount === 0} className="bg-white/5 border-white/15 text-white hover:bg-white/10 disabled:opacity-40">
                      <Trash2 className="w-4 h-4 mr-1.5" /> Clear
                    </Button>
                  </div>

                  {!started && (
                    <p className="text-amber-300/70 text-[11px] text-center">Start the camera, then draw or place glow text on the screen.</p>
                  )}
                </div>
                );
              })()}
            </div>
          </div>
        </>
      )}

      {/* Draw quick bar (panel minimized) */}
      {isDrawTool && drawMinimized && (
        <div className="absolute left-1/2 -translate-x-1/2 bottom-[calc(env(safe-area-inset-bottom,0px)+260px)] md:bottom-24 z-50 flex items-center gap-1.5 rounded-full bg-black/70 backdrop-blur-xl border border-white/15 px-2.5 py-2 shadow-lg"
          onPointerDown={e => e.stopPropagation()} onClick={e => e.stopPropagation()}>
          {(() => {
            const b = INK_BRUSHES.find(x => x.id === inkBrush) ?? INK_BRUSHES[0];
            const bg = b.color === "rainbow" ? "conic-gradient(from 0deg,#ff5b5b,#f5c453,#46e0ff,#2d8cff,#a855f7,#ff5b5b)" : b.color;
            return <span className="w-6 h-6 rounded-full flex-shrink-0" style={{ background: bg, boxShadow: `0 0 10px ${b.color === "rainbow" ? "#46e0ff" : b.color}` }} />;
          })()}
          <button onClick={undoInk} disabled={inkCount === 0} aria-label="Undo" className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center text-white disabled:opacity-40"><Undo2 className="w-4 h-4" /></button>
          <button onClick={clearInk} disabled={inkCount === 0} aria-label="Clear" className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center text-white disabled:opacity-40"><Trash2 className="w-4 h-4" /></button>
          <button onClick={() => setDrawMinimized(false)} className="h-9 px-3.5 rounded-full bg-white text-black text-xs font-bold flex items-center gap-1.5"><ChevronUp className="w-4 h-4" /> Tools</button>
        </div>
      )}

      {/* ── DUET SOURCE REFERENCE ──────────────────────────────────────────────── */}
      {duetOfPostId && duetSourceSrc && !publishing && (
        <div className="absolute left-3 top-20 z-50 w-28 rounded-2xl overflow-hidden border bg-black/70 backdrop-blur-md shadow-lg"
          style={{ borderColor: "rgba(180,76,255,.5)" }}
          onPointerDown={e => e.stopPropagation()} onClick={e => e.stopPropagation()}>
          <div className="px-2 py-1 text-[10px] font-bold flex items-center gap-1" style={{ color: "#D9B8FF" }}>
            <Users className="w-3 h-3" /> Duet source
          </div>
          <video src={duetSourceSrc} controls playsInline muted className="w-full aspect-[9/16] object-cover bg-black" />
        </div>
      )}

      {/* ── PUBLISH MODAL ──────────────────────────────────────────────────────── */}
      {hasResult && publishing && (
        <div className="absolute inset-0 z-[60] flex items-center justify-center p-4" style={{ background: "rgba(4,7,14,.7)", backdropFilter: "blur(6px)" }}>
          <div className="w-full max-w-md rounded-[24px] p-4 space-y-3" style={{ background: "rgba(12,18,32,.96)", border: PANEL_BORDER }}>
            <div className="flex items-center justify-between">
              <p className="font-bold text-base">Publish</p>
              <button onClick={() => setPublishing(false)} className="w-7 h-7 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,.08)" }}><X className="w-4 h-4" /></button>
            </div>
            <Input placeholder="Add a title…" value={postTitle} onChange={e => setPostTitle(e.target.value)} className="bg-white/10 border-white/15 text-white placeholder:text-white/40" />
            <Textarea placeholder="Write a caption…" value={postBody} onChange={e => setPostBody(e.target.value)} className="min-h-[60px] resize-none text-sm bg-white/10 border-white/15 text-white placeholder:text-white/40" />
            <Select value={postTo} onValueChange={handlePostToChange}>
              <SelectTrigger className="bg-white/10 border-white/15 text-white"><SelectValue placeholder="General feed" /></SelectTrigger>
              {/* Must clear the studio's z-[100] portal (see desktop sheet). */}
              <SelectContent className="z-[120]">
                <SelectItem value="general">General feed</SelectItem>
                <SelectItem value="chasers">Chasers only</SelectItem>
                <SelectItem value="private">Private (only me)</SelectItem>
                {(communities ?? []).map(c => <SelectItem key={c.id} value={String(c.id)}>c/{c.name}</SelectItem>)}
              </SelectContent>
            </Select>
            {musicEligible && (
              <button onClick={() => setMusicSheetOpen(true)} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl bg-white/10 border border-white/15 text-left hover:bg-white/15 transition-colors">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-fuchsia-500/30 to-indigo-500/30 border border-white/10 flex items-center justify-center shrink-0"><Music className="w-4 h-4 text-white" /></div>
                <div className="min-w-0 flex-1">
                  {selectedTrack
                    ? <><p className="text-white text-sm font-semibold truncate">{selectedTrack.title}</p><p className="text-white/50 text-[11px] capitalize truncate">{selectedTrack.mood} · {musicFitMode}{musicSelMode === "auto" && musicSuggestion?.track.id === selectedTrack.id ? " · auto-matched" : ""}</p></>
                    : <><p className="text-white text-sm font-semibold">Add music</p><p className="text-white/50 text-[11px] truncate">{musicLoading ? "Loading tracks…" : musicSuggestion ? `Try “${musicSuggestion.track.title}”` : "Browse moods"}</p></>}
                </div>
                <ChevronUp className="w-4 h-4 text-white/40 shrink-0" />
              </button>
            )}
            {duetOfPostId && (
              <div className="flex items-center gap-2 rounded-2xl px-3 py-2.5 text-sm" style={{ background: "rgba(180,76,255,.12)", border: "1px solid rgba(180,76,255,.4)", color: "#D9B8FF" }}>
                <Users className="w-4 h-4 shrink-0" />
                <span>Duet — your clip posts side-by-side with the original video.</span>
              </div>
            )}
            {/* Derivative-reuse consent — opt-in, only where there's something to reuse. */}
            {!photoUrl && (segments.length > 0 || slides.length > 0) && (
              <label className="flex items-center justify-between gap-2 cursor-pointer rounded-2xl px-3 py-2.5 bg-white/5 border border-white/10">
                <span className="flex items-center gap-1.5 text-sm text-white"><Music className="w-4 h-4 text-white/70" /> Let others reuse this sound</span>
                <input type="checkbox" checked={allowSoundReuse} onChange={e => setAllowSoundReuse(e.target.checked)} className="h-4 w-4 accent-[#22C7F2]" />
              </label>
            )}
            {!photoUrl && segments.length > 0 && (
              <label className="flex items-center justify-between gap-2 cursor-pointer rounded-2xl px-3 py-2.5 bg-white/5 border border-white/10">
                <span className="flex items-center gap-1.5 text-sm text-white"><Users className="w-4 h-4 text-white/70" /> Allow duets with this video</span>
                <input type="checkbox" checked={allowDuet} onChange={e => setAllowDuet(e.target.checked)} className="h-4 w-4 accent-[#22C7F2]" />
              </label>
            )}
            {/* Frameless immersive display — premium/pro creators, opt-in per post. */}
            {canFrameless && (
              <label className="flex items-center justify-between gap-2 cursor-pointer rounded-2xl px-3 py-2.5" style={{ background: "rgba(180,76,255,.1)", border: "1px solid rgba(180,76,255,.35)" }}>
                <span className="flex items-center gap-1.5 text-sm text-white">
                  <Maximize2 className="w-4 h-4" style={{ color: "#D9B8FF" }} /> Frameless immersive view
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full" style={{ background: "rgba(180,76,255,.25)", color: "#D9B8FF" }}>PRO</span>
                </span>
                <input type="checkbox" checked={frameless} onChange={e => setFrameless(e.target.checked)} className="h-4 w-4 accent-[#B44CFF]" />
              </label>
            )}
            {joinChallengeId && reuseCreator && (
              <div className="flex items-center gap-2 rounded-2xl px-3 py-2.5 text-sm" style={{ background: "rgba(34,199,242,.1)", border: "1px solid rgba(34,199,242,.4)", color: "#7FD8FF" }}>
                <Wand2 className="w-4 h-4 shrink-0" />
                <span>Reusing @{reuseCreator}'s AI Filter Challenge look</span>
              </div>
            )}
            {!joinChallengeId && aiExperienceId && (
              <div className="rounded-2xl p-3 space-y-2" style={{ background: "rgba(255,255,255,.05)", border: "1px solid rgba(34,199,242,.3)" }}>
                <label className="flex items-center justify-between gap-2 cursor-pointer">
                  <span className="flex items-center gap-1.5 text-sm font-semibold text-white">
                    <Wand2 className="w-4 h-4 text-[#22C7F2]" /> Make this an AI Filter Challenge
                  </span>
                  <input
                    type="checkbox"
                    checked={startChallengeOn}
                    onChange={(e) => setStartChallengeOn(e.target.checked)}
                    className="h-4 w-4 accent-[#22C7F2]"
                  />
                </label>
                {startChallengeOn && (
                  <>
                    <Input
                      placeholder="Challenge prompt — e.g. Show your golden hour"
                      value={challengePrompt}
                      onChange={(e) => setChallengePrompt(e.target.value.slice(0, 200))}
                      className="bg-white/10 border-white/15 text-white placeholder:text-white/40"
                    />
                    <p className="text-white/45 text-[11px] leading-relaxed">
                      Others can reuse your exact look after you post and share it to unlock public use.
                    </p>
                  </>
                )}
              </div>
            )}
            <ContentDisclosureFields
              variant="dark"
              kind={disclosedKind}
              onKindChange={setDisclosedKind}
              containsPaidPromotion={paidPromotion}
              onPaidPromotionChange={setPaidPromotion}
            />
            <div className="flex gap-2">
              <button onClick={() => setPublishing(false)} className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl bg-white/10 border border-white/15 text-white text-sm"><ChevronLeft className="w-4 h-4" /> Back</button>
              <button onClick={handleSaveDraft} disabled={savingDraft} className="flex items-center gap-1.5 px-3 py-2.5 rounded-2xl bg-white/10 border border-white/15 text-white text-sm disabled:opacity-50">
                {savingDraft ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} <span className="hidden sm:inline">Draft</span>
              </button>
              <button onClick={publish} disabled={isPending || isUploading || exporting} className="r2c-luxstudio-publish flex-1 flex items-center justify-center gap-2 py-2.5 rounded-2xl text-sm font-bold disabled:opacity-60">
                {isPending || isUploading || exporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Video className="w-4 h-4" />}
                {exporting ? `Combining… ${Math.round(exportProgress * 100)}%` : isUploading ? "Uploading…" : isPending ? "Publishing…" : "Publish Now"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── DRAFTS ─────────────────────────────────────────────────────────────── */}
      {draftsOpen && (
        <DraftsPanel
          onClose={() => { setDraftsOpen(false); refreshDraftCount(); }}
          onResume={handleResume}
        />
      )}

      {/* ── MUSIC PICKER ───────────────────────────────────────────────────────── */}
      <MusicSheet
        open={musicSheetOpen}
        onClose={() => setMusicSheetOpen(false)}
        tracks={musicTracks}
        moods={musicMoods}
        loading={musicLoading}
        selectedTrackId={musicTrackId}
        onSelect={(id) => { setMusicTrackId(id); setMusicSelMode("manual"); }}
        fitMode={musicFitMode}
        onFitModeChange={setMusicFitMode}
        muteVideoAudio={muteVideoAudio}
        onMuteVideoAudioChange={setMuteVideoAudio}
        contentVolume={contentVolume}
        onContentVolumeChange={setContentVolume}
        musicVolume={musicVolume}
        onMusicVolumeChange={setMusicVolume}
        suggestion={musicSuggestion}
        onGenerated={handleTrackGenerated}
        defaultPrompt={musicSuggestion ? `${musicSuggestion.mood} instrumental` : undefined}
        onAiMatch={photoUrl || slides.length > 0 ? handleAiMoodMatch : undefined}
        aiMatching={aiMoodMatch.isPending}
      />

      {/* ── AI FILTER CHALLENGE — share to unlock (after starting one) ──────────── */}
      {shareSheet && (
        <ChallengeShareSheet
          open
          onOpenChange={(o) => {
            if (!o) {
              setShareSheet(null);
              onClose();
            }
          }}
          challengeId={shareSheet.challengeId}
          postId={shareSheet.postId}
          prompt={challengePrompt}
        />
      )}

      {/* ── CSS animations ─────────────────────────────────────────────────────── */}
      <style>{`
        @keyframes countPop {
          0%   { transform: scale(1.4); opacity: 1; }
          60%  { transform: scale(0.9); opacity: 1; }
          100% { transform: scale(1);   opacity: 0; }
        }
        @keyframes fadeOut { 0% { opacity: 1; } 100% { opacity: 0; } }
        .animate-fade-out { animation: fadeOut 0.3s ease-out forwards; }
        .scrollbar-none::-webkit-scrollbar { display: none; }
        .scrollbar-none { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  );
}
