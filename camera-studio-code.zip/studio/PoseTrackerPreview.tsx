// Standalone, unlisted debug preview for the reusable body-pose tracking
// infrastructure (StudioPoseTracker + poseAngles). No AppLayout / auth. Renders the
// LIVE webcam with a skeleton overlay drawn from the tracker's normalized landmarks
// plus live joint-angle readouts, so the pose pipeline + angle math can be verified on
// a real device (this environment has no WebGL2 / no camera). Not an end-user feature
// and unreferenced by any navigation — the pose infra ships without a shipping filter.
import { useEffect, useRef, useState } from "react";
import { StudioPoseTracker } from "./poseTracking";
import { computePoseAngles, POSE_LANDMARKS as L } from "./poseAngles";

// MediaPipe pose connections we draw (upper body + legs; a readable subset).
const BONES: [number, number][] = [
  [L.leftShoulder, L.rightShoulder],
  [L.leftShoulder, L.leftElbow], [L.leftElbow, L.leftWrist],
  [L.rightShoulder, L.rightElbow], [L.rightElbow, L.rightWrist],
  [L.leftShoulder, L.leftHip], [L.rightShoulder, L.rightHip], [L.leftHip, L.rightHip],
  [L.leftHip, L.leftKnee], [L.leftKnee, L.leftAnkle],
  [L.rightHip, L.rightKnee], [L.rightKnee, L.rightAnkle],
];
const JOINTS = [
  L.leftShoulder, L.rightShoulder, L.leftElbow, L.rightElbow, L.leftWrist, L.rightWrist,
  L.leftHip, L.rightHip, L.leftKnee, L.rightKnee, L.leftAnkle, L.rightAnkle,
];

export default function PoseTrackerPreview() {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");
  const [msg, setMsg] = useState("");

  useEffect(() => {
    let raf = 0;
    let disposed = false;
    let stream: MediaStream | null = null;
    const video = document.createElement("video");
    video.playsInline = true; video.muted = true;
    const tracker = new StudioPoseTracker(video);

    const display = document.createElement("canvas");
    display.width = 720; display.height = 960;
    display.style.width = "100%"; display.style.height = "100%"; display.style.display = "block";
    const ctx = display.getContext("2d")!;
    wrapRef.current?.appendChild(display);

    // Mirrored cover blit of the selfie video (matches the studio's default mirror).
    const drawCover = (src: CanvasImageSource, sw: number, sh: number) => {
      const cw = display.width, ch = display.height;
      const scale = Math.max(cw / sw, ch / sh);
      const dw = sw * scale, dh = sh * scale;
      const dx = (cw - dw) / 2, dy = (ch - dh) / 2;
      ctx.save();
      ctx.translate(cw, 0); ctx.scale(-1, 1); // selfie mirror
      ctx.drawImage(src, dx, dy, dw, dh);
      ctx.restore();
      return { scale, dx, dy, sw };
    };

    // Map a normalized landmark to DISPLAY px through the same cover + mirror.
    const mapper = (geo: { scale: number; dx: number; dy: number; sw: number }) => {
      const cw = display.width;
      const vh = video.videoHeight || geo.sw;
      const px = (nx: number) => cw - (geo.dx + nx * geo.sw * geo.scale);
      const py = (ny: number) => geo.dy + ny * vh * geo.scale;
      return { px, py };
    };

    const drawSkeleton = (
      norm: Float32Array,
      geo: { scale: number; dx: number; dy: number; sw: number },
    ) => {
      const { px, py } = mapper(geo);
      ctx.lineWidth = 4; ctx.strokeStyle = "rgba(120,230,160,0.75)";
      for (const [a, b] of BONES) {
        ctx.beginPath();
        ctx.moveTo(px(norm[a * 3]), py(norm[a * 3 + 1]));
        ctx.lineTo(px(norm[b * 3]), py(norm[b * 3 + 1]));
        ctx.stroke();
      }
      ctx.fillStyle = "#7dffb0";
      for (const i of JOINTS) {
        ctx.beginPath();
        ctx.arc(px(norm[i * 3]), py(norm[i * 3 + 1]), 7, 0, Math.PI * 2);
        ctx.fill();
      }
    };

    const fmt = (v: number | null) => (v == null ? "—" : `${Math.round(v)}°`);
    const burnHud = (lines: string[]) => {
      ctx.font = "600 22px system-ui, sans-serif";
      ctx.textBaseline = "top";
      let y = 12;
      for (const line of lines) {
        const w = ctx.measureText(line).width + 20;
        ctx.fillStyle = "rgba(0,0,0,0.55)";
        ctx.fillRect(8, y - 4, w, 30);
        ctx.fillStyle = "#eafcea";
        ctx.fillText(line, 18, y);
        y += 34;
      }
    };

    const loop = () => {
      raf = requestAnimationFrame(loop);
      ctx.clearRect(0, 0, display.width, display.height);
      const geo = video.videoWidth > 0 ? drawCover(video, video.videoWidth, video.videoHeight) : null;
      const t = tracker.getTracking();
      if (t && geo) {
        drawSkeleton(t.norm, geo);
        const a = computePoseAngles(t.world);
        burnHud([
          `L elbow ${fmt(a.leftElbow)}    R elbow ${fmt(a.rightElbow)}`,
          `L knee ${fmt(a.leftKnee)}    R knee ${fmt(a.rightKnee)}`,
          `L shoulder ${fmt(a.leftShoulder)}    R shoulder ${fmt(a.rightShoulder)}`,
          `L hip ${fmt(a.leftHip)}    R hip ${fmt(a.rightHip)}`,
          `fade ${t.fade.toFixed(2)}`,
        ]);
      } else {
        burnHud(["no pose detected — stand back so your body is in frame"]);
      }
    };

    const start = async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "user", width: 720, height: 960 }, audio: false,
        });
        if (disposed) return;
        video.srcObject = stream;
        await video.play();
        await tracker.start();
        if (disposed) return;
        setStatus("ready");
        loop();
      } catch (e: unknown) {
        if (disposed) return;
        setStatus("error");
        setMsg(e instanceof Error ? e.message : String(e));
      }
    };

    start();

    return () => {
      disposed = true;
      cancelAnimationFrame(raf);
      tracker.dispose();
      stream?.getTracks().forEach((tr) => tr.stop());
      display.remove();
    };
  }, []);

  return (
    <div style={{
      position: "fixed", inset: 0, background: "#0a0a0a", display: "flex",
      flexDirection: "column", alignItems: "center", justifyContent: "center",
      gap: 10, fontFamily: "system-ui, sans-serif", color: "#eee", padding: 12,
    }}>
      <div style={{ fontSize: 12, letterSpacing: 2, opacity: 0.7, textTransform: "uppercase" }}>
        Body-pose tracker — live debug preview
      </div>
      <div ref={wrapRef} style={{
        width: "min(90vw, 460px)", aspectRatio: "3 / 4", background: "#000",
        borderRadius: 14, overflow: "hidden", boxShadow: "0 0 44px rgba(90,170,90,0.18)",
      }} />
      <div style={{ fontSize: 11, opacity: 0.6, textAlign: "center", maxWidth: 380 }}>
        status: {status}{msg ? ` — ${msg}` : ""}
        <br />
        Move your arms and legs — the skeleton tracks your body and the readouts show
        each joint's angle. Angles read "—" when a joint isn't reliably visible.
      </div>
    </div>
  );
}
