import React from "react";
import { createPortal } from "react-dom";
import { CameraStudio } from "./CameraStudio";
import { subscribeStudioLaunch, type StudioLaunchOptions } from "@/lib/studioLauncher";
import { suspendFeedPlayback, resumeFeedPlayback } from "@/components/post/PostMedia";

// App-level Camera Studio overlay, opened instantly (no page reload) by
// launchStudio() — the fast path behind "Use this sound", "Duet" and
// "Use this filter". Mounted once in App.tsx inside the router/providers.
export function StudioLauncherHost() {
  // seq keys the CameraStudio so a re-launch with different options always
  // gets a fresh studio instance instead of stale internal state.
  const [launch, setLaunch] = React.useState<(StudioLaunchOptions & { seq: number }) | null>(null);
  const seqRef = React.useRef(0);

  React.useEffect(
    () => subscribeStudioLaunch((opts) => setLaunch({ ...opts, seq: ++seqRef.current })),
    [],
  );

  // Feed clips must never keep playing (possibly with sound) behind the
  // studio — same contract as the immersive/Slipstream overlays.
  React.useEffect(() => {
    if (!launch) return;
    suspendFeedPlayback();
    return () => resumeFeedPlayback();
  }, [launch]);

  if (!launch) return null;

  // z-[120] sits above the immersive viewer / Slipstream overlays (z-[100])
  // so launching from inside a viewer lands the studio on top.
  return createPortal(
    <div className="fixed inset-0 z-[120] bg-black" style={{ touchAction: "none" }}>
      <CameraStudio
        key={launch.seq}
        onClose={() => setLaunch(null)}
        challengeId={launch.challengeId}
        preselectMusicTrackId={launch.preselectMusicTrackId}
        duetOfPostId={launch.duetOfPostId}
      />
    </div>,
    document.body,
  );
}
