// ── Experience Renderer ───────────────────────────────────────────────────────
// Each experience defines a cinematic canvas compositor.
// "render" is called every animation frame and draws on top of (or behind) the
// camera feed.  "filterCss" is applied to the <video> / <canvas> element so the
// raw camera itself is transformed.
// "onTap" is called when the user clicks inside the camera viewport.
// ─────────────────────────────────────────────────────────────────────────────

export interface Experience {
  id: string;
  label: string;
  creator: string;
  uses: string;
  rating: number;
  category: "Safety" | "Industrial" | "Fantasy" | "Gaming" | "AI" | "Comedy" | "Trending" | "Convo";
  tagline: string;
  previewGradient: string;
  previewEmoji: string;
  filterCss: string;        // applied to the camera element
  needsGreenScreen: boolean; // whether to composite user over AI bg
  render: (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number, state: ExperienceState) => void;
  onTap?: (x: number, y: number, state: ExperienceState) => void;
}

export interface ExperienceState {
  score: number;
  tapTargets: TapTarget[];
  particles: Particle[];
  scanAngle: number;
  hazards: HazardMarker[];
  evidenceMarkers: EvidenceMarker[];
  dragonPos: { x: number; y: number; orbit: number };
  sparkEmitters: SparkEmitter[];
  lastTapX: number;
  lastTapY: number;
  lastTapFrame: number;
}

export interface TapTarget { id: string; x: number; y: number; label: string; caught: boolean; frame: number; }
export interface Particle { x: number; y: number; vx: number; vy: number; life: number; maxLife: number; r: number; color: string; type: "spark" | "smoke" | "magic" | "rune"; }
export interface HazardMarker { id: string; x: number; y: number; label: string; frame: number; visible: boolean; }
export interface EvidenceMarker { id: string; x: number; y: number; label: string; frame: number; }
export interface SparkEmitter { x: number; y: number; active: boolean; }

export function makeExperienceState(): ExperienceState {
  return {
    score: 0,
    tapTargets: [],
    particles: [],
    scanAngle: 0,
    hazards: [],
    evidenceMarkers: [],
    dragonPos: { x: 0.5, y: 0.15, orbit: 0 },
    sparkEmitters: [],
    lastTapX: 0.5,
    lastTapY: 0.5,
    lastTapFrame: -1000,
  };
}

// ── Draw helpers ──────────────────────────────────────────────────────────────
function hexToRgba(hex: string, alpha: number) {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r},${g},${b},${alpha})`;
}

function drawRoundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function drawCornerBracket(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, dir: [1 | -1, 1 | -1]) {
  const [dx, dy] = dir;
  ctx.beginPath();
  ctx.moveTo(x, y + dy * size);
  ctx.lineTo(x, y);
  ctx.lineTo(x + dx * size, y);
  ctx.stroke();
}

function emitSparks(state: ExperienceState, cx: number, cy: number, count: number) {
  for (let i = 0; i < count; i++) {
    const angle = Math.random() * Math.PI * 2;
    const speed = 1 + Math.random() * 4;
    state.particles.push({
      x: cx, y: cy,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed - 4,
      life: 1, maxLife: 1,
      r: 2 + Math.random() * 4,
      color: Math.random() > 0.5 ? "#fff" : "#ff9800",
      type: "spark",
    });
  }
}

function emitMagic(state: ExperienceState, cx: number, cy: number, count: number) {
  for (let i = 0; i < count; i++) {
    const angle = -Math.PI / 2 + (Math.random() - 0.5) * Math.PI;
    const speed = 1 + Math.random() * 3;
    state.particles.push({
      x: cx, y: cy,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      life: 1, maxLife: 1,
      r: 3 + Math.random() * 5,
      color: ["#a855f7", "#7c3aed", "#6366f1", "#c084fc", "#ffffff"][Math.floor(Math.random() * 5)],
      type: "magic",
    });
  }
}

function tickParticles(state: ExperienceState) {
  const decay = 0.018;
  for (const p of state.particles) {
    p.x += p.vx;
    p.y += p.vy;
    if (p.type === "spark") { p.vy += 0.3; p.vx *= 0.97; }
    if (p.type === "smoke") { p.vy -= 0.1; p.vx *= 0.98; }
    if (p.type === "magic") { p.vx *= 0.96; p.vy *= 0.96; }
    p.life = Math.max(0, p.life - decay);
  }
  state.particles = state.particles.filter(p => p.life > 0);
}

function drawParticles(ctx: CanvasRenderingContext2D, state: ExperienceState, w: number, h: number) {
  for (const p of state.particles) {
    ctx.globalAlpha = p.life;
    ctx.fillStyle = p.color;
    if (p.type === "smoke") {
      ctx.beginPath();
      ctx.arc(p.x * w, p.y * h, p.r * 3 * (1 - p.life + 0.5), 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.beginPath();
      ctx.arc(p.x * w, p.y * h, p.r * p.life, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.globalAlpha = 1;
}

// ── Experiences ───────────────────────────────────────────────────────────────
export const EXPERIENCES: Experience[] = [

  // ── Blueprint Vision ───────────────────────────────────────────────────────
  {
    id: "blueprint_vision",
    label: "Blueprint Vision",
    creator: "SafetyNerd87",
    uses: "12.4M",
    rating: 4.9,
    category: "Safety",
    tagline: "See the world like an engineer.",
    previewGradient: "linear-gradient(135deg,#0a1929,#0d2137,#1a3a5c,#0f4c81)",
    previewEmoji: "📐",
    filterCss: "grayscale(0.3) sepia(0.5) hue-rotate(190deg) saturate(3) brightness(0.75) contrast(1.1)",
    needsGreenScreen: false,
    render(ctx, w, h, frame) {
      // Blueprint grid
      ctx.globalAlpha = 0.18;
      ctx.strokeStyle = "#4fc3f7";
      ctx.lineWidth = 1;
      const spacing = w / 20;
      for (let x = 0; x < w; x += spacing) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke(); }
      for (let y = 0; y < h; y += spacing) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke(); }

      // Scan beam
      const scanY = ((frame * 2.5) % (h + 60)) - 30;
      const grad = ctx.createLinearGradient(0, scanY - 30, 0, scanY + 30);
      grad.addColorStop(0, "rgba(79,195,247,0)");
      grad.addColorStop(0.5, "rgba(79,195,247,0.28)");
      grad.addColorStop(1, "rgba(79,195,247,0)");
      ctx.fillStyle = grad;
      ctx.globalAlpha = 1;
      ctx.fillRect(0, scanY - 30, w, 60);

      // Corner brackets
      ctx.globalAlpha = 0.9;
      ctx.strokeStyle = "#4fc3f7";
      ctx.lineWidth = 3;
      const bm = 24;
      const bs = 40;
      drawCornerBracket(ctx, bm, bm, bs, [1, 1]);
      drawCornerBracket(ctx, w - bm, bm, bs, [-1, 1]);
      drawCornerBracket(ctx, bm, h - bm, bs, [1, -1]);
      drawCornerBracket(ctx, w - bm, h - bm, bs, [-1, -1]);

      // HUD: top left status
      ctx.globalAlpha = 0.92;
      ctx.fillStyle = "rgba(13,33,55,0.75)";
      drawRoundRect(ctx, 16, 16, 220, 90, 6);
      ctx.fill();
      ctx.fillStyle = "#4fc3f7";
      ctx.font = "bold 11px monospace";
      ctx.fillText("BLUEPRINT VISION ACTIVE", 28, 36);
      ctx.fillStyle = "#81d4fa";
      ctx.font = "10px monospace";
      ctx.fillText(`SCAN DEPTH:  ${(2.1 + Math.sin(frame * 0.04) * 0.4).toFixed(2)} m`, 28, 55);
      ctx.fillText(`OBJECTS:     ${3 + Math.floor(frame / 90) % 4}`, 28, 71);
      ctx.fillText(`STATUS:      ANALYZING...`, 28, 87);

      // Floating dimension labels (animated appearance)
      const labels = [
        { x: 0.3, y: 0.35, text: "↔ 2.4m", delay: 30 },
        { x: 0.6, y: 0.55, text: "↕ 1.8m", delay: 70 },
        { x: 0.2, y: 0.65, text: "◎ MATERIAL: STEEL", delay: 110 },
        { x: 0.65, y: 0.25, text: "⚙ LOAD BEARING", delay: 150 },
      ];
      for (const lbl of labels) {
        if (frame < lbl.delay) continue;
        const age = Math.min(frame - lbl.delay, 20) / 20;
        ctx.globalAlpha = age * 0.9;
        ctx.fillStyle = "rgba(13,33,55,0.7)";
        const tw = ctx.measureText(lbl.text).width;
        drawRoundRect(ctx, lbl.x * w - 6, lbl.y * h - 14, tw + 12, 20, 4);
        ctx.fill();
        ctx.fillStyle = "#4fc3f7";
        ctx.font = "bold 10px monospace";
        ctx.fillText(lbl.text, lbl.x * w, lbl.y * h);
      }

      // Bottom status bar
      ctx.globalAlpha = 0.85;
      ctx.fillStyle = "rgba(13,33,55,0.8)";
      ctx.fillRect(0, h - 36, w, 36);
      ctx.fillStyle = "#4fc3f7";
      ctx.font = "bold 11px monospace";
      ctx.textAlign = "center";
      ctx.fillText("BLUEPRINT VISION  ·  Run2TCoM Camera Studio  ·  SafetyNerd87", w / 2, h - 14);
      ctx.textAlign = "left";
      ctx.globalAlpha = 1;
    },
  },

  // ── Control Room Commander ─────────────────────────────────────────────────
  {
    id: "control_room",
    label: "Control Room Commander",
    creator: "BuildMaster",
    uses: "4.2M",
    rating: 4.7,
    category: "Industrial",
    tagline: "Command the plant. Control the process.",
    previewGradient: "linear-gradient(135deg,#0f2027,#203a43,#2c5364)",
    previewEmoji: "🏭",
    filterCss: "saturate(1.1) brightness(0.9) contrast(1.05)",
    needsGreenScreen: false,
    render(ctx, w, h, frame) {
      // Side process panels (left)
      ctx.globalAlpha = 0.82;
      ctx.fillStyle = "rgba(0,20,40,0.8)";
      ctx.fillRect(0, 0, w * 0.22, h);
      // Process flow lines
      ctx.strokeStyle = "#00e5ff";
      ctx.lineWidth = 2;
      ctx.globalAlpha = 0.7;
      const pipes = [[0.06, 0.15, 0.18, 0.15], [0.06, 0.3, 0.18, 0.3], [0.06, 0.45, 0.18, 0.45], [0.06, 0.6, 0.18, 0.6]];
      for (const [x1, y1, x2, y2] of pipes) {
        ctx.beginPath(); ctx.moveTo(x1 * w, y1 * h); ctx.lineTo(x2 * w, y2 * h); ctx.stroke();
        ctx.beginPath(); ctx.arc(x1 * w, y1 * h, 6, 0, Math.PI * 2);
        ctx.fillStyle = Math.random() > 0.995 ? "#f44336" : "#00e5ff";
        ctx.fill();
      }
      // Trend chart
      ctx.globalAlpha = 0.9;
      ctx.strokeStyle = "#76ff03";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (let i = 0; i <= 20; i++) {
        const fx = 0.01 + (i / 20) * 0.19;
        const fy = 0.68 + Math.sin((frame + i * 8) * 0.08) * 0.06;
        i === 0 ? ctx.moveTo(fx * w, fy * h) : ctx.lineTo(fx * w, fy * h);
      }
      ctx.stroke();

      // Right panel
      ctx.globalAlpha = 0.82;
      ctx.fillStyle = "rgba(0,20,40,0.8)";
      ctx.fillRect(w * 0.78, 0, w * 0.22, h);
      // Alarm indicators
      const alarms = [
        { label: "TEMP", val: "287°C", ok: true },
        { label: "PRESS", val: "12.4 BAR", ok: true },
        { label: "FLOW", val: "94 m³/h", ok: frame % 200 > 160 ? false : true },
        { label: "LEVEL", val: "67%", ok: true },
      ];
      ctx.font = "bold 10px monospace";
      for (let i = 0; i < alarms.length; i++) {
        const ay = (0.15 + i * 0.16) * h;
        ctx.globalAlpha = 0.9;
        ctx.fillStyle = alarms[i].ok ? "#1b5e20" : "#b71c1c";
        drawRoundRect(ctx, w * 0.80, ay, w * 0.18, 28, 4);
        ctx.fill();
        ctx.fillStyle = alarms[i].ok ? "#76ff03" : "#ff1744";
        ctx.fillText(alarms[i].label, w * 0.81, ay + 11);
        ctx.fillText(alarms[i].val, w * 0.81, ay + 22);
      }

      // Top HUD bar
      ctx.globalAlpha = 0.9;
      ctx.fillStyle = "rgba(0,20,40,0.85)";
      ctx.fillRect(0, 0, w, 32);
      ctx.fillStyle = "#00e5ff";
      ctx.font = "bold 12px monospace";
      ctx.textAlign = "center";
      ctx.fillText("⚡  UNIT 3 CONTROL ROOM  ·  SHIFT A  ·  ALL SYSTEMS NOMINAL", w / 2, 20);
      ctx.textAlign = "left";
      ctx.globalAlpha = 1;
    },
  },

  // ── Safety Inspector Vision ────────────────────────────────────────────────
  {
    id: "safety_inspector",
    label: "Safety Inspector Vision",
    creator: "HSECreator",
    uses: "7.8M",
    rating: 4.8,
    category: "Safety",
    tagline: "AR hazard detection. Find it before it finds you.",
    previewGradient: "linear-gradient(135deg,#1a0505,#3d0000,#590000)",
    previewEmoji: "🔍",
    filterCss: "saturate(1.2) brightness(1.0) contrast(1.08)",
    needsGreenScreen: false,
    render(ctx, w, h, frame, state) {
      // Ensure hazards are seeded
      if (state.hazards.length === 0) {
        const defs = [
          { id: "h1", x: 0.2, y: 0.4, label: "⚠ TRIP HAZARD" },
          { id: "h2", x: 0.75, y: 0.6, label: "🚫 EGRESS BLOCKED" },
          { id: "h3", x: 0.5, y: 0.3, label: "⚠ PPE REQUIRED" },
          { id: "h4", x: 0.15, y: 0.7, label: "☠ CHEMICAL RISK" },
          { id: "h5", x: 0.8, y: 0.35, label: "⚡ ELECTRICAL" },
        ];
        for (const d of defs) {
          state.hazards.push({ ...d, frame: 40 + Math.floor(Math.random() * 80), visible: false });
        }
      }
      // Reveal hazards over time
      for (const hz of state.hazards) {
        if (!hz.visible && frame > hz.frame) hz.visible = true;
      }

      // Scan beam (red)
      const scanY = ((frame * 2) % (h + 40)) - 20;
      const scanGrad = ctx.createLinearGradient(0, scanY - 20, 0, scanY + 20);
      scanGrad.addColorStop(0, "rgba(244,67,54,0)");
      scanGrad.addColorStop(0.5, "rgba(244,67,54,0.22)");
      scanGrad.addColorStop(1, "rgba(244,67,54,0)");
      ctx.fillStyle = scanGrad;
      ctx.fillRect(0, scanY - 20, w, 40);

      // Hazard markers
      for (const hz of state.hazards) {
        if (!hz.visible) continue;
        const age = Math.min(frame - hz.frame, 20) / 20;
        ctx.globalAlpha = age * 0.92;
        const mx = hz.x * w;
        const my = hz.y * h;
        // Pulsing ring
        const pulse = 0.5 + 0.5 * Math.sin(frame * 0.12);
        ctx.strokeStyle = "#f44336";
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(mx, my, 20 + pulse * 8, 0, Math.PI * 2); ctx.stroke();
        // Label pill
        ctx.fillStyle = "rgba(183,28,28,0.85)";
        const tw = ctx.measureText(hz.label).width;
        drawRoundRect(ctx, mx - tw / 2 - 8, my + 26, tw + 16, 20, 10);
        ctx.fill();
        ctx.fillStyle = "#ffffff";
        ctx.font = "bold 10px sans-serif";
        ctx.textAlign = "center";
        ctx.fillText(hz.label, mx, my + 40);
        ctx.textAlign = "left";
      }

      // Score panel
      const found = state.hazards.filter(h => h.visible).length;
      ctx.globalAlpha = 0.9;
      ctx.fillStyle = "rgba(0,0,0,0.7)";
      drawRoundRect(ctx, w - 160, 12, 148, 60, 8);
      ctx.fill();
      ctx.fillStyle = "#f44336";
      ctx.font = "bold 12px monospace";
      ctx.textAlign = "right";
      ctx.fillText(`HAZARDS: ${found}/${state.hazards.length}`, w - 20, 36);
      ctx.fillStyle = "#ffeb3b";
      ctx.font = "bold 11px monospace";
      ctx.fillText(`SCORE: ${state.score + found * 100} XP`, w - 20, 56);
      ctx.textAlign = "left";
      ctx.globalAlpha = 1;
    },
    onTap(x, y, state) {
      for (const hz of state.hazards) {
        if (!hz.visible) continue;
        const dist = Math.sqrt((hz.x - x) ** 2 + (hz.y - y) ** 2);
        if (dist < 0.08) { state.score += 100; hz.visible = false; hz.frame = 9999; }
      }
    },
  },

  // ── Welding Sparks ─────────────────────────────────────────────────────────
  {
    id: "welding_sparks",
    label: "Welding Sparks",
    creator: "SafetyNerd87",
    uses: "9.1M",
    rating: 4.7,
    category: "Industrial",
    tagline: "Arc flash. Sparks. Real heat. No PPE required.",
    previewGradient: "linear-gradient(135deg,#1a0a00,#3d1a00,#6b2f00)",
    previewEmoji: "⚡",
    filterCss: "brightness(1.0) saturate(1.1)",
    needsGreenScreen: false,
    render(ctx, w, h, frame, state) {
      // Arc glow at bottom center
      const ex = 0.5, ey = 0.85;
      const glow = ctx.createRadialGradient(ex * w, ey * h, 0, ex * w, ey * h, 120);
      glow.addColorStop(0, `rgba(255,200,50,${0.5 + 0.3 * Math.sin(frame * 0.4)})`);
      glow.addColorStop(0.4, "rgba(255,100,0,0.18)");
      glow.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = glow;
      ctx.fillRect(0, 0, w, h);

      // Arc flash flicker
      if (frame % 7 < 2) {
        ctx.globalAlpha = 0.12;
        ctx.fillStyle = "#fff";
        ctx.fillRect(0, 0, w, h);
        ctx.globalAlpha = 1;
      }

      // Emit sparks
      if (frame % 2 === 0) emitSparks(state, ex, ey, 6);
      // Emit smoke
      if (frame % 8 === 0) {
        state.particles.push({
          x: ex + (Math.random() - 0.5) * 0.04,
          y: ey - 0.02,
          vx: (Math.random() - 0.5) * 0.3,
          vy: -0.5 - Math.random() * 0.3,
          life: 1, maxLife: 1,
          r: 6 + Math.random() * 8,
          color: "rgba(120,120,120,0.4)",
          type: "smoke",
        });
      }
      tickParticles(state);
      drawParticles(ctx, state, w, h);

      // Arc electrode visual
      ctx.globalAlpha = 0.9;
      ctx.strokeStyle = "#ff9800";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(ex * w - 20, ey * h - 40);
      ctx.lineTo(ex * w, ey * h);
      ctx.stroke();
      // Weld point flash
      ctx.globalAlpha = 0.6 + 0.4 * Math.sin(frame * 0.5);
      ctx.fillStyle = "#fff";
      ctx.beginPath(); ctx.arc(ex * w, ey * h, 5, 0, Math.PI * 2); ctx.fill();

      // HUD
      ctx.globalAlpha = 0.85;
      ctx.fillStyle = "rgba(0,0,0,0.7)";
      drawRoundRect(ctx, 12, h - 52, 200, 40, 6);
      ctx.fill();
      ctx.fillStyle = "#ff9800";
      ctx.font = "bold 11px monospace";
      ctx.fillText("⚡ WELDING ARC ACTIVE", 20, h - 34);
      ctx.fillStyle = "#ffcc80";
      ctx.font = "10px monospace";
      ctx.fillText(`AMPS: ${(180 + Math.sin(frame * 0.2) * 12).toFixed(0)}A  VOLTS: 24V`, 20, h - 20);
      ctx.globalAlpha = 1;
    },
  },

  // ── Hazard Hunt ────────────────────────────────────────────────────────────
  {
    id: "hazard_hunt",
    label: "Hazard Hunt",
    creator: "HSECreator",
    uses: "6.3M",
    rating: 4.8,
    category: "Gaming",
    tagline: "Pokémon Go for safety. Find them. Tap them. Win.",
    previewGradient: "linear-gradient(135deg,#0d1b2a,#1b4332,#0a3d1e)",
    previewEmoji: "🎯",
    filterCss: "brightness(1.02) saturate(1.1)",
    needsGreenScreen: false,
    render(ctx, w, h, frame, state) {
      // Spawn targets
      if (state.tapTargets.length < 4 && frame % 120 === 0) {
        const defs = ["🔥 FIRE RISK", "☠ TOXIC", "⚡ ELECTRICAL", "⚠ FALL HAZARD", "🚧 STRUCK-BY", "💧 SLIP HAZARD"];
        state.tapTargets.push({
          id: `t${frame}`,
          x: 0.1 + Math.random() * 0.8,
          y: 0.15 + Math.random() * 0.65,
          label: defs[Math.floor(Math.random() * defs.length)],
          caught: false,
          frame,
        });
      }

      // Draw targets
      for (const t of state.tapTargets) {
        if (t.caught) continue;
        const age = frame - t.frame;
        const pulse = 0.7 + 0.3 * Math.sin(frame * 0.15 + t.x * 10);
        ctx.globalAlpha = Math.min(age / 20, 1) * 0.95;
        // Glow
        const rg = ctx.createRadialGradient(t.x * w, t.y * h, 0, t.x * w, t.y * h, 36 * pulse);
        rg.addColorStop(0, "rgba(255,235,59,0.4)");
        rg.addColorStop(1, "rgba(255,235,59,0)");
        ctx.fillStyle = rg;
        ctx.beginPath(); ctx.arc(t.x * w, t.y * h, 36 * pulse, 0, Math.PI * 2); ctx.fill();
        // Ring
        ctx.strokeStyle = "#ffeb3b";
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(t.x * w, t.y * h, 22 * pulse, 0, Math.PI * 2); ctx.stroke();
        // Label
        ctx.fillStyle = "rgba(0,0,0,0.8)";
        const tw = ctx.measureText(t.label).width;
        drawRoundRect(ctx, t.x * w - tw / 2 - 6, t.y * h + 28, tw + 12, 20, 10);
        ctx.fill();
        ctx.fillStyle = "#ffeb3b";
        ctx.font = "bold 10px sans-serif";
        ctx.textAlign = "center";
        ctx.fillText(t.label, t.x * w, t.y * h + 42);
        ctx.textAlign = "left";
      }
      state.tapTargets = state.tapTargets.filter(t => !t.caught && frame - t.frame < 300);

      // Score
      ctx.globalAlpha = 0.9;
      ctx.fillStyle = "rgba(0,0,0,0.75)";
      drawRoundRect(ctx, 12, 12, 190, 70, 8);
      ctx.fill();
      ctx.fillStyle = "#ffeb3b";
      ctx.font = "bold 14px sans-serif";
      ctx.fillText("🎯 HAZARD HUNT", 22, 36);
      ctx.fillStyle = "#ffffff";
      ctx.font = "11px monospace";
      ctx.fillText(`SCORE:   ${state.score} XP`, 22, 54);
      ctx.fillText(`TARGETS: ${state.tapTargets.length} visible`, 22, 70);
      ctx.globalAlpha = 1;
    },
    onTap(x, y, state) {
      for (const t of state.tapTargets) {
        if (t.caught) continue;
        const dist = Math.sqrt((t.x - x) ** 2 + (t.y - y) ** 2);
        if (dist < 0.07) { t.caught = true; state.score += 250; }
      }
    },
  },

  // ── Dragon Companion ───────────────────────────────────────────────────────
  {
    id: "dragon_companion",
    label: "Dragon Companion",
    creator: "FantasyForge",
    uses: "28.7M",
    rating: 4.9,
    category: "Fantasy",
    tagline: "A real AI companion. Not a sticker. It responds to you.",
    previewGradient: "linear-gradient(135deg,#1a0505,#4a0e0e,#6b1010,#8b1a1a)",
    previewEmoji: "🐉",
    filterCss: "brightness(0.95) saturate(1.1) hue-rotate(5deg)",
    needsGreenScreen: false,
    render(ctx, w, h, frame, state) {
      // Update dragon orbit
      state.dragonPos.orbit += 0.018;
      const ox = 0.5 + Math.cos(state.dragonPos.orbit) * 0.32;
      const oy = 0.18 + Math.sin(state.dragonPos.orbit * 0.7) * 0.12;
      state.dragonPos.x = ox;
      state.dragonPos.y = oy;

      // Dragon body (canvas path dragon)
      const dx = ox * w, dy = oy * h;
      const scale = w * 0.055;
      const angle = Math.sin(state.dragonPos.orbit) > 0 ? 0.3 : -0.3 + Math.PI;
      ctx.save();
      ctx.translate(dx, dy);
      ctx.rotate(angle);

      // Wing shadow
      ctx.globalAlpha = 0.3;
      ctx.fillStyle = "#8b1a1a";
      ctx.beginPath();
      ctx.ellipse(-scale * 1.2, -scale * 0.3, scale * 1.5, scale * 0.7, -0.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(scale * 1.2, -scale * 0.3, scale * 1.5, scale * 0.7, 0.5, 0, Math.PI * 2);
      ctx.fill();

      // Wings
      ctx.globalAlpha = 0.85;
      const wingFlap = Math.sin(frame * 0.25) * 0.4;
      ctx.fillStyle = "#c62828";
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo(-scale * 2, -scale * (1.8 + wingFlap), -scale * 2.8, -scale * 0.2);
      ctx.quadraticCurveTo(-scale * 1.5, scale * 0.5, 0, scale * 0.3);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo(scale * 2, -scale * (1.8 + wingFlap), scale * 2.8, -scale * 0.2);
      ctx.quadraticCurveTo(scale * 1.5, scale * 0.5, 0, scale * 0.3);
      ctx.fill();

      // Body
      ctx.fillStyle = "#b71c1c";
      ctx.beginPath();
      ctx.ellipse(0, scale * 0.3, scale * 0.5, scale * 0.9, 0, 0, Math.PI * 2);
      ctx.fill();

      // Head
      ctx.fillStyle = "#c62828";
      ctx.beginPath();
      ctx.ellipse(0, -scale * 0.5, scale * 0.38, scale * 0.38, 0, 0, Math.PI * 2);
      ctx.fill();

      // Eye
      ctx.fillStyle = "#ffeb3b";
      ctx.beginPath();
      ctx.arc(-scale * 0.12, -scale * 0.58, scale * 0.1, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#000";
      ctx.beginPath();
      ctx.arc(-scale * 0.12, -scale * 0.58, scale * 0.05, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();
      ctx.globalAlpha = 1;

      // Fire breath every 180 frames
      if (frame % 180 < 40) {
        const fireAge = frame % 180;
        const fireAlpha = fireAge < 10 ? fireAge / 10 : (40 - fireAge) / 30;
        ctx.globalAlpha = fireAlpha;
        const fx = dx + Math.cos(angle - 0.1) * scale * 0.5;
        const fy = dy + Math.sin(angle - 0.1) * scale * 0.5;
        const fg = ctx.createRadialGradient(fx, fy, 0, fx + 80, fy + 20, 80);
        fg.addColorStop(0, "#fff");
        fg.addColorStop(0.2, "#ffeb3b");
        fg.addColorStop(0.6, "#ff5722");
        fg.addColorStop(1, "rgba(244,67,54,0)");
        ctx.fillStyle = fg;
        ctx.beginPath();
        ctx.arc(fx + 40, fy + 10, 80, 0, Math.PI * 2);
        ctx.fill();
        if (frame % 180 < 30) emitSparks(state, fx / w, fy / h, 3);
        ctx.globalAlpha = 1;
      }

      tickParticles(state);
      drawParticles(ctx, state, w, h);

      // Companion label
      ctx.globalAlpha = 0.8;
      ctx.fillStyle = "rgba(0,0,0,0.6)";
      drawRoundRect(ctx, ox * w - 55, oy * h + scale * 1.5 + 5, 110, 22, 11);
      ctx.fill();
      ctx.fillStyle = "#ff8a65";
      ctx.font = "bold 10px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("🐉 Your Companion", ox * w, oy * h + scale * 1.5 + 20);
      ctx.textAlign = "left";
      ctx.globalAlpha = 1;
    },
    onTap(x, y, state) {
      emitSparks(state, x, y, 15);
      emitMagic(state, x, y, 10);
    },
  },

  // ── Wizard Master ──────────────────────────────────────────────────────────
  {
    id: "wizard_master",
    label: "Wizard Master",
    creator: "FantasyForge",
    uses: "15.2M",
    rating: 4.8,
    category: "Fantasy",
    tagline: "You have the power. Cast spells. Control reality.",
    previewGradient: "linear-gradient(135deg,#0d0221,#1a0533,#2d0b5a,#4a0d8a)",
    previewEmoji: "🪄",
    filterCss: "brightness(0.9) saturate(1.3) hue-rotate(250deg)",
    needsGreenScreen: false,
    render(ctx, w, h, frame, state) {
      // Magic circle at bottom
      const cx = w * 0.5, cy = h * 0.82;
      const r = 80 + 10 * Math.sin(frame * 0.04);
      ctx.globalAlpha = 0.5 + 0.2 * Math.sin(frame * 0.06);
      ctx.strokeStyle = "#a855f7";
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
      ctx.beginPath(); ctx.arc(cx, cy, r * 0.7, 0, Math.PI * 2); ctx.stroke();
      // Rotating runes
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 2 + frame * 0.02;
        const rx = cx + Math.cos(a) * r;
        const ry = cy + Math.sin(a) * r;
        ctx.fillStyle = "#c084fc";
        ctx.font = "14px monospace";
        ctx.textAlign = "center";
        ctx.fillText("✦", rx, ry);
      }
      ctx.textAlign = "left";

      // Ambient magic particles emit
      if (frame % 4 === 0) {
        const a = Math.random() * Math.PI * 2;
        emitMagic(state, cx / w + Math.cos(a) * 0.08, cy / h + Math.sin(a) * 0.04, 2);
      }

      // Tap spell burst
      if (state.lastTapFrame > frame - 60) {
        emitMagic(state, state.lastTapX, state.lastTapY, 3);
      }

      tickParticles(state);
      drawParticles(ctx, state, w, h);

      // Glowing vignette
      const vig = ctx.createRadialGradient(w / 2, h / 2, h * 0.3, w / 2, h / 2, h * 0.8);
      vig.addColorStop(0, "rgba(0,0,0,0)");
      vig.addColorStop(1, "rgba(76,13,138,0.35)");
      ctx.globalAlpha = 1;
      ctx.fillStyle = vig;
      ctx.fillRect(0, 0, w, h);

      // HUD
      ctx.globalAlpha = 0.85;
      ctx.fillStyle = "rgba(13,2,33,0.75)";
      drawRoundRect(ctx, 12, 12, 175, 54, 8);
      ctx.fill();
      ctx.fillStyle = "#c084fc";
      ctx.font = "bold 12px sans-serif";
      ctx.fillText("🪄 WIZARD MASTER", 20, 32);
      ctx.fillStyle = "#e9d5ff";
      ctx.font = "10px monospace";
      ctx.fillText(`MANA: ${Math.min(100, 40 + frame % 60)}%   POWER: ${state.score + 3}`, 20, 50);
      ctx.globalAlpha = 1;
    },
    onTap(x, y, state) {
      state.lastTapX = x; state.lastTapY = y; state.lastTapFrame = 99999;
      emitMagic(state, x, y, 25);
      state.score += 10;
    },
  },

  // ── Incident Investigator ──────────────────────────────────────────────────
  {
    id: "incident_investigator",
    label: "Incident Investigator",
    creator: "HSECreator",
    uses: "2.1M",
    rating: 4.9,
    category: "Safety",
    tagline: "Professional investigation. Evidence. Measurements. Timeline.",
    previewGradient: "linear-gradient(135deg,#0a0a14,#141424,#1c1c34)",
    previewEmoji: "🔎",
    filterCss: "contrast(1.1) saturate(0.8) brightness(0.95)",
    needsGreenScreen: false,
    render(ctx, w, h, frame, state) {
      // Evidence markers from taps
      for (let i = 0; i < state.evidenceMarkers.length; i++) {
        const m = state.evidenceMarkers[i];
        const mx = m.x * w, my = m.y * h;
        ctx.globalAlpha = 0.9;
        ctx.fillStyle = "#1565c0";
        ctx.beginPath(); ctx.arc(mx, my, 14, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = "#fff";
        ctx.font = "bold 11px monospace";
        ctx.textAlign = "center";
        ctx.fillText(String(i + 1), mx, my + 4);
        ctx.textAlign = "left";
        // Connecting lines
        if (i > 0) {
          const prev = state.evidenceMarkers[i - 1];
          ctx.strokeStyle = "rgba(21,101,192,0.5)";
          ctx.lineWidth = 1.5;
          ctx.setLineDash([6, 4]);
          ctx.beginPath();
          ctx.moveTo(prev.x * w, prev.y * h);
          ctx.lineTo(mx, my);
          ctx.stroke();
          ctx.setLineDash([]);
        }
        // Label
        ctx.fillStyle = "rgba(13,17,40,0.85)";
        const tw = ctx.measureText(m.label).width;
        drawRoundRect(ctx, mx + 18, my - 12, tw + 12, 20, 4);
        ctx.fill();
        ctx.fillStyle = "#90caf9";
        ctx.font = "9px monospace";
        ctx.fillText(m.label, mx + 24, my + 1);
      }

      // Recording indicator
      if (frame % 60 < 30) {
        ctx.globalAlpha = 0.9;
        ctx.fillStyle = "#f44336";
        ctx.beginPath(); ctx.arc(w - 24, 20, 6, 0, Math.PI * 2); ctx.fill();
      }
      ctx.globalAlpha = 0.85;
      ctx.fillStyle = "#fff";
      ctx.font = "bold 10px monospace";
      ctx.textAlign = "right";
      ctx.fillText("● REC  INVESTIGATION MODE", w - 36, 24);
      ctx.textAlign = "left";

      // Timeline bar at bottom
      ctx.globalAlpha = 0.88;
      ctx.fillStyle = "rgba(0,0,0,0.75)";
      ctx.fillRect(0, h - 42, w, 42);
      ctx.fillStyle = "#90caf9";
      ctx.font = "10px monospace";
      ctx.fillText(`EVIDENCE MARKERS: ${state.evidenceMarkers.length}   TAP TO MARK EVIDENCE`, 16, h - 22);
      ctx.fillText(`CASE ID: INV-${String(frame).padStart(6, "0")}  INVESTIGATOR: YOU`, 16, h - 8);
      ctx.globalAlpha = 1;
    },
    onTap(x, y, state) {
      const labels = ["Photo taken", "Measurement set", "Witness location", "Physical evidence", "Damage area", "Entry/Exit point"];
      state.evidenceMarkers.push({
        id: `e${state.evidenceMarkers.length}`,
        x, y,
        label: labels[state.evidenceMarkers.length % labels.length],
        frame: 0,
      });
    },
  },

  // ── Forklift Operator ─────────────────────────────────────────────────────
  {
    id: "forklift_operator",
    label: "Forklift Operator",
    creator: "BuildMaster",
    uses: "3.4M",
    rating: 4.6,
    category: "Industrial",
    tagline: "Get in the cab. Move the load. Watch your mirrors.",
    previewGradient: "linear-gradient(135deg,#1a1000,#2a1800,#3d2200)",
    previewEmoji: "🚧",
    filterCss: "brightness(0.95) saturate(1.0)",
    needsGreenScreen: false,
    render(ctx, w, h, frame) {
      // Cab frame overlay
      ctx.globalAlpha = 0.88;
      ctx.fillStyle = "rgba(20,12,0,0.7)";
      // Left pillar
      ctx.fillRect(0, 0, w * 0.12, h);
      // Right pillar
      ctx.fillRect(w * 0.88, 0, w * 0.12, h);
      // Top beam
      ctx.fillRect(0, 0, w, h * 0.14);
      // Bottom dashboard
      ctx.fillRect(0, h * 0.78, w, h * 0.22);

      // Pillar detail (yellow safety stripes)
      ctx.fillStyle = "#ffb300";
      for (let i = 0; i < 6; i++) {
        if (i % 2 === 0) {
          ctx.fillRect(0, i * (h / 6), w * 0.12, h / 12);
          ctx.fillRect(w * 0.88, i * (h / 6), w * 0.12, h / 12);
        }
      }

      // Dashboard gauges
      ctx.fillStyle = "#1a1000";
      ctx.strokeStyle = "#ff8f00";
      ctx.lineWidth = 2;

      // Speed gauge
      const gx = w * 0.3, gy = h * 0.88;
      ctx.globalAlpha = 1;
      ctx.strokeStyle = "#888";
      ctx.beginPath(); ctx.arc(gx, gy, 28, Math.PI * 0.8, Math.PI * 2.2); ctx.stroke();
      const speed = 0.4 + 0.3 * Math.sin(frame * 0.05);
      const needleA = Math.PI * 0.8 + speed * Math.PI * 1.4;
      ctx.strokeStyle = "#ff8f00";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(gx, gy);
      ctx.lineTo(gx + Math.cos(needleA) * 22, gy + Math.sin(needleA) * 22);
      ctx.stroke();
      ctx.fillStyle = "#ffcc80";
      ctx.font = "9px monospace";
      ctx.textAlign = "center";
      ctx.fillText("SPD", gx, gy + 14);

      // Hour meter
      const hx = w * 0.5, hy = h * 0.88;
      ctx.fillStyle = "#111";
      drawRoundRect(ctx, hx - 36, hy - 14, 72, 24, 4);
      ctx.fill();
      ctx.fillStyle = "#76ff03";
      ctx.font = "bold 12px monospace";
      ctx.fillText(`${(frame / 30).toFixed(1)}h`, hx, hy + 4);
      ctx.fillStyle = "#4caf50";
      ctx.font = "8px monospace";
      ctx.fillText("HOURS", hx, hy + 15);

      // Fork position indicator
      const forkPct = 40 + 30 * Math.sin(frame * 0.03);
      const bx = w * 0.7, by = h * 0.83;
      ctx.strokeStyle = "#555";
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(bx, by + 30); ctx.stroke();
      ctx.strokeStyle = "#ff8f00";
      ctx.beginPath(); ctx.moveTo(bx, by + 30 - forkPct * 0.3); ctx.lineTo(bx, by + 30); ctx.stroke();
      ctx.fillStyle = "#ffcc80";
      ctx.font = "9px monospace";
      ctx.textAlign = "center";
      ctx.fillText("FORK", bx, by - 4);

      // Warning: backup alarm
      if (frame % 60 < 12) {
        ctx.globalAlpha = 0.92;
        ctx.fillStyle = "#ffeb3b";
        ctx.fillRect(w * 0.12, 0, w * 0.76, h * 0.14);
        ctx.fillStyle = "#000";
        ctx.font = "bold 18px monospace";
        ctx.textAlign = "center";
        ctx.fillText("⚠  CAUTION — FORKLIFT REVERSING  ⚠", w / 2, h * 0.09);
      } else {
        ctx.fillStyle = "#fff";
        ctx.font = "bold 13px monospace";
        ctx.textAlign = "center";
        ctx.fillText("OPERATOR CAB  ·  CERTIFIED FORKLIFT  ·  Run2TCoM", w / 2, h * 0.09);
      }

      ctx.textAlign = "left";
      ctx.globalAlpha = 1;
    },
  },

  // ══════════════════════════════════════════════════════════════════════════
  //  VISUAL STYLE WORLDS  — full color + texture transformations
  // ══════════════════════════════════════════════════════════════════════════

  // ── Century Egg ────────────────────────────────────────────────────────────
  {
    id: "century_egg",
    label: "Century Egg",
    creator: "Run2TCoM Studio",
    uses: "8.3M",
    rating: 4.9,
    category: "Trending",
    tagline: "Translucent jade. Amber glow. Pine flower crystals.",
    previewGradient: "linear-gradient(135deg,#0d1f14,#1a3324,#0f2b20,#2a4a34)",
    previewEmoji: "🥚",
    filterCss: "brightness(0.76) saturate(0.38) hue-rotate(148deg) contrast(1.35) sepia(0.06)",
    needsGreenScreen: false,
    render(ctx, w, h, frame) {
      // ── Pine flower (松花) crystallization overlay ──────────────────────
      ctx.globalAlpha = 0.13;
      ctx.strokeStyle = "#9dd4b0";
      ctx.lineWidth = 0.7;

      const PINE_FLOWER_POSITIONS = [
        [0.12, 0.18, 52], [0.68, 0.13, 44], [0.38, 0.44, 60],
        [0.84, 0.58, 38], [0.18, 0.72, 48], [0.58, 0.78, 42],
        [0.04, 0.48, 36], [0.92, 0.30, 40], [0.50, 0.22, 34],
        [0.76, 0.86, 46],
      ];

      function drawPineFlower(cx: number, cy: number, size: number, depth: number, angle: number) {
        if (size < 3.5 || depth === 0) return;
        ctx.save(); ctx.translate(cx, cy); ctx.rotate(angle);
        for (let i = 0; i < 6; i++) {
          const a = (i / 6) * Math.PI * 2;
          const ex = Math.cos(a) * size, ey = Math.sin(a) * size;
          ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(ex, ey); ctx.stroke();
          drawPineFlower(ex, ey, size * 0.42, depth - 1, a + Math.PI / 7);
        }
        ctx.restore();
      }

      for (const [px, py, sz] of PINE_FLOWER_POSITIONS) {
        const rot = (px * 7.3 + py * 5.1) * Math.PI;
        const breathe = 1 + 0.04 * Math.sin(frame * 0.015 + px * 10);
        drawPineFlower(px * w, py * h, (sz as number) * breathe, 3, rot);
      }

      // ── Jade ambient fill ──────────────────────────────────────────────
      ctx.globalAlpha = 0.07;
      const jadeGrad = ctx.createRadialGradient(w * 0.5, h * 0.5, 0, w * 0.5, h * 0.5, w * 0.6);
      jadeGrad.addColorStop(0, "#2d7a50");
      jadeGrad.addColorStop(1, "rgba(20,60,35,0)");
      ctx.fillStyle = jadeGrad;
      ctx.fillRect(0, 0, w, h);

      // ── Amber yolk glow (off-center, shifts slowly) ───────────────────
      const ax = 0.42 + 0.06 * Math.sin(frame * 0.008);
      const ay = 0.5 + 0.04 * Math.cos(frame * 0.01);
      ctx.globalAlpha = 0.09 + 0.03 * Math.sin(frame * 0.04);
      const amberGrad = ctx.createRadialGradient(ax * w, ay * h, 0, ax * w, ay * h, w * 0.22);
      amberGrad.addColorStop(0, "#c8820a");
      amberGrad.addColorStop(0.6, "rgba(180,100,10,0.3)");
      amberGrad.addColorStop(1, "rgba(180,100,10,0)");
      ctx.fillStyle = amberGrad;
      ctx.fillRect(0, 0, w, h);

      // ── Jelly highlight shimmer (top-left specular) ───────────────────
      const shx = 0.28 + 0.05 * Math.sin(frame * 0.022);
      ctx.globalAlpha = 0.06 + 0.025 * Math.sin(frame * 0.055);
      const shimmerGrad = ctx.createRadialGradient(shx * w, h * 0.28, 0, shx * w, h * 0.28, w * 0.13);
      shimmerGrad.addColorStop(0, "rgba(200,255,220,0.9)");
      shimmerGrad.addColorStop(1, "rgba(200,255,220,0)");
      ctx.fillStyle = shimmerGrad;
      ctx.fillRect(0, 0, w, h);

      // ── Dark vignette edges ────────────────────────────────────────────
      ctx.globalAlpha = 0.35;
      const vig = ctx.createRadialGradient(w / 2, h / 2, h * 0.25, w / 2, h / 2, h * 0.78);
      vig.addColorStop(0, "rgba(0,0,0,0)");
      vig.addColorStop(1, "rgba(0,12,6,0.7)");
      ctx.fillStyle = vig;
      ctx.fillRect(0, 0, w, h);

      ctx.globalAlpha = 1;
    },
  },

  // ── Molten Gold ────────────────────────────────────────────────────────────
  {
    id: "molten_gold",
    label: "Molten Gold",
    creator: "Run2TCoM Studio",
    uses: "11.2M",
    rating: 4.8,
    category: "Trending",
    tagline: "Liquid amber. Floating embers. Pure cinematic warmth.",
    previewGradient: "linear-gradient(135deg,#3d1f00,#7a3d00,#c46200,#f59e0b)",
    previewEmoji: "✨",
    filterCss: "sepia(0.55) saturate(2.4) brightness(1.06) contrast(1.12) hue-rotate(12deg)",
    needsGreenScreen: false,
    render(ctx, w, h, frame, state) {
      // Emit gold shimmer particles
      if (frame % 3 === 0) {
        for (let i = 0; i < 3; i++) {
          state.particles.push({
            x: Math.random(),
            y: 0.85 + Math.random() * 0.15,
            vx: (Math.random() - 0.5) * 0.004,
            vy: -(0.003 + Math.random() * 0.006),
            life: 1, maxLife: 1,
            r: 1.5 + Math.random() * 3,
            color: ["#fbbf24", "#f59e0b", "#fcd34d", "#fff7c0"][Math.floor(Math.random() * 4)],
            type: "spark",
          });
        }
      }
      tickParticles(state);

      // Draw particles as glowing embers
      for (const p of state.particles) {
        ctx.globalAlpha = p.life * 0.85;
        // Glow halo
        const grd = ctx.createRadialGradient(p.x * w, p.y * h, 0, p.x * w, p.y * h, p.r * 3);
        grd.addColorStop(0, p.color);
        grd.addColorStop(1, "rgba(251,191,36,0)");
        ctx.fillStyle = grd;
        ctx.beginPath(); ctx.arc(p.x * w, p.y * h, p.r * 3, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = "#fffde7";
        ctx.beginPath(); ctx.arc(p.x * w, p.y * h, p.r * p.life, 0, Math.PI * 2); ctx.fill();
      }

      // Warm edge glow
      ctx.globalAlpha = 0.18 + 0.06 * Math.sin(frame * 0.03);
      const edgeGlow = ctx.createRadialGradient(w / 2, h, 0, w / 2, h, h);
      edgeGlow.addColorStop(0, "#f59e0b");
      edgeGlow.addColorStop(0.5, "rgba(245,158,11,0.3)");
      edgeGlow.addColorStop(1, "rgba(245,158,11,0)");
      ctx.fillStyle = edgeGlow;
      ctx.fillRect(0, 0, w, h);

      // Top-center gold crown glow
      ctx.globalAlpha = 0.12 + 0.04 * Math.sin(frame * 0.05);
      const topGlow = ctx.createRadialGradient(w / 2, 0, 0, w / 2, 0, h * 0.4);
      topGlow.addColorStop(0, "#fcd34d");
      topGlow.addColorStop(1, "rgba(252,211,77,0)");
      ctx.fillStyle = topGlow;
      ctx.fillRect(0, 0, w, h);

      ctx.globalAlpha = 1;
    },
  },

  // ── Cyberpunk Rain ─────────────────────────────────────────────────────────
  {
    id: "cyberpunk_rain",
    label: "Cyberpunk Rain",
    creator: "Run2TCoM Studio",
    uses: "14.6M",
    rating: 4.7,
    category: "Trending",
    tagline: "Neon streets. Falling rain. Electric city nights.",
    previewGradient: "linear-gradient(135deg,#0a001f,#10003d,#1a0050,#2d0080)",
    previewEmoji: "🌧️",
    filterCss: "saturate(2.2) hue-rotate(220deg) brightness(0.78) contrast(1.22)",
    needsGreenScreen: false,
    render(ctx, w, h, frame, state) {
      // Spawn rain drops
      if (frame % 2 === 0) {
        for (let i = 0; i < 8; i++) {
          state.particles.push({
            x: Math.random(),
            y: 0,
            vx: 0.001 + (Math.random() - 0.5) * 0.001,
            vy: 0.022 + Math.random() * 0.018,
            life: 1, maxLife: 1,
            r: 0.5 + Math.random() * 1,
            color: Math.random() > 0.92
              ? (Math.random() > 0.5 ? "#ff00ff" : "#00ffff")
              : `rgba(100,150,255,${0.3 + Math.random() * 0.4})`,
            type: "smoke",
          });
        }
      }
      tickParticles(state);

      // Draw rain as streaks
      for (const p of state.particles) {
        ctx.globalAlpha = p.life * 0.7;
        ctx.strokeStyle = p.color;
        ctx.lineWidth = p.r;
        ctx.beginPath();
        ctx.moveTo(p.x * w, p.y * h);
        ctx.lineTo(p.x * w + p.vx * w * 4, p.y * h - p.vy * h * 5);
        ctx.stroke();
      }

      // Neon puddle reflections at bottom
      const puddleY = h * 0.88;
      ctx.globalAlpha = 0.3 + 0.1 * Math.sin(frame * 0.06);
      const neons = ["#ff00ff", "#00ffff", "#7700ff", "#0077ff"];
      for (let i = 0; i < 4; i++) {
        const rx = (0.15 + i * 0.22) * w;
        const pudGrad = ctx.createRadialGradient(rx, puddleY, 0, rx, puddleY, 60 + i * 20);
        pudGrad.addColorStop(0, neons[i] + "44");
        pudGrad.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = pudGrad;
        ctx.fillRect(0, 0, w, h);
      }

      // Neon edge flicker
      ctx.globalAlpha = 0.08 + 0.05 * Math.sin(frame * 0.18);
      ctx.fillStyle = "#7700ff";
      ctx.fillRect(0, 0, 8, h);
      ctx.fillStyle = "#00ffff";
      ctx.fillRect(w - 8, 0, 8, h);

      ctx.globalAlpha = 1;
    },
  },

  // ── Apocalypse ─────────────────────────────────────────────────────────────
  {
    id: "apocalypse",
    label: "Apocalypse",
    creator: "Run2TCoM Studio",
    uses: "22.1M",
    rating: 4.8,
    category: "Fantasy",
    tagline: "Ash. Fire. Smoke. The world is ending and you look incredible.",
    previewGradient: "linear-gradient(135deg,#1a0000,#3d0000,#600000,#8b1a1a)",
    previewEmoji: "🌋",
    filterCss: "saturate(0.25) hue-rotate(10deg) brightness(0.72) contrast(1.2) sepia(0.1)",
    needsGreenScreen: false,
    render(ctx, w, h, frame, state) {
      // Emit ash particles
      if (frame % 3 === 0) {
        for (let i = 0; i < 5; i++) {
          state.particles.push({
            x: Math.random(),
            y: -0.02,
            vx: (Math.random() - 0.5) * 0.003,
            vy: 0.004 + Math.random() * 0.004,
            life: 1, maxLife: 1,
            r: 2 + Math.random() * 4,
            color: `rgba(${140 + Math.floor(Math.random() * 40)},${100 + Math.floor(Math.random() * 30)},${80 + Math.floor(Math.random() * 20)},0.7)`,
            type: "smoke",
          });
        }
      }
      tickParticles(state);
      drawParticles(ctx, state, w, h);

      // Red sky glow at top
      ctx.globalAlpha = 0.28 + 0.08 * Math.sin(frame * 0.025);
      const skyGlow = ctx.createLinearGradient(0, 0, 0, h * 0.6);
      skyGlow.addColorStop(0, "rgba(180,20,0,0.7)");
      skyGlow.addColorStop(0.4, "rgba(120,10,0,0.3)");
      skyGlow.addColorStop(1, "rgba(60,0,0,0)");
      ctx.fillStyle = skyGlow;
      ctx.fillRect(0, 0, w, h);

      // Fire glow from bottom
      ctx.globalAlpha = 0.22 + 0.1 * Math.sin(frame * 0.04);
      const fireGlow = ctx.createLinearGradient(0, h, 0, h * 0.6);
      fireGlow.addColorStop(0, "rgba(255,60,0,0.6)");
      fireGlow.addColorStop(1, "rgba(255,60,0,0)");
      ctx.fillStyle = fireGlow;
      ctx.fillRect(0, 0, w, h);

      // Lightning strike (rare)
      if (frame % 280 < 4) {
        ctx.globalAlpha = 0.6 + 0.4 * Math.random();
        ctx.fillStyle = "#fff5f0";
        ctx.fillRect(0, 0, w, h);
        // Bolt
        ctx.globalAlpha = 0.9;
        ctx.strokeStyle = "#fffbe6";
        ctx.lineWidth = 3;
        ctx.shadowBlur = 20;
        ctx.shadowColor = "#fff";
        ctx.beginPath();
        const bx = 0.3 + Math.random() * 0.4;
        ctx.moveTo(bx * w, 0);
        ctx.lineTo((bx + 0.05) * w, h * 0.3);
        ctx.lineTo((bx - 0.03) * w, h * 0.5);
        ctx.lineTo((bx + 0.04) * w, h * 0.7);
        ctx.stroke();
        ctx.shadowBlur = 0;
      }

      ctx.globalAlpha = 1;
    },
    onTap(x, y, state) {
      // Tap creates ash burst
      for (let i = 0; i < 20; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 0.003 + Math.random() * 0.006;
        state.particles.push({
          x, y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed - 0.003,
          life: 1, maxLife: 1,
          r: 3 + Math.random() * 6,
          color: `rgba(${150 + Math.floor(Math.random() * 50)},80,60,0.8)`,
          type: "smoke",
        });
      }
    },
  },

  // ── Ancient Egypt ──────────────────────────────────────────────────────────
  {
    id: "ancient_egypt",
    label: "Ancient Egypt",
    creator: "Run2TCoM Studio",
    uses: "9.8M",
    rating: 4.8,
    category: "Fantasy",
    tagline: "Gold dust. Hieroglyphs. You are pharaoh.",
    previewGradient: "linear-gradient(135deg,#3d2600,#7a4d00,#c47d00,#e8a700)",
    previewEmoji: "🏺",
    filterCss: "sepia(0.5) saturate(1.8) brightness(1.04) contrast(1.08) hue-rotate(18deg)",
    needsGreenScreen: false,
    render(ctx, w, h, frame, state) {
      // Gold dust particle emission
      if (frame % 4 === 0) {
        for (let i = 0; i < 4; i++) {
          state.particles.push({
            x: Math.random(),
            y: 0.9 + Math.random() * 0.12,
            vx: (Math.random() - 0.5) * 0.005,
            vy: -(0.004 + Math.random() * 0.005),
            life: 1, maxLife: 1,
            r: 1 + Math.random() * 2.5,
            color: ["#fbbf24", "#f59e0b", "#fcd34d", "#fef3c7"][Math.floor(Math.random() * 4)],
            type: "magic",
          });
        }
      }
      tickParticles(state);
      drawParticles(ctx, state, w, h);

      // Floating hieroglyphs
      const glyphs = ["𓀀", "𓂀", "𓃰", "𓄿", "𓅬", "𓆣", "𓇋", "𓈖", "𓉐", "𓊃", "𓋴", "𓌀"];
      const glyphSeeds = [
        { x: 0.08, y: 0.22, i: 0 }, { x: 0.88, y: 0.18, i: 1 },
        { x: 0.06, y: 0.55, i: 2 }, { x: 0.90, y: 0.50, i: 3 },
        { x: 0.08, y: 0.80, i: 4 }, { x: 0.88, y: 0.78, i: 5 },
      ];
      ctx.font = "bold 22px serif";
      ctx.textAlign = "center";
      for (const gs of glyphSeeds) {
        const floatY = gs.y + 0.025 * Math.sin(frame * 0.018 + gs.i * 1.4);
        ctx.globalAlpha = 0.45 + 0.15 * Math.sin(frame * 0.02 + gs.i);
        ctx.fillStyle = "#fbbf24";
        ctx.fillText(glyphs[gs.i], gs.x * w, floatY * h);
      }
      ctx.textAlign = "left";

      // Gold column borders
      ctx.globalAlpha = 0.28;
      const colGrad = ctx.createLinearGradient(0, 0, w * 0.12, 0);
      colGrad.addColorStop(0, "rgba(245,158,11,0.7)");
      colGrad.addColorStop(1, "rgba(245,158,11,0)");
      ctx.fillStyle = colGrad;
      ctx.fillRect(0, 0, w * 0.12, h);
      const colGrad2 = ctx.createLinearGradient(w, 0, w * 0.88, 0);
      colGrad2.addColorStop(0, "rgba(245,158,11,0.7)");
      colGrad2.addColorStop(1, "rgba(245,158,11,0)");
      ctx.fillStyle = colGrad2;
      ctx.fillRect(w * 0.88, 0, w * 0.12, h);

      // Golden sky crown
      ctx.globalAlpha = 0.14 + 0.05 * Math.sin(frame * 0.03);
      const crownGrad = ctx.createRadialGradient(w / 2, 0, 0, w / 2, 0, h * 0.45);
      crownGrad.addColorStop(0, "#fcd34d");
      crownGrad.addColorStop(1, "rgba(252,211,77,0)");
      ctx.fillStyle = crownGrad;
      ctx.fillRect(0, 0, w, h);

      ctx.globalAlpha = 1;
    },
    onTap(x, y, state) {
      for (let i = 0; i < 18; i++) {
        const angle = Math.random() * Math.PI * 2;
        state.particles.push({
          x, y,
          vx: Math.cos(angle) * (0.002 + Math.random() * 0.005),
          vy: Math.sin(angle) * (0.002 + Math.random() * 0.005) - 0.005,
          life: 1, maxLife: 1,
          r: 2 + Math.random() * 3,
          color: ["#fbbf24", "#fcd34d", "#fef3c7"][Math.floor(Math.random() * 3)],
          type: "magic",
        });
      }
    },
  },

  // ── Noir Detective ────────────────────────────────────────────────────────
  {
    id: "noir_detective",
    label: "Noir Detective",
    creator: "Run2TCoM Studio",
    uses: "7.4M",
    rating: 4.7,
    category: "Trending",
    tagline: "Rain-soaked streets. Deep shadows. You've seen too much.",
    previewGradient: "linear-gradient(135deg,#0a0a0a,#1a1a1a,#2a2a2a,#111)",
    previewEmoji: "🕵️",
    filterCss: "grayscale(1) contrast(1.45) brightness(0.82)",
    needsGreenScreen: false,
    render(ctx, w, h, frame, state) {
      // Film grain
      if (frame % 2 === 0) {
        const imageData = ctx.createImageData(w, h);
        const data = imageData.data;
        for (let i = 0; i < data.length; i += 4) {
          const grain = (Math.random() - 0.5) * 28;
          data[i] = grain; data[i+1] = grain; data[i+2] = grain; data[i+3] = 18;
        }
        ctx.putImageData(imageData, 0, 0);
      }

      // Heavy vignette
      ctx.globalAlpha = 0.55;
      const vig = ctx.createRadialGradient(w / 2, h / 2, h * 0.2, w / 2, h / 2, h * 0.75);
      vig.addColorStop(0, "rgba(0,0,0,0)");
      vig.addColorStop(1, "rgba(0,0,0,0.9)");
      ctx.fillStyle = vig;
      ctx.fillRect(0, 0, w, h);

      // Horizontal scan lines
      ctx.globalAlpha = 0.07;
      ctx.fillStyle = "#000";
      for (let y = 0; y < h; y += 4) { ctx.fillRect(0, y, w, 2); }

      // Rain (sparse, diagonal)
      if (frame % 3 === 0) {
        for (let i = 0; i < 5; i++) {
          state.particles.push({
            x: Math.random(),
            y: 0,
            vx: 0.002,
            vy: 0.018 + Math.random() * 0.012,
            life: 1, maxLife: 1,
            r: 0.4,
            color: "rgba(200,200,200,0.5)",
            type: "smoke",
          });
        }
      }
      tickParticles(state);
      for (const p of state.particles) {
        ctx.globalAlpha = p.life * 0.4;
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 0.7;
        ctx.beginPath();
        ctx.moveTo(p.x * w, p.y * h);
        ctx.lineTo((p.x + 0.01) * w, (p.y - 0.03) * h);
        ctx.stroke();
      }

      // Occasional cigarette ember at bottom-right
      const emberPulse = 0.7 + 0.3 * Math.sin(frame * 0.08);
      ctx.globalAlpha = emberPulse * 0.6;
      const emberGrad = ctx.createRadialGradient(w * 0.85, h * 0.88, 0, w * 0.85, h * 0.88, 18);
      emberGrad.addColorStop(0, "#ff4400");
      emberGrad.addColorStop(1, "rgba(255,68,0,0)");
      ctx.fillStyle = emberGrad;
      ctx.fillRect(0, 0, w, h);

      ctx.globalAlpha = 1;
    },
  },

  // ── Jade Marble ────────────────────────────────────────────────────────────
  {
    id: "jade_marble",
    label: "Jade Marble",
    creator: "Run2TCoM Studio",
    uses: "5.7M",
    rating: 4.6,
    category: "Trending",
    tagline: "Cool stone. Luminous veins. Ancient luxury.",
    previewGradient: "linear-gradient(135deg,#0d2b1e,#1a4a30,#0f3324,#254f38)",
    previewEmoji: "💚",
    filterCss: "saturate(0.55) hue-rotate(142deg) brightness(0.9) contrast(1.18) sepia(0.05)",
    needsGreenScreen: false,
    render(ctx, w, h, frame) {
      ctx.globalAlpha = 0.12;
      ctx.strokeStyle = "#a8e6c5";
      ctx.lineWidth = 1.2;
      for (let i = 0; i < 8; i++) {
        const seed = i * 1.3 + 0.7;
        ctx.beginPath();
        for (let x = 0; x <= w; x += 4) {
          const y = (seed * 0.12 * h) + Math.sin(x * 0.008 + seed) * h * 0.08
                    + Math.sin(x * 0.02 + seed * 2.1) * h * 0.03
                    + Math.sin(frame * 0.005 + seed * 0.5) * h * 0.01;
          if (x === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
        }
        ctx.stroke();
      }
      ctx.strokeStyle = "#c8f5e0";
      ctx.lineWidth = 0.6;
      for (let i = 0; i < 5; i++) {
        const ox = i * 0.22 * w;
        ctx.beginPath();
        ctx.moveTo(ox, 0);
        ctx.bezierCurveTo(ox + w * 0.08, h * 0.3, ox - w * 0.05, h * 0.6, ox + w * 0.1, h);
        ctx.stroke();
      }
      ctx.globalAlpha = 0.08 + 0.03 * Math.sin(frame * 0.03);
      const bloom = ctx.createRadialGradient(w * 0.5, h * 0.4, 0, w * 0.5, h * 0.4, w * 0.4);
      bloom.addColorStop(0, "#a8e6c5");
      bloom.addColorStop(1, "rgba(168,230,197,0)");
      ctx.fillStyle = bloom;
      ctx.fillRect(0, 0, w, h);
      ctx.globalAlpha = 1;
    },
  },

  // ── Conversation Effects ─────────────────────────────────────────────────────
  {
    id: "convo_storm",
    label: "Comment Storm",
    creator: "Run2TCoM",
    uses: "LIVE",
    rating: 5.0,
    category: "Convo",
    tagline: "100+ comments tears through the screen.",
    previewGradient: "linear-gradient(135deg,#2e1065,#4c1d95,#1e1b4b)",
    previewEmoji: "🌪️",
    filterCss: "contrast(1.1) saturate(1.2)",
    needsGreenScreen: false,
    render(ctx, w, h, frame, state) {
      const TEXTS = ["omg 💬","🔥🔥","facts!","lmao 💀","THREAD","🤯","W post","OMG","👀","🐐","no cap","real","🙌","slay","ratio"];
      if (frame % 8 === 0) {
        const angle = Math.random() * Math.PI * 2;
        const radius = 0.22 + Math.random() * 0.28;
        state.particles.push({
          x: 0.5 + Math.cos(angle) * radius,
          y: 0.5 + Math.sin(angle) * radius * 0.55,
          vx: 0, vy: 0, life: 1, maxLife: 1, r: 0,
          color: TEXTS[Math.floor(Math.random() * TEXTS.length)],
          type: "magic",
        });
      }
      for (let i = state.particles.length - 1; i >= 0; i--) {
        const p = state.particles[i];
        const dx = p.x - 0.5, dy = p.y - 0.5;
        const dist = Math.sqrt(dx*dx + dy*dy) + 0.001;
        const ang = Math.atan2(dy, dx) + 0.042 / (dist + 0.08);
        const nd = dist * 0.992;
        p.x = 0.5 + Math.cos(ang) * nd;
        p.y = 0.5 + Math.sin(ang) * nd * 0.55;
        p.life -= 0.007;
        if (p.life <= 0 || nd < 0.015) { state.particles.splice(i, 1); continue; }
        ctx.globalAlpha = p.life * 0.88;
        ctx.font = `bold ${Math.round(10 + p.life * 5)}px sans-serif`;
        ctx.fillStyle = p.life > 0.5 ? "#c084fc" : "#a855f7";
        ctx.shadowColor = "#7c3aed"; ctx.shadowBlur = 10;
        ctx.fillText(p.color, p.x * w, p.y * h);
      }
      ctx.shadowBlur = 0;
      ctx.globalAlpha = 0.1 + 0.06 * Math.sin(frame * 0.08);
      const vg = ctx.createRadialGradient(w/2, h/2, 0, w/2, h/2, w * 0.22);
      vg.addColorStop(0, "#a855f7"); vg.addColorStop(1, "rgba(168,85,247,0)");
      ctx.fillStyle = vg; ctx.fillRect(0, 0, w, h);
      ctx.globalAlpha = 1;
    },
  },

  {
    id: "convo_fire",
    label: "Fire Debate",
    creator: "Run2TCoM",
    uses: "LIVE",
    rating: 5.0,
    category: "Convo",
    tagline: "Split opinion. Both sides are burning.",
    previewGradient: "linear-gradient(90deg,#7f1d1d,#1e1b4b)",
    previewEmoji: "🔥",
    filterCss: "contrast(1.15)",
    needsGreenScreen: false,
    render(ctx, w, h, frame, state) {
      ctx.globalAlpha = 0.16;
      const left = ctx.createLinearGradient(0, 0, w * 0.55, 0);
      left.addColorStop(0, "rgba(239,68,68,0.7)"); left.addColorStop(1, "rgba(239,68,68,0)");
      ctx.fillStyle = left; ctx.fillRect(0, 0, w * 0.55, h);
      const right = ctx.createLinearGradient(w, 0, w * 0.45, 0);
      right.addColorStop(0, "rgba(59,130,246,0.7)"); right.addColorStop(1, "rgba(59,130,246,0)");
      ctx.fillStyle = right; ctx.fillRect(w * 0.45, 0, w * 0.55, h);
      if (frame % 3 === 0) {
        for (let s = 0; s < 5; s++) {
          const isLeft = s < 3;
          state.particles.push({
            x: isLeft ? 0.05 + Math.random() * 0.4 : 0.55 + Math.random() * 0.4,
            y: 1.02, vx: (Math.random() - 0.5) * 0.004, vy: -(0.013 + Math.random() * 0.01),
            life: 1, maxLife: 1, r: 5 + Math.random() * 9,
            color: isLeft ? "#ef4444" : "#3b82f6", type: "spark",
          });
        }
      }
      for (let i = state.particles.length - 1; i >= 0; i--) {
        const p = state.particles[i];
        p.x += p.vx; p.y += p.vy; p.life -= 0.02;
        if (p.life <= 0 || p.y < -0.1) { state.particles.splice(i, 1); continue; }
        const warm = p.color === "#ef4444" ? "#fbbf24" : "#60a5fa";
        const gr = ctx.createRadialGradient(p.x*w, p.y*h, 0, p.x*w, p.y*h, p.r * p.life);
        gr.addColorStop(0, warm); gr.addColorStop(0.45, p.color); gr.addColorStop(1, "rgba(0,0,0,0)");
        ctx.globalAlpha = p.life * 0.72;
        ctx.fillStyle = gr;
        ctx.beginPath(); ctx.arc(p.x*w, p.y*h, p.r * p.life, 0, Math.PI * 2); ctx.fill();
      }
      ctx.globalAlpha = 0.45 + 0.3 * Math.sin(frame * 0.14);
      ctx.strokeStyle = "#fff8"; ctx.lineWidth = 1.5;
      ctx.setLineDash([5, 7]);
      ctx.beginPath(); ctx.moveTo(w/2, 0); ctx.lineTo(w/2, h); ctx.stroke();
      ctx.setLineDash([]);
      ctx.globalAlpha = 0.65;
      ctx.font = "bold 15px sans-serif"; ctx.textAlign = "center";
      ctx.fillStyle = "#fca5a5"; ctx.fillText("TEAM RED", w * 0.25, 30);
      ctx.fillStyle = "#93c5fd"; ctx.fillText("TEAM BLUE", w * 0.75, 30);
      ctx.textAlign = "start"; ctx.globalAlpha = 1;
    },
  },

  {
    id: "convo_wisdom",
    label: "Wisdom Mode",
    creator: "Run2TCoM",
    uses: "LIVE",
    rating: 5.0,
    category: "Convo",
    tagline: "High saves. The post became scripture.",
    previewGradient: "linear-gradient(135deg,#1c1510,#2a1f0a,#3d2c08)",
    previewEmoji: "✨",
    filterCss: "sepia(0.2) brightness(1.05) saturate(1.1)",
    needsGreenScreen: false,
    render(ctx, w, h, frame, state) {
      if (frame % 4 === 0) {
        for (let i = 0; i < 3; i++) {
          state.particles.push({
            x: Math.random(), y: -0.03,
            vx: (Math.random() - 0.5) * 0.003, vy: 0.007 + Math.random() * 0.005,
            life: 1, maxLife: 1, r: 2 + Math.random() * 3,
            color: Math.random() > 0.5 ? "#fbbf24" : "#f59e0b", type: "spark",
          });
        }
      }
      for (let i = state.particles.length - 1; i >= 0; i--) {
        const p = state.particles[i];
        p.x += p.vx; p.y += p.vy; p.life -= 0.014;
        if (p.y > 1.06) { state.particles.splice(i, 1); continue; }
        const gr = ctx.createRadialGradient(p.x*w, p.y*h, 0, p.x*w, p.y*h, p.r * 2.2);
        gr.addColorStop(0, "#fffde7"); gr.addColorStop(0.5, p.color); gr.addColorStop(1, "rgba(0,0,0,0)");
        ctx.globalAlpha = p.life * 0.82;
        ctx.fillStyle = gr;
        ctx.beginPath(); ctx.arc(p.x*w, p.y*h, p.r * 2.2, 0, Math.PI * 2); ctx.fill();
      }
      const words = ["Truth","Vision","Power","Clarity","Wisdom","Light","Impact","Gold"];
      const seed = (n: number) => Math.abs(Math.sin(n * 99.3));
      for (let i = 0; i < 4; i++) {
        const wx = (seed(i * 2.1) * 0.66 + 0.17) * w;
        const wy = (seed(i * 5.7) * 0.55 + 0.18) * h;
        const bob = Math.sin(frame * 0.025 + i * 2.1) * 7;
        ctx.globalAlpha = 0.3 + 0.12 * Math.sin(frame * 0.03 + i);
        ctx.font = `bold ${11 + i * 2}px serif`;
        ctx.fillStyle = "#fbbf24";
        ctx.shadowColor = "#f59e0b"; ctx.shadowBlur = 14;
        ctx.fillText(words[i % words.length], wx, wy + bob);
      }
      ctx.shadowBlur = 0;
      ctx.globalAlpha = 0.1 + 0.05 * Math.sin(frame * 0.04);
      const aura = ctx.createRadialGradient(w/2, h * 0.45, 0, w/2, h * 0.45, w * 0.38);
      aura.addColorStop(0, "#fbbf24"); aura.addColorStop(1, "rgba(251,191,36,0)");
      ctx.fillStyle = aura; ctx.fillRect(0, 0, w, h);
      ctx.globalAlpha = 1;
    },
  },

  {
    id: "convo_viral",
    label: "Viral Thread",
    creator: "Run2TCoM",
    uses: "LIVE",
    rating: 5.0,
    category: "Convo",
    tagline: "Trending. Names orbit the frame.",
    previewGradient: "linear-gradient(135deg,#083344,#0e7490,#0369a1)",
    previewEmoji: "🌀",
    filterCss: "hue-rotate(182deg) saturate(1.22) contrast(1.08)",
    needsGreenScreen: false,
    render(ctx, w, h, frame) {
      const names = ["@kai","@alice","@bob","@run2tcom","@jane","@creator"];
      for (let i = 0; i < 6; i++) {
        const oR = (0.28 + i * 0.058) * Math.min(w, h) * 0.48;
        const ang = frame * (0.005 + i * 0.0018) + (i / 6) * Math.PI * 2;
        const nx = w/2 + Math.cos(ang) * oR;
        const ny = h/2 + Math.sin(ang) * oR * 0.58;
        ctx.globalAlpha = 0.1 + 0.06 * Math.sin(frame * 0.03 + i);
        ctx.strokeStyle = "#22d3ee"; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(w/2, h/2); ctx.lineTo(nx, ny); ctx.stroke();
        const ng = ctx.createRadialGradient(nx, ny, 0, nx, ny, 13);
        ng.addColorStop(0, "#67e8f9"); ng.addColorStop(1, "rgba(103,232,249,0)");
        ctx.globalAlpha = 0.75;
        ctx.fillStyle = ng; ctx.beginPath(); ctx.arc(nx, ny, 13, 0, Math.PI*2); ctx.fill();
        ctx.globalAlpha = 0.65 + 0.2 * Math.sin(frame * 0.04 + i);
        ctx.font = "bold 10px monospace"; ctx.fillStyle = "#cffafe";
        ctx.fillText(names[i], nx + 10, ny + 4);
      }
      ctx.globalAlpha = 0.09 + 0.05 * Math.sin(frame * 0.07);
      const pulse = ctx.createRadialGradient(w/2, h/2, 0, w/2, h/2, w * 0.26);
      pulse.addColorStop(0, "#22d3ee"); pulse.addColorStop(1, "rgba(34,211,238,0)");
      ctx.fillStyle = pulse; ctx.fillRect(0, 0, w, h);
      for (let r = 0; r < 3; r++) {
        const rr = ((frame * 3 + r * 80) % 260);
        ctx.globalAlpha = Math.max(0, (1 - rr / 260) * 0.14);
        ctx.strokeStyle = "#22d3ee"; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.ellipse(w/2, h/2, rr * 0.78, rr * 0.48, 0, 0, Math.PI * 2); ctx.stroke();
      }
      ctx.globalAlpha = 1;
    },
  },

  {
    id: "convo_crown",
    label: "Luminary Crown",
    creator: "Run2TCoM",
    uses: "LIVE",
    rating: 5.0,
    category: "Convo",
    tagline: "Top post of the week. You earned it.",
    previewGradient: "linear-gradient(135deg,#1c1307,#2d1f08,#3d2c0a)",
    previewEmoji: "👑",
    filterCss: "brightness(1.08) contrast(1.05) saturate(1.1)",
    needsGreenScreen: false,
    render(ctx, w, h, frame, state) {
      if (frame % 5 === 0) {
        for (let i = 0; i < 3; i++) {
          state.particles.push({
            x: 0.5 + (Math.random() - 0.5) * 0.55,
            y: 0.06 + Math.random() * 0.18,
            vx: (Math.random() - 0.5) * 0.006, vy: -(0.006 + Math.random() * 0.006),
            life: 1, maxLife: 1, r: 2.5 + Math.random() * 3,
            color: ["#fbbf24","#fcd34d","#f59e0b","#fffde7"][Math.floor(Math.random()*4)],
            type: "magic",
          });
        }
      }
      for (let i = state.particles.length - 1; i >= 0; i--) {
        const p = state.particles[i];
        p.x += p.vx; p.y += p.vy; p.life -= 0.016;
        if (p.life <= 0) { state.particles.splice(i, 1); continue; }
        const pg = ctx.createRadialGradient(p.x*w, p.y*h, 0, p.x*w, p.y*h, p.r * 2.2);
        pg.addColorStop(0, "#fffde7"); pg.addColorStop(0.5, p.color); pg.addColorStop(1, "rgba(0,0,0,0)");
        ctx.globalAlpha = p.life * 0.85;
        ctx.fillStyle = pg;
        ctx.beginPath(); ctx.arc(p.x*w, p.y*h, p.r * 2.2, 0, Math.PI*2); ctx.fill();
      }
      const bob = Math.sin(frame * 0.04) * 5;
      const crownCx = w / 2, crownCy = h * 0.09 + bob;
      const crownR = w * 0.075;
      ctx.globalAlpha = 0.18 + 0.08 * Math.sin(frame * 0.05);
      const cg = ctx.createRadialGradient(crownCx, crownCy, 0, crownCx, crownCy, crownR * 2.5);
      cg.addColorStop(0, "#fbbf24"); cg.addColorStop(1, "rgba(251,191,36,0)");
      ctx.fillStyle = cg; ctx.fillRect(0, 0, w, h);
      for (let r = 0; r < 8; r++) {
        const rayAng = (r / 8) * Math.PI * 2 + frame * 0.008;
        ctx.globalAlpha = 0.055 + 0.03 * Math.sin(frame * 0.1 + r);
        ctx.strokeStyle = "#fbbf24"; ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(crownCx + Math.cos(rayAng) * crownR * 0.6, crownCy + Math.sin(rayAng) * crownR * 0.6);
        ctx.lineTo(crownCx + Math.cos(rayAng) * crownR * 3.2, crownCy + Math.sin(rayAng) * crownR * 3.2);
        ctx.stroke();
      }
      ctx.globalAlpha = 0.92;
      ctx.font = `${Math.round(crownR * 1.85)}px sans-serif`;
      ctx.textAlign = "center"; ctx.textBaseline = "middle";
      ctx.fillText("👑", crownCx, crownCy);
      ctx.textBaseline = "alphabetic";
      ctx.globalAlpha = 0.55 + 0.15 * Math.sin(frame * 0.06);
      ctx.font = "bold 13px serif"; ctx.fillStyle = "#fbbf24";
      ctx.shadowColor = "#f59e0b"; ctx.shadowBlur = 12;
      ctx.fillText("✦ LUMINARY ✦", w/2, h - 22);
      ctx.shadowBlur = 0; ctx.textAlign = "start"; ctx.globalAlpha = 1;
    },
  },
];
