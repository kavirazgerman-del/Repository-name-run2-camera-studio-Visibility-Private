// drafts.ts — local-only (IndexedDB) draft storage for Camera Studio.
//
// Why IndexedDB (not localStorage): a real draft must persist the CAPTURED MEDIA —
// video segment Blobs (up to 50MB), photo/slide data URLs — not just a caption
// string. That media would blow past localStorage's ~5MB string quota, so the old
// "Save Draft" (a localStorage string that restored nothing) couldn't work.
// IndexedDB stores Blobs natively, so drafts persist durably on THIS device/browser
// with zero upload — nothing leaves the device until the user actually publishes.
//
// Drafts are intentionally local to this browser. We keep two object stores: `drafts`
// holds the full record (incl. blobs); `drafts_meta` holds a tiny per-draft summary
// (+thumbnail) so listing drafts never has to load megabytes of video into memory.

import { type VideoSegment, type MusicFitMode } from "./videoExport";
import { type MusicTrack } from "@workspace/api-client-react";
import { type AIBackground } from "./panels/AIPanel";
import { type DisclosureKind } from "@/lib/disclosure";
import { type InkElement, type BrushId, type AnchorMode } from "./ink";
import { type NeonPatriotParams } from "./neonPatriot";
import { type BeautyXParams } from "./beautyX";
import { type SolargraphParams } from "./solargraph";
import { type CarnivalParams } from "./carnival";
import { type NeonMoodParams } from "./neonMood";

export const DRAFT_SCHEMA_VERSION = 1;
// Soft cap — we warn past this but never silently delete a user's media.
export const MAX_DRAFTS = 12;

const DB_NAME = "r2c-studio-drafts";
const DB_VERSION = 1;
const STORE = "drafts";
const META_STORE = "drafts_meta";

// A video segment with its transient object URL stripped. The blob is what's
// durable; the object URL is recreated on restore (see hydrateSegments).
export interface SerializedSegment {
  id: string;
  blob: Blob;
  mimeType: string;
  duration: number;
  trimStart: number;
  trimEnd: number;
  width: number;
  height: number;
}

// Everything needed to fully restore a post-in-progress. A few fields are typed
// loosely (string / unknown) because their source unions live privately inside
// CameraStudio.tsx; the restore handler casts them back. Stored via structured
// clone (handles Blobs, nested objects, and Infinity for inkLife).
export interface StudioDraft {
  id: string;
  schemaVersion: number;
  createdAt: number;
  updatedAt: number;

  // Media
  photoUrl: string | null;
  slides: string[];
  segments: SerializedSegment[];

  // Mode / config
  creativeMode: string;
  studioMode: string;
  source: "camera" | "canvas";
  canvasBg: string;
  maxDuration: number | null;
  duration: number;

  // Post fields
  postTitle: string;
  postBody: string;
  communityId: string;
  // Creator-chosen audience ('general' | 'chasers' | 'private'). Optional for
  // backward-compat with drafts saved before the audience picker existed.
  audience?: string;
  disclosedKind: DisclosureKind | null;
  paidPromotion: boolean;

  // Music (best-effort: curated tracks restore; a custom track's audio may need
  // re-selection after reload — a dead selection is harmless, publish guards on it).
  musicTrackId: number | null;
  musicFitMode: MusicFitMode;
  muteVideoAudio: boolean;
  // Export-mix levels (0..1). Optional for backward-compat with drafts saved
  // before volume controls existed (restored with sensible defaults).
  contentVolume?: number;
  musicVolume?: number;
  customTracks: MusicTrack[];

  // Filters / effects
  filterStack: string[];
  filterIntensity: number;
  marketFilterCss: string | null;
  marketFilterLabel: string | null;
  aiBg: AIBackground | null;
  gsThreshold: number;
  activeExperienceId: string | null;
  neonRainParams: unknown;
  neonPatriotParams: NeonPatriotParams;
  beautyXParams: BeautyXParams;
  solargraphParams: SolargraphParams;
  carnivalParams: CarnivalParams;
  neonMoodParams?: NeonMoodParams;

  // Motion Ink
  ink: InkElement[];
  inkAnchor: AnchorMode;
  inkBrush: BrushId;
  inkSize: number;
  inkFont: number;
  inkGlow: number;
  inkLife: number;
}

// Lightweight summary for the drafts list — never carries Blobs, so listing stays
// cheap even with several large video drafts saved.
export interface DraftMeta {
  id: string;
  label: string;
  kind: string;
  thumb: string | null;
  createdAt: number;
  updatedAt: number;
  sizeBytes: number;
  durationSec: number;
}

export function draftsSupported(): boolean {
  return typeof indexedDB !== "undefined";
}

export function newDraftId(): string {
  try {
    if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  } catch { /* fall through to fallback */ }
  return `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!draftsSupported()) {
      reject(new Error("Drafts aren't supported in this browser."));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: "id" });
      if (!db.objectStoreNames.contains(META_STORE)) db.createObjectStore(META_STORE, { keyPath: "id" });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("Couldn't open drafts storage."));
  });
}

function metaFor(d: StudioDraft, thumb: string | null): DraftMeta {
  const segBytes = d.segments.reduce((n, s) => n + (s.blob?.size ?? 0), 0);
  const strBytes = (d.photoUrl?.length ?? 0) + d.slides.reduce((n, s) => n + s.length, 0);
  const durationSec =
    d.segments.length > 0
      ? d.segments.reduce((n, s) => n + Math.max(0, s.trimEnd - s.trimStart), 0)
      : d.duration;
  const label =
    d.postTitle.trim() ||
    (d.photoUrl
      ? "Untitled photo"
      : d.slides.length > 0
        ? "Untitled slideshow"
        : d.segments.length > 0
          ? "Untitled video"
          : "Untitled draft");
  return {
    id: d.id,
    label,
    kind: d.creativeMode,
    thumb,
    createdAt: d.createdAt,
    updatedAt: d.updatedAt,
    sizeBytes: segBytes + strBytes,
    durationSec,
  };
}

export async function saveDraft(draft: StudioDraft, thumb: string | null): Promise<void> {
  const db = await openDb();
  try {
    const meta = metaFor(draft, thumb);
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction([STORE, META_STORE], "readwrite");
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error ?? new Error("Couldn't save this draft."));
      tx.onabort = () =>
        reject(
          tx.error?.name === "QuotaExceededError"
            ? new Error("Not enough storage to save this draft. Clear some drafts and try again.")
            : tx.error ?? new Error("Couldn't save this draft."),
        );
      tx.objectStore(STORE).put(draft);
      tx.objectStore(META_STORE).put(meta);
    });
  } finally {
    db.close();
  }
}

export async function listDrafts(): Promise<DraftMeta[]> {
  const db = await openDb();
  try {
    const metas = await new Promise<DraftMeta[]>((resolve, reject) => {
      const tx = db.transaction(META_STORE, "readonly");
      const req = tx.objectStore(META_STORE).getAll();
      req.onsuccess = () => resolve((req.result as DraftMeta[]) ?? []);
      req.onerror = () => reject(req.error ?? new Error("Couldn't load drafts."));
    });
    return metas.sort((a, b) => b.updatedAt - a.updatedAt);
  } finally {
    db.close();
  }
}

export async function getDraft(id: string): Promise<StudioDraft | null> {
  const db = await openDb();
  try {
    return await new Promise<StudioDraft | null>((resolve, reject) => {
      const tx = db.transaction(STORE, "readonly");
      const req = tx.objectStore(STORE).get(id);
      req.onsuccess = () => resolve((req.result as StudioDraft) ?? null);
      req.onerror = () => reject(req.error ?? new Error("Couldn't open that draft."));
    });
  } finally {
    db.close();
  }
}

export async function deleteDraft(id: string): Promise<void> {
  const db = await openDb();
  try {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction([STORE, META_STORE], "readwrite");
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error ?? new Error("Couldn't delete that draft."));
      tx.objectStore(STORE).delete(id);
      tx.objectStore(META_STORE).delete(id);
    });
  } finally {
    db.close();
  }
}

export async function countDrafts(): Promise<number> {
  const db = await openDb();
  try {
    return await new Promise<number>((resolve, reject) => {
      const tx = db.transaction(META_STORE, "readonly");
      const req = tx.objectStore(META_STORE).count();
      req.onsuccess = () => resolve(req.result ?? 0);
      req.onerror = () => reject(req.error ?? new Error("Couldn't count drafts."));
    });
  } finally {
    db.close();
  }
}

// Strip each segment's transient object URL for storage — the blob is durable.
export function serializeSegments(segs: VideoSegment[]): SerializedSegment[] {
  return segs.map((s) => ({
    id: s.id,
    blob: s.blob,
    mimeType: s.mimeType,
    duration: s.duration,
    trimStart: s.trimStart,
    trimEnd: s.trimEnd,
    width: s.width,
    height: s.height,
  }));
}

// Re-create a live object URL for each stored segment blob on restore.
export function hydrateSegments(segs: SerializedSegment[]): VideoSegment[] {
  return segs.map((s) => ({ ...s, url: URL.createObjectURL(s.blob) }));
}

// Grab a single still from a video blob to use as a list thumbnail. Best-effort:
// resolves null (not reject) on any failure or timeout so saving a draft never hangs
// or breaks just because we couldn't make a preview.
export function firstFrameDataUrl(blob: Blob, atSec = 0): Promise<string | null> {
  return new Promise((resolve) => {
    let url: string | null = null;
    let done = false;
    const finish = (val: string | null) => {
      if (done) return;
      done = true;
      try {
        v.onloadeddata = null;
        v.onseeked = null;
        v.onerror = null;
        v.removeAttribute("src");
        v.load();
      } catch { /* ignore */ }
      if (url) URL.revokeObjectURL(url);
      resolve(val);
    };
    let v: HTMLVideoElement;
    try {
      v = document.createElement("video");
      url = URL.createObjectURL(blob);
      v.muted = true;
      v.playsInline = true;
      v.preload = "auto";
      v.src = url;
    } catch {
      resolve(null);
      return;
    }
    const grab = () => {
      try {
        const w = v.videoWidth;
        const h = v.videoHeight;
        if (!w || !h) return finish(null);
        const scale = Math.min(1, 320 / Math.max(w, h));
        const c = document.createElement("canvas");
        c.width = Math.max(1, Math.round(w * scale));
        c.height = Math.max(1, Math.round(h * scale));
        const ctx = c.getContext("2d");
        if (!ctx) return finish(null);
        ctx.drawImage(v, 0, 0, c.width, c.height);
        finish(c.toDataURL("image/jpeg", 0.6));
      } catch {
        finish(null);
      }
    };
    v.onloadeddata = () => {
      const t = Math.min(Math.max(0, atSec), (v.duration || 0.2) * 0.5, 0.2);
      if (t > 0 && Math.abs(v.currentTime - t) > 0.01) {
        try { v.currentTime = t; } catch { grab(); }
      } else {
        grab();
      }
    };
    v.onseeked = grab;
    v.onerror = () => finish(null);
    setTimeout(() => finish(null), 4000);
  });
}
