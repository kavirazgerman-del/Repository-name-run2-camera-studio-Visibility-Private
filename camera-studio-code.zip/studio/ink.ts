/*  ink.ts — Run2TCoM Motion Ink engine
 *  Time- & space-anchored drawing + glowing text, as ONE unified system.
 *  Drop into the web studio and call renderInk() inside your compositeFrame loop,
 *  AFTER the video/filters layer and BEFORE capture, so ink bakes into the file.
 */

export type BrushId = "neon" | "gold" | "comet" | "ember" | "rainbow";
export interface Brush { id: BrushId; label: string; color: string | "rainbow"; }

export const INK_BRUSHES: Brush[] = [
  { id: "neon",    label: "Neon",    color: "#2D8CFF" },
  { id: "gold",    label: "Gold",    color: "#F5C453" },
  { id: "comet",   label: "Comet",   color: "#46E0FF" },
  { id: "ember",   label: "Ember",   color: "#FF6B6B" },
  { id: "rainbow", label: "Rainbow", color: "rainbow" },
];

export type AnchorMode = "frame" | "subject";

interface InkBase {
  id: string;
  brushId: BrushId;
  glow: number;            // shadowBlur in px
  start: number;           // seconds into the clip (0 for stills)
  life: number;            // seconds visible (use Infinity to persist)
  anchor: AnchorMode;      // "frame" = fixed; "subject" = follows tracked point
  drawOn: boolean;         // animate the reveal ("draws itself")
  anchorPt?: { x: number; y: number }; // normalized subject pos at creation (for tracking)
}
export interface InkStroke extends InkBase { type: "stroke"; pts: { x: number; y: number }[]; size: number; } // pts normalized 0..1
export interface InkText extends InkBase { type: "text"; text: string; x: number; y: number; fontPx: number; align?: CanvasTextAlign; }
export type InkElement = InkStroke | InkText;

const BRUSH_MAP: Record<string, Brush> = Object.fromEntries(INK_BRUSHES.map((b) => [b.id, b]));
const fadeWindow = (life: number) => Math.min(0.6, life * 0.3);

function colorAt(brush: Brush, time: number, i = 0, n = 1): string {
  if (brush.color === "rainbow") return `hsl(${((i / Math.max(1, n)) * 300 + time * 40) % 360}, 90%, 62%)`;
  return brush.color;
}

/**
 * Paint all ink elements active at `timeSec`.
 * @param getSubjectOffset optional tracker: given the element's anchor point + time,
 *   return how far (in px) the tracked subject has moved since the element was drawn.
 *   Wire this to MediaPipe / optical flow. Omit it and "subject" anchoring stays put.
 */
export function renderInk(
  ctx: CanvasRenderingContext2D,
  timeSec: number,
  W: number,
  H: number,
  elements: InkElement[],
  getSubjectOffset?: (anchorPt: { x: number; y: number }, time: number) => { dx: number; dy: number },
): void {
  for (const el of elements) {
    const dt = timeSec - el.start;
    if (dt < 0 || dt > el.life) continue;

    let alpha = 1;
    const fade = fadeWindow(el.life);
    if (isFinite(el.life) && dt > el.life - fade) alpha = Math.max(0, (el.life - dt) / fade);

    let ox = 0, oy = 0;
    if (el.anchor === "subject" && el.anchorPt && getSubjectOffset) {
      const o = getSubjectOffset(el.anchorPt, timeSec);
      ox = o.dx; oy = o.dy;
    }

    const brush = BRUSH_MAP[el.brushId] || INK_BRUSHES[0];
    ctx.save();
    ctx.globalAlpha = alpha;

    if (el.type === "text") {
      const col = colorAt(brush, timeSec);
      ctx.textAlign = el.align || "center";
      ctx.textBaseline = "middle";
      ctx.font = `700 ${el.fontPx}px 'Space Grotesk', system-ui, sans-serif`;
      // white core + colored glow halo (matches the draw brushes)
      ctx.shadowBlur = el.glow * 1.4; ctx.shadowColor = col; ctx.fillStyle = "#fff";
      ctx.fillText(el.text, el.x * W + ox, el.y * H + oy);
      ctx.shadowBlur = el.glow; ctx.fillStyle = col; ctx.globalAlpha = alpha * 0.6;
      ctx.fillText(el.text, el.x * W + ox, el.y * H + oy);
    } else {
      let n = el.pts.length;
      if (el.drawOn) {
        const rev = Math.min(1, dt / Math.min(0.7, el.life * 0.4));
        n = Math.max(2, Math.ceil(rev * el.pts.length));
      }
      // Never index past the points we actually have. A single-point stroke
      // (e.g. a tap) with drawOn would otherwise force n=2 and read pts[1].x.
      n = Math.min(n, el.pts.length);
      if (n >= 2) {
        ctx.lineCap = "round"; ctx.lineJoin = "round"; ctx.lineWidth = el.size; ctx.shadowBlur = el.glow;
        for (let i = 1; i < n; i++) {
          const col = colorAt(brush, timeSec, i, el.pts.length);
          ctx.strokeStyle = col; ctx.shadowColor = col;
          ctx.beginPath();
          ctx.moveTo(el.pts[i - 1].x * W + ox, el.pts[i - 1].y * H + oy);
          ctx.lineTo(el.pts[i].x * W + ox, el.pts[i].y * H + oy);
          ctx.stroke();
        }
      }
    }
    ctx.restore();
  }
}

/** Stills: render every element fully, ignoring time windows. */
export function renderInkStatic(ctx: CanvasRenderingContext2D, W: number, H: number, elements: InkElement[]): void {
  renderInk(ctx, 0, W, H, elements.map((e) => ({ ...e, start: 0, life: Infinity })));
}

/* ---- creation helpers (call from your pointer + text handlers) ---- */
let _id = 0;
export const newId = () => `ink_${Date.now()}_${_id++}`;

export function beginStroke(opts: {
  brushId: BrushId; size: number; glow: number; start: number; life: number;
  anchor: AnchorMode; drawOn: boolean; first: { x: number; y: number }; anchorPt?: { x: number; y: number };
}): InkStroke {
  return { id: newId(), type: "stroke", pts: [opts.first], brushId: opts.brushId, size: opts.size,
    glow: opts.glow, start: opts.start, life: opts.life, anchor: opts.anchor, drawOn: opts.drawOn, anchorPt: opts.anchorPt };
}

export function makeText(opts: {
  text: string; x: number; y: number; fontPx: number; brushId: BrushId; glow: number;
  start: number; life: number; anchor: AnchorMode; drawOn: boolean; anchorPt?: { x: number; y: number };
}): InkText {
  return { id: newId(), type: "text", ...opts };
}
