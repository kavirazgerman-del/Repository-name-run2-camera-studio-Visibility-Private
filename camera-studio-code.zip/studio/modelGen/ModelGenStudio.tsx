// In-app 3D generator studio (premium-gated). Turns a short text prompt into a
// fast-draft 3D model via the server's Meshy-backed pipeline, polls the job, and
// shows the result in a live GLB viewer. Generated models are PRIVATE by default;
// sharing to the feed is an explicit, separate action.
import { useEffect, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  useGenerateModel,
  useGetModelJob,
  useGetModelLimits,
  useListMyModels,
  useShareModel,
  useUnshareModel,
  getListMyModelsQueryKey,
  getGetModelLimitsQueryKey,
  getGetModelJobQueryKey,
  type UserModelJob,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { useMembership } from "@/lib/MembershipContext";
import ModelViewer from "./ModelViewer";

const MIN = 3;
const MAX = 600;

export default function ModelGenStudio() {
  const { level, isLoading: memLoading } = useMembership();
  const isFree = level === "free";
  const qc = useQueryClient();

  const [prompt, setPrompt] = useState("");
  const [activeJobId, setActiveJobId] = useState<number | null>(null);
  const [selected, setSelected] = useState<UserModelJob | null>(null);
  const processedRef = useRef<number | null>(null);

  const { data: limits } = useGetModelLimits({
    query: { enabled: !isFree, queryKey: getGetModelLimitsQueryKey() },
  });
  const { data: models } = useListMyModels({
    query: { enabled: !isFree, queryKey: getListMyModelsQueryKey() },
  });

  const jobQuery = useGetModelJob(activeJobId ?? 0, {
    query: {
      enabled: !!activeJobId,
      queryKey: getGetModelJobQueryKey(activeJobId ?? 0),
      refetchInterval: (q) => {
        const s = (q.state.data as UserModelJob | undefined)?.status;
        return s === "succeeded" || s === "failed" ? false : 2500;
      },
    },
  });
  const job = jobQuery.data;

  const gen = useGenerateModel({
    mutation: {
      onSuccess: (created) => {
        processedRef.current = null;
        setSelected(null);
        setActiveJobId(created.id);
        setPrompt("");
      },
      onError: (err) => {
        const msg =
          (err as { data?: { error?: string } })?.data?.error ??
          "Couldn't start the generation. Please try again.";
        toast.error(msg);
      },
    },
  });

  // React to the polled job reaching a terminal state exactly once.
  useEffect(() => {
    if (!job || job.id !== activeJobId) return;
    if (processedRef.current === job.id) return;
    if (job.status === "succeeded") {
      processedRef.current = job.id;
      setSelected(job);
      qc.invalidateQueries({ queryKey: getListMyModelsQueryKey() });
      qc.invalidateQueries({ queryKey: getGetModelLimitsQueryKey() });
      setActiveJobId(null);
      toast.success("Your 3D model is ready.");
    } else if (job.status === "failed") {
      processedRef.current = job.id;
      setActiveJobId(null);
      toast.error(job.errorReason || "That generation didn't work out. Try a different prompt.");
    }
  }, [job, activeJobId, qc]);

  const trimmed = prompt.trim();
  const tooShort = trimmed.length > 0 && trimmed.length < MIN;
  const outOfGens = !!limits && limits.remaining <= 0;
  const busy = gen.isPending || !!activeJobId;
  const canGenerate =
    !busy && !isFree && !outOfGens && trimmed.length >= MIN && trimmed.length <= MAX;

  const submit = () => {
    if (!canGenerate) return;
    gen.mutate({ data: { prompt: trimmed } });
  };

  if (memLoading) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-10 text-center text-sm text-muted-foreground">
        Loading…
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-6">
      <header className="mb-5">
        <h1 className="text-2xl font-bold tracking-tight">3D Generator</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Describe something and we'll sculpt a quick 3D draft you can spin around.
        </p>
      </header>

      {isFree ? (
        <PremiumUpsell />
      ) : (
        <>
          <section className="rounded-2xl border border-border bg-card p-4">
            <label htmlFor="model-prompt" className="text-sm font-medium">
              What should we make?
            </label>
            <textarea
              id="model-prompt"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value.slice(0, MAX))}
              rows={3}
              placeholder="A cute running bunny wearing sneakers, cartoon style"
              disabled={busy}
              className="mt-2 w-full resize-none rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary disabled:opacity-60"
            />
            <div className="mt-2 flex items-center justify-between gap-3">
              <span
                className={`text-xs ${tooShort ? "text-destructive" : "text-muted-foreground"}`}
              >
                {tooShort
                  ? `At least ${MIN} characters`
                  : `${trimmed.length}/${MAX}`}
              </span>
              <span className="text-xs text-muted-foreground">
                {limits
                  ? `${limits.remaining} of ${limits.limit} free generations left today`
                  : ""}
              </span>
            </div>
            <div className="mt-3 flex items-center gap-3">
              <Button onClick={submit} disabled={!canGenerate}>
                {busy ? "Generating…" : "Generate"}
              </Button>
              {outOfGens && (
                <span className="text-xs text-muted-foreground">
                  You've used today's free generations{limits?.resetAt ? " — check back tomorrow." : "."}
                </span>
              )}
            </div>
          </section>

          {busy && (
            <section className="mt-4 rounded-2xl border border-border bg-card p-4">
              <div className="flex items-center gap-3">
                <span className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
                <div>
                  <p className="text-sm font-medium">Sculpting your model…</p>
                  <p className="text-xs text-muted-foreground">
                    This usually takes under a minute. You can keep browsing — it'll appear here when it's done.
                  </p>
                </div>
              </div>
            </section>
          )}

          {selected?.modelUrl && (
            <section className="mt-4 overflow-hidden rounded-2xl border border-border bg-card">
              <ModelViewer
                url={selected.modelUrl}
                className="aspect-square w-full bg-[#0a0a12]"
              />
              <div className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">
                      {selected.prompt || "Generated model"}
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {selected.isPublic
                        ? "Shared to your feed. Anyone who can see your posts can view it in 3D."
                        : "Only you can see this. Drag to rotate, scroll or pinch to zoom."}
                    </p>
                  </div>
                  <span className="shrink-0 rounded-full border border-border px-2 py-0.5 text-[11px] text-muted-foreground">
                    {selected.isPublic ? "Shared" : "Private"}
                  </span>
                </div>
                <div className="mt-3">
                  <ShareControls model={selected} onUpdated={setSelected} />
                </div>
              </div>
            </section>
          )}

          <ModelGallery
            models={models ?? []}
            selectedId={selected?.id ?? null}
            onSelect={(m) => {
              processedRef.current = null;
              setSelected(m);
            }}
          />
        </>
      )}
    </div>
  );
}

function errMsg(err: unknown, fallback: string): string {
  return (err as { data?: { error?: string } })?.data?.error ?? fallback;
}

// Explicit share / unshare for a single finished model. Sharing reveals an
// optional caption first (moderated server-side); unsharing pulls the feed post
// and reverts the model to private. Both refresh the gallery so the badges match.
function ShareControls({
  model,
  onUpdated,
}: {
  model: UserModelJob;
  onUpdated: (m: UserModelJob) => void;
}) {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [caption, setCaption] = useState("");

  const share = useShareModel({
    mutation: {
      onSuccess: (m) => {
        onUpdated(m);
        setOpen(false);
        setCaption("");
        qc.invalidateQueries({ queryKey: getListMyModelsQueryKey() });
        toast.success("Shared to your feed.");
      },
      onError: (err) => toast.error(errMsg(err, "Couldn't share this model. Please try again.")),
    },
  });
  const unshare = useUnshareModel({
    mutation: {
      onSuccess: (m) => {
        onUpdated(m);
        qc.invalidateQueries({ queryKey: getListMyModelsQueryKey() });
        toast.success("Removed from your feed.");
      },
      onError: (err) => toast.error(errMsg(err, "Couldn't remove this model. Please try again.")),
    },
  });

  if (model.isPublic) {
    return (
      <Button
        variant="outline"
        size="sm"
        disabled={unshare.isPending}
        onClick={() => unshare.mutate({ id: model.id })}
      >
        {unshare.isPending ? "Removing…" : "Remove from feed"}
      </Button>
    );
  }

  if (!open) {
    return (
      <Button size="sm" onClick={() => setOpen(true)}>
        Share to feed
      </Button>
    );
  }

  const trimmed = caption.trim();
  return (
    <div className="w-full">
      <textarea
        value={caption}
        onChange={(e) => setCaption(e.target.value.slice(0, 600))}
        rows={2}
        placeholder="Add a caption (optional)"
        disabled={share.isPending}
        className="w-full resize-none rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary disabled:opacity-60"
      />
      <div className="mt-2 flex items-center gap-2">
        <Button
          size="sm"
          disabled={share.isPending}
          onClick={() => share.mutate({ id: model.id, data: { caption: trimmed || null } })}
        >
          {share.isPending ? "Sharing…" : "Share"}
        </Button>
        <Button
          size="sm"
          variant="ghost"
          disabled={share.isPending}
          onClick={() => {
            setOpen(false);
            setCaption("");
          }}
        >
          Cancel
        </Button>
      </div>
    </div>
  );
}

function ModelGallery({
  models,
  selectedId,
  onSelect,
}: {
  models: UserModelJob[];
  selectedId: number | null;
  onSelect: (m: UserModelJob) => void;
}) {
  const done = models.filter((m) => m.status === "succeeded" && m.modelUrl);
  if (done.length === 0) return null;
  return (
    <section className="mt-6">
      <h2 className="mb-3 text-sm font-semibold">Your models</h2>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {done.map((m) => {
          const active = m.id === selectedId;
          return (
            <button
              key={m.id}
              onClick={() => onSelect(m)}
              className={`group overflow-hidden rounded-xl border text-left transition ${
                active ? "border-primary" : "border-border hover:border-muted-foreground"
              }`}
            >
              <div className="aspect-square w-full bg-[#0a0a12]">
                {m.thumbnailUrl ? (
                  <img
                    src={m.thumbnailUrl}
                    alt={m.prompt || "3D model"}
                    className="h-full w-full object-cover"
                    loading="lazy"
                  />
                ) : (
                  <div className="flex h-full w-full items-center justify-center text-2xl">🧊</div>
                )}
              </div>
              <div className="flex items-center justify-between gap-2 p-2">
                <span className="truncate text-xs">{m.prompt || "Model"}</span>
                <span className="shrink-0 text-[10px] text-muted-foreground">
                  {m.isPublic ? "Shared" : "Private"}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
}

function PremiumUpsell() {
  return (
    <section className="rounded-2xl border border-border bg-card p-6 text-center">
      <div className="text-3xl">🧊</div>
      <h2 className="mt-2 text-lg font-semibold">The 3D Generator is a premium feature</h2>
      <p className="mx-auto mt-1 max-w-md text-sm text-muted-foreground">
        Premium members can turn text prompts into 3D models — with a couple of free
        drafts every day. Upgrade to start creating.
      </p>
    </section>
  );
}
