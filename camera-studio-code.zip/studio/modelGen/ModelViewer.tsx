// Lightweight, self-contained GLB viewer for the 3D generator studio. Loads a
// single .glb from a same-origin URL, frames it, and lets the user orbit
// (pointer drag) and zoom (wheel / pinch). Auto-rotates while idle. No
// OrbitControls dependency (not bundled in this three build) — the orbit math is
// a tiny spherical-coordinate camera around the model's centre.
import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";

type Status = "loading" | "ready" | "error";

export default function ModelViewer({
  url,
  className,
  autoRotate = true,
}: {
  url: string;
  className?: string;
  autoRotate?: boolean;
}) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [status, setStatus] = useState<Status>("loading");

  useEffect(() => {
    const wrap = wrapRef.current;
    if (!wrap) return;

    setStatus("loading");
    let disposed = false;
    let raf = 0;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    if (!renderer.getContext()) {
      setStatus("error");
      return;
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    const canvas = renderer.domElement;
    canvas.style.width = "100%";
    canvas.style.height = "100%";
    canvas.style.display = "block";
    canvas.style.touchAction = "none";
    wrap.appendChild(canvas);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, 1, 0.01, 100);

    // Studio lighting: soft ambient + a key/fill pair so generated meshes read
    // with form rather than as a flat silhouette.
    scene.add(new THREE.AmbientLight(0xffffff, 0.9));
    const key = new THREE.DirectionalLight(0xffffff, 1.6);
    key.position.set(2.5, 4, 3);
    scene.add(key);
    const fill = new THREE.DirectionalLight(0x88aaff, 0.7);
    fill.position.set(-3, 1, -2);
    scene.add(fill);

    // Spherical orbit state around the model centre.
    const target = new THREE.Vector3(0, 0, 0);
    let radius = 3;
    let theta = Math.PI * 0.15; // azimuth
    let phi = Math.PI * 0.42; // polar (from +Y)
    let radius0 = 3;

    const applyCamera = () => {
      const sinPhi = Math.sin(phi);
      camera.position.set(
        target.x + radius * sinPhi * Math.sin(theta),
        target.y + radius * Math.cos(phi),
        target.z + radius * sinPhi * Math.cos(theta),
      );
      camera.lookAt(target);
    };

    const resize = () => {
      const w = wrap.clientWidth || 1;
      const h = wrap.clientHeight || 1;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(wrap);

    // ── pointer-drag orbit + wheel/pinch zoom ──
    const pointers = new Map<number, { x: number; y: number }>();
    let dragging = false;
    let lastX = 0;
    let lastY = 0;
    let pinchDist = 0;
    let interacted = false;

    const onPointerDown = (e: PointerEvent) => {
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      canvas.setPointerCapture(e.pointerId);
      interacted = true;
      if (pointers.size === 1) {
        dragging = true;
        lastX = e.clientX;
        lastY = e.clientY;
      } else if (pointers.size === 2) {
        const [a, b] = [...pointers.values()];
        pinchDist = Math.hypot(a.x - b.x, a.y - b.y);
      }
    };
    const onPointerMove = (e: PointerEvent) => {
      if (!pointers.has(e.pointerId)) return;
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pointers.size >= 2) {
        const [a, b] = [...pointers.values()];
        const d = Math.hypot(a.x - b.x, a.y - b.y);
        if (pinchDist > 0) {
          radius = clamp(radius * (pinchDist / d), radius0 * 0.4, radius0 * 3);
        }
        pinchDist = d;
        return;
      }
      if (!dragging) return;
      const dx = e.clientX - lastX;
      const dy = e.clientY - lastY;
      lastX = e.clientX;
      lastY = e.clientY;
      theta -= dx * 0.01;
      phi = clamp(phi - dy * 0.01, 0.15, Math.PI - 0.15);
    };
    const onPointerUp = (e: PointerEvent) => {
      pointers.delete(e.pointerId);
      if (pointers.size < 2) pinchDist = 0;
      if (pointers.size === 0) dragging = false;
    };
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      interacted = true;
      radius = clamp(radius * (1 + Math.sign(e.deltaY) * 0.1), radius0 * 0.4, radius0 * 3);
    };
    canvas.addEventListener("pointerdown", onPointerDown);
    canvas.addEventListener("pointermove", onPointerMove);
    canvas.addEventListener("pointerup", onPointerUp);
    canvas.addEventListener("pointercancel", onPointerUp);
    canvas.addEventListener("wheel", onWheel, { passive: false });

    let model: THREE.Object3D | null = null;
    const loader = new GLTFLoader();
    loader.load(
      url,
      (gltf) => {
        if (disposed) return;
        model = gltf.scene;
        // Centre and normalise the model to a unit-ish size so the initial
        // framing is consistent regardless of the export's scale.
        const box = new THREE.Box3().setFromObject(model);
        const size = box.getSize(new THREE.Vector3());
        const centre = box.getCenter(new THREE.Vector3());
        const maxDim = Math.max(size.x, size.y, size.z) || 1;
        model.position.sub(centre);
        scene.add(model);
        radius = maxDim * 2.2;
        radius0 = radius;
        applyCamera();
        setStatus("ready");
      },
      undefined,
      () => {
        if (disposed) return;
        setStatus("error");
      },
    );

    const loop = () => {
      raf = requestAnimationFrame(loop);
      if (autoRotate && !dragging && !interacted) theta += 0.004;
      applyCamera();
      renderer.render(scene, camera);
    };
    loop();

    return () => {
      disposed = true;
      cancelAnimationFrame(raf);
      ro.disconnect();
      canvas.removeEventListener("pointerdown", onPointerDown);
      canvas.removeEventListener("pointermove", onPointerMove);
      canvas.removeEventListener("pointerup", onPointerUp);
      canvas.removeEventListener("pointercancel", onPointerUp);
      canvas.removeEventListener("wheel", onWheel);
      if (model) {
        model.traverse((o) => {
          const mesh = o as THREE.Mesh;
          if (mesh.geometry) mesh.geometry.dispose();
          const mat = mesh.material as THREE.Material | THREE.Material[] | undefined;
          if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
          else mat?.dispose();
        });
      }
      renderer.dispose();
      canvas.remove();
    };
  }, [url, autoRotate]);

  return (
    <div className={className} style={{ position: "relative" }}>
      <div ref={wrapRef} style={{ width: "100%", height: "100%" }} />
      {status !== "ready" && (
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 13,
            color: "rgba(255,255,255,0.7)",
            pointerEvents: "none",
          }}
        >
          {status === "loading" ? "Loading 3D model…" : "Couldn't load this model."}
        </div>
      )}
    </div>
  );
}

function clamp(v: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, v));
}
