import React from "react";
import { X, ImagePlus, UploadCloud, Camera, Images, Film, TriangleAlert, ShieldCheck } from "lucide-react";

// AddMediaSheet — the modern "add media" entry for Camera Studio. Replaces the old
// hidden-input + blocking ownership modal flow with one clear surface that:
//   • explains the import rules BEFORE the OS picker opens (photos OR one video,
//     1 photo → photo post, several → slideshow),
//   • folds the first-time ownership notice inline (the Browse tap doubles as the
//     explicit acknowledgment — same localStorage key as before),
//   • warns when importing will replace work already on the stage,
//   • adds desktop drag & drop (harmless no-op surface on touch devices).
// It only COLLECTS files — every file flows into the parent's existing import
// pipeline unchanged.
interface AddMediaSheetProps {
  open: boolean;
  onClose: () => void;
  /** True when segments/slides/a photo already exist — importing replaces them. */
  hasContent: boolean;
  /** True until the one-time upload-ownership notice has been acknowledged. */
  needsAck: boolean;
  /** Max photos accepted for a slideshow (kept in lockstep with the studio cap). */
  maxSlides: number;
  /** Open the OS file picker (parent acks + clicks its hidden input). */
  onBrowse: () => void;
  /** Files dropped directly onto the sheet (desktop drag & drop). */
  onFiles: (files: File[]) => void;
}

const PANEL_BG = "rgba(12,18,32,.92)";
const PANEL_BORDER = "1px solid rgba(120,160,255,.18)";

export function AddMediaSheet({ open, onClose, hasContent, needsAck, maxSlides, onBrowse, onFiles }: AddMediaSheetProps) {
  const [dragOver, setDragOver] = React.useState(false);
  // "Fine" pointers (mouse/trackpad) get the drag & drop hint; touch devices don't.
  const [finePointer] = React.useState(() => {
    try { return window.matchMedia("(pointer: fine)").matches; } catch { return false; }
  });

  if (!open) return null;

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const files = Array.from(e.dataTransfer?.files ?? []);
    if (files.length > 0) onFiles(files);
  };

  return (
    <div
      className="fixed inset-0 z-[80] flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm sm:p-6"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Add photos or video"
    >
      <div
        className="w-full sm:max-w-md rounded-t-3xl sm:rounded-3xl p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))]"
        style={{ background: PANEL_BG, border: PANEL_BORDER, backdropFilter: "blur(18px)", WebkitBackdropFilter: "blur(18px)" }}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <ImagePlus className="w-5 h-5" style={{ color: "#22C7F2" }} />
            <h3 className="text-white text-base font-bold">Add photos or video</h3>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="w-8 h-8 rounded-full flex items-center justify-center hover:brightness-125"
            style={{ background: "rgba(255,255,255,.08)", color: "#F8FAFC" }}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Big browse / drop target */}
        <button
          type="button"
          onClick={onBrowse}
          onDragOver={e => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          className="w-full rounded-2xl flex flex-col items-center justify-center gap-2 py-8 px-4 transition-all"
          style={{
            border: dragOver ? "2px dashed #22C7F2" : "2px dashed rgba(120,160,255,.35)",
            background: dragOver ? "rgba(34,199,242,.12)" : "rgba(255,255,255,.03)",
          }}
        >
          <UploadCloud className="w-8 h-8" style={{ color: "#22C7F2" }} />
          <span className="text-sm font-bold text-white">
            {needsAck ? "I understand — browse my device" : "Browse your photos & videos"}
          </span>
          {finePointer && (
            <span className="text-xs" style={{ color: "#A9B8CA" }}>or drag &amp; drop files here</span>
          )}
        </button>

        {/* Plain-language rules — shown BEFORE the picker so nobody hits a surprise toast. */}
        <div className="mt-4 space-y-2">
          <RuleRow icon={Camera} text="1 photo becomes a photo post" />
          <RuleRow icon={Images} text={`Several photos become a slideshow (up to ${maxSlides})`} />
          <RuleRow icon={Film} text="1 video at a time — photos or video, not both" />
        </div>

        {/* Replace warning — only when there's work on the stage to lose. */}
        {hasContent && (
          <div
            className="mt-4 flex items-start gap-2 rounded-2xl p-3 text-xs leading-relaxed"
            style={{ background: "rgba(246,185,74,.1)", border: "1px solid rgba(246,185,74,.35)", color: "#F6B94A" }}
          >
            <TriangleAlert className="w-4 h-4 shrink-0 mt-0.5" />
            <span>Adding media replaces what you've made so far. Save it as a draft first if you want to keep it.</span>
          </div>
        )}

        {/* One-time ownership notice — the Browse tap above is the acknowledgment. */}
        {needsAck && (
          <div
            className="mt-4 flex items-start gap-2 rounded-2xl p-3 text-xs leading-relaxed"
            style={{ background: "rgba(255,255,255,.04)", border: PANEL_BORDER, color: "#A9B8CA" }}
          >
            <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5" style={{ color: "#22C7F2" }} />
            <span>
              Only upload photos or videos you made or have the right to share. No copyrighted
              movies, shows, or music — to add a soundtrack, pick one from the music library.
            </span>
          </div>
        )}
      </div>
    </div>
  );
}

function RuleRow({ icon: Icon, text }: { icon: React.ElementType; text: string }) {
  return (
    <div className="flex items-center gap-2.5 text-xs" style={{ color: "#A9B8CA" }}>
      <span
        className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
        style={{ background: "rgba(34,199,242,.1)", border: "1px solid rgba(34,199,242,.25)" }}
      >
        <Icon className="w-3.5 h-3.5" style={{ color: "#22C7F2" }} />
      </span>
      {text}
    </div>
  );
}
