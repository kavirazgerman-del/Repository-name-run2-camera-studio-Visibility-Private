// ── AI Creative Director — config-driven filter renderer (web) ────────────────
//
// Renders a generated `AiFilterConfig` (governed + clamped server-side) through
// the SAME Camera Studio canvas engine every other filter uses, so a generated
// look previews live AND bakes into the captured photo/video. Pure data in →
// pixels out; this module holds NO React/component state.
//
// Two seams:
//   • aiConfigGradeCss(config, t) — the CSS colour grade, injected into the
//     studio's existing gradeCssRef/activeCss path so it bakes at capture via
//     Canvas2D ctx.filter (a style.filter on the element is preview-only).
//   • renderAiConfigFilter(ctx, …)  — the whitelisted overlay layers, drawn by
//     compositeFrame on top of the graded base, exactly like Neon Rain.
//
// The overlay fields are SEEDED + frame-driven (no persistent particle buffer),
// so a given (config, frame) always draws the same thing — deterministic, cheap,
// and trivially testable. Intensity 0 is a guaranteed identity (no grade, no
// overlay draws), matching every other studio filter.

import type { AiFilterConfig, AiFilterOverlay } from "@workspace/api-client-react";

const clamp01 = (n: number) => (n < 0 ? 0 : n > 1 ? 1 : n);
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const round3 = (n: number) => Math.round(n * 1000) / 1000;
const frac = (n: number) => n - Math.floor(n);

// Small, fast, fully-deterministic PRNG so seeded fields are stable per (seed).
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hexToRgb(hex: string): [number, number, number] {
  const m = /^#?([0-9a-f]{6})$/i.exec((hex || "").trim());
  if (!m) return [255, 255, 255];
  const n = parseInt(m[1], 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
const rgba = (hex: string, a: number) => {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r},${g},${b},${round3(clamp01(a))})`;
};

/**
 * Build the CSS colour-grade string for a config, scaled by `t` (0..1, the
 * studio's intensity). Each primitive lerps from its NEUTRAL value to the
 * config value, so t=0 returns "" (a true identity — no grade applied).
 */
export function aiConfigGradeCss(config: AiFilterConfig | null | undefined, t = 1): string {
  if (!config?.grade) return "";
  const k = clamp01(t);
  if (k <= 0) return "";
  const g = config.grade;
  const brightness = round3(lerp(1, g.brightness, k));
  const contrast = round3(lerp(1, g.contrast, k));
  const saturate = round3(lerp(1, g.saturate, k));
  const hue = round3(lerp(0, g.hueRotate, k));
  const sepia = round3(lerp(0, g.sepia, k));
  const parts = [
    brightness !== 1 ? `brightness(${brightness})` : "",
    contrast !== 1 ? `contrast(${contrast})` : "",
    saturate !== 1 ? `saturate(${saturate})` : "",
    hue !== 0 ? `hue-rotate(${hue}deg)` : "",
    sepia !== 0 ? `sepia(${sepia})` : "",
  ].filter(Boolean);
  return parts.join(" ");
}

// Animation tempo from the config's motion + speed, scaled by intensity. `still`
// freezes every moving layer (multiplier 0) so the look is a clean static grade.
function motionTempo(config: AiFilterConfig, t: number): number {
  const motion = config.animation?.motion ?? "gentle";
  const speed = clamp01(config.animation?.speed ?? 0.5);
  const base = motion === "still" ? 0 : motion === "dynamic" ? 1 : 0.55;
  return base * (0.25 + 0.75 * speed) * t;
}

// Resolve an overlay colour, falling back to the palette then white.
function overlayColor(ov: AiFilterOverlay, accents: string[]): string {
  if (/^#?[0-9a-f]{6}$/i.test((ov.color || "").trim())) return ov.color;
  return accents[0] ?? "#ffffff";
}

/**
 * Draw all whitelisted overlay layers for a config. Stateless + seeded: the same
 * (config, frame) always produces the same frame. `intensity` (0..1) scales the
 * whole effect; at 0 nothing is drawn (identity). The context is always restored
 * to a clean state so later layers (Motion Ink, stacked filters) draw true.
 */
export function renderAiConfigFilter(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  frame: number,
  config: AiFilterConfig | null | undefined,
  intensity = 1,
): void {
  const t = clamp01(intensity);
  if (!config || t <= 0 || !Array.isArray(config.overlays)) return;
  const accents = Array.isArray(config.accentColors) && config.accentColors.length
    ? config.accentColors
    : ["#ffffff"];
  const tempo = motionTempo(config, t);
  const time = frame * tempo * 0.05;

  config.overlays.forEach((ov, idx) => {
    if (!ov || typeof ov.type !== "string") return;
    const s = clamp01(ov.strength) * t;
    if (s <= 0) return;
    const density = clamp01(ov.density ?? 0.5);
    const color = overlayColor(ov, accents);
    const seed = 0x9e3779b1 ^ (idx * 0x85ebca77);
    ctx.save();
    switch (ov.type) {
      case "glow":
        drawGlow(ctx, w, h, color, s, time);
        break;
      case "vignette":
        drawVignette(ctx, w, h, color, s);
        break;
      case "grain":
        drawGrain(ctx, w, h, s, frame, density);
        break;
      case "particles":
        drawParticles(ctx, w, h, color, s, density, time, seed);
        break;
      case "rain":
        drawRain(ctx, w, h, color, s, density, time, seed);
        break;
      case "fog":
        drawFog(ctx, w, h, color, s, time, seed);
        break;
      case "fabric":
        drawFabric(ctx, w, h, color, s, time);
        break;
      case "lens_droplets":
        drawLensDroplets(ctx, w, h, color, s, density, seed);
        break;
      case "shimmer":
        drawShimmer(ctx, w, h, color, s, time);
        break;
      case "light_leak":
        drawLightLeak(ctx, w, h, color, s, time, seed);
        break;
      default:
        break;
    }
    ctx.restore();
  });

  // Leave the context pristine for downstream layers.
  ctx.globalAlpha = 1;
  ctx.filter = "none";
  ctx.shadowBlur = 0;
  ctx.globalCompositeOperation = "source-over";
}

/* ── Overlay primitives ───────────────────────────────────────────────────── */

function drawGlow(ctx: CanvasRenderingContext2D, w: number, h: number, color: string, s: number, time: number) {
  ctx.globalCompositeOperation = "screen";
  const pulse = 1 + 0.06 * Math.sin(time * 1.3);
  const g = ctx.createRadialGradient(w / 2, h * 0.42, 0, w / 2, h * 0.42, (w * 0.62) * pulse);
  g.addColorStop(0, rgba(color, 0.55 * s));
  g.addColorStop(0.5, rgba(color, 0.18 * s));
  g.addColorStop(1, rgba(color, 0));
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
}

function drawVignette(ctx: CanvasRenderingContext2D, w: number, h: number, color: string, s: number) {
  ctx.translate(w / 2, h / 2);
  ctx.scale(w / 2, h / 2);
  const vg = ctx.createRadialGradient(0, 0, 0, 0, 0, 1);
  vg.addColorStop(0.5, rgba(color, 0));
  vg.addColorStop(0.82, rgba(color, 0.22 * s));
  vg.addColorStop(1, rgba(color, 0.62 * s));
  ctx.fillStyle = vg;
  ctx.fillRect(-1, -1, 2, 2);
}

function drawGrain(ctx: CanvasRenderingContext2D, w: number, h: number, s: number, frame: number, density: number) {
  // Animated film grain — re-seed per frame so it shimmers; count scales with density.
  const rng = mulberry32(0x1234567 ^ (frame * 2654435761));
  const count = Math.round((w * h) / 1400 * (0.4 + density * 0.9));
  ctx.globalCompositeOperation = "overlay";
  for (let i = 0; i < count; i++) {
    const x = rng() * w;
    const y = rng() * h;
    const v = rng();
    ctx.globalAlpha = (0.04 + v * 0.12) * s;
    ctx.fillStyle = v > 0.5 ? "#ffffff" : "#000000";
    ctx.fillRect(x, y, 1.4, 1.4);
  }
}

function drawParticles(
  ctx: CanvasRenderingContext2D, w: number, h: number, color: string,
  s: number, density: number, time: number, seed: number,
) {
  const count = Math.round(28 + density * 90);
  const rng = mulberry32(seed);
  ctx.globalCompositeOperation = "screen";
  for (let i = 0; i < count; i++) {
    const sx = rng();
    const phase = rng();
    const depth = 0.3 + rng() * 0.7;
    const r = (1 + depth * 3) * (0.6 + s * 0.8);
    // Rise + gentle horizontal sway; wrap with frac so the field loops seamlessly.
    const y = frac(phase - time * 0.06 * depth);
    const x = frac(sx + Math.sin((phase + time * 0.4) * Math.PI * 2) * 0.02);
    const a = (0.12 + depth * 0.4) * s;
    const px = x * w;
    const py = y * h;
    const g = ctx.createRadialGradient(px, py, 0, px, py, r * 3);
    g.addColorStop(0, rgba(color, a));
    g.addColorStop(1, rgba(color, 0));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(px, py, r * 3, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawRain(
  ctx: CanvasRenderingContext2D, w: number, h: number, color: string,
  s: number, density: number, time: number, seed: number,
) {
  const count = Math.round(40 + density * 150);
  const rng = mulberry32(seed);
  ctx.globalCompositeOperation = "screen";
  ctx.lineCap = "round";
  for (let i = 0; i < count; i++) {
    const sx = rng();
    const phase = rng();
    const depth = 0.3 + rng() * 0.7;
    const y = frac(phase + time * (0.18 + depth * 0.5));
    const x = frac(sx - y * 0.06); // slight diagonal drift
    const len = (0.05 + depth * 0.09) * h;
    const x1 = x * w;
    const y1 = y * h;
    ctx.globalAlpha = (0.08 + depth * 0.32) * s;
    ctx.strokeStyle = color;
    ctx.lineWidth = 0.6 + depth * 1.6;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x1 - len * 0.12, y1 - len);
    ctx.stroke();
  }
}

function drawFog(
  ctx: CanvasRenderingContext2D, w: number, h: number, color: string,
  s: number, time: number, seed: number,
) {
  const rng = mulberry32(seed);
  ctx.globalCompositeOperation = "screen";
  const blobs = 3;
  for (let i = 0; i < blobs; i++) {
    const baseX = rng();
    const baseY = 0.25 + rng() * 0.6;
    const rad = (0.4 + rng() * 0.4) * w;
    const x = frac(baseX + time * 0.01 * (i + 1)) * w;
    const y = baseY * h + Math.sin(time * 0.3 + i) * h * 0.04;
    const g = ctx.createRadialGradient(x, y, 0, x, y, rad);
    g.addColorStop(0, rgba(color, 0.16 * s));
    g.addColorStop(1, rgba(color, 0));
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
  }
}

function drawFabric(ctx: CanvasRenderingContext2D, w: number, h: number, color: string, s: number, time: number) {
  // Diagonal moving sheen bands — a soft satin/fabric drape.
  ctx.globalCompositeOperation = "soft-light";
  const bands = 5;
  ctx.save();
  ctx.translate(w / 2, h / 2);
  ctx.rotate(-0.5);
  ctx.translate(-w / 2, -h / 2);
  for (let i = 0; i < bands; i++) {
    const p = frac(i / bands + time * 0.03);
    const x = p * w * 1.5 - w * 0.25;
    const grad = ctx.createLinearGradient(x - w * 0.12, 0, x + w * 0.12, 0);
    grad.addColorStop(0, rgba(color, 0));
    grad.addColorStop(0.5, rgba(color, 0.22 * s));
    grad.addColorStop(1, rgba(color, 0));
    ctx.fillStyle = grad;
    ctx.fillRect(x - w * 0.12, -h * 0.5, w * 0.24, h * 2);
  }
  ctx.restore();
}

function drawLensDroplets(
  ctx: CanvasRenderingContext2D, w: number, h: number, color: string,
  s: number, density: number, seed: number,
) {
  const count = Math.round(10 + density * 36);
  const rng = mulberry32(seed);
  ctx.globalCompositeOperation = "screen";
  for (let i = 0; i < count; i++) {
    const x = rng() * w;
    const y = rng() * h;
    const r = (4 + rng() * 16) * (0.6 + s * 0.8);
    const g = ctx.createRadialGradient(x - r * 0.3, y - r * 0.3, 0, x, y, r);
    g.addColorStop(0, rgba("#ffffff", 0.5 * s));
    g.addColorStop(0.4, rgba(color, 0.18 * s));
    g.addColorStop(1, rgba(color, 0));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawShimmer(ctx: CanvasRenderingContext2D, w: number, h: number, color: string, s: number, time: number) {
  // A single bright diagonal highlight sweeping across the frame.
  ctx.globalCompositeOperation = "screen";
  const p = frac(time * 0.06);
  const cx = p * w * 1.4 - w * 0.2;
  ctx.save();
  ctx.translate(cx, 0);
  ctx.rotate(-0.35);
  const band = w * 0.16;
  const grad = ctx.createLinearGradient(-band, 0, band, 0);
  grad.addColorStop(0, rgba(color, 0));
  grad.addColorStop(0.5, rgba("#ffffff", 0.35 * s));
  grad.addColorStop(1, rgba(color, 0));
  ctx.fillStyle = grad;
  ctx.fillRect(-band, -h, band * 2, h * 3);
  ctx.restore();
}

function drawLightLeak(
  ctx: CanvasRenderingContext2D, w: number, h: number, color: string,
  s: number, time: number, seed: number,
) {
  const rng = mulberry32(seed);
  const corner = Math.floor(rng() * 4);
  const drift = Math.sin(time * 0.4) * 0.05;
  const corners: Array<[number, number]> = [
    [0, 0], [w, 0], [0, h], [w, h],
  ];
  const [cx, cy] = corners[corner];
  const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, w * (0.7 + drift));
  ctx.globalCompositeOperation = "screen";
  g.addColorStop(0, rgba(color, 0.4 * s));
  g.addColorStop(0.4, rgba(color, 0.14 * s));
  g.addColorStop(1, rgba(color, 0));
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
}
