// ── Studio — reusable single-body pose tracker ──────────────────────────────────
// A generic MediaPipe PoseLandmarker (numPoses:1, VIDEO) that any Camera Studio
// consumer can drive off the live <video>. This is the ONE body-pose implementation
// in the studio — the Army Bunny filter re-exports it (armyBunny/poseTracker.ts) so no
// second PoseLandmarker is ever created.
//
// It mirrors the other studio trackers' lifecycle contract: throttled async detection
// on its own strictly-increasing timestamp clock, EMA smoothing, hold-then-fade on
// tracking loss, and a clean no-op (getTracking() === null) if the model/GL fails to
// load — so consumers degrade gracefully (raw video passes through) rather than crash.
//
// Detection is intentionally decoupled from rendering: a setTimeout timer runs
// detection at ~20fps and writes smoothed landmarks into a reused snapshot; the rAF
// compositor reads getTracking() synchronously. Runs on the MAIN THREAD (no Web
// Worker / OffscreenCanvas), matching every existing studio tracker.
import { FilesetResolver, PoseLandmarker, type PoseLandmarkerResult } from "@mediapipe/tasks-vision";
import { computePoseAngles, type PoseAngles } from "./poseAngles";

const DETECT_MS = 50;  // ~20fps detection cadence (protects the compositor)
const EMA = 0.5;       // landmark smoothing toward each new detection
const HOLD_MS = 140;   // keep the last pose briefly after a dropped frame
const FADE_MS = 280;   // then fade out over this long
const N = 33;          // MediaPipe pose landmark count

export interface PoseSnapshot {
  /** Normalized image landmarks, 33×3 ([0..1] x/y, relative z). */
  norm: Float32Array;
  /** World landmarks in metres, 33×3, origin at the hip midpoint. */
  world: Float32Array;
  /** 1 = live, decays to 0 after tracking loss. */
  fade: number;
}

export class StudioPoseTracker {
  private video: HTMLVideoElement;
  private landmarker: PoseLandmarker | null = null;
  private starting = false;
  private disposed = false;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private lastTs = 0;

  private norm = new Float32Array(N * 3);
  private world = new Float32Array(N * 3);
  private has = false;
  private lastSeen = 0;
  private snap: PoseSnapshot = { norm: this.norm, world: this.world, fade: 0 };

  constructor(video: HTMLVideoElement) { this.video = video; }

  async start() {
    if (this.disposed || this.starting || this.landmarker) return;
    this.starting = true;
    try {
      const base = import.meta.env.BASE_URL || "/";
      const fileset = await FilesetResolver.forVisionTasks(`${base}mediapipe/wasm`);
      if (this.disposed) return;
      const make = (delegate: "GPU" | "CPU") => PoseLandmarker.createFromOptions(fileset, {
        baseOptions: { modelAssetPath: `${base}mediapipe/pose_landmarker_lite.task`, delegate },
        runningMode: "VIDEO",
        numPoses: 1,
      });
      try { this.landmarker = await make("GPU"); }
      catch { this.landmarker = await make("CPU"); }
      if (this.disposed) { this.landmarker?.close(); this.landmarker = null; return; }
      this.loop();
    } catch (err) {
      console.error("[studio-pose] pose tracker init failed", err);
    } finally {
      this.starting = false;
    }
  }

  private loop = () => {
    if (this.disposed) return;
    this.detectOnce();
    this.timer = setTimeout(this.loop, DETECT_MS);
  };

  private detectOnce() {
    const v = this.video, lm = this.landmarker;
    if (!lm || !v || v.readyState < 2 || v.videoWidth === 0) return;
    let ts = performance.now();
    if (ts <= this.lastTs) ts = this.lastTs + 1; // strictly increasing (required)
    this.lastTs = ts;
    let res: PoseLandmarkerResult;
    try { res = lm.detectForVideo(v, ts); } catch { return; }

    const pose = res.landmarks?.[0];
    const wpose = res.worldLandmarks?.[0];
    if (!pose || pose.length < N || !wpose || wpose.length < N) return;

    if (!this.has) {
      for (let i = 0; i < N; i++) {
        this.norm[i * 3] = pose[i].x; this.norm[i * 3 + 1] = pose[i].y; this.norm[i * 3 + 2] = pose[i].z;
        this.world[i * 3] = wpose[i].x; this.world[i * 3 + 1] = wpose[i].y; this.world[i * 3 + 2] = wpose[i].z;
      }
      this.has = true;
    } else {
      for (let i = 0; i < N; i++) {
        this.norm[i * 3] += (pose[i].x - this.norm[i * 3]) * EMA;
        this.norm[i * 3 + 1] += (pose[i].y - this.norm[i * 3 + 1]) * EMA;
        this.norm[i * 3 + 2] += (pose[i].z - this.norm[i * 3 + 2]) * EMA;
        this.world[i * 3] += (wpose[i].x - this.world[i * 3]) * EMA;
        this.world[i * 3 + 1] += (wpose[i].y - this.world[i * 3 + 1]) * EMA;
        this.world[i * 3 + 2] += (wpose[i].z - this.world[i * 3 + 2]) * EMA;
      }
    }
    this.lastSeen = performance.now();
  }

  /** Latest smoothed snapshot, or null when there is no usable pose. */
  getTracking(): PoseSnapshot | null {
    if (!this.has) return null;
    const dt = performance.now() - this.lastSeen;
    let fade = 1;
    if (dt > HOLD_MS) fade = Math.max(0, 1 - (dt - HOLD_MS) / FADE_MS);
    if (fade <= 0) return null;
    this.snap.fade = fade;
    return this.snap;
  }

  dispose() {
    this.disposed = true;
    if (this.timer) { clearTimeout(this.timer); this.timer = null; }
    this.landmarker?.close();
    this.landmarker = null;
  }
}

/** Latest pose snapshot plus precomputed common limb angles (both null when absent). */
export interface PoseFrame {
  snapshot: PoseSnapshot | null;
  angles: PoseAngles | null;
}

/**
 * Reusable accessor: read the latest pose + derived angles from a tracker (or null)
 * without reaching into any specific consumer's internals. The single place limb
 * angles are computed, so the compositor seam, the debug preview, and any future
 * consumer stay consistent. Returns nulls when there is no usable pose.
 */
export function readPose(tracker: StudioPoseTracker | null | undefined): PoseFrame {
  const snapshot = tracker?.getTracking() ?? null;
  return { snapshot, angles: snapshot ? computePoseAngles(snapshot.world) : null };
}
