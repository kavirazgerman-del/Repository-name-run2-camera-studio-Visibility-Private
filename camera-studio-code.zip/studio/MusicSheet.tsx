import React from "react";
import { X, Play, Pause, Check, Music, Sparkles, Volume2, VolumeX, Wand2, Loader2, SlidersHorizontal, Film, UploadCloud, ShieldCheck } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  useGenerateMusicTrack,
  useUploadMusicTrack,
  useGetMyMusicTracks,
  useSubmitMusicUploadRequest,
  useGetMyMusicUploadRequests,
  type MusicTrack,
  type MusicUploadRequest,
  type UploadMusicTrackInputPlatform,
} from "@workspace/api-client-react";
import { useUpload } from "@workspace/object-storage-web";
import { useAuth } from "@/lib/AuthContext";
import type { MusicFitMode } from "./videoExport";
import type { MusicSuggestion } from "./musicMatch";

// Pull a user-facing message off an ApiError-shaped rejection (it carries the
// server's `{ error }` envelope on `.data`), falling back to a generic message.
function generateErrorMessage(err: unknown): string {
  const data = (err as { data?: { error?: string } } | null)?.data;
  return data?.error || "Couldn't generate that track. Try again.";
}

function uploadErrorMessage(err: unknown): string {
  const data = (err as { data?: { error?: string } } | null)?.data;
  return data?.error || "Couldn't upload that track. Try again.";
}

function requestErrorMessage(err: unknown): string {
  const data = (err as { data?: { error?: string } } | null)?.data;
  return data?.error || "Couldn't submit that request. Try again.";
}

// AI music platforms a user can attest an uploaded track came from. Must stay in
// lockstep with the server's MUSIC_PLATFORMS enum.
const UPLOAD_PLATFORMS: { value: UploadMusicTrackInputPlatform; label: string }[] = [
  { value: "suno", label: "Suno" },
  { value: "zona", label: "Zona" },
  { value: "udio", label: "Udio" },
  { value: "other", label: "Other AI platform" },
];

const FIT_MODES: { id: MusicFitMode; label: string; hint: string }[] = [
  { id: "loop", label: "Loop", hint: "Repeat to fill the video" },
  { id: "trim", label: "Trim", hint: "Play once, cut at the end" },
  { id: "stretch", label: "Stretch", hint: "Speed to match length" },
  { id: "once", label: "Once", hint: "Play through a single time" },
];

const MOOD_ORDER = ["upbeat", "chill", "cinematic", "emotional", "electronic", "acoustic"];

interface MusicSheetProps {
  open: boolean;
  onClose: () => void;
  tracks: MusicTrack[];
  moods: Record<string, MusicTrack[]>;
  selectedTrackId: number | null;
  onSelect: (id: number | null) => void;
  fitMode: MusicFitMode;
  onFitModeChange: (m: MusicFitMode) => void;
  // Replace the filmed clip's own audio with only the chosen soundtrack.
  muteVideoAudio: boolean;
  onMuteVideoAudioChange: (v: boolean) => void;
  // Independent export-mix levels (0..1): the creator's own content/video audio
  // and the platform soundtrack. Only meaningful once a track is selected.
  contentVolume: number;
  onContentVolumeChange: (v: number) => void;
  musicVolume: number;
  onMusicVolumeChange: (v: number) => void;
  suggestion: MusicSuggestion | null;
  loading?: boolean;
  // Called with the freshly generated custom track so the parent can add it to
  // its track list and select it (so its audio is baked into the export).
  onGenerated: (track: MusicTrack) => void;
  // Optional seed for the generation prompt (e.g. derived from caption + look).
  defaultPrompt?: string;
  // AI photo→mood match. Provided only when the post has a photo/slide source;
  // the parent owns the API call + track selection, this is just the button.
  onAiMatch?: () => void;
  aiMatching?: boolean;
}

export function MusicSheet({
  open,
  onClose,
  tracks,
  moods,
  selectedTrackId,
  onSelect,
  fitMode,
  onFitModeChange,
  muteVideoAudio,
  onMuteVideoAudioChange,
  contentVolume,
  onContentVolumeChange,
  musicVolume,
  onMusicVolumeChange,
  suggestion,
  loading,
  onGenerated,
  onAiMatch,
  aiMatching,
  defaultPrompt,
}: MusicSheetProps) {
  const audioRef = React.useRef<HTMLAudioElement | null>(null);
  const [previewId, setPreviewId] = React.useState<number | null>(null);
  const [activeMood, setActiveMood] = React.useState<string>("all");
  const [prompt, setPrompt] = React.useState("");
  const [genError, setGenError] = React.useState<string | null>(null);
  const generate = useGenerateMusicTrack();

  // Upload is adult-only; the server also enforces this (403 for teens). The
  // serialized age-group field is the obfuscated `n` (typed as ageGroup), so read
  // it the same way the rest of the app does.
  const { user } = useAuth();
  const canUpload = (user as any)?.n === "adult";

  const [tab, setTab] = React.useState<"library" | "upload" | "original">("library");
  const fileRef = React.useRef<HTMLInputElement | null>(null);
  const [upFile, setUpFile] = React.useState<File | null>(null);
  const [upTitle, setUpTitle] = React.useState("");
  const [upPlatform, setUpPlatform] = React.useState<UploadMusicTrackInputPlatform>("suno");
  const [upPlatformOther, setUpPlatformOther] = React.useState("");
  const [upAttested, setUpAttested] = React.useState(false);
  const [upError, setUpError] = React.useState<string | null>(null);
  const { uploadFile, isUploading } = useUpload();
  const upload = useUploadMusicTrack();
  const uploadBusy = isUploading || upload.isPending;

  // The user's own previously-uploaded AI-platform tracks (creator-private).
  const myUploads = useGetMyMusicTracks({
    query: { enabled: open && canUpload, queryKey: ["/api/music-tracks/mine"] },
  });
  const myTracks: MusicTrack[] = myUploads.data?.tracks ?? [];
  // Approved original-music submissions are promoted into a creator-private
  // track that lands in `myTracks`; index them so an approved request can offer
  // a direct "use" action once the promoted track is available.
  const myTracksById = React.useMemo(() => {
    const map = new Map<number, MusicTrack>();
    for (const t of myTracks) map.set(t.id, t);
    return map;
  }, [myTracks]);

  // Tier-3: original human-made music. The user uploads the audio (scanned) plus
  // an optional ownership certificate/proof image (not scanned as audio), signs an
  // attestation, and submits a review request. Nothing plays or publishes until a
  // staff member approves it — so this tab never selects a track.
  const origFileRef = React.useRef<HTMLInputElement | null>(null);
  const origCertRef = React.useRef<HTMLInputElement | null>(null);
  const [origFile, setOrigFile] = React.useState<File | null>(null);
  const [origCert, setOrigCert] = React.useState<File | null>(null);
  const [origTitle, setOrigTitle] = React.useState("");
  const [origSignedName, setOrigSignedName] = React.useState("");
  const [origAttested, setOrigAttested] = React.useState(false);
  const [origError, setOrigError] = React.useState<string | null>(null);
  const [origDone, setOrigDone] = React.useState(false);
  const origAudioUpload = useUpload({ basePath: "/api/music-upload-requests" });
  const origCertUpload = useUpload({ basePath: "/api/music-upload-requests", scan: false });
  const submitRequest = useSubmitMusicUploadRequest();
  const origBusy = origAudioUpload.isUploading || origCertUpload.isUploading || submitRequest.isPending;

  const myRequestsQuery = useGetMyMusicUploadRequests({
    query: { enabled: open && canUpload, queryKey: ["/api/music-upload-requests/mine"] },
  });
  const myRequests: MusicUploadRequest[] = myRequestsQuery.data?.requests ?? [];

  // Stop preview playback whenever the sheet closes.
  React.useEffect(() => {
    if (!open && audioRef.current) {
      audioRef.current.pause();
      setPreviewId(null);
    }
  }, [open]);

  // Reset to the Library tab each time the sheet opens (and never leave the user
  // stranded on a hidden Upload tab if their account can't upload).
  React.useEffect(() => {
    if (open) setTab("library");
  }, [open]);

  // Seed the prompt from the caption/look once per opening, only while empty.
  React.useEffect(() => {
    if (open && defaultPrompt && prompt.trim() === "") {
      setPrompt(defaultPrompt.slice(0, 300));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  React.useEffect(() => () => { audioRef.current?.pause(); }, []);

  async function handleGenerate() {
    const p = prompt.trim();
    if (p.length < 3 || generate.isPending) return;
    setGenError(null);
    try {
      const track = await generate.mutateAsync({
        data: { prompt: p, mood: activeMood !== "all" ? activeMood : null },
      });
      onGenerated(track);
    } catch (err) {
      setGenError(generateErrorMessage(err));
    }
  }

  function resetUploadForm() {
    setUpFile(null);
    setUpTitle("");
    setUpPlatform("suno");
    setUpPlatformOther("");
    setUpAttested(false);
    if (fileRef.current) fileRef.current.value = "";
  }

  async function handleUpload() {
    if (uploadBusy) return;
    setUpError(null);
    if (!upFile) { setUpError("Choose an audio file to upload."); return; }
    if (!upTitle.trim()) { setUpError("Give your track a title."); return; }
    if (upPlatform === "other" && !upPlatformOther.trim()) {
      setUpError("Tell us which AI platform you used.");
      return;
    }
    if (!upAttested) {
      setUpError("Please confirm the track was made on an AI music platform.");
      return;
    }

    const uploaded = await uploadFile(upFile);
    if (!uploaded) {
      setUpError("That file couldn't be uploaded. Please try again.");
      return;
    }

    try {
      const track = await upload.mutateAsync({
        data: {
          objectPath: uploaded.objectPath,
          title: upTitle.trim(),
          platform: upPlatform,
          platformOther: upPlatform === "other" ? upPlatformOther.trim() : undefined,
          attested: true,
        },
      });
      onGenerated(track);
      resetUploadForm();
      void myUploads.refetch();
      setTab("library");
    } catch (err) {
      setUpError(uploadErrorMessage(err));
    }
  }

  function resetOriginalForm() {
    setOrigFile(null);
    setOrigCert(null);
    setOrigTitle("");
    setOrigSignedName("");
    setOrigAttested(false);
    if (origFileRef.current) origFileRef.current.value = "";
    if (origCertRef.current) origCertRef.current.value = "";
  }

  async function handleSubmitOriginal() {
    if (origBusy) return;
    setOrigError(null);
    setOrigDone(false);
    if (!origFile) { setOrigError("Choose the audio file for your original track."); return; }
    if (!origTitle.trim()) { setOrigError("Give your track a title."); return; }
    if (!origSignedName.trim()) { setOrigError("Type your full name to sign the ownership statement."); return; }
    if (!origAttested) { setOrigError("Please confirm you own this music and have the right to use it."); return; }

    // Audio is scanned; an unclean/unscanned object is rejected server-side at
    // submit, so a null here means the scan blocked or the upload failed.
    const audio = await origAudioUpload.uploadFile(origFile);
    if (!audio) {
      setOrigError("That audio couldn't be uploaded or didn't pass the safety check. Please try again.");
      return;
    }

    let certPath: string | undefined;
    if (origCert) {
      const cert = await origCertUpload.uploadFile(origCert);
      if (!cert) {
        setOrigError("Your proof file couldn't be uploaded. Please try again.");
        return;
      }
      certPath = cert.objectPath;
    }

    try {
      await submitRequest.mutateAsync({
        data: {
          audioObjectPath: audio.objectPath,
          certObjectPath: certPath,
          title: origTitle.trim(),
          mood: activeMood !== "all" ? activeMood : undefined,
          signedName: origSignedName.trim(),
          attested: true,
        },
      });
      resetOriginalForm();
      setOrigDone(true);
      void myRequestsQuery.refetch();
    } catch (err) {
      setOrigError(requestErrorMessage(err));
    }
  }

  if (!open) return null;

  const moodKeys = [
    ...MOOD_ORDER.filter((m) => moods[m]?.length),
    ...Object.keys(moods).filter((m) => !MOOD_ORDER.includes(m)),
  ];

  const visible =
    activeMood === "all" ? tracks : tracks.filter((t) => t.mood === activeMood);

  function togglePreview(track: MusicTrack) {
    const a = audioRef.current;
    if (!a) return;
    if (previewId === track.id) {
      a.pause();
      setPreviewId(null);
      return;
    }
    a.src = track.audioUrl;
    a.currentTime = 0;
    void a.play().catch(() => setPreviewId(null));
    setPreviewId(track.id);
  }

  function choose(id: number | null) {
    onSelect(id);
  }

  return (
    // z-[70] so this sits ABOVE the Publish modal (z-[60]); otherwise opening
    // "Add music" from inside Publish mounts the picker behind it and it looks
    // like nothing happens. Stays below the z-[80] blocking gate overlay.
    <div className="absolute inset-0 z-[70] flex flex-col bg-black/90 backdrop-blur-xl">
      <audio ref={audioRef} onEnded={() => setPreviewId(null)} className="hidden" />

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
        <div className="flex items-center gap-2 text-white">
          <Music className="w-5 h-5" />
          <span className="font-bold">Soundtrack</span>
        </div>
        <button
          onClick={onClose}
          className="w-9 h-9 rounded-full bg-white/10 border border-white/15 flex items-center justify-center text-white"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Library / Upload / Original tab switcher (Upload + Original are adult-only) */}
      {canUpload && (
        <div className="flex gap-1.5 px-4 pt-3">
          {([
            { id: "library", label: "Library", icon: Music },
            { id: "upload", label: "AI music", icon: UploadCloud },
            { id: "original", label: "My music", icon: ShieldCheck },
          ] as const).map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={cn(
                "flex-1 py-2 rounded-xl text-[11px] font-bold uppercase tracking-wide transition-all border flex items-center justify-center gap-1.5",
                tab === id
                  ? "bg-white text-black border-white"
                  : "bg-white/5 text-white/60 border-white/10 hover:text-white",
              )}
            >
              <Icon className="w-3.5 h-3.5" />
              {label}
            </button>
          ))}
        </div>
      )}

      {tab === "library" && (
      <>
      {/* AI photo→mood match (photo & slideshow posts only) */}
      {onAiMatch && (
        <button
          onClick={onAiMatch}
          disabled={aiMatching}
          className="mx-4 mt-3 flex w-[calc(100%-2rem)] items-center gap-3 rounded-2xl border border-sky-400/30 bg-sky-500/10 px-3 py-2.5 text-left disabled:opacity-60"
        >
          <div className="w-8 h-8 rounded-full bg-sky-500/20 flex items-center justify-center shrink-0">
            <Sparkles className={`w-4 h-4 text-sky-300 ${aiMatching ? "animate-pulse" : ""}`} />
          </div>
          <div className="min-w-0">
            <div className="text-[11px] uppercase tracking-wide text-sky-300/80 font-semibold">
              AI music match
            </div>
            <div className="text-sm text-white font-semibold truncate">
              {aiMatching ? "Reading your photo's mood…" : "Let AI read the photo & pick a track"}
            </div>
          </div>
        </button>
      )}

      {/* Auto-match suggestion */}
      {suggestion && (
        <button
          onClick={() => choose(suggestion.track.id)}
          className="mx-4 mt-3 flex items-center gap-3 rounded-2xl border border-fuchsia-400/30 bg-fuchsia-500/10 px-3 py-2.5 text-left"
        >
          <div className="w-8 h-8 rounded-full bg-fuchsia-500/20 flex items-center justify-center shrink-0">
            <Sparkles className="w-4 h-4 text-fuchsia-300" />
          </div>
          <div className="min-w-0">
            <div className="text-[11px] uppercase tracking-wide text-fuchsia-300/80 font-semibold">
              Suggested for your post
            </div>
            <div className="text-sm text-white font-semibold truncate">
              {suggestion.track.title}
              <span className="ml-1.5 text-white/40 font-normal capitalize">· {suggestion.mood}</span>
            </div>
          </div>
        </button>
      )}

      {/* Generate custom track */}
      <div className="mx-4 mt-3 rounded-2xl border border-white/10 bg-white/5 p-3">
        <div className="flex items-center gap-2 text-white/50 text-[11px] font-semibold uppercase tracking-wide mb-2">
          <Wand2 className="w-3.5 h-3.5" /> Create your own
        </div>
        <div className="flex gap-2">
          <input
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                void handleGenerate();
              }
            }}
            maxLength={300}
            placeholder="e.g. dreamy lo-fi for a sunset run"
            className="flex-1 min-w-0 rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-white/30"
          />
          <button
            onClick={() => void handleGenerate()}
            disabled={generate.isPending || prompt.trim().length < 3}
            className="px-4 py-2 rounded-xl bg-fuchsia-500 text-white text-sm font-bold disabled:opacity-40 flex items-center gap-1.5 shrink-0"
          >
            {generate.isPending ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Wand2 className="w-4 h-4" />
            )}
            {generate.isPending ? "Making…" : "Generate"}
          </button>
        </div>
        {genError && <p className="mt-2 text-xs text-rose-300">{genError}</p>}
        <p className="mt-2 text-[11px] text-white/30">
          Instrumental only · added to your tracks
        </p>
      </div>

      {/* Mood filter chips */}
      <div className="flex gap-1.5 overflow-x-auto px-4 py-3 no-scrollbar">
        {(["all", ...moodKeys] as const).map((m) => (
          <button
            key={m}
            onClick={() => setActiveMood(m)}
            className={cn(
              "px-3 py-1.5 rounded-full text-xs font-semibold capitalize whitespace-nowrap transition-all border",
              activeMood === m
                ? "bg-white text-black border-white"
                : "bg-white/5 text-white/60 border-white/10 hover:text-white",
            )}
          >
            {m}
          </button>
        ))}
      </div>

      {/* Track list */}
      <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-2">
        {loading && (
          <div className="py-10 text-center text-white/40 text-sm">Loading tracks…</div>
        )}
        {!loading && visible.length === 0 && (
          <div className="py-10 text-center text-white/40 text-sm">No tracks in this mood yet.</div>
        )}
        {visible.map((t) => {
          const isSelected = selectedTrackId === t.id;
          const isPlaying = previewId === t.id;
          return (
            <div
              key={t.id}
              className={cn(
                "flex items-center gap-3 rounded-2xl border px-3 py-2.5 transition-all",
                isSelected
                  ? "border-white/60 bg-white/15"
                  : "border-white/10 bg-white/5",
              )}
            >
              <button
                onClick={() => togglePreview(t)}
                className="w-10 h-10 rounded-full bg-white/10 border border-white/15 flex items-center justify-center text-white shrink-0"
                aria-label={isPlaying ? "Pause preview" : "Play preview"}
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
              </button>
              <button onClick={() => choose(t.id)} className="flex-1 min-w-0 text-left">
                <div className="text-sm font-semibold text-white truncate">{t.title}</div>
                <div className="text-[11px] text-white/40 truncate capitalize">
                  {t.mood}
                  {t.tags.length > 0 && <span className="text-white/25"> · {t.tags.slice(0, 3).join(", ")}</span>}
                </div>
              </button>
              <button
                onClick={() => choose(isSelected ? null : t.id)}
                className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-all",
                  isSelected ? "bg-white text-black" : "bg-white/10 text-white/60 border border-white/15",
                )}
                aria-label={isSelected ? "Remove track" : "Use track"}
              >
                <Check className="w-4 h-4" />
              </button>
            </div>
          );
        })}
      </div>
      </>
      )}

      {/* Upload tab — AI-platform music only (adult-only) */}
      {tab === "upload" && canUpload && (
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
          {/* What this is / provenance note */}
          <div className="flex items-start gap-2.5 rounded-2xl border border-sky-400/25 bg-sky-500/10 px-3 py-2.5">
            <ShieldCheck className="w-4 h-4 text-sky-300 shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed text-sky-100/80">
              Upload a track you made on an AI music platform (Suno, Zona, Udio…).
              Only you can add it to your posts, and it's never added to the shared
              library. Have your own original music instead? That needs a quick
              review — reach out to the team.
            </p>
          </div>

          <div className="rounded-2xl border border-white/10 bg-white/5 p-3 space-y-3">
            {/* File */}
            <div className="space-y-1.5">
              <label className="text-white/50 text-[11px] font-semibold uppercase tracking-wide">
                Audio file
              </label>
              <input
                ref={fileRef}
                type="file"
                accept="audio/*"
                disabled={uploadBusy}
                onChange={(e) => { setUpFile(e.target.files?.[0] ?? null); setUpError(null); }}
                className="w-full text-sm text-white/80 file:mr-3 file:rounded-lg file:border-0 file:bg-white/10 file:px-3 file:py-1.5 file:text-white file:text-xs file:font-semibold"
              />
              <p className="text-[11px] text-white/30">MP3, M4A, AAC, WAV, or OGG · up to 25&nbsp;MB and 6&nbsp;minutes.</p>
            </div>

            {/* Title */}
            <div className="space-y-1.5">
              <label className="text-white/50 text-[11px] font-semibold uppercase tracking-wide">Title</label>
              <input
                value={upTitle}
                maxLength={120}
                onChange={(e) => setUpTitle(e.target.value)}
                placeholder="e.g. Midnight Sprint"
                className="w-full rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-white/30"
              />
            </div>

            {/* Platform */}
            <div className="space-y-1.5">
              <label className="text-white/50 text-[11px] font-semibold uppercase tracking-wide">AI platform</label>
              <select
                value={upPlatform}
                onChange={(e) => setUpPlatform(e.target.value as UploadMusicTrackInputPlatform)}
                className="w-full rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-sm text-white focus:outline-none focus:border-white/30"
              >
                {UPLOAD_PLATFORMS.map((p) => (
                  <option key={p.value} value={p.value} className="bg-neutral-900">
                    {p.label}
                  </option>
                ))}
              </select>
            </div>

            {upPlatform === "other" && (
              <div className="space-y-1.5">
                <label className="text-white/50 text-[11px] font-semibold uppercase tracking-wide">Which platform?</label>
                <input
                  value={upPlatformOther}
                  maxLength={60}
                  onChange={(e) => setUpPlatformOther(e.target.value)}
                  placeholder="e.g. Riffusion"
                  className="w-full rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-white/30"
                />
              </div>
            )}

            {/* Attestation */}
            <label className="flex items-start gap-2.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={upAttested}
                onChange={(e) => setUpAttested(e.target.checked)}
                className="mt-0.5 h-4 w-4 shrink-0 accent-fuchsia-500"
              />
              <span className="text-[11px] leading-relaxed text-white/60">
                I made this track on an AI music platform and have the right to use it.
                I understand original human-made music must be submitted for review instead.
              </span>
            </label>

            {upError && <p className="text-xs text-rose-300">{upError}</p>}

            <button
              onClick={() => void handleUpload()}
              disabled={uploadBusy}
              className="w-full py-2.5 rounded-xl bg-fuchsia-500 text-white text-sm font-bold disabled:opacity-40 flex items-center justify-center gap-1.5"
            >
              {uploadBusy ? <Loader2 className="w-4 h-4 animate-spin" /> : <UploadCloud className="w-4 h-4" />}
              {isUploading ? "Uploading…" : upload.isPending ? "Saving…" : "Upload track"}
            </button>
          </div>

          {/* The user's previous uploads, re-selectable */}
          <div className="space-y-2">
            <div className="text-white/50 text-[11px] font-semibold uppercase tracking-wide px-1">
              Your uploads
            </div>
            {myUploads.isLoading && (
              <div className="py-6 text-center text-white/40 text-sm">Loading…</div>
            )}
            {!myUploads.isLoading && myTracks.length === 0 && (
              <div className="py-6 text-center text-white/30 text-sm">Nothing uploaded yet.</div>
            )}
            {myTracks.map((t) => {
              const isSelected = selectedTrackId === t.id;
              const isPlaying = previewId === t.id;
              return (
                <div
                  key={t.id}
                  className={cn(
                    "flex items-center gap-3 rounded-2xl border px-3 py-2.5 transition-all",
                    isSelected ? "border-white/60 bg-white/15" : "border-white/10 bg-white/5",
                  )}
                >
                  <button
                    onClick={() => togglePreview(t)}
                    className="w-10 h-10 rounded-full bg-white/10 border border-white/15 flex items-center justify-center text-white shrink-0"
                    aria-label={isPlaying ? "Pause preview" : "Play preview"}
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                  </button>
                  <button onClick={() => onGenerated(t)} className="flex-1 min-w-0 text-left">
                    <div className="text-sm font-semibold text-white truncate">{t.title}</div>
                    <div className="text-[11px] text-white/40 truncate capitalize">{t.mood}</div>
                  </button>
                  <button
                    onClick={() => (isSelected ? choose(null) : onGenerated(t))}
                    className={cn(
                      "w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-all",
                      isSelected ? "bg-white text-black" : "bg-white/10 text-white/60 border border-white/15",
                    )}
                    aria-label={isSelected ? "Remove track" : "Use track"}
                  >
                    <Check className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Original tab — human-made music submitted for staff review (adult-only) */}
      {tab === "original" && canUpload && (
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
          {/* What this is */}
          <div className="flex items-start gap-2.5 rounded-2xl border border-amber-400/25 bg-amber-500/10 px-3 py-2.5">
            <ShieldCheck className="w-4 h-4 text-amber-300 shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed text-amber-100/80">
              Made your own original music? Submit it here with proof of ownership.
              A team member reviews every submission — your track stays completely
              private and can't be used in posts until it's approved.
            </p>
          </div>

          <div className="rounded-2xl border border-white/10 bg-white/5 p-3 space-y-3">
            {/* Audio file */}
            <div className="space-y-1.5">
              <label className="text-white/50 text-[11px] font-semibold uppercase tracking-wide">
                Audio file
              </label>
              <input
                ref={origFileRef}
                type="file"
                accept="audio/*"
                disabled={origBusy}
                onChange={(e) => { setOrigFile(e.target.files?.[0] ?? null); setOrigError(null); setOrigDone(false); }}
                className="w-full text-sm text-white/80 file:mr-3 file:rounded-lg file:border-0 file:bg-white/10 file:px-3 file:py-1.5 file:text-white file:text-xs file:font-semibold"
              />
              <p className="text-[11px] text-white/30">MP3, M4A, AAC, WAV, or OGG · up to 25&nbsp;MB and 6&nbsp;minutes.</p>
            </div>

            {/* Title */}
            <div className="space-y-1.5">
              <label className="text-white/50 text-[11px] font-semibold uppercase tracking-wide">Title</label>
              <input
                value={origTitle}
                maxLength={120}
                onChange={(e) => { setOrigTitle(e.target.value); setOrigDone(false); }}
                placeholder="e.g. Sunrise Anthem"
                className="w-full rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-white/30"
              />
            </div>

            {/* Proof of ownership (optional image) */}
            <div className="space-y-1.5">
              <label className="text-white/50 text-[11px] font-semibold uppercase tracking-wide">
                Proof of ownership <span className="text-white/30 normal-case">(optional)</span>
              </label>
              <input
                ref={origCertRef}
                type="file"
                accept="image/*"
                disabled={origBusy}
                onChange={(e) => { setOrigCert(e.target.files?.[0] ?? null); setOrigError(null); setOrigDone(false); }}
                className="w-full text-sm text-white/80 file:mr-3 file:rounded-lg file:border-0 file:bg-white/10 file:px-3 file:py-1.5 file:text-white file:text-xs file:font-semibold"
              />
              <p className="text-[11px] text-white/30">A screenshot or photo of a copyright certificate, distribution receipt, or similar. Only staff can see it.</p>
            </div>

            {/* Signed name */}
            <div className="space-y-1.5">
              <label className="text-white/50 text-[11px] font-semibold uppercase tracking-wide">Your full name</label>
              <input
                value={origSignedName}
                maxLength={120}
                onChange={(e) => { setOrigSignedName(e.target.value); setOrigDone(false); }}
                placeholder="Type your name to sign"
                className="w-full rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-white/30"
              />
            </div>

            {/* Attestation */}
            <label className="flex items-start gap-2.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={origAttested}
                onChange={(e) => { setOrigAttested(e.target.checked); setOrigDone(false); }}
                className="mt-0.5 h-4 w-4 shrink-0 accent-amber-400"
              />
              <span className="text-[11px] leading-relaxed text-white/60">
                I created this music myself and own all rights to it, or I have written
                permission to use it. I understand it will be reviewed by staff before
                it can be used, and that false claims may cost me access.
              </span>
            </label>

            {origError && <p className="text-xs text-rose-300">{origError}</p>}
            {origDone && (
              <p className="text-xs text-emerald-300">
                Submitted for review. We'll let you know once the team has taken a look.
              </p>
            )}

            <button
              onClick={() => void handleSubmitOriginal()}
              disabled={origBusy}
              className="w-full py-2.5 rounded-xl bg-amber-400 text-black text-sm font-bold disabled:opacity-40 flex items-center justify-center gap-1.5"
            >
              {origBusy ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
              {origAudioUpload.isUploading || origCertUpload.isUploading
                ? "Uploading…"
                : submitRequest.isPending
                  ? "Submitting…"
                  : "Submit for review"}
            </button>
          </div>

          {/* The user's own submissions and their status */}
          <div className="space-y-2">
            <div className="text-white/50 text-[11px] font-semibold uppercase tracking-wide px-1">
              Your submissions
            </div>
            {myRequestsQuery.isLoading && (
              <div className="py-6 text-center text-white/40 text-sm">Loading…</div>
            )}
            {!myRequestsQuery.isLoading && myRequests.length === 0 && (
              <div className="py-6 text-center text-white/30 text-sm">No submissions yet.</div>
            )}
            {myRequests.map((r) => {
              const approvedTrack =
                r.status === "approved" && r.promotedTrackId != null
                  ? myTracksById.get(r.promotedTrackId) ?? null
                  : null;
              const isSelected = approvedTrack != null && selectedTrackId === approvedTrack.id;
              const isPlaying = approvedTrack != null && previewId === approvedTrack.id;
              return (
                <div
                  key={r.id}
                  className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 px-3 py-2.5"
                >
                  {approvedTrack && (
                    <button
                      onClick={() => togglePreview(approvedTrack)}
                      className="w-10 h-10 rounded-full bg-white/10 border border-white/15 flex items-center justify-center text-white shrink-0"
                      aria-label={isPlaying ? "Pause preview" : "Play preview"}
                    >
                      {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                    </button>
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-semibold text-white truncate">{r.title}</div>
                    {r.reviewReason && (
                      <div className="text-[11px] text-white/40 truncate">{r.reviewReason}</div>
                    )}
                  </div>
                  {approvedTrack ? (
                    <button
                      onClick={() => (isSelected ? choose(null) : onGenerated(approvedTrack))}
                      className={cn(
                        "px-3 h-8 rounded-full flex items-center gap-1.5 shrink-0 text-xs font-semibold transition-all",
                        isSelected
                          ? "bg-white text-black"
                          : "bg-emerald-500/20 text-emerald-200 border border-emerald-400/30",
                      )}
                      aria-label={isSelected ? "Remove track" : "Use track"}
                    >
                      <Check className="w-3.5 h-3.5" />
                      {isSelected ? "Added" : "Use"}
                    </button>
                  ) : (
                    <span
                      className={cn(
                        "px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide shrink-0",
                        r.status === "approved"
                          ? "bg-emerald-500/20 text-emerald-300"
                          : r.status === "rejected"
                            ? "bg-rose-500/20 text-rose-300"
                            : "bg-amber-500/20 text-amber-300",
                      )}
                    >
                      {r.status === "approved" ? "Approved" : r.status === "rejected" ? "Not approved" : "In review"}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Fit-to-length + actions */}
      <div className="border-t border-white/10 p-4 space-y-3" style={{ paddingBottom: "calc(1rem + env(safe-area-inset-bottom))" }}>
        <div className="flex items-center gap-2 text-white/50 text-[11px] font-semibold uppercase tracking-wide">
          <Volume2 className="w-3.5 h-3.5" /> Fit to length
        </div>
        <div className="grid grid-cols-4 gap-1.5">
          {FIT_MODES.map((f) => (
            <button
              key={f.id}
              onClick={() => onFitModeChange(f.id)}
              title={f.hint}
              className={cn(
                "py-2 rounded-xl text-xs font-semibold transition-all border",
                fitMode === f.id
                  ? "bg-white text-black border-white"
                  : "bg-white/5 text-white/60 border-white/10 hover:text-white",
              )}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Balance the creator's own content audio against the platform track.
            Only shown when a soundtrack is selected (nothing to balance otherwise). */}
        {selectedTrackId != null && (
          <div className="space-y-2.5">
            <div className="flex items-center gap-2 text-white/50 text-[11px] font-semibold uppercase tracking-wide">
              <SlidersHorizontal className="w-3.5 h-3.5" /> Mix levels
            </div>
            <div className={cn("rounded-2xl border border-white/10 bg-white/5 px-3 py-2.5", muteVideoAudio && "opacity-40")}>
              <div className="mb-1.5 flex items-center justify-between">
                <span className="flex items-center gap-2 text-sm font-semibold text-white">
                  <Film className="h-4 w-4 text-white/70" /> Content volume
                </span>
                <span className="text-xs tabular-nums text-white/50">{Math.round(contentVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                step={1}
                value={Math.round(contentVolume * 100)}
                disabled={muteVideoAudio}
                onChange={(e) => onContentVolumeChange(Number(e.target.value) / 100)}
                className="w-full accent-fuchsia-500 disabled:cursor-not-allowed"
                aria-label="Content volume"
              />
              <p className="mt-1 text-[11px] text-white/30">
                {muteVideoAudio ? "Muted — using only the soundtrack" : "Your video / filmed audio"}
              </p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/5 px-3 py-2.5">
              <div className="mb-1.5 flex items-center justify-between">
                <span className="flex items-center gap-2 text-sm font-semibold text-white">
                  <Music className="h-4 w-4 text-white/70" /> Music volume
                </span>
                <span className="text-xs tabular-nums text-white/50">{Math.round(musicVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                step={1}
                value={Math.round(musicVolume * 100)}
                onChange={(e) => onMusicVolumeChange(Number(e.target.value) / 100)}
                className="w-full accent-fuchsia-500"
                aria-label="Music volume"
              />
              <p className="mt-1 text-[11px] text-white/30">The background track added on platform</p>
            </div>
          </div>
        )}

        {/* Replace the filmed clip's own audio with only the soundtrack. */}
        <button
          onClick={() => onMuteVideoAudioChange(!muteVideoAudio)}
          aria-pressed={muteVideoAudio}
          className={cn(
            "flex w-full items-center justify-between rounded-2xl border px-3 py-2.5 text-left transition-all",
            muteVideoAudio ? "border-white/60 bg-white/15" : "border-white/10 bg-white/5",
          )}
        >
          <div className="flex min-w-0 items-center gap-2.5">
            <VolumeX className="w-4 h-4 shrink-0 text-white/70" />
            <div className="min-w-0">
              <div className="text-sm font-semibold text-white">Replace original sound</div>
              <div className="text-[11px] text-white/40">{muteVideoAudio ? "On — posts the platform track only, not your clip's own sound" : "Off — your clip's original sound will play (keep off only if you own it)"}</div>
            </div>
          </div>
          <span
            className={cn(
              "relative h-6 w-11 shrink-0 rounded-full transition-colors",
              muteVideoAudio ? "bg-emerald-400" : "bg-white/20",
            )}
          >
            <span
              className={cn(
                "absolute top-0.5 h-5 w-5 rounded-full bg-white transition-transform",
                muteVideoAudio ? "translate-x-[22px]" : "translate-x-0.5",
              )}
            />
          </span>
        </button>

        <div className="flex gap-2 pt-1">
          {selectedTrackId != null && (
            <button
              onClick={() => choose(null)}
              className="px-4 py-2.5 rounded-2xl bg-white/10 border border-white/15 text-white text-sm font-semibold"
            >
              Clear
            </button>
          )}
          <button
            onClick={onClose}
            className="flex-1 py-2.5 rounded-2xl bg-white text-black text-sm font-bold"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
