// ── Neon Patriot — offscreen WebGL2 flag-on-face renderer ───────────────────────
// Renders a US flag SHRINK-WRAPPED over the tracked face into a TRANSPARENT
// 1280x720 offscreen canvas. The 2D compositor then blits this with
// ctx.drawImage(), so the effect bakes into photo/video export with no changes to
// the capture pipeline.
//
// Pipeline: 468 face landmarks → screen-space mesh (object-fit:cover + mirror) →
// REAL per-vertex normals computed from the 3D landmark geometry → flag texture
// sampled by screen-bbox UVs (with stretch) → glossy plastic specular + sheen +
// contour shading + a baked Fresnel NEON RIM so the flag reads as a taut, glowing
// plastic wrap clinging to the face (not a flat sticker).

import { FACEMESH_TRIANGULATION } from "./faceMeshTriangulation";
import type { NeonPatriotParams, NPLevel3 } from "./neonPatriot";

const NV = 468;                 // landmarks used for the mesh (iris pts 468+ ignored)
const W = 1280, H = 720;        // matches the studio bake buffer
const FLIP_FLAG_Y = false;      // canton sits at face-top; flip if it renders inverted
const Z_RELIEF = 0.7;           // how strongly landmark depth bulges the wrap normals

// MediaPipe FACEMESH_FACE_OVAL landmark ring — these silhouette vertices get a low
// edge weight so the flag body fades out cleanly at the face boundary (no hard
// cutout); the neon rim still lights the silhouette via Fresnel.
const FACE_OVAL = [
  10,338,297,332,284,251,389,356,454,323,361,288,397,365,379,378,400,377,
  152,148,176,149,150,136,172,58,132,93,234,127,162,21,54,103,67,109,
];

// ── Procedural US flag texture (recognizable, crisp, no asset dependency) ───────
function makeFlagCanvas(): HTMLCanvasElement {
  const fw = 950, fh = 500;                         // ~1.9:1 official ratio
  const cv = document.createElement("canvas");
  cv.width = fw; cv.height = fh;
  const g = cv.getContext("2d")!;
  // 13 stripes (7 red / 6 white)
  const sh = fh / 13;
  for (let i = 0; i < 13; i++) {
    g.fillStyle = i % 2 === 0 ? "#B22234" : "#FFFFFF";
    g.fillRect(0, i * sh, fw, sh + 1);
  }
  // Union (canton): 7 stripes tall, 0.4 wide
  const uw = fw * 0.4, uh = sh * 7;
  g.fillStyle = "#3C3B6E";
  g.fillRect(0, 0, uw, uh);
  // 50 stars — 9 rows alternating 6 / 5, evenly inset within the union.
  g.fillStyle = "#FFFFFF";
  const colW = uw / 6, rowH = uh / 9;
  const starR = Math.min(colW, rowH) * 0.32;
  for (let row = 0; row < 9; row++) {
    const even = row % 2 === 0;          // even rows: 6 stars, odd rows: 5 (offset)
    const cols = even ? 6 : 5;
    const cy = rowH * (row + 0.5);
    for (let c = 0; c < cols; c++) {
      const cx = colW * (c + (even ? 0.5 : 1.0));
      star(g, cx, cy, starR);
    }
  }
  return cv;
}
function star(g: CanvasRenderingContext2D, cx: number, cy: number, r: number) {
  g.beginPath();
  for (let i = 0; i < 10; i++) {
    const ang = -Math.PI / 2 + (i * Math.PI) / 5;
    const rad = i % 2 === 0 ? r : r * 0.42;
    const x = cx + Math.cos(ang) * rad, y = cy + Math.sin(ang) * rad;
    i === 0 ? g.moveTo(x, y) : g.lineTo(x, y);
  }
  g.closePath();
  g.fill();
}

const VERT = `#version 300 es
precision highp float;
in vec2 aPos;     // clip space
in vec2 aUV;      // screen-bbox flag uv
in vec3 aNormal;  // real per-vertex face normal (view space, +z toward camera)
in float aEdge;   // 1 interior, 0 silhouette
uniform vec2 uStretch;
out vec2 vUV;
out vec3 vN;
out float vEdge;
void main() {
  vUV = (aUV - 0.5) / uStretch + 0.5;
  vN = aNormal;
  vEdge = aEdge;
  gl_Position = vec4(aPos, 0.0, 1.0);
}`;

// Glossy plastic-wrap shading from the REAL face normal, plus a baked neon Fresnel
// rim so the glow survives even where the body alpha falls off at the silhouette.
const FRAG = `#version 300 es
precision highp float;
in vec2 vUV;
in vec3 vN;
in float vEdge;
uniform sampler2D uFlag;
uniform float uAlpha;   // body translucency * intensity
uniform float uSpec;    // glossy specular strength * intensity
uniform float uGlow;    // neon rim strength * intensity
out vec4 frag;
void main() {
  vec3 flag = texture(uFlag, clamp(vUV, 0.0, 1.0)).rgb;
  vec3 N = normalize(vN);
  vec3 V = vec3(0.0, 0.0, 1.0);
  vec3 L = normalize(vec3(-0.35, 0.42, 0.86));
  vec3 Hf = normalize(L + V);
  float ndl = clamp(dot(N, L), 0.0, 1.0);
  float ndh = clamp(dot(N, Hf), 0.0, 1.0);
  float ndv = clamp(dot(N, V), 0.0, 1.0);

  // Plastic sheen: a tight mirror hotspot + a broad satin lobe.
  float spec  = pow(ndh, 70.0) * uSpec;
  float sheen = pow(ndh, 9.0) * 0.22 * uSpec;
  // Contour shading driven by the real geometry → the flag visibly clings to the
  // nose / cheeks / brow instead of sitting flat.
  float shade = 0.46 + 0.6 * ndl;
  vec3 bodyCol = clamp(flag * shade + spec + sheen, 0.0, 1.0);
  float baseA = uAlpha * smoothstep(0.0, 0.42, vEdge);

  // Neon Fresnel rim — bright on the silhouette AND every steep contour edge, in
  // the flag's own colour (red glows red, blue glows blue, white blooms white).
  float fres = pow(1.0 - ndv, 2.3);
  float rimA = clamp(fres * uGlow, 0.0, 1.0);
  vec3 rimCol = clamp(flag * 1.4 + 0.22, 0.0, 1.0);

  // Composite the rim OVER the body so the output is VALID premultiplied alpha
  // (rgb <= a). This bakes cleanly through ctx.drawImage to photo/video; the extra
  // additive "neon" punch is added by the 2D bloom pass, not by overdriving rgb>a.
  vec3 pBody = bodyCol * baseA;
  vec3 pRim = rimCol * rimA;
  vec3 outRGB = pRim + pBody * (1.0 - rimA);
  float outA = rimA + baseA * (1.0 - rimA);
  frag = vec4(outRGB, outA);
}`;

const STRETCH: Record<NeonPatriotParams["stretch"], [number, number]> = {
  subtle: [0.84, 0.84], med: [1.0, 1.0], extreme: [1.22, 1.32],
};
const TRANSLUCENCY: Record<NeonPatriotParams["translucency"], number> = {
  low: 0.9, med: 0.66, high: 0.42,   // low = most opaque
};
// Baked neon rim strength per glow level (in addition to the 2D bloom pass).
const GLOW: Record<NPLevel3, number> = { low: 0.5, med: 0.9, high: 1.35 };

interface GLState {
  cv: HTMLCanvasElement; gl: WebGL2RenderingContext; prog: WebGLProgram;
  vao: WebGLVertexArrayObject; posBuf: WebGLBuffer; uvBuf: WebGLBuffer; nrmBuf: WebGLBuffer;
  idxCount: number; flagTex: WebGLTexture;
  loc: { uStretch: WebGLUniformLocation; uFlag: WebGLUniformLocation; uAlpha: WebGLUniformLocation; uSpec: WebGLUniformLocation; uGlow: WebGLUniformLocation };
  pos: Float32Array; uv: Float32Array; nrm: Float32Array; p3: Float32Array;
}

let S: GLState | null = null;
let failed = false;

function compile(gl: WebGL2RenderingContext, type: number, src: string): WebGLShader {
  const sh = gl.createShader(type)!;
  gl.shaderSource(sh, src); gl.compileShader(sh);
  if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS))
    throw new Error("[NeonPatriot] shader: " + gl.getShaderInfoLog(sh));
  return sh;
}

function init(): GLState | null {
  if (failed) return null;
  try {
    const cv = document.createElement("canvas");
    cv.width = W; cv.height = H;
    const gl = cv.getContext("webgl2", {
      alpha: true, premultipliedAlpha: true, antialias: true,
      preserveDrawingBuffer: false, depth: false,
    });
    if (!gl) { failed = true; return null; }
    cv.addEventListener("webglcontextlost", (e) => { e.preventDefault(); S = null; }, false);

    const prog = gl.createProgram()!;
    gl.attachShader(prog, compile(gl, gl.VERTEX_SHADER, VERT));
    gl.attachShader(prog, compile(gl, gl.FRAGMENT_SHADER, FRAG));
    gl.bindAttribLocation(prog, 0, "aPos");
    gl.bindAttribLocation(prog, 1, "aUV");
    gl.bindAttribLocation(prog, 2, "aNormal");
    gl.bindAttribLocation(prog, 3, "aEdge");
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS))
      throw new Error("[NeonPatriot] link: " + gl.getProgramInfoLog(prog));

    const vao = gl.createVertexArray()!;
    gl.bindVertexArray(vao);

    const pos = new Float32Array(NV * 2);
    const uv = new Float32Array(NV * 2);
    const nrm = new Float32Array(NV * 3);
    const p3 = new Float32Array(NV * 3);
    const edge = new Float32Array(NV).fill(1);
    for (const i of FACE_OVAL) if (i < NV) edge[i] = 0;

    const posBuf = gl.createBuffer()!;
    gl.bindBuffer(gl.ARRAY_BUFFER, posBuf);
    gl.bufferData(gl.ARRAY_BUFFER, pos.byteLength, gl.DYNAMIC_DRAW);
    gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);

    const uvBuf = gl.createBuffer()!;
    gl.bindBuffer(gl.ARRAY_BUFFER, uvBuf);
    gl.bufferData(gl.ARRAY_BUFFER, uv.byteLength, gl.DYNAMIC_DRAW);
    gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 2, gl.FLOAT, false, 0, 0);

    const nrmBuf = gl.createBuffer()!;
    gl.bindBuffer(gl.ARRAY_BUFFER, nrmBuf);
    gl.bufferData(gl.ARRAY_BUFFER, nrm.byteLength, gl.DYNAMIC_DRAW);
    gl.enableVertexAttribArray(2); gl.vertexAttribPointer(2, 3, gl.FLOAT, false, 0, 0);

    const edgeBuf = gl.createBuffer()!;
    gl.bindBuffer(gl.ARRAY_BUFFER, edgeBuf);
    gl.bufferData(gl.ARRAY_BUFFER, edge, gl.STATIC_DRAW);
    gl.enableVertexAttribArray(3); gl.vertexAttribPointer(3, 1, gl.FLOAT, false, 0, 0);

    const idxBuf = gl.createBuffer()!;
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, idxBuf);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, FACEMESH_TRIANGULATION, gl.STATIC_DRAW);

    const flagTex = gl.createTexture()!;
    gl.bindTexture(gl.TEXTURE_2D, flagTex);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, FLIP_FLAG_Y);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, makeFlagCanvas());
    gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

    gl.bindVertexArray(null);

    const loc = {
      uStretch: gl.getUniformLocation(prog, "uStretch")!,
      uFlag: gl.getUniformLocation(prog, "uFlag")!,
      uAlpha: gl.getUniformLocation(prog, "uAlpha")!,
      uSpec: gl.getUniformLocation(prog, "uSpec")!,
      uGlow: gl.getUniformLocation(prog, "uGlow")!,
    };
    S = { cv, gl, prog, vao, posBuf, uvBuf, nrmBuf, idxCount: FACEMESH_TRIANGULATION.length, flagTex, loc, pos, uv, nrm, p3 };
    return S;
  } catch (err) {
    console.error(err);
    failed = true;
    return null;
  }
}

// Accumulate smooth per-vertex normals from the 3D mesh so the flag's shading clings
// to the real face surface. Normals are forced to face the camera (+z) so the result
// is robust to the selfie mirror flipping triangle winding.
function computeNormals(p3: Float32Array, nrm: Float32Array) {
  nrm.fill(0);
  const T = FACEMESH_TRIANGULATION;
  for (let t = 0; t < T.length; t += 3) {
    const a = T[t], b = T[t + 1], c = T[t + 2];
    if (a >= NV || b >= NV || c >= NV) continue;
    const ax = p3[a * 3], ay = p3[a * 3 + 1], az = p3[a * 3 + 2];
    const e1x = p3[b * 3] - ax, e1y = p3[b * 3 + 1] - ay, e1z = p3[b * 3 + 2] - az;
    const e2x = p3[c * 3] - ax, e2y = p3[c * 3 + 1] - ay, e2z = p3[c * 3 + 2] - az;
    let nx = e1y * e2z - e1z * e2y;
    let ny = e1z * e2x - e1x * e2z;
    let nz = e1x * e2y - e1y * e2x;
    if (nz < 0) { nx = -nx; ny = -ny; nz = -nz; }   // toward camera
    nrm[a * 3] += nx; nrm[a * 3 + 1] += ny; nrm[a * 3 + 2] += nz;
    nrm[b * 3] += nx; nrm[b * 3 + 1] += ny; nrm[b * 3 + 2] += nz;
    nrm[c * 3] += nx; nrm[c * 3 + 1] += ny; nrm[c * 3 + 2] += nz;
  }
  for (let i = 0; i < NV; i++) {
    let nx = nrm[i * 3], ny = nrm[i * 3 + 1], nz = nrm[i * 3 + 2];
    const len = Math.hypot(nx, ny, nz) || 1;
    nx /= len; ny /= len; nz /= len;
    if (nz < 0) { nx = -nx; ny = -ny; nz = -nz; }
    nrm[i * 3] = nx; nrm[i * 3 + 1] = ny; nrm[i * 3 + 2] = nz;
  }
}

// Render the flag mesh for the given smoothed landmarks; returns the offscreen
// canvas to blit, or null if WebGL2 is unavailable / there is nothing to draw.
export function renderFlagMesh(
  landmarks: Float32Array, count: number,
  vw: number, vh: number, mirror: boolean, params: NeonPatriotParams,
): HTMLCanvasElement | null {
  if (count < NV) return null;
  const s = S ?? init();
  if (!s) return null;
  const { gl, pos, uv, nrm, p3 } = s;

  // 1) Project landmarks → screen px (object-fit:cover + mirror), capturing bbox.
  // Inlined to match drawVideoCover EXACTLY (kept here to avoid a circular import).
  const scale = Math.max(W / vw, H / vh);
  const sw = vw * scale, sh = vh * scale;
  const dx = (W - sw) / 2, dy = (H - sh) / 2;
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (let i = 0; i < NV; i++) {
    let x = dx + landmarks[i * 3] * sw;
    if (mirror) x = W - x;
    const y = dy + landmarks[i * 3 + 1] * sh;
    // 3D position in canvas-pixel space; landmark z (image-normalized) bulges the
    // surface toward the camera so the wrap has real relief for the normals.
    p3[i * 3] = x; p3[i * 3 + 1] = y; p3[i * 3 + 2] = -landmarks[i * 3 + 2] * W * Z_RELIEF;
    if (x < minX) minX = x; if (x > maxX) maxX = x;
    if (y < minY) minY = y; if (y > maxY) maxY = y;
  }
  const bw = Math.max(1, maxX - minX), bh = Math.max(1, maxY - minY);
  for (let i = 0; i < NV; i++) {
    const x = p3[i * 3], y = p3[i * 3 + 1];
    pos[i * 2] = (x / W) * 2 - 1;
    pos[i * 2 + 1] = 1 - (y / H) * 2;
    uv[i * 2] = (x - minX) / bw;
    uv[i * 2 + 1] = (y - minY) / bh;
  }
  computeNormals(p3, nrm);

  // 2) Upload + draw into the transparent offscreen target.
  const intensity = Math.max(0, Math.min(1, params.intensity / 100));
  gl.bindVertexArray(s.vao);
  gl.bindBuffer(gl.ARRAY_BUFFER, s.posBuf); gl.bufferSubData(gl.ARRAY_BUFFER, 0, pos);
  gl.bindBuffer(gl.ARRAY_BUFFER, s.uvBuf); gl.bufferSubData(gl.ARRAY_BUFFER, 0, uv);
  gl.bindBuffer(gl.ARRAY_BUFFER, s.nrmBuf); gl.bufferSubData(gl.ARRAY_BUFFER, 0, nrm);

  gl.viewport(0, 0, W, H);
  gl.clearColor(0, 0, 0, 0);
  gl.clear(gl.COLOR_BUFFER_BIT);
  gl.enable(gl.BLEND);
  gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);   // premultiplied source-over

  gl.useProgram(s.prog);
  const [stx, sty] = STRETCH[params.stretch];
  gl.uniform2f(s.loc.uStretch, stx, sty);
  gl.uniform1f(s.loc.uAlpha, TRANSLUCENCY[params.translucency] * intensity);
  gl.uniform1f(s.loc.uSpec, 0.95 * intensity);
  gl.uniform1f(s.loc.uGlow, GLOW[params.glow] * intensity);
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, s.flagTex);
  gl.uniform1i(s.loc.uFlag, 0);

  gl.drawElements(gl.TRIANGLES, s.idxCount, gl.UNSIGNED_SHORT, 0);
  gl.bindVertexArray(null);
  return s.cv;
}
