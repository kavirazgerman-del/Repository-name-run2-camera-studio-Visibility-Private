// ── Caricature — instant on-device "funhouse" whole-body exaggeration ────────────
// Today's AI Filter Challenge. A BASE-SWAP (not an overlay): CameraStudio's
// compositeFrame calls renderCaricatureBase INSTEAD of drawVideoCover so the warp
// bakes into photo + video capture and the CSS colour grade (set via ctx.filter
// before the base draw) still applies.
//
// The look is a vertical funhouse remap that MAGNIFIES the band around the head and
// COMPRESSES the body below — a big-head / small-body caricature of the WHOLE figure,
// plus a matching horizontal head bulge. The magnify band is centred on the detected
// head when the shared face tracker has a face (optional), otherwise on a sensible
// default — so it works even with no face lock. Intensity 0 = a pixel-perfect no-op
// (identity remap), matching every other Studio filter.

import type { NeonPatriotTracking } from "./neonPatriot";

function clamp01(x: number): number { return x < 0 ? 0 : x > 1 ? 1 : x; }
function smoothstep(a: number, b: number, x: number): number {
  if (a === b) return x < a ? 0 : 1;
  const t = clamp01((x - a) / (b - a));
  return t * t * (3 - 2 * t);
}

interface Cover { sw: number; sh: number; ox: number; oy: number; }
function coverParams(vw: number, vh: number, cw: number, ch: number): Cover {
  const scale = Math.max(cw / vw, ch / vh);
  const sw = vw * scale, sh = vh * scale;
  return { sw, sh, ox: (cw - sw) / 2, oy: (ch - sh) / 2 };
}

// Plain cover draw (mirrors drawVideoCover in CameraStudio — kept local so this
// module stays self-contained).
function drawCover(ctx: CanvasRenderingContext2D, video: HTMLVideoElement, cw: number, ch: number, mirror: boolean) {
  const vw = video.videoWidth || cw, vh = video.videoHeight || ch;
  const { sw, sh, ox, oy } = coverParams(vw, vh, cw, ch);
  ctx.save();
  ctx.beginPath(); ctx.rect(0, 0, cw, ch); ctx.clip();
  if (mirror) { ctx.translate(cw, 0); ctx.scale(-1, 1); }
  ctx.drawImage(video, ox, oy, sw, sh);
  ctx.restore();
}

export interface CaricatureBand { headCenterU: number; chinU: number; centerXU: number; }

// Derive the head band (in canvas-vertical "u" space, 0..1) + horizontal centre from
// the face landmarks, mapped through the SAME cover transform the video uses. Returns
// null when no face is present so the caller falls back to defaults.
export function caricatureBandFromTracking(
  tracking: NeonPatriotTracking | null, vw: number, vh: number, cw: number, ch: number,
): CaricatureBand | null {
  const lm = tracking?.landmarks; const n = tracking?.count ?? 0;
  if (!lm || n <= 0) return null;
  let minY = 1, maxY = 0, sumX = 0, cnt = 0;
  for (let i = 0; i < n; i++) {
    const x = lm[i * 3], y = lm[i * 3 + 1];
    if (y < minY) minY = y;
    if (y > maxY) maxY = y;
    sumX += x; cnt++;
  }
  if (cnt === 0) return null;
  const meanX = sumX / cnt;
  const { sw, sh, ox, oy } = coverParams(vw, vh, cw, ch);
  const topU = (oy + minY * sh) / ch;
  const botU = (oy + maxY * sh) / ch;
  const cxU = (ox + meanX * sw) / cw;
  const headCenterU = Math.min(0.6, Math.max(0.05, (topU + botU) / 2));
  return {
    headCenterU,
    chinU: Math.min(0.85, Math.max(headCenterU + 0.04, botU)),
    centerXU: Math.min(0.85, Math.max(0.15, cxU)),
  };
}

// Render the caricature directly onto the bake context. Draws the plain cover video
// first (so no warp seam ever reveals a gap), then the magnify/compress strips on top.
export function renderCaricatureBase(
  ctx: CanvasRenderingContext2D, video: HTMLVideoElement,
  cw: number, ch: number, mirror: boolean,
  tracking: NeonPatriotTracking | null, vw: number, vh: number, intensity: number,
) {
  drawCover(ctx, video, cw, ch, mirror);
  const t = clamp01(intensity);
  if (t <= 0.001) return; // identity — leave the plain frame untouched

  const band = caricatureBandFromTracking(tracking, vw, vh, cw, ch);
  const headCenterU = band?.headCenterU ?? 0.26;
  const chinU = band?.chinU ?? 0.44;
  const cxU = band?.centerXU ?? 0.5;
  const headSigma = Math.max(0.10, chinU * 0.55); // spread of the head magnify bell

  const A = 1.55 * t; // head magnify gain
  const B = 0.50 * t; // body compress depth
  const N = 84;
  const m = new Float32Array(N);
  let total = 0;
  for (let i = 0; i < N; i++) {
    const u = (i + 0.5) / N;
    const head = Math.exp(-Math.pow((u - headCenterU) / headSigma, 2));
    const body = smoothstep(chinU + 0.02, chinU + 0.22, u);
    let mm = 1 + A * head - B * body;
    if (mm < 0.18) mm = 0.18;
    m[i] = mm; total += mm;
  }
  // Cumulative (normalised) → guarantees a monotonic remap that fills 0..1 exactly.
  const v = new Float32Array(N + 1);
  for (let i = 0; i < N; i++) v[i + 1] = v[i] + m[i] / total;

  const { sw, sh, ox, oy } = coverParams(vw, vh, cw, ch);
  const invY = (u: number) => { const ny = (u * ch - oy) / sh; return ny < 0 ? 0 : ny > 1 ? 1 : ny; };
  const cx = cxU * cw;

  ctx.save();
  ctx.beginPath(); ctx.rect(0, 0, cw, ch); ctx.clip();
  if (mirror) { ctx.translate(cw, 0); ctx.scale(-1, 1); }
  ctx.imageSmoothingEnabled = true;
  for (let i = 0; i < N; i++) {
    const ny0 = invY(i / N), ny1 = invY((i + 1) / N);
    const sy = ny0 * vh;
    const sHpx = Math.max(0.5, (ny1 - ny0) * vh);
    const dy = v[i] * ch;
    const dH = Math.max(0.5, (v[i + 1] - v[i]) * ch);
    const hs = 1 + (m[i] - 1) * 0.45;     // horizontal bulge tracks the vertical magnify
    const dW = cw * hs;
    const dx = cx - dW / 2;
    ctx.drawImage(video, 0, sy, vw, sHpx, dx, dy, dW, dH);
  }
  ctx.restore();
}
