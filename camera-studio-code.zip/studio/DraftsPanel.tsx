import React from "react";
import { X, Trash2, Play, Film, Images, Image as ImageIcon, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { listDrafts, deleteDraft, type DraftMeta } from "./drafts";

const PANEL_BORDER = "1px solid rgba(120,160,255,.18)";

function relativeTime(ts: number): string {
  const s = Math.max(0, Math.floor((Date.now() - ts) / 1000));
  if (s < 45) return "just now";
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 7) return `${d}d ago`;
  return new Date(ts).toLocaleDateString();
}

function fmtSize(bytes: number): string {
  if (bytes <= 0) return "";
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function fmtDur(sec: number): string {
  if (!sec || sec <= 0) return "";
  const s = Math.round(sec);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

function KindIcon({ kind }: { kind: string }) {
  if (kind === "slideshow") return <Images className="w-4 h-4 text-white/60" />;
  if (kind === "photo") return <ImageIcon className="w-4 h-4 text-white/60" />;
  return <Film className="w-4 h-4 text-white/60" />;
}

interface Props {
  onClose: () => void;
  onResume: (id: string) => void;
}

// Drafts list — saved-on-this-device posts-in-progress. Resume restores everything
// back into the studio; Delete frees the stored media (two-tap confirm).
export function DraftsPanel({ onClose, onResume }: Props) {
  const [drafts, setDrafts] = React.useState<DraftMeta[] | null>(null);
  const [confirmId, setConfirmId] = React.useState<string | null>(null);
  const [busyId, setBusyId] = React.useState<string | null>(null);

  const refresh = React.useCallback(async () => {
    try {
      setDrafts(await listDrafts());
    } catch {
      setDrafts([]);
      toast.error("Couldn't load your drafts.");
    }
  }, []);

  React.useEffect(() => { void refresh(); }, [refresh]);

  async function handleDelete(id: string) {
    setBusyId(id);
    try {
      await deleteDraft(id);
      setConfirmId(null);
      await refresh();
      toast.success("Draft deleted.");
    } catch {
      toast.error("Couldn't delete that draft.");
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div
      className="absolute inset-0 z-[80] flex items-center justify-center p-4"
      style={{ background: "rgba(4,7,14,.72)", backdropFilter: "blur(6px)" }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-[24px] p-4 flex flex-col max-h-[80vh]"
        style={{ background: "rgba(12,18,32,.97)", border: PANEL_BORDER }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-1">
          <div>
            <p className="font-bold text-base text-white">Your drafts</p>
            <p className="text-white/45 text-[11px]">Saved on this device</p>
          </div>
          <button
            onClick={onClose}
            aria-label="Close drafts"
            className="w-7 h-7 rounded-full flex items-center justify-center shrink-0"
            style={{ background: "rgba(255,255,255,.08)" }}
          >
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        <div className="mt-2 flex-1 overflow-y-auto -mx-1 px-1 space-y-2">
          {drafts === null && (
            <div className="py-10 flex items-center justify-center text-white/50">
              <Loader2 className="w-5 h-5 animate-spin" />
            </div>
          )}

          {drafts !== null && drafts.length === 0 && (
            <div className="py-10 text-center text-white/50 text-sm px-6">
              No saved drafts yet. Capture something, then tap{" "}
              <span className="text-white/80 font-medium">Save draft</span> to keep it for later.
            </div>
          )}

          {drafts?.map((d) => (
            <div
              key={d.id}
              className="flex items-center gap-3 p-2 rounded-2xl"
              style={{ background: "rgba(255,255,255,.05)", border: "1px solid rgba(255,255,255,.08)" }}
            >
              <div className="w-14 h-14 rounded-xl overflow-hidden bg-black/40 border border-white/10 flex items-center justify-center shrink-0">
                {d.thumb ? (
                  <img src={d.thumb} alt="" className="w-full h-full object-cover" />
                ) : (
                  <KindIcon kind={d.kind} />
                )}
              </div>

              <div className="min-w-0 flex-1">
                <p className="text-white text-sm font-semibold truncate">{d.label}</p>
                <p className="text-white/45 text-[11px] truncate capitalize">
                  {[d.kind, relativeTime(d.updatedAt), fmtDur(d.durationSec), fmtSize(d.sizeBytes)]
                    .filter(Boolean)
                    .join(" · ")}
                </p>
              </div>

              {confirmId === d.id ? (
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => handleDelete(d.id)}
                    disabled={busyId === d.id}
                    className="px-2.5 h-8 rounded-lg text-[11px] font-semibold text-white disabled:opacity-50"
                    style={{ background: "rgba(239,68,68,.85)" }}
                  >
                    {busyId === d.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : "Delete"}
                  </button>
                  <button
                    onClick={() => setConfirmId(null)}
                    disabled={busyId === d.id}
                    className="px-2.5 h-8 rounded-lg text-[11px] font-medium text-white/80"
                    style={{ background: "rgba(255,255,255,.08)" }}
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => onResume(d.id)}
                    className="flex items-center gap-1.5 px-3 h-8 rounded-lg text-[11px] font-bold"
                    style={{ background: "linear-gradient(135deg,#22C7F2,#B44CFF)", color: "#06101F" }}
                  >
                    <Play className="w-3.5 h-3.5" /> Resume
                  </button>
                  <button
                    onClick={() => setConfirmId(d.id)}
                    aria-label="Delete draft"
                    className="w-8 h-8 rounded-lg flex items-center justify-center text-white/70 hover:text-white"
                    style={{ background: "rgba(255,255,255,.06)" }}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
