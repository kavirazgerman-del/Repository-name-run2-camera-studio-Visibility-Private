// ── Neon Mood Caricature — public barrel ────────────────────────────────────────
// Single import surface for CameraStudio's integration: the async multi-face tracker,
// the optional person-on-black segmenter, the synchronous overlay renderer, and the
// shared params/types. The preview (NeonMoodPreview.tsx) imports the modules directly.

export { NeonMoodTracker } from "./tracker";
export { NeonMoodSegmenter } from "./segmentation";
export { renderNeonMood } from "./renderer";
export {
  DEFAULT_NEON_MOOD_PARAMS,
  NM_GLOW_LEVELS,
  MOOD_PALETTES,
  MOOD_IDS,
  type NeonMoodParams,
  type NMGlow,
  type NeonMoodId,
  type NeonMoodFace,
  type NeonMoodTracking,
} from "./types";
