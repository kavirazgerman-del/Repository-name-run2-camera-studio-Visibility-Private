// ── Neon Mood — selfie segmentation (auto black "neon studio" background) ───────
// Wraps MediaPipe ImageSegmenter (selfie_segmenter.tflite) on a throttled async
// timer and rasterizes the latest person mask into an offscreen canvas whose ALPHA
// = person confidence. The preview uses it (only at Glow = "high") to composite the
// subject onto pure black. Reuses the SAME vision wasm fileset as the face tracker.
//
// Robustness: this model's confidence-mask ordering/polarity isn't guaranteed, so we
// auto-detect orientation each frame (a selfie subject is centred → the centre must
// read as foreground; if it doesn't, we invert). If the asset/model fails to load,
// `failed` is set and getMaskCanvas() returns null so the preview cleanly falls back
// to the real background.

import { ImageSegmenter, FilesetResolver, type ImageSegmenterResult } from "@mediapipe/tasks-vision";

const DETECT_MS = 60; // ~16fps mask cadence (the rAF compositor stays at video fps)

export class NeonMoodSegmenter {
  ready = false;
  failed = false;

  private video: HTMLVideoElement;
  private seg: ImageSegmenter | null = null;
  private starting = false;
  private disposed = false;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private lastTs = 0;
  private maskCanvas: HTMLCanvasElement | null = null;
  private maskCtx: CanvasRenderingContext2D | null = null;
  private hasMask = false;
  private invert = false;
  private invertDecided = false;

  constructor(video: HTMLVideoElement) { this.video = video; }

  async start() {
    if (this.disposed || this.starting || this.seg) return;
    this.starting = true;
    try {
      const base = import.meta.env.BASE_URL || "/";
      const fileset = await FilesetResolver.forVisionTasks(`${base}mediapipe/wasm`);
      if (this.disposed) return;
      const make = (delegate: "GPU" | "CPU") => ImageSegmenter.createFromOptions(fileset, {
        baseOptions: { modelAssetPath: `${base}mediapipe/selfie_segmenter.tflite`, delegate },
        runningMode: "VIDEO",
        outputConfidenceMasks: true,
        outputCategoryMask: false,
      });
      try { this.seg = await make("GPU"); }
      catch { this.seg = await make("CPU"); }
      if (this.disposed) { this.seg?.close(); this.seg = null; return; }
      this.ready = true;
      this.loop();
    } catch (err) {
      this.failed = true;
      console.error("[NeonMood] segmenter init failed", err);
    } finally {
      this.starting = false;
    }
  }

  private loop = () => {
    if (this.disposed) return;
    this.detectOnce();
    this.timer = setTimeout(this.loop, DETECT_MS);
  };

  private detectOnce() {
    const v = this.video, seg = this.seg;
    if (!seg || !v || v.readyState < 2 || v.videoWidth === 0) return;
    let ts = performance.now();
    if (ts <= this.lastTs) ts = this.lastTs + 1;
    this.lastTs = ts;
    let res: ImageSegmenterResult;
    try { res = seg.segmentForVideo(v, ts); } catch { return; }
    try {
      const masks = res.confidenceMasks;
      const mask = masks && masks.length ? masks[masks.length - 1] : null;
      if (mask) {
        const w = mask.width, h = mask.height;
        const data = mask.getAsFloat32Array(); // 0..1 per pixel
        // Orientation (which polarity = foreground) is decided ONCE then LOCKED, so an
        // off-centre subject can't flip the mask mid-session. A selfie subject is
        // centred, so for the foreground mask the centre reads higher than the
        // corners; if it doesn't, this mask is background-confidence → invert.
        let invert = this.invert;
        if (!this.invertDecided) {
          let cSum = 0, cN = 0, kSum = 0, kN = 0;
          const cx0 = w * 0.35, cx1 = w * 0.65, cy0 = h * 0.30, cy1 = h * 0.70;
          for (let y = 0; y < h; y += 6) {
            for (let x = 0; x < w; x += 6) {
              const val = data[y * w + x];
              if (x >= cx0 && x <= cx1 && y >= cy0 && y <= cy1) { cSum += val; cN++; }
              else if ((x < w * 0.12 || x > w * 0.88) && (y < h * 0.12 || y > h * 0.88)) { kSum += val; kN++; }
            }
          }
          const margin = (cN ? cSum / cN : 0) - (kN ? kSum / kN : 0);
          invert = margin < 0;
          if (Math.abs(margin) > 0.08) { this.invert = invert; this.invertDecided = true; }
        }

        if (!this.maskCanvas || this.maskCanvas.width !== w || this.maskCanvas.height !== h) {
          this.maskCanvas = document.createElement("canvas");
          this.maskCanvas.width = w; this.maskCanvas.height = h;
          this.maskCtx = this.maskCanvas.getContext("2d");
        }
        const mctx = this.maskCtx;
        if (mctx) {
          const img = mctx.createImageData(w, h);
          const d = img.data;
          for (let i = 0; i < w * h; i++) {
            let p = data[i];
            if (invert) p = 1 - p;
            const a = p <= 0 ? 0 : p >= 1 ? 255 : (p * 255) | 0;
            d[i * 4] = 255; d[i * 4 + 1] = 255; d[i * 4 + 2] = 255; d[i * 4 + 3] = a;
          }
          mctx.putImageData(img, 0, 0);
          this.hasMask = true;
        }
      }
    } catch {
      /* transient mask read failure — keep the previous mask */
    } finally {
      res.close();
    }
  }

  // Offscreen canvas (alpha = person confidence) or null if no mask is ready yet.
  getMaskCanvas(): HTMLCanvasElement | null {
    return this.hasMask ? this.maskCanvas : null;
  }

  dispose() {
    this.disposed = true;
    if (this.timer) { clearTimeout(this.timer); this.timer = null; }
    this.seg?.close();
    this.seg = null;
  }
}
