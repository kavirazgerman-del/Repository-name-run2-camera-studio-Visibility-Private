// ── Neon Mood Caricature — standalone PREVIEW page ──────────────────────────────
// A self-contained, unlisted route (/neon-mood-preview) so the look can be approved
// in a real browser (camera + MediaPipe assets work here exactly as Camera Studio
// does). It is intentionally NOT wired into CameraStudio's filter list — integration
// is a separate, later step once this preview is approved.
//
// All camera frames stay client-side: nothing is uploaded, recorded, or logged.

import React from "react";
import { NeonMoodTracker } from "./tracker";
import { NeonMoodSegmenter } from "./segmentation";
import { renderNeonMood } from "./renderer";
import {
  type NeonMoodParams, type NMGlow,
  DEFAULT_NEON_MOOD_PARAMS, NM_GLOW_LEVELS,
} from "./types";

const CW = 1280;
const CH = 720;

// Cover-fit math shared by the video draw and the mask draw (so the segmentation
// mask aligns pixel-for-pixel with the framed video).
function coverParams(cw: number, ch: number, vw: number, vh: number) {
  const scale = Math.max(cw / vw, ch / vh);
  const sw = vw * scale, sh = vh * scale;
  return { sw, sh, ox: (cw - sw) / 2, oy: (ch - sh) / 2 };
}

// Local copy of CameraStudio's cover-draw (kept decoupled from that file).
function drawVideoCover(
  ctx: CanvasRenderingContext2D, video: HTMLVideoElement,
  cw: number, ch: number, mirror: boolean,
) {
  const vw = video.videoWidth || cw;
  const vh = video.videoHeight || ch;
  const { sw, sh, ox, oy } = coverParams(cw, ch, vw, vh);
  ctx.save();
  ctx.beginPath(); ctx.rect(0, 0, cw, ch); ctx.clip();
  if (mirror) { ctx.translate(cw, 0); ctx.scale(-1, 1); }
  ctx.drawImage(video, ox, oy, sw, sh);
  ctx.restore();
}

// Person-on-black: draw the framed video, keep only the segmented subject (mask
// alpha), then place it over pure black. Falls back to the plain video draw if the
// mask isn't ready. Video + mask use identical cover params so they stay aligned.
function drawStudio(
  ctx: CanvasRenderingContext2D, personCtx: CanvasRenderingContext2D,
  video: HTMLVideoElement, mask: HTMLCanvasElement,
  cw: number, ch: number, mirror: boolean,
) {
  const vw = video.videoWidth || cw;
  const vh = video.videoHeight || ch;
  const { sw, sh, ox, oy } = coverParams(cw, ch, vw, vh);
  personCtx.clearRect(0, 0, cw, ch);
  personCtx.save();
  personCtx.beginPath(); personCtx.rect(0, 0, cw, ch); personCtx.clip();
  if (mirror) { personCtx.translate(cw, 0); personCtx.scale(-1, 1); }
  personCtx.drawImage(video, ox, oy, sw, sh);
  personCtx.globalCompositeOperation = "destination-in";
  personCtx.imageSmoothingEnabled = true;
  personCtx.drawImage(mask, ox, oy, sw, sh);
  personCtx.restore();
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, cw, ch);
  ctx.drawImage(personCtx.canvas, 0, 0);
}

export default function NeonMoodPreview() {
  const videoRef = React.useRef<HTMLVideoElement>(null);
  const canvasRef = React.useRef<HTMLCanvasElement>(null);
  const streamRef = React.useRef<MediaStream | null>(null);
  const rafRef = React.useRef<number>(0);
  const trackerRef = React.useRef<NeonMoodTracker | null>(null);
  const segmenterRef = React.useRef<NeonMoodSegmenter | null>(null);
  const personCanvasRef = React.useRef<HTMLCanvasElement | null>(null);
  const personCtxRef = React.useRef<CanvasRenderingContext2D | null>(null);
  const facingModeRef = React.useRef<"user" | "environment">("user");
  const mirrorRef = React.useRef(true);

  const [started, setStarted] = React.useState(false);
  const [permissionError, setPermissionError] = React.useState<string | null>(null);
  const [facingMode, setFacingMode] = React.useState<"user" | "environment">("user");
  const [segStatus, setSegStatus] = React.useState<"loading" | "ready" | "failed">("loading");
  const [params, setParams] = React.useState<NeonMoodParams>(DEFAULT_NEON_MOOD_PARAMS);

  // Ref-mirror params so the rAF loop always reads the latest without re-subscribing.
  const paramsRef = React.useRef(params);
  React.useEffect(() => { paramsRef.current = params; }, [params]);

  // Keep the tracker's Mood Lock in sync with the control.
  React.useEffect(() => {
    if (trackerRef.current) trackerRef.current.moodLock = params.moodLock;
  }, [params.moodLock]);

  async function startCamera(mode?: "user" | "environment"): Promise<boolean> {
    setPermissionError(null);
    const fm = mode ?? facingModeRef.current;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: CW }, height: { ideal: CH }, facingMode: fm },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setStarted(true);
      return true;
    } catch (err: any) {
      setPermissionError(
        err?.name === "NotAllowedError"
          ? "Camera permission denied. Allow camera access and try again."
          : `Camera error: ${err?.message ?? String(err)}`,
      );
      return false;
    }
  }

  async function switchCamera() {
    const next: "user" | "environment" = facingModeRef.current === "user" ? "environment" : "user";
    const nextMirror = next === "user";
    facingModeRef.current = next;
    setFacingMode(next);
    mirrorRef.current = nextMirror;
    if (started) {
      streamRef.current?.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
      // Tear down the loop while we re-acquire; if it fails, surface the error UI.
      setStarted(false);
      await startCamera(next);
    }
  }

  // Tracker + segmenter lifecycle + render loop (runs once a camera stream is live).
  React.useEffect(() => {
    if (!started) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;
    canvas.width = CW; canvas.height = CH;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Offscreen buffer for the person-on-black studio composite.
    const personCanvas = document.createElement("canvas");
    personCanvas.width = CW; personCanvas.height = CH;
    personCanvasRef.current = personCanvas;
    personCtxRef.current = personCanvas.getContext("2d");

    const tracker = new NeonMoodTracker(video);
    tracker.moodLock = paramsRef.current.moodLock;
    trackerRef.current = tracker;
    void tracker.start();

    const segmenter = new NeonMoodSegmenter(video);
    segmenterRef.current = segmenter;
    let active = true;
    setSegStatus("loading");
    void segmenter.start().then(() => {
      if (active) setSegStatus(segmenter.failed ? "failed" : segmenter.ready ? "ready" : "failed");
    });

    const draw = () => {
      const v = videoRef.current;
      if (v && v.readyState >= 2 && v.videoWidth > 0) {
        const mirror = mirrorRef.current;
        const vw = v.videoWidth, vh = v.videoHeight;
        const p = paramsRef.current;
        const tracking = tracker.getTracking();
        const hasFace = tracking.faces.length > 0;
        // Auto black "neon studio" background: only when the filter is ACTIVE
        // (enabled + intensity > 0) at Glow=high, the mask is ready, AND a face is
        // present — so Off / intensity-0 / empty scenes keep the real background.
        const studioOn = p.enabled && p.intensity > 0 && p.glow === "high";
        const mask = studioOn ? segmenter.getMaskCanvas() : null;
        const personCtx = personCtxRef.current;
        ctx.clearRect(0, 0, CW, CH);
        if (mask && hasFace && personCtx) {
          drawStudio(ctx, personCtx, v, mask, CW, CH, mirror);
        } else {
          drawVideoCover(ctx, v, CW, CH, mirror);
        }
        renderNeonMood(ctx, CW, CH, tracking, vw, vh, mirror, p);
      }
      rafRef.current = requestAnimationFrame(draw);
    };
    rafRef.current = requestAnimationFrame(draw);

    return () => {
      active = false;
      cancelAnimationFrame(rafRef.current);
      tracker.dispose();
      trackerRef.current = null;
      segmenter.dispose();
      segmenterRef.current = null;
      personCanvasRef.current = null;
      personCtxRef.current = null;
    };
  }, [started]);

  // Stop the camera on unmount.
  React.useEffect(() => {
    return () => {
      cancelAnimationFrame(rafRef.current);
      streamRef.current?.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    };
  }, []);

  const set = <K extends keyof NeonMoodParams>(key: K, value: NeonMoodParams[K]) =>
    setParams((p) => ({ ...p, [key]: value }));

  return (
    <div className="min-h-dvh w-full bg-black text-white flex flex-col items-center">
      {/* Preview-only banner */}
      <div className="w-full bg-fuchsia-600/20 border-b border-fuchsia-500/40 px-4 py-2 text-center text-xs sm:text-sm text-fuchsia-200">
        PREVIEW ONLY — Neon Mood Caricature is not yet in the app. Approve this look to add it to Camera Studio.
      </div>

      <div className="w-full max-w-5xl px-4 py-4 flex flex-col gap-4">
        <header className="flex items-center justify-between gap-3">
          <h1 className="text-lg sm:text-2xl font-bold tracking-tight">
            <span className="text-cyan-300">Neon</span>{" "}
            <span className="text-fuchsia-400">Mood</span>{" "}
            <span className="text-amber-300">Caricature</span>
          </h1>
          <span className="text-xs text-white/50">Up to 2 faces · auto mood → palette</span>
        </header>

        {/* Stage */}
        <div className="relative w-full aspect-video rounded-2xl overflow-hidden bg-zinc-950 ring-1 ring-white/10 shadow-[0_0_60px_-15px_rgba(168,85,247,0.6)]">
          <video ref={videoRef} className="hidden" playsInline muted />
          <canvas ref={canvasRef} className="w-full h-full object-contain" />

          {!started && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 p-6 text-center">
              {permissionError ? (
                <p className="text-red-300 text-sm max-w-md">{permissionError}</p>
              ) : (
                <p className="text-white/70 text-sm max-w-md">
                  Enable your camera to see the live neon caricature. Frames never leave your device.
                </p>
              )}
              <button
                onClick={() => startCamera()}
                className="rounded-full bg-fuchsia-500 hover:bg-fuchsia-400 px-6 py-3 font-semibold text-black transition-colors"
              >
                {permissionError ? "Try again" : "Enable camera"}
              </button>
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4 rounded-2xl bg-white/[0.03] ring-1 ring-white/10 p-4">
          {/* On/Off */}
          <Row label="Neon Mood">
            <Toggle on={params.enabled} onChange={(v) => set("enabled", v)} label={params.enabled ? "On" : "Off"} />
          </Row>

          {/* Mood Lock */}
          <Row label="Mood Lock">
            <Toggle on={params.moodLock} onChange={(v) => set("moodLock", v)} label={params.moodLock ? "Locked" : "Auto"} />
          </Row>

          {/* Intensity */}
          <Row label={`Intensity · ${params.intensity}`}>
            <input
              type="range" min={0} max={100} value={params.intensity}
              onChange={(e) => set("intensity", Number(e.target.value))}
              className="w-full accent-fuchsia-400"
            />
          </Row>

          {/* Line Thickness */}
          <Row label={`Line Thickness · ${params.lineThickness}`}>
            <input
              type="range" min={0} max={100} value={params.lineThickness}
              onChange={(e) => set("lineThickness", Number(e.target.value))}
              className="w-full accent-cyan-400"
            />
          </Row>

          {/* Glow Level */}
          <Row label="Glow Level">
            <div className="flex gap-1.5">
              {NM_GLOW_LEVELS.map((g) => (
                <button
                  key={g.id}
                  onClick={() => set("glow", g.id as NMGlow)}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                    params.glow === g.id
                      ? "bg-amber-400 text-black"
                      : "bg-white/5 text-white/70 hover:bg-white/10"
                  }`}
                >
                  {g.label}
                </button>
              ))}
            </div>
          </Row>

          {/* Switch Camera */}
          <Row label="Camera">
            <button
              onClick={switchCamera}
              className="px-4 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-sm font-medium transition-colors"
            >
              Switch ({facingMode === "user" ? "Front" : "Back"})
            </button>
          </Row>
        </div>

        <p className="text-center text-xs text-white/40">
          Glow “High” auto-switches on the black neon-studio background; Low/Med keep your real
          background with mood glow accents.
          {params.glow === "high" && started && (
            <span className="block mt-1 text-white/55">
              {segStatus === "ready"
                ? "Neon studio background: on (subject on black)."
                : segStatus === "failed"
                  ? "Studio background unavailable — showing your real background."
                  : "Loading studio background…"}
            </span>
          )}
        </p>
      </div>
    </div>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <span className="text-sm text-white/70 shrink-0">{label}</span>
      <div className="flex-1 max-w-[60%] flex justify-end">{children}</div>
    </div>
  );
}

function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      onClick={() => onChange(!on)}
      className={`relative inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-sm font-medium transition-colors ${
        on ? "bg-emerald-400 text-black" : "bg-white/10 text-white/70"
      }`}
    >
      <span className={`h-2 w-2 rounded-full ${on ? "bg-black/70" : "bg-white/40"}`} />
      {label}
    </button>
  );
}
