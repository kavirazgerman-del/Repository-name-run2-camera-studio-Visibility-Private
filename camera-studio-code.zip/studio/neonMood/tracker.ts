// ── Neon Mood — multi-face tracker (numFaces:2 + blendshapes) ───────────────────
// A SEPARATE tracker from NeonPatriotTracker (which is single-face, no blendshapes
// and shared by four other filters — do NOT modify it). This one:
//   • runs FaceLandmarker with numFaces:2 + outputFaceBlendshapes:true on a
//     throttled async timer (never draws),
//   • keeps up to two STABLE per-face slots (identity matched by centroid so each
//     person keeps their own smoothing + mood),
//   • EMA-smooths landmarks AND blendshapes, holds + fades on tracking loss,
//   • estimates a per-face mood with dwell/hysteresis and an optional Mood Lock.
//
// The synchronous renderer consumes getTracking() each compositor frame.

import { FaceLandmarker, FilesetResolver, type FaceLandmarkerResult } from "@mediapipe/tasks-vision";
import { scoreMoods, pickMood, makeGetter } from "./mood";
import { type NeonMoodId, type NeonMoodTracking, type NeonMoodFace } from "./types";

const DETECT_MS = 50;     // ~20fps detection cadence (protects the compositor)
const EMA = 0.5;          // landmark smoothing toward each new detection
const EMA_BS = 0.35;      // blendshape smoothing (slower → stable mood)
const HOLD_MS = 140;      // keep the last pose briefly after a dropped frame
const FADE_MS = 280;      // then fade out over this long
const MATCH_DIST = 0.28;  // max normalized centroid distance to keep an identity
const DWELL_MS = 350;     // a new mood must persist this long before it switches
const MARGIN = 0.06;      // …and beat the current mood's score by at least this

interface Slot {
  smoothed: Float32Array | null;
  count: number;
  bs: Record<string, number>;       // smoothed blendshape activations
  cx: number; cy: number;           // smoothed centroid (normalized space)
  lastSeen: number;                 // performance.now() of last successful update
  matchedThisFrame: boolean;
  // mood state
  mood: NeonMoodId;
  moodConf: number;
  hasMood: boolean;
  candidate: NeonMoodId | null;
  candidateSince: number;
  // reused snapshot object (no per-frame alloc in the hot path)
  snap: NeonMoodFace;
}

function makeSlot(): Slot {
  return {
    smoothed: null, count: 0, bs: {}, cx: 0, cy: 0, lastSeen: 0,
    matchedThisFrame: false,
    mood: "calm", moodConf: 0, hasMood: false, candidate: null, candidateSince: 0,
    snap: { landmarks: new Float32Array(0), count: 0, fade: 0, mood: "calm", moodConfidence: 0 },
  };
}

interface Detection {
  lm: { x: number; y: number; z: number }[];
  cats: { categoryName: string; score: number }[];
  cx: number; cy: number;
}

export class NeonMoodTracker {
  // Public knob — the preview sets this to freeze per-face moods.
  moodLock = false;

  private video: HTMLVideoElement;
  private landmarker: FaceLandmarker | null = null;
  private starting = false;
  private disposed = false;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private lastTs = 0;
  private slots: Slot[] = [makeSlot(), makeSlot()];
  private out: NeonMoodTracking = { faces: [] };

  constructor(video: HTMLVideoElement) { this.video = video; }

  async start() {
    if (this.disposed || this.starting || this.landmarker) return;
    this.starting = true;
    try {
      const base = import.meta.env.BASE_URL || "/";
      const fileset = await FilesetResolver.forVisionTasks(`${base}mediapipe/wasm`);
      if (this.disposed) return;
      const make = (delegate: "GPU" | "CPU") => FaceLandmarker.createFromOptions(fileset, {
        baseOptions: { modelAssetPath: `${base}mediapipe/face_landmarker.task`, delegate },
        runningMode: "VIDEO",
        numFaces: 2,
        outputFaceBlendshapes: true,
      });
      try { this.landmarker = await make("GPU"); }
      catch { this.landmarker = await make("CPU"); }
      if (this.disposed) { this.landmarker?.close(); this.landmarker = null; return; }
      this.loop();
    } catch (err) {
      // Asset/model load failed — leave landmarker null; the renderer simply shows
      // nothing (filter degrades to a clean no-op) rather than crashing.
      console.error("[NeonMood] tracker init failed", err);
    } finally {
      this.starting = false;
    }
  }

  private loop = () => {
    if (this.disposed) return;
    this.detectOnce();
    this.timer = setTimeout(this.loop, DETECT_MS);
  };

  private detectOnce() {
    const v = this.video, lm = this.landmarker;
    if (!lm || !v || v.readyState < 2 || v.videoWidth === 0) return;
    let ts = performance.now();
    if (ts <= this.lastTs) ts = this.lastTs + 1; // strictly increasing (required)
    this.lastTs = ts;
    let res: FaceLandmarkerResult;
    try { res = lm.detectForVideo(v, ts); } catch { return; }

    const faces = res.faceLandmarks ?? [];
    const blends = res.faceBlendshapes ?? [];
    const dets: Detection[] = [];
    for (let i = 0; i < faces.length; i++) {
      const f = faces[i];
      if (!f || !f.length) continue;
      let sx = 0, sy = 0;
      for (let j = 0; j < f.length; j++) { sx += f[j].x; sy += f[j].y; }
      dets.push({ lm: f, cats: blends[i]?.categories ?? [], cx: sx / f.length, cy: sy / f.length });
    }

    const now = performance.now();
    for (const s of this.slots) s.matchedThisFrame = false;

    // 1) Match each live slot to its nearest unused detection (keeps identities).
    const usedDet = new Set<number>();
    for (const slot of this.slots) {
      if (slot.count === 0 || now - slot.lastSeen > HOLD_MS + FADE_MS) continue;
      let best = -1, bestD = Infinity;
      for (let di = 0; di < dets.length; di++) {
        if (usedDet.has(di)) continue;
        const d = dets[di];
        const dist = Math.hypot(d.cx - slot.cx, d.cy - slot.cy);
        if (dist < bestD) { bestD = dist; best = di; }
      }
      if (best >= 0 && bestD < MATCH_DIST) {
        this.updateSlot(slot, dets[best], now, false);
        usedDet.add(best);
      }
    }

    // 2) Remaining detections claim a free / stalest slot as a NEW identity.
    for (let di = 0; di < dets.length; di++) {
      if (usedDet.has(di)) continue;
      let target: Slot | null = null;
      let oldest = Infinity;
      for (const slot of this.slots) {
        if (slot.matchedThisFrame) continue;
        const key = slot.count === 0 ? -1 : slot.lastSeen;
        if (key < oldest) { oldest = key; target = slot; }
      }
      if (target) { this.updateSlot(target, dets[di], now, true); usedDet.add(di); }
    }
  }

  private updateSlot(slot: Slot, d: Detection, now: number, fresh: boolean) {
    const f = d.lm;
    const n = f.length;
    if (!slot.smoothed || slot.count !== n || fresh) {
      slot.smoothed = new Float32Array(n * 3);
      for (let i = 0; i < n; i++) {
        slot.smoothed[i * 3] = f[i].x;
        slot.smoothed[i * 3 + 1] = f[i].y;
        slot.smoothed[i * 3 + 2] = f[i].z;
      }
      slot.count = n;
      slot.bs = {};
      for (const c of d.cats) slot.bs[c.categoryName] = c.score;
    } else {
      const s = slot.smoothed;
      for (let i = 0; i < n; i++) {
        s[i * 3]     += (f[i].x - s[i * 3]) * EMA;
        s[i * 3 + 1] += (f[i].y - s[i * 3 + 1]) * EMA;
        s[i * 3 + 2] += (f[i].z - s[i * 3 + 2]) * EMA;
      }
      for (const c of d.cats) {
        const prev = slot.bs[c.categoryName] ?? c.score;
        slot.bs[c.categoryName] = prev + (c.score - prev) * EMA_BS;
      }
    }
    if (fresh) { slot.cx = d.cx; slot.cy = d.cy; }
    else { slot.cx += (d.cx - slot.cx) * EMA; slot.cy += (d.cy - slot.cy) * EMA; }
    slot.lastSeen = now;
    slot.matchedThisFrame = true;
    this.updateMood(slot, now, fresh);
  }

  private updateMood(slot: Slot, now: number, fresh: boolean) {
    const scores = scoreMoods(makeGetter(slot.bs));
    const pick = pickMood(scores);
    slot.moodConf = pick.confidence;
    if (!slot.hasMood || fresh) {
      slot.mood = pick.mood; slot.hasMood = true; slot.candidate = null; return;
    }
    if (this.moodLock) { slot.candidate = null; return; } // frozen
    if (pick.mood === slot.mood) { slot.candidate = null; return; }
    // A different mood must persist for DWELL_MS AND beat the current by MARGIN.
    if (slot.candidate !== pick.mood) { slot.candidate = pick.mood; slot.candidateSince = now; return; }
    if (now - slot.candidateSince >= DWELL_MS &&
        scores[pick.mood] > scores[slot.mood] + MARGIN) {
      slot.mood = pick.mood;
      slot.candidate = null;
    }
  }

  // Latest snapshot for the synchronous renderer (reuses per-slot objects).
  getTracking(): NeonMoodTracking {
    const now = performance.now();
    const faces: NeonMoodFace[] = this.out.faces;
    faces.length = 0;
    for (const slot of this.slots) {
      if (slot.count === 0 || !slot.smoothed) continue;
      const dt = now - slot.lastSeen;
      let fade = 1;
      if (dt > HOLD_MS) fade = Math.max(0, 1 - (dt - HOLD_MS) / FADE_MS);
      if (fade <= 0) continue;
      const snap = slot.snap;
      snap.landmarks = slot.smoothed;
      snap.count = slot.count;
      snap.fade = fade;
      snap.mood = slot.mood;
      snap.moodConfidence = slot.moodConf;
      faces.push(snap);
    }
    return this.out;
  }

  dispose() {
    this.disposed = true;
    if (this.timer) { clearTimeout(this.timer); this.timer = null; }
    this.landmarker?.close();
    this.landmarker = null;
  }
}
