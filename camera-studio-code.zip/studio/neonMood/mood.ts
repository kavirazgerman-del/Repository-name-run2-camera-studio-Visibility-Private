// ── Neon Mood — deterministic blendshape → mood scoring ─────────────────────────
// Pure functions only. Given smoothed FaceLandmarker blendshape activations (ARKit
// style category names in 0..1), score every named mood — positive AND negative
// (angry, furious, sad, fearful, disgusted, surprised) — and pick the strongest.
// Stateless — hysteresis / dwell / Mood Lock live in the tracker so the same inputs
// always produce the same scores here. Negative moods are tuned with explicit smile
// penalties so they reliably beat the positive/neutral set when the face is actually
// scowling, frowning or wide-eyed (rather than getting swallowed by calm/confident).

import { type NeonMoodId, MOOD_IDS } from "./types";

const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);

// A getter over a smoothed blendshape map (missing categories read as 0).
export type Blendshapes = (name: string) => number;

export interface MoodPick {
  mood: NeonMoodId;
  confidence: number; // 0..1 — gap between the top two scores (used for hysteresis)
}

// Score every mood from the smoothed activations. Calm is the neutral baseline:
// it wins when the face is relaxed and loses as soon as another expression fires.
export function scoreMoods(g: Blendshapes): Record<NeonMoodId, number> {
  const smileL = g("mouthSmileLeft");
  const smileR = g("mouthSmileRight");
  const smile = (smileL + smileR) / 2;
  const smileAsym = Math.abs(smileL - smileR);
  const jaw = g("jawOpen");
  const browInner = g("browInnerUp");
  const browOuter = (g("browOuterUpLeft") + g("browOuterUpRight")) / 2;
  const browUp = (browInner + browOuter) / 2;
  const browDown = (g("browDownLeft") + g("browDownRight")) / 2;
  const eyeWide = (g("eyeWideLeft") + g("eyeWideRight")) / 2;
  const eyeSquint = (g("eyeSquintLeft") + g("eyeSquintRight")) / 2;
  const cheekSquint = (g("cheekSquintLeft") + g("cheekSquintRight")) / 2;
  const frown = (g("mouthFrownLeft") + g("mouthFrownRight")) / 2;
  const sneer = (g("noseSneerLeft") + g("noseSneerRight")) / 2;
  const pucker = g("mouthPucker");
  const dimple = (g("mouthDimpleLeft") + g("mouthDimpleRight")) / 2;
  // Extra activations used by the negative moods.
  const press = (g("mouthPressLeft") + g("mouthPressRight")) / 2;       // lips clamped — anger
  const upperUp = (g("mouthUpperUpLeft") + g("mouthUpperUpRight")) / 2; // top lip raised — disgust
  const stretch = (g("mouthStretchLeft") + g("mouthStretchRight")) / 2; // mouth pulled wide — fear/snarl
  const shrug = g("mouthShrugUpper");                                   // chin/lip shrug — sadness

  // Overall expressive "activity" — calm is the inverse of this. Includes the negative
  // activations so a scowl/grimace correctly suppresses calm.
  const activity = Math.max(
    smile, jaw, browUp, browDown, frown, eyeWide, eyeSquint, sneer, press, upperUp, stretch,
  );

  const scores: Record<NeonMoodId, number> = {
    // positive / neutral
    joyful:     smile * 1.10 + jaw * 0.70 + cheekSquint * 0.70 + eyeWide * 0.20,
    happy:      smile * 1.00 + cheekSquint * 0.45 + dimple * 0.30 - jaw * 0.40,
    energetic:  jaw * 1.20 + browUp * 0.60 + eyeWide * 0.50 + smile * 0.35,
    romantic:   smile * 0.55 + eyeSquint * 0.35 + pucker * 0.55 + (1 - jaw) * 0.12 - frown * 0.30,
    calm:       (1 - activity) * 1.05 - frown * 0.40,
    // a soft, wistful low-energy sadness; loses to `sad` once the frown/brow really fire
    melancholy: frown * 0.75 + browInner * 0.55 + eyeSquint * 0.30 + shrug * 0.30 - smile * 0.60 - jaw * 0.35,
    mysterious: smileAsym * 1.50 + eyeSquint * 0.45 + sneer * 0.35 - jaw * 0.20,
    confident:  smile * 0.45 + browDown * 0.70 + smileAsym * 0.40 + dimple * 0.20 - jaw * 0.40,
    // negative / intense — heavy smile penalties so they win over confident/calm/mysterious
    angry:      browDown * 1.30 + eyeSquint * 0.70 + press * 0.65 + frown * 0.35 + sneer * 0.35
                  - smile * 1.30 - browUp * 0.55,
    furious:    browDown * 1.45 + eyeSquint * 0.85 + sneer * 0.75 + stretch * 0.50 + jaw * 0.35 + press * 0.30
                  - smile * 1.50 - browUp * 0.65,
    sad:        frown * 1.30 + browInner * 1.05 + shrug * 0.45 - smile * 0.95 - browDown * 0.45 - jaw * 0.35,
    fearful:    eyeWide * 1.15 + browInner * 0.85 + stretch * 0.75 + jaw * 0.35
                  - smile * 0.85 - browDown * 0.55 - cheekSquint * 0.40,
    disgusted:  sneer * 1.30 + upperUp * 0.95 + browDown * 0.40 - smile * 0.85 - jaw * 0.25,
    surprised:  eyeWide * 1.20 + jaw * 1.00 + browUp * 0.95 - smile * 0.45 - browDown * 0.50 - cheekSquint * 0.30,
  };
  return scores;
}

// Argmax with a confidence = (top − runner-up).
export function pickMood(scores: Record<NeonMoodId, number>): MoodPick {
  let best: NeonMoodId = "calm";
  let bestV = -Infinity;
  let second = -Infinity;
  for (const id of MOOD_IDS) {
    const v = scores[id];
    if (v > bestV) { second = bestV; bestV = v; best = id; }
    else if (v > second) { second = v; }
  }
  const conf = clamp01((bestV - second));
  return { mood: best, confidence: conf };
}

// Convenience: build a getter over a plain smoothed map.
export function makeGetter(map: Record<string, number>): Blendshapes {
  return (name: string) => map[name] ?? 0;
}
