// ── Neon Mood — synchronous Canvas2D renderer ───────────────────────────────────
// Draws each tracked face as a BOLD neon-line caricature in its mood palette, with
// additive glow, a mood-tinted background bloom, dense detail line-work, drifting
// mood-specific FX, and a mood label + confidence meter. Crucially the caricature is
// WARPED to express the detected emotion (furrowed brows for anger, drooping brows +
// downturned mouth for sadness, huge eyes + gaping mouth for surprise, …) and the FX
// family reinforces it (steam/fire/tears/rain/sweat/burst/…) so the viewer can SEE the
// mood, not just read a colour. Pure Canvas2D (no WebGL) so it bakes straight into the
// capture buffer and is robust in environments without WebGL2. Shares the cover-mapping
// helpers with the other face filters and matches the
// (ctx,w,h,tracking,vw,vh,mirror,params) contract so CameraStudio drives it unchanged.
//
// No-op rules (all verified statically): disabled, intensity 0, or no faces → draws
// nothing; every face is drawn inside balanced save()/restore() pairs.

import { FaceLandmarker } from "@mediapipe/tasks-vision";
import { makeCoverMap, mapX, mapY } from "../neonPatriot";
import {
  type NeonMoodTracking, type NeonMoodFace, type NeonMoodParams,
  type NMGlow, MOOD_PALETTES,
} from "./types";
import { MOOD_EXPRESSIONS, type MoodExpressionSpec } from "./expressions";

type Conn = { start: number; end: number };

// Static MediaPipe connection sets (resolved once at module load).
const FL = FaceLandmarker;
const OVAL: Conn[] = FL.FACE_LANDMARKS_FACE_OVAL;
const LIPS: Conn[] = FL.FACE_LANDMARKS_LIPS;
const LEYE: Conn[] = FL.FACE_LANDMARKS_LEFT_EYE;
const REYE: Conn[] = FL.FACE_LANDMARKS_RIGHT_EYE;
const LBROW: Conn[] = FL.FACE_LANDMARKS_LEFT_EYEBROW;
const RBROW: Conn[] = FL.FACE_LANDMARKS_RIGHT_EYEBROW;
const LIRIS: Conn[] = FL.FACE_LANDMARKS_LEFT_IRIS;
const RIRIS: Conn[] = FL.FACE_LANDMARKS_RIGHT_IRIS;

// Custom nose accent (canonical FaceMesh indices) — no static set ships for it.
const NOSE: Conn[] = [
  { start: 168, end: 197 }, { start: 197, end: 195 }, { start: 195, end: 5 },
  { start: 5, end: 4 }, { start: 4, end: 1 },
  { start: 98, end: 97 }, { start: 97, end: 2 }, { start: 2, end: 326 }, { start: 326, end: 327 },
];

const idxOf = (conns: Conn[]): Set<number> => {
  const s = new Set<number>();
  for (const c of conns) { s.add(c.start); s.add(c.end); }
  return s;
};
const L_IRIS_IDX = idxOf(LIRIS);
const R_IRIS_IDX = idxOf(RIRIS);
const LEFT_EYE_IDX = new Set<number>([...idxOf(LEYE), ...L_IRIS_IDX]);
const RIGHT_EYE_IDX = new Set<number>([...idxOf(REYE), ...R_IRIS_IDX]);
const LIPS_IDX = idxOf(LIPS);
const OVAL_IDX = idxOf(OVAL);
const BROW_IDX = new Set<number>([...idxOf(LBROW), ...idxOf(RBROW)]);

const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);

const GLOW_BASE: Record<NMGlow, number> = { low: 7, med: 13, high: 22 };
const GLOW_MUL: Record<NMGlow, number> = { low: 0.7, med: 1.0, high: 1.45 };
const PARTICLES: Record<NMGlow, number> = { low: 10, med: 16, high: 24 };

// Honor reduce-motion once (FX / jitter freeze rather than drift).
const REDUCE_MOTION =
  typeof window !== "undefined" && typeof window.matchMedia === "function"
    ? window.matchMedia("(prefers-reduced-motion: reduce)").matches
    : false;

// "#rrggbb" + alpha → "rgba(...)".
function rgba(hex: string, a: number): string {
  const h = hex.replace("#", "");
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${clamp01(a)})`;
}

// Deterministic per-face hash → [0,1) (no Math.random in the hot path so capture is stable).
function hash01(a: number, b: number): number {
  const v = Math.sin(a * 97.13 + b * 43.77) * 43758.5453;
  return v - Math.floor(v);
}

// Reusable scratch buffers (grown as needed; the renderer runs in the rAF hot path).
let _P: Float32Array = new Float32Array(0);
let _E: Float32Array = new Float32Array(0);

function strokeConns(
  ctx: CanvasRenderingContext2D, E: Float32Array, conns: Conn[],
  color: string, lw: number, blur: number, alpha: number,
) {
  ctx.beginPath();
  for (const c of conns) {
    const a = c.start * 2, b = c.end * 2;
    ctx.moveTo(E[a], E[a + 1]);
    ctx.lineTo(E[b], E[b + 1]);
  }
  ctx.lineWidth = lw;
  ctx.strokeStyle = color;
  ctx.globalAlpha = alpha;
  ctx.shadowColor = color;
  ctx.shadowBlur = blur;
  ctx.stroke();
}

function meanOf(E: Float32Array, idx: Set<number>): { x: number; y: number } {
  let sx = 0, sy = 0, n = 0;
  for (const i of idx) { sx += E[i * 2]; sy += E[i * 2 + 1]; n++; }
  return n > 0 ? { x: sx / n, y: sy / n } : { x: 0, y: 0 };
}

// ── mood-expression warp ────────────────────────────────────────────────────────
// Small geometric offsets applied to the ALREADY-caricatured landmarks so the line-art
// itself reads the emotion. Bounded in face-relative units and scaled by caricature.
function applyMoodWarp(
  E: Float32Array, fcx: number, faceW: number, faceH: number,
  spec: MoodExpressionSpec, car: number,
) {
  const bY = faceH * 0.06 * car;   // brow vertical travel
  const bX = faceW * 0.05 * car;   // brow inward travel
  const halfW = Math.max(1, faceW * 0.34);

  for (const i of BROW_IDX) {
    const x = E[i * 2], y = E[i * 2 + 1];
    const inner = clamp01(1 - Math.abs(x - fcx) / halfW); // 1 at the midline
    const side = x < fcx ? -1 : 1;
    switch (spec.brow) {
      case "raise":  E[i * 2 + 1] = y - bY; break;
      case "furrow": // pulled DOWN (inner most) and IN toward the nose — the classic scowl
        E[i * 2 + 1] = y + bY * (0.5 + inner);
        E[i * 2]     = x - side * bX * inner;
        break;
      case "droop":  // inner UP, outer DOWN — worried / sad
        E[i * 2 + 1] = y - bY * inner + bY * 0.7 * (1 - inner);
        break;
      case "arch":   // outer UP — sultry / surprised
        E[i * 2 + 1] = y - bY * (1 - inner) * 1.1;
        break;
      default: break;
    }
  }

  const eyeScale = spec.eye === "wide" ? 1.18 : spec.eye === "narrow" ? 0.78 : spec.eye === "droop" ? 0.9 : 1;
  const eyeDrop = spec.eye === "droop" ? faceH * 0.012 : 0;
  if (eyeScale !== 1 || eyeDrop) {
    const lc = meanOf(E, LEFT_EYE_IDX);
    for (const i of LEFT_EYE_IDX) E[i * 2 + 1] = lc.y + (E[i * 2 + 1] - lc.y) * eyeScale + eyeDrop;
    const rc = meanOf(E, RIGHT_EYE_IDX);
    for (const i of RIGHT_EYE_IDX) E[i * 2 + 1] = rc.y + (E[i * 2 + 1] - rc.y) * eyeScale + eyeDrop;
  }

  const mc = meanOf(E, LIPS_IDX);
  const mY = faceH * 0.05 * car;
  const cw = Math.max(1, faceW * 0.22);
  for (const i of LIPS_IDX) {
    const x = E[i * 2], y = E[i * 2 + 1];
    const corner = clamp01(Math.abs(x - mc.x) / cw);
    switch (spec.mouth) {
      case "frown": E[i * 2 + 1] = y + mY * corner; break;             // corners down
      case "smile": E[i * 2 + 1] = y - mY * corner * 0.8; break;       // corners up
      case "open":  E[i * 2 + 1] = mc.y + (y - mc.y) * 1.35; break;    // jaw drop
      case "tight": E[i * 2 + 1] = mc.y + (y - mc.y) * 0.6; break;     // pressed lips
      case "sneer": if (x < mc.x && y < mc.y) E[i * 2 + 1] = y - mY * 0.9; break; // one-sided snarl
      default: break;
    }
  }
}

// ── small FX primitives ─────────────────────────────────────────────────────────
function fillDroplet(ctx: CanvasRenderingContext2D, x: number, y: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x, y - r * 1.8);
  ctx.bezierCurveTo(x + r * 1.2, y - r * 0.2, x + r * 0.9, y + r, x, y + r);
  ctx.bezierCurveTo(x - r * 0.9, y + r, x - r * 1.2, y - r * 0.2, x, y - r * 1.8);
  ctx.closePath();
  ctx.fill();
}

function fillHeart(ctx: CanvasRenderingContext2D, x: number, y: number, s: number) {
  ctx.beginPath();
  ctx.moveTo(x, y + s * 0.35);
  ctx.bezierCurveTo(x + s, y - s * 0.6, x + s * 1.4, y + s * 0.5, x, y + s * 1.2);
  ctx.bezierCurveTo(x - s * 1.4, y + s * 0.5, x - s, y - s * 0.6, x, y + s * 0.35);
  ctx.closePath();
  ctx.fill();
}

// ── mood-specific FX layer ──────────────────────────────────────────────────────
function drawMoodFx(
  ctx: CanvasRenderingContext2D, spec: MoodExpressionSpec,
  pal: { primary: string; secondary: string; particle: string },
  fcx: number, fcy: number, faceW: number, faceH: number, topY: number,
  lEye: { x: number; y: number }, rEye: { x: number; y: number },
  alphaBase: number, blur: number, glowMul: number, count: number,
  timeS: number, faceIndex: number,
) {
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  ctx.lineCap = "round";
  const A = alphaBase * glowMul;
  const acc = spec.accent;

  switch (spec.fx) {
    case "sparks": {
      ctx.lineWidth = Math.max(1, faceW * 0.012);
      for (let k = 0; k < count; k++) {
        const s = hash01(faceIndex + 3, k);
        const phase = REDUCE_MOTION ? s : (timeS * (0.5 + s * 0.7) + s) % 1;
        const ang = -Math.PI / 2 + (s - 0.5) * 2.4;
        const dist = faceW * (0.4 + phase * 1.1);
        const x = fcx + Math.cos(ang) * dist, y = fcy - faceH * 0.1 + Math.sin(ang) * dist;
        const len = faceW * 0.07 * (0.6 + s);
        const a = (1 - phase) * 0.85 * A;
        if (a <= 0.01) continue;
        ctx.globalAlpha = a;
        ctx.strokeStyle = k % 2 ? acc : pal.particle;
        ctx.shadowColor = acc; ctx.shadowBlur = blur * 0.8;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x - Math.cos(ang) * len, y - Math.sin(ang) * len);
        ctx.stroke();
      }
      break;
    }
    case "steam": {
      const cols = 5;
      ctx.lineWidth = Math.max(1.4, faceW * 0.016);
      for (let c = 0; c < cols; c++) {
        const baseX = fcx + (c - (cols - 1) / 2) * faceW * 0.24;
        const wobble = REDUCE_MOTION ? 0 : Math.sin(timeS * 2 + c) * faceW * 0.05;
        ctx.globalAlpha = (0.32 + 0.1 * (c % 2)) * A;
        ctx.strokeStyle = acc; ctx.shadowColor = acc; ctx.shadowBlur = blur;
        ctx.beginPath();
        const steps = 7, top = topY - faceH * 0.95, bot = topY - faceH * 0.05;
        for (let s = 0; s <= steps; s++) {
          const t = s / steps;
          const y = bot + (top - bot) * t;
          const x = baseX + Math.sin(t * 6 + (REDUCE_MOTION ? 0 : timeS * 3) + c) * faceW * 0.05 + wobble * t;
          if (s === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
        }
        ctx.stroke();
      }
      break;
    }
    case "fire": {
      const tongues = 7;
      const base = topY + faceH * 0.02;
      for (let f = 0; f < tongues; f++) {
        const fx = fcx + (f - (tongues - 1) / 2) * faceW * 0.17;
        const flick = REDUCE_MOTION ? 0.7 : 0.5 + 0.5 * Math.abs(Math.sin(timeS * 7 + f * 1.7));
        const hgt = faceH * (0.35 + 0.5 * flick);
        const wdt = faceW * 0.1;
        ctx.globalAlpha = 0.5 * A;
        ctx.fillStyle = f % 2 ? acc : pal.secondary;
        ctx.shadowColor = acc; ctx.shadowBlur = blur * 1.2;
        ctx.beginPath();
        ctx.moveTo(fx - wdt, base);
        ctx.quadraticCurveTo(fx - wdt * 0.5, base - hgt * 0.6, fx, base - hgt);
        ctx.quadraticCurveTo(fx + wdt * 0.5, base - hgt * 0.6, fx + wdt, base);
        ctx.closePath();
        ctx.fill();
      }
      break;
    }
    case "tears": {
      for (const eye of [lEye, rEye]) {
        for (let d = 0; d < 3; d++) {
          const s = hash01(faceIndex * 7 + (eye === lEye ? 1 : 2), d);
          const phase = REDUCE_MOTION ? s : (timeS * 0.5 + s) % 1;
          const x = eye.x + (s - 0.5) * faceW * 0.04;
          const y = eye.y + faceH * 0.05 + phase * faceH * 0.95;
          const a = (1 - phase) * 0.9 * A;
          if (a <= 0.01) continue;
          ctx.globalAlpha = a;
          ctx.fillStyle = acc; ctx.shadowColor = acc; ctx.shadowBlur = blur;
          fillDroplet(ctx, x, y, faceW * 0.022 * (0.7 + s * 0.6));
        }
      }
      break;
    }
    case "rain": {
      ctx.lineWidth = Math.max(1, faceW * 0.01);
      for (let k = 0; k < count; k++) {
        const s = hash01(faceIndex + 9, k);
        const phase = REDUCE_MOTION ? s : (timeS * 0.9 + s) % 1;
        const x = fcx - faceW + s * faceW * 2;
        const y = topY - faceH * 0.4 + phase * faceH * 2;
        const len = faceH * 0.12;
        ctx.globalAlpha = 0.5 * A;
        ctx.strokeStyle = acc; ctx.shadowColor = acc; ctx.shadowBlur = blur * 0.5;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x - len * 0.35, y + len);
        ctx.stroke();
      }
      break;
    }
    case "sweat": {
      for (const side of [-1, 1]) {
        const s = hash01(faceIndex + 11, side + 2);
        const phase = REDUCE_MOTION ? s : (timeS * 0.45 + s) % 1;
        const x = fcx + side * faceW * 0.42 - side * phase * faceW * 0.05;
        const y = topY + faceH * 0.18 + phase * faceH * 0.85;
        ctx.globalAlpha = (1 - phase * 0.4) * 0.9 * A;
        ctx.fillStyle = acc; ctx.shadowColor = acc; ctx.shadowBlur = blur;
        fillDroplet(ctx, x, y, faceW * 0.026);
      }
      break;
    }
    case "burst": {
      const rays = 12, r0 = Math.max(faceW, faceH) * 0.62;
      ctx.lineWidth = Math.max(1.4, faceW * 0.016);
      for (let r = 0; r < rays; r++) {
        const ang = (r / rays) * Math.PI * 2;
        const pulse = REDUCE_MOTION ? 0.6 : 0.5 + 0.5 * Math.sin(timeS * 6 + r);
        const r1 = r0 + faceW * 0.14 * (0.4 + pulse);
        ctx.globalAlpha = 0.7 * A;
        ctx.strokeStyle = r % 2 ? acc : pal.primary;
        ctx.shadowColor = acc; ctx.shadowBlur = blur;
        ctx.beginPath();
        ctx.moveTo(fcx + Math.cos(ang) * r0, fcy + Math.sin(ang) * r0);
        ctx.lineTo(fcx + Math.cos(ang) * r1, fcy + Math.sin(ang) * r1);
        ctx.stroke();
      }
      // exclamation mark over the head
      ctx.globalAlpha = 0.95 * A;
      ctx.fillStyle = acc; ctx.shadowColor = acc; ctx.shadowBlur = blur * 1.3;
      ctx.font = `900 ${Math.max(16, faceW * 0.26)}px ui-sans-serif, system-ui, sans-serif`;
      ctx.textAlign = "center"; ctx.textBaseline = "alphabetic";
      ctx.fillText("!", fcx, topY - faceH * 0.18);
      break;
    }
    case "smoke": {
      for (let k = 0; k < count; k++) {
        const s = hash01(faceIndex + 5, k);
        const phase = REDUCE_MOTION ? s : (timeS * 0.12 + s) % 1;
        const ang = s * Math.PI * 2 + (REDUCE_MOTION ? 0 : timeS * 0.1);
        const rad = faceW * (0.4 + s * 0.75) * (0.6 + 0.4 * phase);
        const x = fcx + Math.cos(ang) * rad;
        const y = fcy - faceH * 0.1 - phase * faceH * 1.25;
        const a = (1 - phase) * 0.4 * A;
        if (a <= 0.01) continue;
        ctx.globalAlpha = a;
        ctx.fillStyle = k % 2 ? acc : pal.particle;
        ctx.shadowColor = acc; ctx.shadowBlur = blur * 1.6;
        ctx.beginPath();
        ctx.arc(x, y, faceW * 0.05 * (0.6 + s), 0, Math.PI * 2);
        ctx.fill();
      }
      break;
    }
    case "hearts": {
      const hc = Math.max(4, Math.round(count * 0.55));
      for (let k = 0; k < hc; k++) {
        const s = hash01(faceIndex + 13, k);
        const phase = REDUCE_MOTION ? s : (timeS * 0.3 + s) % 1;
        const x = fcx + (s - 0.5) * faceW * 1.3 + (REDUCE_MOTION ? 0 : Math.sin(timeS * 2 + k) * faceW * 0.08);
        const y = fcy - faceH * 0.1 - phase * faceH * 1.6;
        const a = (1 - phase) * 0.8 * A;
        if (a <= 0.01) continue;
        ctx.globalAlpha = a;
        ctx.fillStyle = k % 2 ? acc : pal.secondary;
        ctx.shadowColor = acc; ctx.shadowBlur = blur;
        fillHeart(ctx, x, y, faceW * 0.03 * (0.7 + s * 0.7));
      }
      break;
    }
    case "calm":
    default: {
      for (let k = 0; k < count; k++) {
        const s = hash01(faceIndex + 1, k);
        const phase = REDUCE_MOTION ? s : (timeS * (0.12 + s * 0.16) + s) % 1;
        const ang = s * Math.PI * 2 + (REDUCE_MOTION ? 0 : timeS * 0.1);
        const rad = faceW * (0.45 + s * 0.8) * (0.6 + 0.4 * phase);
        const x = fcx + Math.cos(ang) * rad;
        const y = fcy - faceH * 0.2 - phase * faceH * 1.4;
        const a = (1 - phase) * 0.45 * A;
        if (a <= 0.01) continue;
        ctx.globalAlpha = a;
        ctx.fillStyle = pal.particle;
        ctx.shadowColor = pal.particle; ctx.shadowBlur = blur * 0.8;
        ctx.beginPath();
        ctx.arc(x, y, faceW * 0.012 * (1 + s * 1.5), 0, Math.PI * 2);
        ctx.fill();
      }
      break;
    }
  }
  ctx.restore();
}

// Jagged "anger" accents: a tight cluster of furrow lines between the brows plus, for
// the most intense moods, a couple of lightning bolts at the temples.
function drawDangerAccents(
  ctx: CanvasRenderingContext2D, spec: MoodExpressionSpec, accent: string,
  fcx: number, browY: number, faceW: number, faceH: number,
  alphaBase: number, blur: number, glowMul: number,
) {
  if (spec.danger < 0.7) return;
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  ctx.lineCap = "round";
  ctx.strokeStyle = accent; ctx.shadowColor = accent; ctx.shadowBlur = blur;
  // furrow lines between the brows
  ctx.lineWidth = Math.max(1.4, faceW * 0.014);
  for (let k = 0; k < 3; k++) {
    const x = fcx + (k - 1) * faceW * 0.045;
    ctx.globalAlpha = (0.55 - Math.abs(k - 1) * 0.12) * alphaBase * glowMul;
    ctx.beginPath();
    ctx.moveTo(x, browY - faceH * 0.02);
    ctx.lineTo(x + (k - 1) * faceW * 0.015, browY + faceH * 0.07);
    ctx.stroke();
  }
  // furious → lightning bolts at the temples
  if (spec.danger >= 0.95) {
    ctx.lineWidth = Math.max(1.6, faceW * 0.018);
    for (const side of [-1, 1]) {
      const bx = fcx + side * faceW * 0.62, by = browY - faceH * 0.1;
      ctx.globalAlpha = 0.8 * alphaBase * glowMul;
      ctx.beginPath();
      ctx.moveTo(bx, by);
      ctx.lineTo(bx + side * faceW * 0.05, by + faceH * 0.06);
      ctx.lineTo(bx - side * faceW * 0.02, by + faceH * 0.08);
      ctx.lineTo(bx + side * faceW * 0.06, by + faceH * 0.16);
      ctx.stroke();
    }
  }
  ctx.restore();
}

// bbox over a landmark set in canvas space.
function bboxOf(E: Float32Array, idx: Set<number>) {
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  for (const i of idx) {
    const x = E[i * 2], y = E[i * 2 + 1];
    if (x < minX) minX = x; if (x > maxX) maxX = x;
    if (y < minY) minY = y; if (y > maxY) maxY = y;
  }
  return {
    minX, maxX, minY, maxY,
    cx: (minX + maxX) / 2, cy: (minY + maxY) / 2,
    w: Math.max(1, maxX - minX), h: Math.max(1, maxY - minY),
  };
}

// Whole-face caricature deformation: scale / shear / sag the ENTIRE head about its
// centre so the silhouette itself reads the mood (sad melts long & droops, surprised
// stretches tall, anger compresses & broadens, disgust twists to one side). Bounded by
// the caricature strength so it never tears the face apart.
function applyMoodFaceShape(
  E: Float32Array, n: number, fcx: number, fcy: number, faceH: number,
  shape: { sx: number; sy: number; skew: number; sag: number }, car: number,
) {
  const sx = 1 + shape.sx * car;
  const sy = 1 + shape.sy * car;
  const skew = shape.skew * car;
  const sag = shape.sag * car;
  if (sx === 1 && sy === 1 && skew === 0 && sag === 0) return;
  const sagDen = Math.max(1, faceH * 0.6);
  for (let i = 0; i < n; i++) {
    let dx = E[i * 2] - fcx;
    let dy = E[i * 2 + 1] - fcy;
    dx *= sx; dy *= sy;
    dx += skew * dy;
    if (sag !== 0 && dy > 0) dy += sag * (dy / sagDen) * faceH;
    E[i * 2] = fcx + dx;
    E[i * 2 + 1] = fcy + dy;
  }
}

// Rich per-eye detail: iris ring + radial striations, a bright pupil + white glint, an
// upper-lid crease arc, and a few outer-corner lashes. `side` is -1 for an eye on the
// left half of the frame, +1 for the right (so lashes fan to the OUTSIDE).
function drawEyeDetail(
  ctx: CanvasRenderingContext2D, E: Float32Array,
  eyeIdx: Set<number>, iris: { x: number; y: number }, side: number,
  pal: { primary: string; secondary: string }, alphaBase: number, blur: number,
  lw: number, detail: number,
) {
  const b = bboxOf(E, eyeIdx);
  const rad = Math.min(b.w, b.h) * 0.46;
  if (rad <= 0.5) return;
  ctx.lineCap = "round";
  // iris ring
  ctx.globalAlpha = 0.9 * alphaBase;
  ctx.strokeStyle = pal.secondary; ctx.shadowColor = pal.secondary; ctx.shadowBlur = blur * 0.8;
  ctx.lineWidth = Math.max(1, lw * 0.7);
  ctx.beginPath(); ctx.arc(iris.x, iris.y, rad, 0, Math.PI * 2); ctx.stroke();
  // radial striations
  const spokes = Math.max(6, Math.round(8 * detail));
  ctx.lineWidth = Math.max(0.8, lw * 0.45);
  ctx.globalAlpha = 0.5 * alphaBase;
  ctx.beginPath();
  for (let k = 0; k < spokes; k++) {
    const a = (k / spokes) * Math.PI * 2;
    ctx.moveTo(iris.x + Math.cos(a) * rad * 0.4, iris.y + Math.sin(a) * rad * 0.4);
    ctx.lineTo(iris.x + Math.cos(a) * rad * 0.88, iris.y + Math.sin(a) * rad * 0.88);
  }
  ctx.stroke();
  // pupil + glint
  ctx.globalAlpha = alphaBase;
  ctx.fillStyle = pal.secondary; ctx.shadowColor = pal.secondary; ctx.shadowBlur = blur;
  ctx.beginPath(); ctx.arc(iris.x, iris.y, rad * 0.34, 0, Math.PI * 2); ctx.fill();
  ctx.globalAlpha = 0.95 * alphaBase;
  ctx.fillStyle = "#ffffff"; ctx.shadowBlur = blur * 0.5;
  ctx.beginPath(); ctx.arc(iris.x - rad * 0.22, iris.y - rad * 0.22, Math.max(0.8, rad * 0.16), 0, Math.PI * 2); ctx.fill();
  // upper-lid crease
  ctx.globalAlpha = 0.5 * alphaBase * detail;
  ctx.strokeStyle = pal.secondary; ctx.shadowColor = pal.secondary; ctx.shadowBlur = blur * 0.7;
  ctx.lineWidth = Math.max(1, lw * 0.6);
  ctx.beginPath();
  ctx.moveTo(b.minX, b.minY - b.h * 0.16);
  ctx.quadraticCurveTo(b.cx, b.minY - b.h * 0.5, b.maxX, b.minY - b.h * 0.16);
  ctx.stroke();
  // outer-corner lashes
  ctx.globalAlpha = 0.7 * alphaBase * detail;
  ctx.lineWidth = Math.max(0.8, lw * 0.5);
  const outX = side < 0 ? b.minX : b.maxX;
  ctx.beginPath();
  for (let k = 0; k < 3; k++) {
    const t = k / 2;
    const bx = outX + side * b.w * 0.02 * (1 - t);
    const by = b.minY - b.h * 0.04 - t * b.h * 0.1;
    ctx.moveTo(bx, by);
    ctx.lineTo(bx + side * b.w * 0.18, by - b.h * 0.3);
  }
  ctx.stroke();
}

// Nose: nostril arcs, a bright bridge highlight, and a tip glint so the nose reads as a
// real feature instead of a faint line. Uses canonical FaceMesh indices.
function drawNoseDetail(
  ctx: CanvasRenderingContext2D, E: Float32Array,
  pal: { primary: string; secondary: string }, alphaBase: number, blur: number,
  faceW: number, lw: number,
) {
  const tipX = E[1 * 2], tipY = E[1 * 2 + 1];
  const laX = E[98 * 2], laY = E[98 * 2 + 1];
  const raX = E[327 * 2], raY = E[327 * 2 + 1];
  const brX = E[168 * 2], brY = E[168 * 2 + 1];
  ctx.lineCap = "round";
  const nr = faceW * 0.035;
  // nostril arcs (stroked separately so they don't connect)
  ctx.globalAlpha = 0.75 * alphaBase;
  ctx.strokeStyle = pal.primary; ctx.shadowColor = pal.primary; ctx.shadowBlur = blur * 0.8;
  ctx.lineWidth = Math.max(1, lw * 0.7);
  ctx.beginPath(); ctx.arc(laX, laY, nr, Math.PI * 0.15, Math.PI * 0.95); ctx.stroke();
  ctx.beginPath(); ctx.arc(raX, raY, nr, Math.PI * 0.05, Math.PI * 0.85); ctx.stroke();
  // bridge highlight
  ctx.globalAlpha = 0.6 * alphaBase;
  ctx.strokeStyle = pal.secondary; ctx.shadowColor = pal.secondary; ctx.shadowBlur = blur;
  ctx.lineWidth = Math.max(1, lw * 0.8);
  ctx.beginPath(); ctx.moveTo(brX, brY); ctx.lineTo(tipX, tipY); ctx.stroke();
  // tip glint
  ctx.globalAlpha = 0.9 * alphaBase;
  ctx.fillStyle = "#ffffff"; ctx.shadowColor = pal.secondary; ctx.shadowBlur = blur * 0.6;
  ctx.beginPath(); ctx.arc(tipX, tipY, Math.max(1, faceW * 0.012), 0, Math.PI * 2); ctx.fill();
}

// Synthesized neon hair: strands grown from the upper face-oval points, fanned outward
// with a mood-driven vertical bias (spike up for anger, droop down for sadness, …).
// MediaPipe has no hair landmarks, so this approximates a hairline from the crown arc.
function drawHair(
  ctx: CanvasRenderingContext2D, E: Float32Array,
  pal: { primary: string; secondary: string; particle: string }, style: string,
  fcx: number, fcy: number, faceW: number, faceH: number,
  alphaBase: number, blur: number, lw: number, detail: number, faceIndex: number, timeS: number,
) {
  const pts: number[] = [];
  for (const i of OVAL_IDX) if (E[i * 2 + 1] < fcy - faceH * 0.18) pts.push(i);
  if (pts.length === 0) return;
  const biasY = style === "spike" ? -1.05 : style === "up" ? -0.75 : style === "droop" ? 0.5 : -0.35;
  const lenF = style === "spike" ? 0.6 : style === "droop" ? 0.5 : 0.42;
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  ctx.lineCap = "round";
  for (let p = 0; p < pts.length; p++) {
    const i = pts[p];
    const bx = E[i * 2], by = E[i * 2 + 1];
    let nx = bx - fcx, ny = by - fcy;
    const nl = Math.hypot(nx, ny) || 1;
    nx /= nl; ny /= nl;
    let vx = nx * 0.65, vy = ny * 0.35 + biasY;
    const vl = Math.hypot(vx, vy) || 1;
    vx /= vl; vy /= vl;
    const s = hash01(faceIndex * 23 + p, 7);
    const L = faceH * lenF * (0.7 + 0.7 * s);
    const ex = bx + vx * L, ey = by + vy * L;
    const sway = (REDUCE_MOTION ? 0 : Math.sin(timeS * 2 + p) * 0.12) + (s - 0.5) * 0.5;
    const mx = (bx + ex) / 2 + (-vy) * faceW * sway;
    const my = (by + ey) / 2 + (vx) * faceW * sway;
    const col = p % 3 === 0 ? pal.secondary : pal.primary;
    // glow pass
    ctx.globalAlpha = 0.32 * alphaBase * detail;
    ctx.strokeStyle = col; ctx.shadowColor = col; ctx.shadowBlur = blur * 1.4;
    ctx.lineWidth = Math.max(1.4, lw * 1.4);
    ctx.beginPath(); ctx.moveTo(bx, by); ctx.quadraticCurveTo(mx, my, ex, ey); ctx.stroke();
    // bright core
    ctx.globalAlpha = 0.7 * alphaBase;
    ctx.shadowBlur = blur * 0.6;
    ctx.lineWidth = Math.max(1, lw * 0.7);
    ctx.beginPath(); ctx.moveTo(bx, by); ctx.quadraticCurveTo(mx, my, ex, ey); ctx.stroke();
  }
  ctx.restore();
}

function drawFace(
  ctx: CanvasRenderingContext2D, w: number, h: number,
  face: NeonMoodFace, faceIndex: number,
  m: ReturnType<typeof makeCoverMap>, params: NeonMoodParams, intensity: number, timeS: number,
) {
  const lm = face.landmarks;
  const n = face.count;
  if (!lm || n <= 0) return;

  if (_P.length < n * 2) { _P = new Float32Array(n * 2); _E = new Float32Array(n * 2); }
  const P = _P, E = _E;

  // 1) Map every landmark into cover/mirror canvas space + face centroid.
  let cxs = 0, cys = 0;
  for (let i = 0; i < n; i++) {
    const x = mapX(m, lm[i * 3]);
    const y = mapY(m, lm[i * 3 + 1]);
    P[i * 2] = x; P[i * 2 + 1] = y; cxs += x; cys += y;
  }
  const fcx = cxs / n, fcy = cys / n;

  // Face bbox (over the oval) → size + label anchor.
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  for (const i of OVAL_IDX) {
    const x = P[i * 2], y = P[i * 2 + 1];
    if (x < minX) minX = x; if (x > maxX) maxX = x;
    if (y < minY) minY = y; if (y > maxY) maxY = y;
  }
  const faceW = Math.max(1, maxX - minX);
  const faceH = Math.max(1, maxY - minY);

  const pal = MOOD_PALETTES[face.mood];
  const spec = MOOD_EXPRESSIONS[face.mood];

  // 2) Caricature exaggeration (BOLD by default).
  const car = clamp01(params.caricature / 100);
  // 2a) Global push from face centre — oval/jaw pushes out more (bigger head).
  for (let i = 0; i < n; i++) {
    const dx = P[i * 2] - fcx, dy = P[i * 2 + 1] - fcy;
    const k = OVAL_IDX.has(i) ? (1 + 0.18 * car) : (1 + 0.05 * car);
    E[i * 2] = fcx + dx * k;
    E[i * 2 + 1] = fcy + dy * k;
  }
  // 2b) Enlarge eyes around each (already-scaled) eye centre.
  const eyeK = 1 + 0.80 * car;
  const lEye0 = meanOf(E, LEFT_EYE_IDX);
  for (const i of LEFT_EYE_IDX) {
    E[i * 2] = lEye0.x + (E[i * 2] - lEye0.x) * eyeK;
    E[i * 2 + 1] = lEye0.y + (E[i * 2 + 1] - lEye0.y) * eyeK;
  }
  const rEye0 = meanOf(E, RIGHT_EYE_IDX);
  for (const i of RIGHT_EYE_IDX) {
    E[i * 2] = rEye0.x + (E[i * 2] - rEye0.x) * eyeK;
    E[i * 2 + 1] = rEye0.y + (E[i * 2 + 1] - rEye0.y) * eyeK;
  }
  // 2c) Widen the mouth around its centre.
  const mouthK = 1 + 0.40 * car;
  const mc0 = meanOf(E, LIPS_IDX);
  for (const i of LIPS_IDX) {
    E[i * 2] = mc0.x + (E[i * 2] - mc0.x) * mouthK;
    E[i * 2 + 1] = mc0.y + (E[i * 2 + 1] - mc0.y) * mouthK;
  }

  // 2c2) WHOLE-FACE caricature deformation — the silhouette itself reads the mood
  // (sad melts long & droops, surprised stretches tall, anger compresses & broadens…).
  applyMoodFaceShape(E, n, fcx, fcy, faceH, spec.shape, car);

  // 2d) MOOD WARP — bend brows/eyes/mouth so the line-art reads the emotion.
  applyMoodWarp(E, fcx, faceW, faceH, spec, car);

  // 2e) Tremble for intense/negative moods (frozen under reduce-motion).
  if (spec.danger > 0.55 && !REDUCE_MOTION) {
    const amp = faceW * 0.012 * spec.danger;
    const jx = Math.sin(timeS * 47) * amp, jy = Math.cos(timeS * 41) * amp * 0.7;
    for (let i = 0; i < n; i++) { E[i * 2] += jx; E[i * 2 + 1] += jy; }
  }

  const fade = face.fade;
  const alphaBase = intensity * fade;
  const glowMul = GLOW_MUL[params.glow];
  const blur = GLOW_BASE[params.glow] * (0.55 + 0.45 * intensity) * glowMul;
  const sizeScale = faceW / 340;
  const lw = Math.max(1.2, (1.4 + (params.lineThickness / 100) * 6.5) * sizeScale);
  const detail = spec.detail;

  // Anchors used by the detail + FX layers (post-warp).
  const lEye = meanOf(E, LEFT_EYE_IDX);
  const rEye = meanOf(E, RIGHT_EYE_IDX);
  const mc = meanOf(E, LIPS_IDX);
  const lIris = meanOf(E, L_IRIS_IDX);
  const rIris = meanOf(E, R_IRIS_IDX);
  let browY = -Infinity;
  for (const i of BROW_IDX) { const y = E[i * 2 + 1]; if (y > browY) browY = y; }
  if (!isFinite(browY)) browY = minY + faceH * 0.25;

  // 3) Mood ambiance — a darker vignette around the face for intense/negative moods,
  // then the additive mood-tinted bloom. (Vignette only on the first face to avoid
  // double-darkening when two people are in frame.)
  if (spec.danger >= 0.6 && faceIndex === 0) {
    ctx.save();
    const vr = Math.max(faceW, faceH) * 2.4;
    const vg = ctx.createRadialGradient(fcx, fcy, vr * 0.35, fcx, fcy, vr);
    vg.addColorStop(0, "rgba(0,0,0,0)");
    vg.addColorStop(1, `rgba(0,0,0,${0.42 * alphaBase * spec.danger})`);
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, w, h);
    ctx.restore();
  }

  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  const r = Math.max(faceW, faceH) * 1.3;
  const grd = ctx.createRadialGradient(fcx, fcy, r * 0.12, fcx, fcy, r);
  grd.addColorStop(0, rgba(pal.primary, 0.24 * alphaBase * glowMul));
  grd.addColorStop(0.55, rgba(pal.secondary, 0.11 * alphaBase * glowMul));
  grd.addColorStop(1, rgba(pal.primary, 0));
  ctx.globalAlpha = 1;
  ctx.fillStyle = grd;
  ctx.beginPath();
  ctx.arc(fcx, fcy, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // 3b) Synthesized neon hair behind the face line-art (mood-driven up/droop/spike).
  drawHair(ctx, E, pal, spec.hair, fcx, fcy, faceW, faceH, alphaBase, blur, lw, detail, faceIndex, timeS);

  // 4) Neon line art — three passes (ultra-wide aura, soft, crisp core), additive.
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  const groups: { conns: Conn[]; color: string }[] = [
    { conns: OVAL, color: pal.primary },
    { conns: NOSE, color: pal.primary },
    { conns: LIPS, color: pal.primary },
    { conns: LEYE, color: pal.secondary },
    { conns: REYE, color: pal.secondary },
    { conns: LIRIS, color: pal.secondary },
    { conns: RIRIS, color: pal.secondary },
    { conns: LBROW, color: pal.secondary },
    { conns: RBROW, color: pal.secondary },
  ];
  // 4a) Outer halo oval — a second, pushed-out face outline for extra depth/detail.
  ctx.save();
  ctx.translate(fcx, fcy);
  ctx.scale(1.07, 1.07);
  ctx.translate(-fcx, -fcy);
  strokeConns(ctx, E, OVAL, pal.primary, lw * 1.3, blur * 1.8, 0.28 * alphaBase * detail);
  ctx.restore();
  // 4b) Ultra-wide aura (density scaled by mood detail).
  for (const grp of groups) {
    strokeConns(ctx, E, grp.conns, grp.color, lw * 3.0, blur * 2.0, 0.30 * alphaBase * detail);
  }
  // 4c) Soft pass.
  for (const grp of groups) {
    strokeConns(ctx, E, grp.conns, grp.color, lw * 1.8, blur * 1.4, 0.5 * alphaBase);
  }
  // 4d) Crisp bright core.
  for (const grp of groups) {
    strokeConns(ctx, E, grp.conns, grp.color, lw, blur * 0.7, alphaBase);
  }
  ctx.restore();

  // 5) Dense extra detail — rich eyes, a real nose, under-eye accents, cheek stardust.
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  ctx.lineCap = "round";
  // detailed eyes (iris ring + striations + pupil/glint + lid crease + lashes)
  drawEyeDetail(ctx, E, LEFT_EYE_IDX, lIris, lIris.x < fcx ? -1 : 1, pal, alphaBase, blur, lw, detail);
  drawEyeDetail(ctx, E, RIGHT_EYE_IDX, rIris, rIris.x < fcx ? -1 : 1, pal, alphaBase, blur, lw, detail);
  // detailed nose (nostrils + bridge highlight + tip glint)
  drawNoseDetail(ctx, E, pal, alphaBase, blur, faceW, lw);
  // under-eye accent strokes
  ctx.strokeStyle = pal.secondary; ctx.shadowColor = pal.secondary; ctx.shadowBlur = blur * 0.8;
  ctx.lineWidth = Math.max(1, lw * 0.7);
  for (const eye of [lEye, rEye]) {
    ctx.globalAlpha = 0.55 * alphaBase * detail;
    ctx.beginPath();
    ctx.moveTo(eye.x - faceW * 0.07, eye.y + faceH * 0.09);
    ctx.quadraticCurveTo(eye.x, eye.y + faceH * 0.12, eye.x + faceW * 0.07, eye.y + faceH * 0.09);
    ctx.stroke();
  }
  // cheek "stardust" clusters (between eye and mouth, pushed outward)
  const dots = Math.round(4 * detail);
  for (const side of [-1, 1]) {
    const baseX = fcx + side * faceW * 0.3;
    const baseY = (fcy + mc.y) / 2;
    for (let d = 0; d < dots; d++) {
      const s = hash01(faceIndex * 17 + side, d);
      const dx = (s - 0.5) * faceW * 0.16;
      const dy = (hash01(faceIndex * 19 + side, d) - 0.5) * faceH * 0.14;
      ctx.globalAlpha = (0.35 + 0.4 * s) * alphaBase * detail;
      ctx.fillStyle = pal.particle; ctx.shadowColor = pal.particle; ctx.shadowBlur = blur * 0.6;
      ctx.beginPath();
      ctx.arc(baseX + dx, baseY + dy, Math.max(0.8, faceW * 0.008 * (0.6 + s)), 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.restore();

  // 6) Mood-specific FX + intense-mood accents.
  const count = Math.round(PARTICLES[params.glow] * (0.7 + 0.5 * detail));
  drawMoodFx(ctx, spec, pal, fcx, fcy, faceW, faceH, minY, lEye, rEye,
    alphaBase, blur, glowMul, count, timeS, faceIndex);
  drawDangerAccents(ctx, spec, spec.accent, fcx, browY, faceW, faceH, alphaBase, blur, glowMul);

  // 7) Mood label + confidence meter above the head.
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  const fs = Math.max(13, faceW * 0.14);
  const labelY = minY - faceH * 0.16;
  ctx.font = `800 ${fs}px ui-sans-serif, system-ui, -apple-system, sans-serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "alphabetic";
  ctx.globalAlpha = alphaBase * 0.95;
  ctx.fillStyle = pal.primary;
  ctx.shadowColor = pal.primary;
  ctx.shadowBlur = blur * 1.3;
  ctx.fillText(pal.label.toUpperCase(), fcx, labelY);
  // confidence meter (gap-to-runner-up, amplified for readability)
  const conf = clamp01(face.moodConfidence * 3);
  const mw = faceW * 0.5, mh = Math.max(3, faceW * 0.02);
  const mx = fcx - mw / 2, my = labelY + fs * 0.28;
  ctx.shadowBlur = 0;
  ctx.globalAlpha = alphaBase * 0.3;
  ctx.fillStyle = pal.secondary;
  ctx.fillRect(mx, my, mw, mh);
  ctx.globalAlpha = alphaBase * 0.95;
  ctx.fillStyle = pal.primary;
  ctx.shadowColor = pal.primary;
  ctx.shadowBlur = blur * 0.8;
  ctx.fillRect(mx, my, mw * conf, mh);
  ctx.restore();
}

export function renderNeonMood(
  ctx: CanvasRenderingContext2D, w: number, h: number,
  tracking: NeonMoodTracking | null, vw: number, vh: number, mirror: boolean,
  params: NeonMoodParams,
) {
  if (!params.enabled || !tracking) return;
  const intensity = clamp01(params.intensity / 100);
  if (intensity <= 0) return;
  const faces = tracking.faces;
  if (!faces || faces.length === 0) return;

  const m = makeCoverMap(w, h, vw, vh, mirror);
  const timeS = performance.now() / 1000;
  for (let i = 0; i < faces.length; i++) {
    const face = faces[i];
    if (!face || face.fade <= 0) continue;
    drawFace(ctx, w, h, face, i, m, params, intensity, timeS);
  }
}
