// ── Neon Mood Caricature — shared types & palettes ──────────────────────────────
// PREVIEW-ONLY subsystem (not yet wired into CameraStudio). Mirrors the existing
// face-filter data contract: an async tracker writes smoothed snapshots that a
// synchronous Canvas2D renderer consumes via (ctx,w,h,tracking,vw,vh,mirror,params).
//
// Unlike NeonPatriotTracker (single face, no blendshapes) this subsystem tracks up
// to TWO faces independently and uses FaceLandmarker blendshapes to estimate a
// per-face mood, which selects a neon palette and drives a bold caricature look.

export type NeonMoodId =
  // positive / neutral
  | "joyful"
  | "happy"
  | "energetic"
  | "romantic"
  | "calm"
  | "melancholy"
  | "mysterious"
  | "confident"
  // negative / intense — added so the filter expresses the REAL detected emotion
  | "angry"
  | "furious"
  | "sad"
  | "fearful"
  | "disgusted"
  | "surprised";

export const MOOD_IDS: NeonMoodId[] = [
  "joyful", "happy", "energetic", "romantic",
  "calm", "melancholy", "mysterious", "confident",
  "angry", "furious", "sad", "fearful", "disgusted", "surprised",
];

export interface MoodPalette {
  id: NeonMoodId;
  label: string;
  primary: string;    // dominant neon line/glow colour
  secondary: string;  // accent neon (eyes / brows / inner detail)
  particle: string;   // mood particle tint
}

// Mood palettes — positive/neutral first, then negative/intense. Negatives lean into
// hot reds (anger), cold blues (sadness), icy violets (fear), and toxic greens (disgust)
// so the colour alone already reads the emotion before the FX layer reinforces it.
export const MOOD_PALETTES: Record<NeonMoodId, MoodPalette> = {
  joyful:     { id: "joyful",     label: "Joyful",     primary: "#39ff14", secondary: "#faff00", particle: "#9dff5c" },
  happy:      { id: "happy",      label: "Happy",      primary: "#ffe600", secondary: "#ffb300", particle: "#ffd84d" },
  energetic:  { id: "energetic",  label: "Energetic",  primary: "#ff6a00", secondary: "#ff1e3c", particle: "#ff5a3c" },
  romantic:   { id: "romantic",   label: "Romantic",   primary: "#ff4fd8", secondary: "#ff1e88", particle: "#ff86e3" },
  calm:       { id: "calm",       label: "Calm",       primary: "#27a8ff", secondary: "#1fe6d4", particle: "#6fd9ff" },
  melancholy: { id: "melancholy", label: "Melancholy", primary: "#7a5cff", secondary: "#2f6bff", particle: "#a394ff" },
  mysterious: { id: "mysterious", label: "Mysterious", primary: "#1fe6d4", secondary: "#9b4bff", particle: "#74dccf" },
  confident:  { id: "confident",  label: "Confident",  primary: "#ff2d3c", secondary: "#ffb01e", particle: "#ff6a4d" },
  angry:      { id: "angry",      label: "Angry",      primary: "#ff2a1a", secondary: "#ff8a00", particle: "#ff5a3c" },
  furious:    { id: "furious",    label: "Furious",    primary: "#ff0033", secondary: "#ffd000", particle: "#ff6a00" },
  sad:        { id: "sad",        label: "Sad",        primary: "#2f7bff", secondary: "#37d4ff", particle: "#86b6ff" },
  fearful:    { id: "fearful",    label: "Fearful",    primary: "#9d7bff", secondary: "#22f5ff", particle: "#cdbcff" },
  disgusted:  { id: "disgusted",  label: "Disgusted",  primary: "#b6ff1a", secondary: "#8a2be2", particle: "#a6e34d" },
  surprised:  { id: "surprised",  label: "Surprised",  primary: "#00e5ff", secondary: "#fff200", particle: "#9bf6ff" },
};

export type NMGlow = "low" | "med" | "high";

export const NM_GLOW_LEVELS: { id: NMGlow; label: string }[] = [
  { id: "low", label: "Low" },
  { id: "med", label: "Med" },
  { id: "high", label: "High" },
];

export interface NeonMoodParams {
  enabled: boolean;
  intensity: number;     // 0..100 — overall strength of the whole effect
  lineThickness: number; // 0..100 — neon stroke width scaler
  glow: NMGlow;          // bloom strength; "high" ALSO requests auto-black studio bg
  caricature: number;    // 0..100 — exaggeration strength (default BOLD)
  moodLock: boolean;     // freeze each face's detected mood until unlocked
}

// Default = BOLD caricature, HIGH glow (per the user's approved decisions).
export const DEFAULT_NEON_MOOD_PARAMS: NeonMoodParams = {
  enabled: true,
  intensity: 85,
  lineThickness: 55,
  glow: "high",
  caricature: 80,
  moodLock: false,
};

// Per-face snapshot consumed by the synchronous renderer each compositor frame.
export interface NeonMoodFace {
  // Smoothed NORMALIZED landmarks, flat [x,y,z,...] in raw-video space (0..1).
  landmarks: Float32Array;
  count: number;          // number of landmarks present
  fade: number;           // 0..1 presence factor (decays after tracking loss)
  mood: NeonMoodId;       // current (possibly locked) mood for this face
  moodConfidence: number; // 0..1 separation between the top two mood scores
}

export interface NeonMoodTracking {
  faces: NeonMoodFace[];  // up to 2, independent identities
}
