// ── Neon Mood — per-mood expression specs ──────────────────────────────────────
// A data-driven description of HOW each mood should be drawn, so the renderer stays a
// set of small geometric helpers instead of one giant per-mood switch. Each spec says
// how to bend the brows / eyes / mouth (the caricature reads the EMOTION, not just a
// colour), which particle/effect family reinforces it, an accent colour for that FX, a
// `danger` factor (drives jitter, jagged accents, a darker vignette for intense/negative
// moods) and a `detail` multiplier for the dense line-art pass.
//
// Keyed by Record<NeonMoodId, …> so adding a mood is compiler-enforced everywhere.

import { type NeonMoodId } from "./types";

export type BrowShape = "neutral" | "raise" | "furrow" | "droop" | "arch";
export type EyeShape = "neutral" | "wide" | "narrow" | "droop";
export type MouthShape = "neutral" | "smile" | "frown" | "open" | "tight" | "sneer";
export type MoodFx =
  | "sparks"   // bright shooting streaks (joy / energy)
  | "steam"    // wavy heat lines rising (anger)
  | "fire"     // jagged flame tongues (furious)
  | "tears"    // droplets falling from the eyes (sad)
  | "rain"     // diagonal streaks (melancholy)
  | "sweat"    // beads sliding down the temples (fear)
  | "burst"    // radial surprise lines + exclamation (surprise)
  | "smoke"    // soft drifting blobs (mysterious / disgust)
  | "hearts"   // floating hearts (romantic)
  | "calm";    // slow gentle motes (calm / neutral)

// Whole-face caricature deformation — the entire head stretches / shrinks / twists to
// sell the emotion (sad melts long & droops, surprised stretches tall, anger compresses
// & broadens, disgust skews to one side). Values are small DELTAS scaled by caricature:
// the head scales by (1 + sx*car) horizontally and (1 + sy*car) vertically, `skew`
// shears X by Y, and `sag` drags lower-face points further down (or up if negative).
export interface FaceShape {
  sx: number;   // horizontal stretch delta
  sy: number;   // vertical stretch delta
  skew: number; // horizontal shear (twist)
  sag: number;  // lower-face droop (positive) / lift (negative)
}

// Hair behaviour — synthesized neon strands above the face read the mood too.
export type HairStyle = "soft" | "up" | "droop" | "spike";

export interface MoodExpressionSpec {
  brow: BrowShape;
  eye: EyeShape;
  mouth: MouthShape;
  fx: MoodFx;
  accent: string;   // FX tint (often hotter/colder than the palette for punch)
  danger: number;   // 0..1 negativity/intensity — jitter, jagged accents, vignette
  detail: number;   // 0.8..1.5 dense line-art density multiplier
  shape: FaceShape; // whole-face exaggeration
  hair: HairStyle;  // synthesized neon hair behaviour
}

export const MOOD_EXPRESSIONS: Record<NeonMoodId, MoodExpressionSpec> = {
  // positive / neutral
  joyful:     { brow: "raise",  eye: "wide",   mouth: "smile",  fx: "sparks", accent: "#fffb8a", danger: 0,    detail: 1.15, shape: { sx: 0.06, sy: 0.00, skew: 0,     sag: -0.03 }, hair: "up"    },
  happy:      { brow: "neutral",eye: "narrow", mouth: "smile",  fx: "sparks", accent: "#ffe66b", danger: 0,    detail: 1.0,  shape: { sx: 0.05, sy: -0.02,skew: 0,     sag: -0.02 }, hair: "soft"  },
  energetic:  { brow: "raise",  eye: "wide",   mouth: "open",   fx: "sparks", accent: "#ff7a3c", danger: 0,    detail: 1.2,  shape: { sx: 0.03, sy: 0.05, skew: 0,     sag: -0.03 }, hair: "up"    },
  romantic:   { brow: "arch",   eye: "droop",  mouth: "smile",  fx: "hearts", accent: "#ff86e3", danger: 0,    detail: 1.05, shape: { sx: 0.02, sy: 0.02, skew: 0.015, sag: 0.00  }, hair: "soft"  },
  calm:       { brow: "neutral",eye: "neutral",mouth: "neutral",fx: "calm",   accent: "#9fe6ff", danger: 0,    detail: 0.9,  shape: { sx: 0.00, sy: 0.00, skew: 0,     sag: 0.00  }, hair: "soft"  },
  melancholy: { brow: "droop",  eye: "droop",  mouth: "frown",  fx: "rain",   accent: "#9fb6ff", danger: 0.3,  detail: 1.0,  shape: { sx: -0.03,sy: 0.08, skew: 0,     sag: 0.04  }, hair: "droop" },
  mysterious: { brow: "arch",   eye: "narrow", mouth: "neutral",fx: "smoke",  accent: "#9b4bff", danger: 0.2,  detail: 1.1,  shape: { sx: 0.00, sy: 0.02, skew: 0.035, sag: 0.00  }, hair: "soft"  },
  confident:  { brow: "furrow", eye: "narrow", mouth: "smile",  fx: "sparks", accent: "#ffb01e", danger: 0.1,  detail: 1.05, shape: { sx: 0.04, sy: -0.01,skew: 0,     sag: -0.02 }, hair: "up"    },
  // negative / intense
  angry:      { brow: "furrow", eye: "narrow", mouth: "tight",  fx: "steam",  accent: "#ff3a1a", danger: 0.8,  detail: 1.3,  shape: { sx: 0.06, sy: -0.05,skew: 0,     sag: -0.02 }, hair: "spike" },
  furious:    { brow: "furrow", eye: "narrow", mouth: "sneer",  fx: "fire",   accent: "#ff5a00", danger: 1.0,  detail: 1.45, shape: { sx: 0.08, sy: -0.07,skew: 0,     sag: -0.03 }, hair: "spike" },
  sad:        { brow: "droop",  eye: "droop",  mouth: "frown",  fx: "tears",  accent: "#56b6ff", danger: 0.45, detail: 1.1,  shape: { sx: -0.04,sy: 0.14, skew: 0,     sag: 0.07  }, hair: "droop" },
  fearful:    { brow: "raise",  eye: "wide",   mouth: "open",   fx: "sweat",  accent: "#9be8ff", danger: 0.6,  detail: 1.2,  shape: { sx: -0.03,sy: 0.10, skew: 0,     sag: 0.02  }, hair: "up"    },
  disgusted:  { brow: "furrow", eye: "narrow", mouth: "sneer",  fx: "smoke",  accent: "#9bff3a", danger: 0.5,  detail: 1.2,  shape: { sx: 0.03, sy: -0.02,skew: 0.07,  sag: 0.00  }, hair: "spike" },
  surprised:  { brow: "raise",  eye: "wide",   mouth: "open",   fx: "burst",  accent: "#fff200", danger: 0.25, detail: 1.25, shape: { sx: -0.02,sy: 0.16, skew: 0,     sag: -0.02 }, hair: "up"    },
};
