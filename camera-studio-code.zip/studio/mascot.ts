// ── Mascot — live full-body AR puppet costume (green/purple) ─────────────────────
// Tomorrow's AI Filter Challenge. An OVERLAY (drawn after the base video into the same
// bake context, so it survives photo + video capture). Recolours the segmented person
// silhouette into a fuzzy green creature with a purple belly, then drops big googly
// mascot eyes + a mouth anchored to the face. Matches the green/purple puppet reference.
//
// Inputs: the person mask (selfie segmenter, alpha = person), a reusable scratch ctx
// for the recolour composite, and the shared face tracker snapshot for the eyes/mouth.
// The mask is applied in the SAME cover+mirror space the base video was drawn in, so
// the costume registers to the body. Intensity 0 = nothing drawn (clean no-op). When
// no mask is ready yet the overlay no-ops (plain video shows) until the model loads.

import type { NeonPatriotTracking } from "./neonPatriot";

function clamp01(x: number): number { return x < 0 ? 0 : x > 1 ? 1 : x; }

interface Cover { sw: number; sh: number; ox: number; oy: number; }
function coverParams(vw: number, vh: number, cw: number, ch: number): Cover {
  const scale = Math.max(cw / vw, ch / vh);
  const sw = vw * scale, sh = vh * scale;
  return { sw, sh, ox: (cw - sw) / 2, oy: (ch - sh) / 2 };
}

interface FaceBox { x: number; y: number; w: number; h: number; cx: number; }
function faceBoxDest(
  tracking: NeonPatriotTracking | null, vw: number, vh: number, cw: number, ch: number, mirror: boolean,
): FaceBox | null {
  const lm = tracking?.landmarks; const n = tracking?.count ?? 0;
  if (!lm || n <= 0) return null;
  let minX = 1, maxX = 0, minY = 1, maxY = 0;
  for (let i = 0; i < n; i++) {
    const x = lm[i * 3], y = lm[i * 3 + 1];
    if (x < minX) minX = x; if (x > maxX) maxX = x;
    if (y < minY) minY = y; if (y > maxY) maxY = y;
  }
  const { sw, sh, ox, oy } = coverParams(vw, vh, cw, ch);
  const toX = (nx: number) => { const dx = ox + nx * sw; return mirror ? cw - dx : dx; };
  const toY = (ny: number) => oy + ny * sh;
  let x0 = toX(minX), x1 = toX(maxX);
  if (x0 > x1) { const t = x0; x0 = x1; x1 = t; }
  const y0 = toY(minY), y1 = toY(maxY);
  return { x: x0, y: y0, w: x1 - x0, h: y1 - y0, cx: (x0 + x1) / 2 };
}

function drawGoogly(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, frame: number, phase: number) {
  ctx.save();
  ctx.fillStyle = "#ffffff";
  ctx.strokeStyle = "#0d0d0d";
  ctx.lineWidth = Math.max(2, r * 0.12);
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  // Wobbling pupil — the "googly" motion.
  const a = frame * 0.05 + phase;
  const px = x + Math.cos(a) * r * 0.34;
  const py = y + Math.sin(a * 1.3) * r * 0.34;
  ctx.fillStyle = "#0d0d0d";
  ctx.beginPath(); ctx.arc(px, py, r * 0.46, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = "rgba(255,255,255,0.9)";
  ctx.beginPath(); ctx.arc(px - r * 0.16, py - r * 0.16, r * 0.13, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
}

// Draw the mascot costume + face. `srcCanvas` is the bake canvas itself (it already
// holds the plain cover video), reused as the pixel source for the recolour.
export function renderMascot(
  ctx: CanvasRenderingContext2D, cw: number, ch: number, frame: number,
  mask: HTMLCanvasElement | null, scratchCtx: CanvasRenderingContext2D | null,
  tracking: NeonPatriotTracking | null, vw: number, vh: number, mirror: boolean, intensity: number,
) {
  const t = clamp01(intensity);
  if (!mask || !scratchCtx || t <= 0.001) return;
  const { sw, sh, ox, oy } = coverParams(vw, vh, cw, ch);
  const sc = scratchCtx;

  // 1) Person-only copy of the already-baked plain frame.
  sc.setTransform(1, 0, 0, 1, 0, 0);
  sc.globalCompositeOperation = "source-over";
  sc.globalAlpha = 1;
  sc.clearRect(0, 0, cw, ch);
  sc.drawImage(ctx.canvas, 0, 0);
  sc.save();
  sc.globalCompositeOperation = "destination-in";
  sc.imageSmoothingEnabled = true;
  if (mirror) { sc.translate(cw, 0); sc.scale(-1, 1); }
  sc.drawImage(mask, ox, oy, sw, sh);
  sc.restore();
  sc.globalCompositeOperation = "source-over";

  // 2) Recolour to green (keeps the body's own shading via the "color" blend), then
  // reclip to the silhouette (the blend bleeds onto transparent pixels otherwise).
  sc.save();
  sc.globalCompositeOperation = "color";
  sc.fillStyle = "#3aa80f";
  sc.fillRect(0, 0, cw, ch);
  sc.restore();
  sc.save();
  sc.globalCompositeOperation = "destination-in";
  if (mirror) { sc.translate(cw, 0); sc.scale(-1, 1); }
  sc.drawImage(mask, ox, oy, sw, sh);
  sc.restore();
  sc.globalCompositeOperation = "source-over";

  // 3) Deepen the green + add a purple belly, both clipped to the person (source-atop).
  const fb = faceBoxDest(tracking, vw, vh, cw, ch, mirror);
  const bellyX = fb ? fb.cx : cw * 0.5;
  const bellyY = fb ? Math.min(ch * 0.92, fb.y + fb.h * 3.0) : ch * 0.62;
  const bellyR = (fb ? fb.w * 1.5 : cw * 0.2);
  sc.save();
  sc.globalCompositeOperation = "source-atop";
  const tint = sc.createLinearGradient(0, 0, 0, ch);
  tint.addColorStop(0, "rgba(60,180,30,0.35)");
  tint.addColorStop(1, "rgba(20,90,10,0.45)");
  sc.fillStyle = tint;
  sc.fillRect(0, 0, cw, ch);
  const belly = sc.createRadialGradient(bellyX, bellyY, 0, bellyX, bellyY, bellyR);
  belly.addColorStop(0, "rgba(157,78,221,0.92)");
  belly.addColorStop(0.7, "rgba(123,47,247,0.5)");
  belly.addColorStop(1, "rgba(123,47,247,0)");
  sc.fillStyle = belly;
  sc.fillRect(0, 0, cw, ch);
  sc.restore();
  sc.globalCompositeOperation = "source-over";

  // 4) Blit the creature onto the bake context — a fuzzy "fur" halo pass, then crisp.
  ctx.save();
  ctx.globalAlpha = t;
  ctx.shadowColor = "rgba(90,225,45,0.9)";
  ctx.shadowBlur = 20;
  ctx.drawImage(sc.canvas, 0, 0);
  ctx.shadowBlur = 0;
  ctx.drawImage(sc.canvas, 0, 0);
  ctx.restore();

  // 5) Googly eyes + mouth on the face (the personality). Only when a face is present.
  if (fb && fb.w > 8) {
    ctx.save();
    ctx.globalAlpha = t;
    const eyeR = Math.max(16, fb.w * 0.26);
    const eyeY = fb.y + fb.h * 0.26;
    const lx = fb.cx - fb.w * 0.26;
    const rx = fb.cx + fb.w * 0.26;
    drawGoogly(ctx, lx, eyeY, eyeR, frame, 0);
    drawGoogly(ctx, rx, eyeY, eyeR, frame, 1.7);

    // Mouth — open grin with a tongue.
    const mouthY = fb.y + fb.h * 0.86;
    const mouthW = fb.w * 0.56;
    const mouthH = fb.h * 0.26;
    ctx.fillStyle = "#5a1e00";
    ctx.strokeStyle = "#2a0e00";
    ctx.lineWidth = Math.max(2, fb.w * 0.03);
    ctx.beginPath();
    ctx.ellipse(fb.cx, mouthY, mouthW / 2, mouthH / 2, 0, 0, Math.PI * 2);
    ctx.fill(); ctx.stroke();
    ctx.fillStyle = "#ff4d6d";
    ctx.beginPath();
    ctx.ellipse(fb.cx, mouthY + mouthH * 0.16, mouthW * 0.3, mouthH * 0.3, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // Leave the context clean for any later draws (Motion Ink etc.).
  ctx.globalAlpha = 1;
  ctx.shadowBlur = 0;
  ctx.globalCompositeOperation = "source-over";
}
