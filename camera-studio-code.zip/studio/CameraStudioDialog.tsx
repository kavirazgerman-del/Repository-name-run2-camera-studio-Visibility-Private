import React from "react";
import { createPortal } from "react-dom";
import { Camera } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CameraStudio } from "./CameraStudio";

interface Props { children?: React.ReactNode; openOnMount?: boolean; challengeId?: number; preselectMusicTrackId?: number; duetOfPostId?: number; }

export function CameraStudioDialog({ children, openOnMount = false, challengeId, preselectMusicTrackId, duetOfPostId }: Props) {
  const [open, setOpen] = React.useState(openOnMount);

  return (
    <>
      <span onClick={() => setOpen(true)} style={{ display: "contents" }}>
        {children ?? (
          <Button variant="outline" className="gap-2 border-r2c-green/40 text-r2c-green hover:bg-r2c-green/10 hover:text-r2c-green hover:border-r2c-green">
            <Camera className="w-4 h-4" />
            <span className="hidden sm:inline">Camera Studio</span>
          </Button>
        )}
      </span>

      {open && createPortal(
        <div
          className="fixed inset-0 bg-black z-[100]"
          style={{ touchAction: "none" }}
        >
          <CameraStudio onClose={() => setOpen(false)} challengeId={challengeId} preselectMusicTrackId={preselectMusicTrackId} duetOfPostId={duetOfPostId} />
        </div>,
        document.body
      )}
    </>
  );
}
