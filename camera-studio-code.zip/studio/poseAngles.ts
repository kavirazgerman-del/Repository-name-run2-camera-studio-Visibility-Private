// ── Studio pose — PURE joint-angle math (no DOM, no three, no MediaPipe) ─────────
// Turns a 33×3 body-pose world-landmark buffer into interior joint angles. Kept
// dependency-free + isomorphic so the hard math is unit-testable in Node (this
// environment has no WebGL2 / no webcam, so anything that touches the camera can only
// be checked on a real device — see poseAngles.test.ts).
//
// It is deliberately generic infrastructure: it knows nothing about any specific
// filter, the Army Bunny rig, or the Echo Challenge scoring model. A consumer picks
// whichever angles it needs.

export type Vec3 = readonly [number, number, number];

// MediaPipe BlazePose 33-landmark indices we care about for limb angles.
export const POSE_LANDMARKS = {
  leftShoulder: 11, rightShoulder: 12,
  leftElbow: 13, rightElbow: 14,
  leftWrist: 15, rightWrist: 16,
  leftHip: 23, rightHip: 24,
  leftKnee: 25, rightKnee: 26,
  leftAnkle: 27, rightAnkle: 28,
} as const;

const EPS = 1e-6;
const RAD_TO_DEG = 180 / Math.PI;

/**
 * Interior angle (radians) at vertex `b` of the path a–b–c, i.e. the angle between
 * the segments b→a and b→c. Uses a clamped acos so floating-point drift past ±1 can
 * never produce NaN, and guards a zero-length adjacent segment by returning a defined
 * value (0) rather than NaN. Always finite.
 */
export function jointAngleRad(a: Vec3, b: Vec3, c: Vec3): number {
  const ux = a[0] - b[0], uy = a[1] - b[1], uz = a[2] - b[2];
  const vx = c[0] - b[0], vy = c[1] - b[1], vz = c[2] - b[2];
  const lu = Math.hypot(ux, uy, uz);
  const lv = Math.hypot(vx, vy, vz);
  if (lu < EPS || lv < EPS) return 0; // degenerate: no defined angle → finite fallback
  let cos = (ux * vx + uy * vy + uz * vz) / (lu * lv);
  if (cos > 1) cos = 1; else if (cos < -1) cos = -1;
  return Math.acos(cos);
}

/** Same as {@link jointAngleRad} but in degrees. Always finite. */
export function jointAngleDeg(a: Vec3, b: Vec3, c: Vec3): number {
  return jointAngleRad(a, b, c) * RAD_TO_DEG;
}

/** Read landmark `i` from a flat 33×3 buffer; null if out of range or non-finite. */
function landmark(world: ArrayLike<number>, i: number): Vec3 | null {
  const o = i * 3;
  if (o < 0 || o + 2 >= world.length) return null;
  const x = world[o], y = world[o + 1], z = world[o + 2];
  if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(z)) return null;
  return [x, y, z];
}

/**
 * Angle (degrees) at vertex `j` formed by the triple i–j–k, read from a flat 33×3
 * world-landmark buffer. Returns null when any landmark is missing (short buffer /
 * non-finite) or the pose is degenerate (a coincident/zero-length adjacent segment),
 * so callers can distinguish "no reliable angle" from a real measurement.
 */
export function landmarkAngleDeg(world: ArrayLike<number>, i: number, j: number, k: number): number | null {
  const A = landmark(world, i), B = landmark(world, j), C = landmark(world, k);
  if (!A || !B || !C) return null;
  const lu = Math.hypot(A[0] - B[0], A[1] - B[1], A[2] - B[2]);
  const lv = Math.hypot(C[0] - B[0], C[1] - B[1], C[2] - B[2]);
  if (lu < EPS || lv < EPS) return null;
  return jointAngleDeg(A, B, C);
}

/** Precomputed common limb angles (degrees), each null when unmeasurable. */
export interface PoseAngles {
  leftElbow: number | null;
  rightElbow: number | null;
  leftKnee: number | null;
  rightKnee: number | null;
  leftShoulder: number | null;
  rightShoulder: number | null;
  leftHip: number | null;
  rightHip: number | null;
}

/**
 * Compute the standard limb angles from a 33×3 world-landmark buffer. Elbows/knees are
 * the classic 3-joint flexion angles; shoulder/hip measure the arm-to-torso and
 * thigh-to-torso opening. Every field degrades to null independently.
 */
export function computePoseAngles(world: ArrayLike<number>): PoseAngles {
  const L = POSE_LANDMARKS;
  return {
    leftElbow: landmarkAngleDeg(world, L.leftShoulder, L.leftElbow, L.leftWrist),
    rightElbow: landmarkAngleDeg(world, L.rightShoulder, L.rightElbow, L.rightWrist),
    leftKnee: landmarkAngleDeg(world, L.leftHip, L.leftKnee, L.leftAnkle),
    rightKnee: landmarkAngleDeg(world, L.rightHip, L.rightKnee, L.rightAnkle),
    leftShoulder: landmarkAngleDeg(world, L.leftElbow, L.leftShoulder, L.leftHip),
    rightShoulder: landmarkAngleDeg(world, L.rightElbow, L.rightShoulder, L.rightHip),
    leftHip: landmarkAngleDeg(world, L.leftShoulder, L.leftHip, L.leftKnee),
    rightHip: landmarkAngleDeg(world, L.rightShoulder, L.rightHip, L.rightKnee),
  };
}
