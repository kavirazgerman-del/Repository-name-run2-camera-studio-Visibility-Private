// ── Solargraph — offscreen WebGL2 tonal-grade + halation image processor ─────────
// Reads the ALREADY-DRAWN 1280x720 bake frame as a texture and returns an opaque
// processed copy (full frame, no zoom/crop) that the 2D compositor blits straight
// back over the base — so the grade BAKES into photo/video export with zero changes
// to the capture pipeline.
//
// Pipeline (one offscreen WebGL2 canvas, ping-pong FBOs):
//   1. upload bake canvas → texSrc
//   2. BRIGHT pass : extract bright light sources at half-res → texBright
//   3. BLUR pass   : separable Gaussian (H then V, twice) → wide soft bloom
//   4. COMPOSITE   : luma gradient-map through the Solargraph palette (amber in the
//                    highlights AND shadows), prussian-blue spatial bleed at the TOP
//                    of the frame, and a warm-gold halation screened around lights.
//
// The grade is a luminance gradient-map, so it can't be expressed as a CSS filter
// (sepia/contrast/etc.) — it has to be baked here. Returns null when WebGL2 is
// unavailable, in which case the caller leaves the base frame untouched.

const W = 1280, H = 720;          // matches the studio bake buffer
const BW = 640, BH = 360;         // half-res bloom (softer + cheaper)
// Sampling the uploaded 2D canvas with FLIP_Y so texture-space matches the quad's
// uv (top-left origin) end-to-end; the final glCanvas then blits back upright.
const FLIP_SRC_Y = true;

// Per-frame grade uniforms (all 0..1, already scaled by overall intensity on the CPU).
export interface SolargraphUniforms {
  grade: number;      // tonal gradient-map strength
  blueBleed: number;  // prussian-blue bleed at the top of the frame
  halation: number;   // warm glow/bloom around bright light sources
}

const QUAD = new Float32Array([-1, -1, 3, -1, -1, 3]); // oversized tri covers screen

const VERT = `#version 300 es
precision highp float;
in vec2 aPos;
out vec2 vUV;
void main() { vUV = aPos * 0.5 + 0.5; gl_Position = vec4(aPos, 0.0, 1.0); }`;

// ── BRIGHT: isolate bright light sources (for halation), downsampled to half-res. ─
const FRAG_BRIGHT = `#version 300 es
precision highp float;
in vec2 vUV;
uniform sampler2D uSrc;
out vec4 frag;
float luma(vec3 c){ return dot(c, vec3(0.299, 0.587, 0.114)); }
void main() {
  vec3 c = texture(uSrc, vUV).rgb;
  float l = luma(c);
  float b = smoothstep(0.58, 0.96, l);   // only the brightest pixels glow
  frag = vec4(c * b, 1.0);
}`;

// ── BLUR: separable 9-tap Gaussian. ─────────────────────────────────────────────
const FRAG_BLUR = `#version 300 es
precision highp float;
in vec2 vUV;
uniform sampler2D uTex;
uniform vec2 uDir;              // texel step along one axis
out vec4 frag;
void main() {
  float w0 = 0.227027, w1 = 0.316216, w2 = 0.070270, w3 = 0.0089;
  vec3 c = texture(uTex, vUV).rgb * w0;
  c += texture(uTex, vUV + uDir * 1.0).rgb * w1 * 0.5;
  c += texture(uTex, vUV - uDir * 1.0).rgb * w1 * 0.5;
  c += texture(uTex, vUV + uDir * 2.0).rgb * w2;
  c += texture(uTex, vUV - uDir * 2.0).rgb * w2;
  c += texture(uTex, vUV + uDir * 3.5).rgb * w3;
  c += texture(uTex, vUV - uDir * 3.5).rgb * w3;
  frag = vec4(c / (w0 + w1 + 2.0 * w2 + 2.0 * w3), 1.0);
}`;

// ── COMPOSITE: the Solargraph look. ──────────────────────────────────────────────
const FRAG_COMP = `#version 300 es
precision highp float;
in vec2 vUV;
uniform sampler2D uSrc;     // original full-res frame
uniform sampler2D uBloom;   // blurred bright-pass
uniform float uGrade;       // tonal gradient-map strength
uniform float uBlue;        // prussian-blue bleed at top
uniform float uHalation;    // warm halation glow
out vec4 frag;

float luma(vec3 c){ return dot(c, vec3(0.299, 0.587, 0.114)); }

// Signature palette (exact hex → linear-ish sRGB 0..1).
const vec3 MIDNIGHT = vec3(0.0510, 0.0667, 0.0902); // #0D1117 Near-Black Midnight
const vec3 SIENNA   = vec3(0.5451, 0.2275, 0.0);    // #8B3A00 Burnt Sienna
const vec3 AMBER    = vec3(0.7529, 0.3922, 0.0);    // #C06400 Deep Amber
const vec3 GOLD     = vec3(0.9608, 0.8745, 0.6667); // #F5DFAA Soft White-Gold
const vec3 PRUSSIAN = vec3(0.1020, 0.1804, 0.2902); // #1A2E4A Prussian Blue

// Map a 0..1 luminance through the warm palette: shadows = midnight→sienna, mids =
// deep amber, highlights = warm gold→soft white-gold. Amber dominates top to bottom.
vec3 gradeMap(float l) {
  vec3 warmGold = mix(AMBER, GOLD, 0.55);
  vec3 c = mix(MIDNIGHT, SIENNA, smoothstep(0.0, 0.20, l));
  c = mix(c, AMBER,    smoothstep(0.18, 0.48, l));
  c = mix(c, warmGold, smoothstep(0.48, 0.76, l));
  c = mix(c, GOLD,     smoothstep(0.76, 1.0, l));
  return c;
}

void main() {
  vec3 src = texture(uSrc, vUV).rgb;
  float l = luma(src);
  vec3 mapped = gradeMap(l);
  // Restore a little original micro-contrast so the grade keeps scene texture
  // rather than flattening into a pure duotone.
  mapped += (l - luma(mapped)) * 0.25;
  vec3 col = mix(src, mapped, uGrade);

  // Prussian-blue vertical bleed at the TOP of the frame (the sky), luma-preserving
  // and backing off on the very brightest pixels so the sun/lights stay warm. NOTE:
  // uploads use UNPACK_FLIP_Y so vUV.y == 0 is the TOP of the final image (matches
  // beautyXGL's convention). Spec-correct (edge0<edge1) smoothstep, then invert.
  float topMask  = 1.0 - smoothstep(0.0, 0.58, vUV.y); // 1 at top edge → 0 by mid-frame
  float keepWarm = 1.0 - smoothstep(0.5, 0.88, l);   // less blue where very bright
  float Lg = luma(col);
  vec3 blueTone = PRUSSIAN * (Lg / max(luma(PRUSSIAN), 1e-3));
  col = mix(col, blueTone, clamp(topMask * keepWarm * uBlue, 0.0, 1.0));

  // Film halation — screen a warm-gold-tinted blurred bright-pass around lights.
  vec3 bloom = texture(uBloom, vUV).rgb;
  vec3 warmHal = clamp(bloom * GOLD * 1.5 * uHalation, 0.0, 1.0);
  col = 1.0 - (1.0 - col) * (1.0 - warmHal);

  frag = vec4(clamp(col, 0.0, 1.0), 1.0);
}`;

interface Prog { p: WebGLProgram; loc: Record<string, WebGLUniformLocation | null>; }
interface GLState {
  cv: HTMLCanvasElement; gl: WebGL2RenderingContext;
  vao: WebGLVertexArrayObject;
  bright: Prog; blur: Prog; comp: Prog;
  texSrc: WebGLTexture; texBrightA: WebGLTexture; texBrightB: WebGLTexture;
  fboBrightA: WebGLFramebuffer; fboBrightB: WebGLFramebuffer;
}

let S: GLState | null = null;
let failed = false;

function compile(gl: WebGL2RenderingContext, type: number, src: string): WebGLShader {
  const sh = gl.createShader(type)!;
  gl.shaderSource(sh, src); gl.compileShader(sh);
  if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS))
    throw new Error("[Solargraph] shader: " + gl.getShaderInfoLog(sh));
  return sh;
}
function link(gl: WebGL2RenderingContext, fragSrc: string, uniforms: string[]): Prog {
  const p = gl.createProgram()!;
  gl.attachShader(p, compile(gl, gl.VERTEX_SHADER, VERT));
  gl.attachShader(p, compile(gl, gl.FRAGMENT_SHADER, fragSrc));
  gl.bindAttribLocation(p, 0, "aPos");
  gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS))
    throw new Error("[Solargraph] link: " + gl.getProgramInfoLog(p));
  const loc: Record<string, WebGLUniformLocation | null> = {};
  for (const u of uniforms) loc[u] = gl.getUniformLocation(p, u);
  return { p, loc };
}
function makeTex(gl: WebGL2RenderingContext, w: number, h: number): WebGLTexture {
  const t = gl.createTexture()!;
  gl.bindTexture(gl.TEXTURE_2D, t);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  return t;
}
function makeFBO(gl: WebGL2RenderingContext, tex: WebGLTexture): WebGLFramebuffer {
  const f = gl.createFramebuffer()!;
  gl.bindFramebuffer(gl.FRAMEBUFFER, f);
  gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
  return f;
}

function init(): GLState | null {
  if (failed) return null;
  try {
    const cv = document.createElement("canvas");
    cv.width = W; cv.height = H;
    const gl = cv.getContext("webgl2", { alpha: false, premultipliedAlpha: false, antialias: false, depth: false, preserveDrawingBuffer: false });
    if (!gl) { failed = true; return null; }
    cv.addEventListener("webglcontextlost", (e) => { e.preventDefault(); S = null; }, false);

    const vao = gl.createVertexArray()!;
    gl.bindVertexArray(vao);
    const buf = gl.createBuffer()!;
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, QUAD, gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    gl.bindVertexArray(null);

    const bright = link(gl, FRAG_BRIGHT, ["uSrc"]);
    const blur = link(gl, FRAG_BLUR, ["uTex", "uDir"]);
    const comp = link(gl, FRAG_COMP, ["uSrc", "uBloom", "uGrade", "uBlue", "uHalation"]);

    const texSrc = makeTex(gl, W, H);
    const texBrightA = makeTex(gl, BW, BH);
    const texBrightB = makeTex(gl, BW, BH);
    const fboBrightA = makeFBO(gl, texBrightA);
    const fboBrightB = makeFBO(gl, texBrightB);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);

    S = { cv, gl, vao, bright, blur, comp, texSrc, texBrightA, texBrightB, fboBrightA, fboBrightB };
    return S;
  } catch (err) {
    console.error(err);
    failed = true;
    return null;
  }
}

// Process the bake frame; returns the opaque processed offscreen canvas to blit, or
// null if WebGL2 is unavailable (caller leaves the base frame untouched).
export function renderSolargraphGL(source: TexImageSource, u: SolargraphUniforms): HTMLCanvasElement | null {
  const s = S ?? init();
  if (!s) return null;
  const { gl } = s;

  gl.bindVertexArray(s.vao);
  gl.disable(gl.BLEND);

  // Upload the current bake frame.
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, s.texSrc);
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, FLIP_SRC_Y);
  gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source);

  // 1) BRIGHT pass → texBrightA (half-res)
  gl.bindFramebuffer(gl.FRAMEBUFFER, s.fboBrightA);
  gl.viewport(0, 0, BW, BH);
  gl.useProgram(s.bright.p);
  gl.uniform1i(s.bright.loc.uSrc, 0);
  gl.drawArrays(gl.TRIANGLES, 0, 3);

  // 2) BLUR — two H/V iterations for a wide, soft halation.
  gl.useProgram(s.blur.p);
  gl.uniform1i(s.blur.loc.uTex, 0);
  for (let i = 0; i < 2; i++) {
    // H: A → B
    gl.bindFramebuffer(gl.FRAMEBUFFER, s.fboBrightB);
    gl.viewport(0, 0, BW, BH);
    gl.bindTexture(gl.TEXTURE_2D, s.texBrightA);
    gl.uniform2f(s.blur.loc.uDir, 1 / BW, 0);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    // V: B → A
    gl.bindFramebuffer(gl.FRAMEBUFFER, s.fboBrightA);
    gl.viewport(0, 0, BW, BH);
    gl.bindTexture(gl.TEXTURE_2D, s.texBrightB);
    gl.uniform2f(s.blur.loc.uDir, 0, 1 / BH);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }

  // 3) COMPOSITE → glCanvas
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  gl.viewport(0, 0, W, H);
  gl.useProgram(s.comp.p);
  gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, s.texSrc); gl.uniform1i(s.comp.loc.uSrc, 0);
  gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, s.texBrightA); gl.uniform1i(s.comp.loc.uBloom, 1);
  gl.uniform1f(s.comp.loc.uGrade, u.grade);
  gl.uniform1f(s.comp.loc.uBlue, u.blueBleed);
  gl.uniform1f(s.comp.loc.uHalation, u.halation);
  gl.drawArrays(gl.TRIANGLES, 0, 3);

  gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, null);
  gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, null);
  gl.bindVertexArray(null);
  return s.cv;
}
