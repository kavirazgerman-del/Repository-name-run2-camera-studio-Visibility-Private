// ── Neon Patriot Overlay — face-tracked flag subsystem ──────────────────────────
// Premium camera filter that drapes a glowing US flag over the subject's face.
//
// Architecture (kept ISOLATED from the Canvas2D compositor it feeds):
//   • MediaPipe FaceLandmarker runs ASYNC on a throttled timer, writing smoothed
//     landmarks into the tracker (NeonPatriotTracker). It never draws.
//   • The synchronous compositor (CameraStudio.compositeFrame) reads the latest
//     tracking snapshot and renders the overlay, then blits it into the same 2D
//     canvas buffer the recorder/photo capture from — so the effect BAKES into
//     export with zero changes to videoExport.ts / capture paths.
//
// Spike phase: renders mapped landmark dots to prove tracking + coord mapping.
// WebGL2 flag renderer is layered on top of this same subsystem next.

import { FaceLandmarker, FilesetResolver, type FaceLandmarkerResult } from "@mediapipe/tasks-vision";
import { renderFlagMesh } from "./neonPatriotGL";

// ── Params (driven by the dedicated controls; intensity merged from the shared
// Filters slider so the knob scales the WHOLE effect at capture time too) ────────
export type NPLevel3 = "low" | "med" | "high";
export type NPStretch = "subtle" | "med" | "extreme";

export interface NeonPatriotParams {
  intensity: number;       // 0..100 — overall strength
  glow: NPLevel3;          // neon bloom strength (default high)
  translucency: NPLevel3;  // how see-through the flag is (default med)
  stretch: NPStretch;      // how far the flag stretches over the face (default med)
}

export const DEFAULT_NEON_PATRIOT_PARAMS: NeonPatriotParams = {
  intensity: 80, glow: "high", translucency: "med", stretch: "med",
};

export const NP_LEVELS: { id: NPLevel3; label: string }[] = [
  { id: "low", label: "Low" }, { id: "med", label: "Med" }, { id: "high", label: "High" },
];
export const NP_STRETCHES: { id: NPStretch; label: string }[] = [
  { id: "subtle", label: "Subtle" }, { id: "med", label: "Med" }, { id: "extreme", label: "Extreme" },
];

// Snapshot consumed by the synchronous renderer every compositor frame.
export interface NeonPatriotTracking {
  // Smoothed NORMALIZED landmarks, flat [x,y,z,...] in raw-video space (0..1).
  // null when there is nothing to show (never tracked, or fully faded out).
  landmarks: Float32Array | null;
  count: number;          // number of landmarks present
  fade: number;           // 0..1 presence factor (decays after tracking loss)
}

// ── Coordinate mapping ──────────────────────────────────────────────────────────
// Map a normalized landmark into the 1280x720 object-fit:cover canvas space,
// matching drawVideoCover EXACTLY (incl. selfie mirror) so the overlay locks to
// the face with no base-video zoom/crop.
export interface CoverMap { sw: number; sh: number; dx: number; dy: number; mirror: boolean; w: number; }
export function makeCoverMap(w: number, h: number, vw: number, vh: number, mirror: boolean): CoverMap {
  const scale = Math.max(w / vw, h / vh);
  const sw = vw * scale, sh = vh * scale;
  return { sw, sh, dx: (w - sw) / 2, dy: (h - sh) / 2, mirror, w };
}
export function mapX(m: CoverMap, nx: number): number {
  const x = m.dx + nx * m.sw;
  return m.mirror ? m.w - x : x;
}
export function mapY(m: CoverMap, ny: number): number {
  return m.dy + ny * m.sh;
}

// ── Tracker ─────────────────────────────────────────────────────────────────────
const DETECT_MS = 45;        // ~22fps detection cadence (protects compositor perf)
const EMA = 0.5;             // smoothing toward each new detection
const HOLD_MS = 130;         // keep the last pose briefly after a dropped frame
const FADE_MS = 260;         // then fade the overlay out over this long

export class NeonPatriotTracker {
  private video: HTMLVideoElement;
  private landmarker: FaceLandmarker | null = null;
  private starting = false;
  private disposed = false;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private smoothed: Float32Array | null = null;
  private count = 0;
  private lastSeen = 0;        // performance.now() of the last successful detection
  private lastTs = 0;          // monotonic timestamp guard for detectForVideo
  private snap: NeonPatriotTracking = { landmarks: null, count: 0, fade: 0 };

  constructor(video: HTMLVideoElement) { this.video = video; }

  async start() {
    if (this.disposed || this.starting || this.landmarker) return;
    this.starting = true;
    try {
      const base = import.meta.env.BASE_URL || "/";
      const fileset = await FilesetResolver.forVisionTasks(`${base}mediapipe/wasm`);
      if (this.disposed) return;
      const make = (delegate: "GPU" | "CPU") => FaceLandmarker.createFromOptions(fileset, {
        baseOptions: { modelAssetPath: `${base}mediapipe/face_landmarker.task`, delegate },
        runningMode: "VIDEO",
        numFaces: 1,
      });
      try { this.landmarker = await make("GPU"); }
      catch { this.landmarker = await make("CPU"); }
      if (this.disposed) { this.landmarker?.close(); this.landmarker = null; return; }
      this.loop();
    } catch (err) {
      // Asset/model load failed — leave landmarker null; the renderer simply shows
      // nothing (filter degrades to a no-op) rather than crashing the studio.
      console.error("[NeonPatriot] tracker init failed", err);
    } finally {
      this.starting = false;
    }
  }

  private loop = () => {
    if (this.disposed) return;
    this.detectOnce();
    this.timer = setTimeout(this.loop, DETECT_MS);
  };

  private detectOnce() {
    const v = this.video, lm = this.landmarker;
    if (!lm || !v || v.readyState < 2 || v.videoWidth === 0) return;
    let ts = performance.now();
    if (ts <= this.lastTs) ts = this.lastTs + 1;  // strictly increasing (required)
    this.lastTs = ts;
    let res: FaceLandmarkerResult;
    try { res = lm.detectForVideo(v, ts); } catch { return; }
    const face = res.faceLandmarks?.[0];
    if (!face || !face.length) return;
    const n = face.length;
    if (!this.smoothed || this.count !== n) {
      this.smoothed = new Float32Array(n * 3);
      for (let i = 0; i < n; i++) {
        this.smoothed[i * 3] = face[i].x;
        this.smoothed[i * 3 + 1] = face[i].y;
        this.smoothed[i * 3 + 2] = face[i].z;
      }
      this.count = n;
    } else {
      const s = this.smoothed;
      for (let i = 0; i < n; i++) {
        s[i * 3]     += (face[i].x - s[i * 3]) * EMA;
        s[i * 3 + 1] += (face[i].y - s[i * 3 + 1]) * EMA;
        s[i * 3 + 2] += (face[i].z - s[i * 3 + 2]) * EMA;
      }
    }
    this.lastSeen = performance.now();
  }

  // Latest snapshot for the synchronous renderer (mutates a reused object — no
  // per-frame allocation in the compositor hot path).
  getTracking(): NeonPatriotTracking {
    const s = this.snap;
    if (this.lastSeen === 0 || !this.smoothed) {
      s.landmarks = null; s.count = 0; s.fade = 0;
      return s;
    }
    const dt = performance.now() - this.lastSeen;
    let fade = 1;
    if (dt > HOLD_MS) fade = Math.max(0, 1 - (dt - HOLD_MS) / FADE_MS);
    s.landmarks = fade > 0 ? this.smoothed : null;
    s.count = this.count;
    s.fade = fade;
    return s;
  }

  dispose() {
    this.disposed = true;
    if (this.timer) { clearTimeout(this.timer); this.timer = null; }
    this.landmarker?.close();
    this.landmarker = null;
  }
}

// ── Spike renderer — mapped landmark dots ───────────────────────────────────────
// Proves tracking + coordinate mapping bake into the canvas (and therefore export)
// before the WebGL2 flag renderer is layered onto the same subsystem.
export function renderNeonPatriotDots(
  ctx: CanvasRenderingContext2D, w: number, h: number,
  tracking: NeonPatriotTracking, vw: number, vh: number, mirror: boolean,
) {
  const lm = tracking.landmarks;
  if (!lm || tracking.fade <= 0) return;
  const m = makeCoverMap(w, h, vw, vh, mirror);
  ctx.save();
  ctx.globalAlpha = tracking.fade;
  ctx.fillStyle = "#39ff14";
  ctx.shadowColor = "#39ff14";
  ctx.shadowBlur = 6;
  for (let i = 0; i < tracking.count; i++) {
    const x = mapX(m, lm[i * 3]);
    const y = mapY(m, lm[i * 3 + 1]);
    ctx.beginPath();
    ctx.arc(x, y, 1.6, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

// Neon glow strength per level → [blur px, additive halo alpha].
const NP_GLOW: Record<NPLevel3, { blur: number; alpha: number }> = {
  low: { blur: 9, alpha: 0.38 }, med: { blur: 16, alpha: 0.58 }, high: { blur: 26, alpha: 0.82 },
};

// Feature-detect Canvas2D blur once (older Safari lacks it → glow degrades to a
// crisp flag rather than failing). The base video is already drawn underneath.
let canFilter: boolean | null = null;
function supportsCanvasFilter(ctx: CanvasRenderingContext2D): boolean {
  if (canFilter !== null) return canFilter;
  try { ctx.filter = "blur(1px)"; canFilter = ctx.filter !== "none"; ctx.filter = "none"; }
  catch { canFilter = false; }
  return canFilter;
}

// ── Overlay renderer ────────────────────────────────────────────────────────────
// Drapes the WebGL2 flag mesh over the tracked face, adds a multicolour neon bloom
// + vignette, and blits everything into the 2D bake buffer (so it captures into
// photo/video export). Everything scales with intensity and fades with the tracking
// snapshot on loss. No-ops cleanly when there is no face or WebGL2 is unavailable.
export function renderNeonPatriot(
  ctx: CanvasRenderingContext2D, w: number, h: number,
  tracking: NeonPatriotTracking, vw: number, vh: number, mirror: boolean,
  params: NeonPatriotParams,
) {
  const lm = tracking.landmarks;
  if (!lm || tracking.fade <= 0) return;
  const glCanvas = renderFlagMesh(lm, tracking.count, vw, vh, mirror, params);
  if (!glCanvas) return;

  const fade = tracking.fade;
  const intensity = Math.max(0, Math.min(1, params.intensity / 100));
  if (intensity <= 0) return;

  // 1) Subtle vignette to seat the effect (scaled by intensity, faded on loss).
  const vig = 0.3 * intensity * fade;
  if (vig > 0.01) {
    const g = ctx.createRadialGradient(w / 2, h * 0.46, h * 0.32, w / 2, h * 0.5, h * 0.82);
    g.addColorStop(0, "rgba(0,0,0,0)");
    g.addColorStop(1, `rgba(3,7,24,${vig})`);
    ctx.save(); ctx.fillStyle = g; ctx.fillRect(0, 0, w, h); ctx.restore();
  }

  // 2) Neon bloom — additive blurred copy of the flag (multicolour halo). The GL
  // flag already carries intensity in its alpha, so DON'T multiply by intensity
  // again here or the whole effect would fall off as intensity² (architect note).
  const glow = NP_GLOW[params.glow];
  if (glow.alpha > 0) {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    if (supportsCanvasFilter(ctx)) {
      // Soft blurred aura around the wrap — the dreamy neon halo.
      ctx.globalAlpha = fade * glow.alpha;
      ctx.filter = `blur(${glow.blur}px)`;
      ctx.drawImage(glCanvas, 0, 0, w, h);
      ctx.filter = "none";
    }
    // Crisp additive punch — brightens the baked Fresnel rim into a true neon edge.
    // Runs even where ctx.filter (blur) is unsupported, so the glow never silently
    // disappears (the original bug: glow was gated entirely on filter support).
    ctx.globalAlpha = fade * glow.alpha * 0.6;
    ctx.drawImage(glCanvas, 0, 0, w, h);
    ctx.restore();
  }

  // 3) Crisp flag on top.
  ctx.save();
  ctx.globalAlpha = fade;
  ctx.drawImage(glCanvas, 0, 0, w, h);
  ctx.restore();
}
