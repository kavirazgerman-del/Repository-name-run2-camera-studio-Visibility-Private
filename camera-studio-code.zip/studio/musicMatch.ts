// Deterministic "auto-match" for the studio soundtrack picker.
//
// Given the post's text (title + caption), the active look (filter ids), and the
// active experience, we score the available moods with a small keyword/look map
// and pick the best track in the top-scoring mood. No model calls — fully
// deterministic so the same inputs always suggest the same track.

import type { MusicTrack } from "@workspace/api-client-react";

export interface MatchContext {
  text?: string;
  filterIds?: string[];
  experienceId?: string | null;
}

export interface MusicSuggestion {
  track: MusicTrack;
  mood: string;
}

// Keyword → mood signals (lowercase, matched as whole-ish tokens).
const KEYWORD_MOODS: Record<string, string[]> = {
  upbeat: [
    "happy", "fun", "party", "celebrate", "celebration", "energy", "energetic",
    "hype", "pump", "dance", "win", "winning", "summer", "friends", "vibe",
    "vibes", "lit", "joy", "excited", "festival", "birthday", "weekend",
  ],
  chill: [
    "chill", "relax", "relaxed", "calm", "study", "lofi", "lo-fi", "sleep",
    "slow", "peace", "peaceful", "cozy", "soft", "dream", "dreamy", "lazy",
    "sunday", "mellow", "quiet", "rest",
  ],
  cinematic: [
    "epic", "dramatic", "story", "trailer", "journey", "adventure", "reveal",
    "transformation", "motivate", "motivation", "goals", "rise", "rising",
    "inspire", "inspiring", "build", "grand", "hero",
  ],
  emotional: [
    "love", "miss", "sad", "memories", "memory", "heart", "family", "grateful",
    "thank", "thanks", "tribute", "remember", "cry", "tears", "goodbye", "forever",
    "hope", "hopeful", "reflect", "reflective",
  ],
  electronic: [
    "neon", "night", "nightlife", "club", "edm", "beat", "beats", "drop",
    "gaming", "game", "tech", "future", "futuristic", "drive", "city", "synth",
    "rave", "bass", "workout", "gym",
  ],
  acoustic: [
    "coffee", "morning", "nature", "hike", "hiking", "guitar", "folk", "home",
    "garden", "warm", "organic", "travel", "road", "trip", "outdoors", "cabin",
    "farm", "rustic",
  ],
};

// Filter id → mood hint (filter ids come from CameraStudio's FILTERS).
const FILTER_MOODS: Record<string, string> = {
  neonrain: "electronic",
  neonsunshine: "chill",
  arctic: "cinematic",
};

// Tie-break priority when multiple moods score equally / nothing scores.
const MOOD_PRIORITY = ["upbeat", "chill", "cinematic", "emotional", "electronic", "acoustic"];

function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, " ")
    .split(/\s+/)
    .filter(Boolean);
}

/**
 * Pick a sensible track for the given context, or null if there are no tracks.
 * The choice is stable for identical inputs.
 */
export function suggestMusic(
  tracks: MusicTrack[],
  ctx: MatchContext,
): MusicSuggestion | null {
  if (!tracks || tracks.length === 0) return null;

  // Only moods that actually exist in the library can be chosen.
  const available = new Set(tracks.map((t) => t.mood));
  const scores: Record<string, number> = {};
  const bump = (mood: string, by: number) => {
    if (!available.has(mood)) return;
    scores[mood] = (scores[mood] ?? 0) + by;
  };

  const tokens = tokenize(ctx.text ?? "");
  const tokenSet = new Set(tokens);
  for (const [mood, words] of Object.entries(KEYWORD_MOODS)) {
    for (const w of words) {
      if (tokenSet.has(w)) bump(mood, 2);
    }
  }

  for (const fid of ctx.filterIds ?? []) {
    const mood = FILTER_MOODS[fid];
    if (mood) bump(mood, 3);
  }

  if (ctx.experienceId) {
    const eid = ctx.experienceId.toLowerCase();
    for (const [mood, words] of Object.entries(KEYWORD_MOODS)) {
      if (words.some((w) => eid.includes(w)) || eid.includes(mood)) bump(mood, 2);
    }
  }

  // Choose the top-scoring available mood; fall back to priority order, then first.
  let bestMood: string | null = null;
  let bestScore = -1;
  for (const mood of MOOD_PRIORITY) {
    const s = scores[mood];
    if (s != null && s > bestScore) {
      bestScore = s;
      bestMood = mood;
    }
  }
  if (!bestMood) {
    bestMood =
      MOOD_PRIORITY.find((m) => available.has(m)) ?? tracks[0].mood;
  }

  // Within the chosen mood, prefer the track with the most tag overlap.
  const inMood = tracks.filter((t) => t.mood === bestMood);
  const pool = inMood.length > 0 ? inMood : tracks;
  let best = pool[0];
  let bestOverlap = -1;
  for (const t of pool) {
    const overlap = (t.tags ?? []).reduce(
      (acc, tag) => acc + (tokenSet.has(tag.toLowerCase()) ? 1 : 0),
      0,
    );
    if (overlap > bestOverlap) {
      bestOverlap = overlap;
      best = t;
    }
  }

  return { track: best, mood: bestMood };
}
