// ── Solargraph — long-exposure solargraphy grade + arc streaks + halation + grain ─
// Premium camera filter. Four cooperating layers, all BAKED into the 2D bake buffer
// (so they capture into photo/video with zero changes to videoExport.ts):
//
//   1. GRADE     — solargraphGL.ts reads the already-drawn bake frame as a texture
//      and returns a processed copy: a luma gradient-map through the Solargraph
//      palette (warm amber in highlights AND shadows), a prussian-blue spatial bleed
//      at the TOP of the frame, and a warm-gold film halation around bright lights.
//      We blit it straight back over the base.
//   2. ARC STREAKS — cached Canvas2D sprite of gentle concentric star-trail arcs
//      sweeping across the upper frame (screen), with a slow drift + alpha breathing.
//   3. GRAIN     — a cached fine monochrome noise tile, tiled with an animated offset
//      and an overlay blend, for a cinematic film texture.
//
// No face tracking — the whole look is a global grade + sky overlays. intensity 0 is
// a full no-op, and every layer's strength scales by intensity so the shared Filters
// slider drives the entire effect through both the live preview and capture paths.

import { renderSolargraphGL, type SolargraphUniforms } from "./solargraphGL";

// ── Params (driven by the dedicated controls; intensity merged from the shared
// Filters slider so the knob scales the WHOLE effect at capture time too) ──────────
export interface SolargraphParams {
  intensity: number;   // 0..100 — overall strength
  grade: number;       // 0..100 — amber tonal gradient-map strength
  blueBleed: number;   // 0..100 — prussian-blue bleed at the top of the frame
  halation: number;    // 0..100 — warm glow/bloom around bright light sources
  arcStreaks: number;  // 0..100 — star-trail arc amount
  grain: number;       // 0..100 — fine cinematic grain amount
  arcsOn: boolean;     // master toggle for arc streaks
  grainOn: boolean;    // master toggle for film grain
}

// Spec defaults — the signature Solargraph look at full intensity.
export const DEFAULT_SOLARGRAPH_PARAMS: SolargraphParams = {
  intensity: 100, grade: 100, blueBleed: 70, halation: 65, arcStreaks: 55, grain: 45,
  arcsOn: true, grainOn: true,
};

const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
const sgOffscreen = (w: number, h: number) => { const c = document.createElement("canvas"); c.width = w; c.height = h; return c; };

const rng = (seed: number) => {
  let s = seed >>> 0;
  return () => { s = (s + 0x6d2b79f5) >>> 0; let x = s; x = Math.imul(x ^ (x >>> 15), x | 1); x ^= x + Math.imul(x ^ (x >>> 7), x | 61); return ((x ^ (x >>> 14)) >>> 0) / 4294967296; };
};

// ── Cached sprites (built once per size, blitted each frame) ──────────────────────
interface SolarSprites { arcs: HTMLCanvasElement; grain: HTMLCanvasElement; }
const spriteCache = new Map<string, SolarSprites>();

function getSolarSprites(w: number, h: number): SolarSprites {
  const key = `${w}x${h}`;
  const hit = spriteCache.get(key);
  if (hit) return hit;

  // Arc streaks — gentle concentric star-trail arcs. Centred well BELOW the frame
  // with a large radius, so the visible segments read as long, slightly-curved
  // sweeps across the upper sky. Pre-rendered so we only animate drift + alpha.
  const arcs = sgOffscreen(w, h);
  const ac = arcs.getContext("2d")!;
  ac.globalCompositeOperation = "screen";
  ac.lineCap = "round";
  const ar = rng(70511);
  const cx = w * 0.46, cy = h * 2.35;          // arc centre, off the bottom of frame
  const baseR = h * 2.05;
  for (let i = 0; i < 16; i++) {
    const r = baseR + i * (h * 0.052) + (ar() - 0.5) * h * 0.02;
    const a = 0.05 + ar() * 0.10;               // subtle
    const span = 0.9 + ar() * 0.5;              // radians of visible arc
    const mid = -Math.PI / 2 + (ar() - 0.5) * 0.5;
    const g = ac.createLinearGradient(0, 0, w, 0);
    g.addColorStop(0, "rgba(245,223,170,0)");
    g.addColorStop(0.5, `rgba(${ar() < 0.5 ? "255,255,255" : "245,223,170"},${a})`);
    g.addColorStop(1, "rgba(245,223,170,0)");
    ac.strokeStyle = g;
    ac.lineWidth = 0.6 + ar() * 1.0;
    ac.beginPath();
    ac.arc(cx, cy, r, mid - span / 2, mid + span / 2);
    ac.stroke();
  }

  // Fine monochrome grain tile, centred on mid-grey so an overlay blend is neutral
  // and only the per-pixel deviation reads as grain.
  const GT = 256;
  const grain = sgOffscreen(GT, GT);
  const gc = grain.getContext("2d")!;
  const img = gc.createImageData(GT, GT);
  const gr = rng(13337);
  for (let i = 0; i < GT * GT; i++) {
    const v = 128 + (gr() - 0.5) * 64;          // ±32 around mid-grey → fine grain
    const o = i * 4;
    img.data[o] = v; img.data[o + 1] = v; img.data[o + 2] = v; img.data[o + 3] = 255;
  }
  gc.putImageData(img, 0, 0);

  const sprites: SolarSprites = { arcs, grain };
  spriteCache.set(key, sprites);
  return sprites;
}

// Structural placeholder so the signature matches CameraStudio's FilterDef.canvas
// (Solargraph keeps no particle state — the buffer is unused).
interface SolarParticle { x: number; y: number; vx: number; vy: number; life: number; r: number; color: string; }

// ── Main render — GL grade blit + arc-streak & grain overlays ─────────────────────
export function renderSolargraph(
  ctx: CanvasRenderingContext2D, w: number, h: number, frame: number, _p: SolarParticle[],
  params: SolargraphParams,
) {
  const t = clamp01(params.intensity / 100);
  if (t <= 0) {                                // intensity 0 ⇒ fully neutral (no draw)
    // Still normalize ctx state so any later stacked layer / Motion Ink starts clean.
    ctx.globalAlpha = 1; ctx.filter = "none"; ctx.shadowBlur = 0; ctx.globalCompositeOperation = "source-over";
    return;
  }

  // ── 1) GL grade + halation + blue bleed (reads the already-drawn base frame) ─────
  const u: SolargraphUniforms = {
    grade: clamp01(params.grade / 100) * t * 0.9,   // keep a touch of realism at max
    blueBleed: clamp01(params.blueBleed / 100) * t,
    halation: clamp01(params.halation / 100) * t * 1.1,
  };
  if (u.grade > 0.001 || u.blueBleed > 0.001 || u.halation > 0.001) {
    const out = renderSolargraphGL(ctx.canvas, u);
    if (out) { ctx.save(); ctx.globalAlpha = 1; ctx.drawImage(out, 0, 0, w, h); ctx.restore(); }
  }

  const S = getSolarSprites(w, h);

  // ── 2) Arc streaks — slow horizontal drift + gentle alpha breathing (screen) ─────
  if (params.arcsOn) {
    const arc = clamp01(params.arcStreaks / 100) * t;
    if (arc > 0.01) {
      ctx.save();
      ctx.globalCompositeOperation = "screen";
      ctx.globalAlpha = arc * (0.7 + 0.25 * Math.sin(frame * 0.02));
      const dx = Math.sin(frame * 0.005) * 0.012 * w;
      ctx.drawImage(S.arcs, dx, 0, w, h);
      ctx.restore();
    }
  }

  // ── 3) Film grain — overlay-blended noise tile with an animated offset ───────────
  if (params.grainOn) {
    const g = clamp01(params.grain / 100) * t;
    if (g > 0.01) {
      ctx.save();
      ctx.globalCompositeOperation = "overlay";
      ctx.globalAlpha = g * 0.6;
      const pat = ctx.createPattern(S.grain, "repeat");
      if (pat) {
        const ox = Math.floor(Math.random() * 256), oy = Math.floor(Math.random() * 256);
        ctx.translate(-ox, -oy);                // jitter the tile each frame
        ctx.fillStyle = pat;
        ctx.fillRect(ox, oy, w, h);
      }
      ctx.restore();
    }
  }

  // Leave the context clean for any later stacked layer / Motion Ink.
  ctx.globalAlpha = 1;
  ctx.filter = "none";
  ctx.shadowBlur = 0;
  ctx.globalCompositeOperation = "source-over";
}
