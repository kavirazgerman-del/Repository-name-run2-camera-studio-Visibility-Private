import { describe, it, expect, vi } from "vitest";
import type { AiFilterConfig } from "@workspace/api-client-react";
import { aiConfigGradeCss, renderAiConfigFilter } from "./aiConfigFilter";

const baseConfig: AiFilterConfig = {
  name: "Golden Glow",
  grade: { brightness: 1.2, contrast: 1.1, saturate: 1.3, hueRotate: -12, sepia: 0.2 },
  overlays: [
    { type: "glow", color: "#ffcc88", strength: 0.7, density: 0.4 },
    { type: "particles", color: "#ffd28a", strength: 0.6, density: 0.5 },
  ],
  animation: { motion: "gentle", speed: 0.5 },
  accentColors: ["#ffcc88", "#ff9966"],
};

// jsdom has no canvas engine, so record the draw calls against a fake 2D context.
function makeCtx() {
  const calls: string[] = [];
  const gradient = {
    addColorStop: vi.fn(),
  };
  const ctx: any = {
    calls,
    save: vi.fn(() => calls.push("save")),
    restore: vi.fn(() => calls.push("restore")),
    translate: vi.fn(),
    scale: vi.fn(),
    rotate: vi.fn(),
    beginPath: vi.fn(),
    arc: vi.fn(() => calls.push("arc")),
    moveTo: vi.fn(),
    lineTo: vi.fn(),
    stroke: vi.fn(() => calls.push("stroke")),
    fill: vi.fn(() => calls.push("fill")),
    fillRect: vi.fn(() => calls.push("fillRect")),
    createRadialGradient: vi.fn(() => gradient),
    createLinearGradient: vi.fn(() => gradient),
    globalAlpha: 1,
    globalCompositeOperation: "source-over",
    filter: "none",
    shadowBlur: 0,
    fillStyle: "",
    strokeStyle: "",
    lineWidth: 1,
    lineCap: "butt",
  };
  return ctx;
}

describe("aiConfigGradeCss", () => {
  it("builds a CSS grade from the config at full strength", () => {
    const css = aiConfigGradeCss(baseConfig, 1);
    expect(css).toContain("brightness(1.2)");
    expect(css).toContain("contrast(1.1)");
    expect(css).toContain("saturate(1.3)");
    expect(css).toContain("hue-rotate(-12deg)");
    expect(css).toContain("sepia(0.2)");
  });

  it("returns an empty string at intensity 0 (identity)", () => {
    expect(aiConfigGradeCss(baseConfig, 0)).toBe("");
  });

  it("lerps from neutral toward the target at partial intensity", () => {
    const css = aiConfigGradeCss(baseConfig, 0.5);
    // brightness halfway between neutral 1 and 1.2 → 1.1
    expect(css).toContain("brightness(1.1)");
  });

  it("omits primitives that resolve to their neutral value", () => {
    const flat: AiFilterConfig = {
      ...baseConfig,
      grade: { brightness: 1, contrast: 1, saturate: 1, hueRotate: 0, sepia: 0 },
    };
    expect(aiConfigGradeCss(flat, 1)).toBe("");
  });

  it("handles a null/missing config", () => {
    expect(aiConfigGradeCss(null, 1)).toBe("");
    expect(aiConfigGradeCss(undefined, 1)).toBe("");
  });
});

describe("renderAiConfigFilter", () => {
  it("draws overlay layers and leaves the context clean", () => {
    const ctx = makeCtx();
    renderAiConfigFilter(ctx, 1280, 720, 10, baseConfig, 1);
    expect(ctx.fillRect).toHaveBeenCalled();
    // One save/restore pair per overlay.
    const saves = ctx.calls.filter((c: string) => c === "save").length;
    const restores = ctx.calls.filter((c: string) => c === "restore").length;
    expect(saves).toBe(restores);
    expect(saves).toBeGreaterThanOrEqual(baseConfig.overlays.length);
    // Context reset for downstream layers.
    expect(ctx.globalCompositeOperation).toBe("source-over");
    expect(ctx.filter).toBe("none");
    expect(ctx.globalAlpha).toBe(1);
  });

  it("draws NOTHING at intensity 0 (identity)", () => {
    const ctx = makeCtx();
    renderAiConfigFilter(ctx, 1280, 720, 10, baseConfig, 0);
    expect(ctx.save).not.toHaveBeenCalled();
    expect(ctx.fillRect).not.toHaveBeenCalled();
  });

  it("is a no-op for a null config or empty overlays", () => {
    const ctx = makeCtx();
    renderAiConfigFilter(ctx, 1280, 720, 0, null, 1);
    renderAiConfigFilter(ctx, 1280, 720, 0, { ...baseConfig, overlays: [] }, 1);
    expect(ctx.save).not.toHaveBeenCalled();
  });

  it("skips an overlay whose strength is 0 but draws the rest", () => {
    const ctx = makeCtx();
    const cfg: AiFilterConfig = {
      ...baseConfig,
      overlays: [
        { type: "glow", color: "#ffffff", strength: 0, density: 0.5 },
        { type: "vignette", color: "#000000", strength: 0.8 },
      ],
    };
    renderAiConfigFilter(ctx, 1280, 720, 5, cfg, 1);
    const saves = ctx.calls.filter((c: string) => c === "save").length;
    expect(saves).toBe(1); // only the vignette drew
  });

  it("renders every whitelisted overlay type without throwing", () => {
    const types = [
      "particles", "rain", "glow", "vignette", "fog",
      "fabric", "lens_droplets", "shimmer", "grain", "light_leak",
    ] as const;
    for (const type of types) {
      const ctx = makeCtx();
      const cfg: AiFilterConfig = {
        ...baseConfig,
        overlays: [{ type, color: "#88ccff", strength: 0.7, density: 0.6 }],
        animation: { motion: "dynamic", speed: 0.8 },
      };
      expect(() => renderAiConfigFilter(ctx, 1280, 720, 17, cfg, 1)).not.toThrow();
      expect(ctx.save).toHaveBeenCalled();
    }
  });

  it("freezes motion when animation is 'still' but still draws", () => {
    const ctx = makeCtx();
    const cfg: AiFilterConfig = { ...baseConfig, animation: { motion: "still", speed: 1 } };
    renderAiConfigFilter(ctx, 1280, 720, 99, cfg, 1);
    expect(ctx.fillRect).toHaveBeenCalled();
  });
});
