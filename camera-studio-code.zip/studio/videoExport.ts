// videoExport.ts — in-browser trim + splice for the Camera Studio.
//
// We re-render the (trimmed) clips in order through a single hidden canvas while
// routing each clip's audio through one WebAudio destination, and record the
// whole thing with ONE MediaRecorder. That produces a single spliced video with
// continuous audio — no ffmpeg.wasm (which needs SharedArrayBuffer / cross-origin
// isolation that isn't guaranteed inside Replit's proxied iframe, and is heavy on
// iOS Safari). Export runs in real time, so callers should show progress.

export interface VideoSegment {
  id: string;
  blob: Blob;
  url: string; // object URL for the blob
  mimeType: string;
  duration: number; // full recorded length (seconds)
  trimStart: number; // seconds, inclusive
  trimEnd: number; // seconds, exclusive
  width: number;
  height: number;
}

export function segDuration(s: VideoSegment): number {
  return Math.max(0, s.trimEnd - s.trimStart);
}

export function totalTrimmedDuration(segs: VideoSegment[]): number {
  return segs.reduce((acc, s) => acc + segDuration(s), 0);
}

// Best recorder container the browser supports. Safari often only offers mp4.
export function pickRecorderMime(): string {
  if (typeof MediaRecorder === "undefined") return "";
  const candidates = [
    "video/webm;codecs=vp9,opus",
    "video/webm;codecs=vp8,opus",
    "video/webm",
    "video/mp4",
  ];
  for (const c of candidates) {
    if (MediaRecorder.isTypeSupported(c)) return c;
  }
  return "";
}

export function extForMime(mime: string): string {
  return mime.includes("mp4") ? "mp4" : "webm";
}

// ── Music baking ──────────────────────────────────────────────────────────────
// A soundtrack is decoded to an AudioBuffer and mixed into the same WebAudio
// destination the clips' audio is routed through, so it lands in the recording.
// "Fit to length" is handled per fitMode; gain has a short fade in/out.
export type MusicFitMode = "loop" | "trim" | "stretch" | "once";

export interface MusicMixOptions {
  url: string;
  fitMode: MusicFitMode;
  volume?: number; // 0..1, default 0.7
}

interface MusicGraph {
  start: (now: number) => void;
  stop: () => void;
}

// Fetch + decode the track and wire BufferSource → Gain → destination. Returns
// null (rather than throwing) on any failure so a missing/undecodable track never
// aborts the whole export — the video is simply rendered without music.
async function buildMusicGraph(
  audioCtx: AudioContext,
  audioDest: MediaStreamAudioDestinationNode,
  music: MusicMixOptions,
  totalDuration: number,
): Promise<MusicGraph | null> {
  let buffer: AudioBuffer;
  try {
    const resp = await fetch(music.url);
    if (!resp.ok) throw new Error(`music fetch failed (${resp.status})`);
    const arr = await resp.arrayBuffer();
    // decodeAudioData via callback form for the widest Safari support.
    buffer = await new Promise<AudioBuffer>((resolve, reject) => {
      audioCtx.decodeAudioData(arr, resolve, reject);
    });
  } catch {
    return null;
  }
  if (!buffer || buffer.duration <= 0 || totalDuration <= 0) return null;

  const src = audioCtx.createBufferSource();
  src.buffer = buffer;
  const gain = audioCtx.createGain();
  src.connect(gain);
  gain.connect(audioDest);

  const vol = Math.min(1, Math.max(0, music.volume ?? 0.7));

  switch (music.fitMode) {
    case "loop":
      src.loop = true;
      break;
    case "stretch": {
      // Time-stretch via playbackRate, clamped so it never sounds absurd; if the
      // clamp still leaves it short, loop so the track doesn't run out early.
      const rate = buffer.duration / totalDuration;
      const clamped = Math.min(2, Math.max(0.5, rate));
      src.playbackRate.value = clamped;
      if (buffer.duration / clamped < totalDuration - 0.1) src.loop = true;
      break;
    }
    case "trim":
    case "once":
    default:
      // Single pass — plays from the start and stops naturally at the buffer end
      // (the recorder stops at totalDuration regardless).
      src.loop = false;
      break;
  }

  return {
    start(now: number) {
      const fadeIn = 0.4;
      const fadeOut = 0.6;
      const safeVol = Math.max(0.0001, vol);
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(safeVol, now + fadeIn);
      const fadeOutAt = now + Math.max(fadeIn + 0.05, totalDuration - fadeOut);
      gain.gain.setValueAtTime(safeVol, fadeOutAt);
      gain.gain.exponentialRampToValueAtTime(0.0001, fadeOutAt + fadeOut);
      try {
        src.start(now);
      } catch {
        /* ignore */
      }
    },
    stop() {
      try {
        src.stop();
      } catch {
        /* ignore */
      }
      try {
        src.disconnect();
      } catch {
        /* ignore */
      }
      try {
        gain.disconnect();
      } catch {
        /* ignore */
      }
    },
  };
}

function makeAudioContext(): AudioContext {
  const AC: typeof AudioContext =
    (window as unknown as { AudioContext: typeof AudioContext }).AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  return new AC();
}

// iOS Safari will NOT reliably load a DETACHED <video> element fed a blob URL —
// it defers loading until the element is in the document and load() is called.
// Detached probing/preparing just times out, which previously discarded the
// recording ("Couldn't load that clip"). Mount it hidden so loading actually
// happens; callers force-load and remove it from the DOM when finished.
// `muted` must stay false for export clips whose audio is routed through WebAudio.
function mountHiddenVideo(opts: { muted?: boolean } = {}): HTMLVideoElement {
  const v = document.createElement("video");
  v.preload = "auto";
  v.muted = !!opts.muted;
  v.playsInline = true;
  v.setAttribute("playsinline", "");
  v.style.cssText =
    "position:fixed;left:-9999px;top:0;width:1px;height:1px;opacity:0;pointer-events:none;";
  document.body.appendChild(v);
  return v;
}

// Read a recorded blob's true duration + natural dimensions. MediaRecorder webm
// blobs frequently report duration === Infinity until the file is seeked, so we
// apply the standard "seek to the end then read currentTime" workaround.
export function probeBlob(
  url: string,
): Promise<{ duration: number; width: number; height: number }> {
  return new Promise((resolve, reject) => {
    // Mounted hidden in the DOM + force-loaded so iOS Safari actually reads the
    // blob's metadata (see mountHiddenVideo); removed on settle via cleanup().
    const v = mountHiddenVideo({ muted: true });
    let settled = false;
    const cleanup = () => {
      try {
        v.removeAttribute("src");
        v.load();
      } catch {
        /* ignore */
      }
      v.remove();
    };
    const timer = setTimeout(() => fail(new Error("Timed out reading clip")), 12000);
    const dims = () => ({ width: v.videoWidth || 1280, height: v.videoHeight || 720 });
    function done(r: { duration: number; width: number; height: number }) {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      cleanup();
      resolve(r);
    }
    function fail(e: Error) {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      cleanup();
      reject(e);
    }
    v.onloadedmetadata = () => {
      const d = v.duration;
      if (d === Infinity || Number.isNaN(d) || d === 0) {
        v.ontimeupdate = () => {
          v.ontimeupdate = null;
          const real = Number.isFinite(v.duration) ? v.duration : v.currentTime;
          try {
            v.currentTime = 0;
          } catch {
            /* ignore */
          }
          done({ duration: real, ...dims() });
        };
        try {
          v.currentTime = 1e7;
        } catch {
          done({ duration: d || 0, ...dims() });
        }
      } else {
        done({ duration: d, ...dims() });
      }
    };
    v.onerror = () => fail(new Error("Could not read recorded clip"));
    v.src = url;
    // Force iOS Safari to actually begin loading now that the element is attached.
    try {
      v.load();
    } catch {
      /* ignore */
    }
  });
}

// object-fit: cover — fill WxH, cropping overflow, preserving aspect ratio.
function drawCover(
  ctx: CanvasRenderingContext2D,
  video: HTMLVideoElement,
  W: number,
  H: number,
) {
  const vw = video.videoWidth;
  const vh = video.videoHeight;
  if (!vw || !vh) return;
  const scale = Math.max(W / vw, H / vh);
  const dw = vw * scale;
  const dh = vh * scale;
  ctx.drawImage(video, (W - dw) / 2, (H - dh) / 2, dw, dh);
}

interface PreparedSegment {
  seg: VideoSegment;
  video: HTMLVideoElement;
  node: MediaElementAudioSourceNode | null;
  clipGain: GainNode | null;
  // When AI voice cleanup is applied to this segment, its own audio is dropped and
  // this buffer source plays in its place (started in playPrepared, at trimStart).
  voiceSource: AudioBufferSourceNode | null;
  voiceGain: GainNode | null;
  audioCtx: AudioContext;
}

// Load a segment and seek it to its in-point WITHOUT recording yet. We do this
// while the MediaRecorder is paused so the (potentially slow on iOS Safari)
// load/seek/play startup never lands in the output as black/frozen/silent time.
function prepareSegment(
  seg: VideoSegment,
  audioCtx: AudioContext,
  audioDest: MediaStreamAudioDestinationNode,
  muteClipAudio: boolean,
  contentVolume: number,
  voiceBuffer: AudioBuffer | null,
): Promise<PreparedSegment> {
  return new Promise((resolve, reject) => {
    // When muteClipAudio is set the clip's own audio is dropped entirely (the user
    // wants to hear only the chosen soundtrack), so mount it muted and skip routing
    // it into the mix. Otherwise it must NOT be muted — its audio is routed through
    // WebAudio so iOS Safari actually loads it; removed in playPrepared's cleanup
    // once rendered, or here if preparation fails. When a cleaned voice buffer is
    // provided the clip is likewise muted (the buffer replaces its audio).
    const video = mountHiddenVideo({ muted: muteClipAudio || !!voiceBuffer });
    let node: MediaElementAudioSourceNode | null = null;
    let clipGain: GainNode | null = null;
    let voiceSource: AudioBufferSourceNode | null = null;
    let voiceGain: GainNode | null = null;
    let settled = false;
    const timer = setTimeout(
      () => fail(new Error("Timed out loading clip for export.")),
      15000,
    );
    const fail = (e: unknown) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      try {
        node?.disconnect();
      } catch {
        /* ignore */
      }
      try {
        clipGain?.disconnect();
      } catch {
        /* ignore */
      }
      try {
        voiceSource?.disconnect();
      } catch {
        /* ignore */
      }
      try {
        voiceGain?.disconnect();
      } catch {
        /* ignore */
      }
      video.remove();
      reject(e instanceof Error ? e : new Error("Clip playback failed during export."));
    };
    const done = () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve({ seg, video, node, clipGain, voiceSource, voiceGain, audioCtx });
    };
    video.onerror = () => fail(new Error("Clip playback failed during export."));
    // loadeddata → first frame is decoded and drawable.
    video.onloadeddata = () => {
      if (!muteClipAudio && !voiceBuffer && !node) {
        try {
          // One source node per fresh element — safe to create. Route the clip's
          // own audio through a gain node so the creator can set its level in the
          // final mix relative to the soundtrack.
          node = audioCtx.createMediaElementSource(video);
          clipGain = audioCtx.createGain();
          clipGain.gain.value = Math.min(1, Math.max(0, contentVolume));
          node.connect(clipGain);
          clipGain.connect(audioDest);
        } catch {
          node = null; // proceed video-only rather than aborting the whole export
          clipGain = null;
        }
      }
      if (voiceBuffer && !voiceSource) {
        try {
          // Cleaned voice replaces the clip's own audio; started in playPrepared so
          // it's aligned to the recorded (not wall-clock) timeline. Same gain shape
          // as the clip path so contentVolume still applies; music mixes on top.
          voiceSource = audioCtx.createBufferSource();
          voiceSource.buffer = voiceBuffer;
          voiceGain = audioCtx.createGain();
          voiceGain.gain.value = Math.min(1, Math.max(0, contentVolume));
          voiceSource.connect(voiceGain);
          voiceGain.connect(audioDest);
        } catch {
          voiceSource = null; // fall back to silent (video-only) rather than abort
          voiceGain = null;
        }
      }
      if (seg.trimStart > 0.05 && Math.abs(video.currentTime - seg.trimStart) > 0.05) {
        video.onseeked = () => {
          video.onseeked = null;
          done();
        };
        try {
          video.currentTime = seg.trimStart;
        } catch {
          done();
        }
      } else {
        done();
      }
    };
    video.src = seg.url;
    // Force iOS Safari to begin loading now that the element is attached.
    try {
      video.load();
    } catch {
      /* ignore */
    }
  });
}

// Playback safety margins. A clip normally ends via `ended` or by reaching
// trimEnd, but neither is guaranteed: MediaRecorder-produced webm blobs often
// report a slightly-too-long duration and then plateau a hair short of the end
// WITHOUT firing `ended`, and rAF stops entirely when the tab is backgrounded.
// Without a wall-clock fallback that made "Combining…" hang at 99% forever.
const CLIP_STALL_MS = 5000; // no currentTime advance for this long ⇒ treat as ended
const CLIP_OVERRUN_MS = 10_000; // wall-clock past the clip's real-time length ⇒ bail
const FINALIZE_TIMEOUT_MS = 10_000; // MediaRecorder.stop() never fired onstop ⇒ flush + move on

// Play one already-prepared segment into the canvas + audio destination, drawing
// frames until trimEnd. The recorder must be actively recording when called.
function playPrepared(
  prep: PreparedSegment,
  ctx: CanvasRenderingContext2D,
  W: number,
  H: number,
  onElapsed: (seconds: number) => void,
): Promise<void> {
  const { seg, video, node, clipGain, voiceSource, voiceGain, audioCtx } = prep;
  return new Promise((resolve, reject) => {
    let raf = 0;
    let watchdog: ReturnType<typeof setInterval> | null = null;
    let settled = false;
    // Wall-clock stall/overrun tracking (see CLIP_STALL_MS / CLIP_OVERRUN_MS).
    const startedAt = performance.now();
    let lastCur = seg.trimStart;
    let lastAdvance = startedAt;
    const cleanup = () => {
      cancelAnimationFrame(raf);
      if (watchdog !== null) {
        clearInterval(watchdog);
        watchdog = null;
      }
      try {
        video.pause();
      } catch {
        /* ignore */
      }
      try {
        node?.disconnect();
      } catch {
        /* ignore */
      }
      try {
        clipGain?.disconnect();
      } catch {
        /* ignore */
      }
      try {
        voiceSource?.stop();
      } catch {
        /* ignore — already ended */
      }
      try {
        voiceSource?.disconnect();
      } catch {
        /* ignore */
      }
      try {
        voiceGain?.disconnect();
      } catch {
        /* ignore */
      }
      video.removeAttribute("src");
      try {
        video.load();
      } catch {
        /* ignore */
      }
      video.remove();
    };
    const finish = () => {
      if (settled) return;
      settled = true;
      cleanup();
      resolve();
    };
    const fail = (e: unknown) => {
      if (settled) return;
      settled = true;
      cleanup();
      reject(e instanceof Error ? e : new Error("Clip playback failed during export."));
    };
    const tick = () => {
      if (settled) return;
      // Small epsilon on the end check: a blob that plateaus a hair short of
      // trimEnd (never firing `ended`) still completes instead of spinning at 99%.
      if (video.ended || video.currentTime >= seg.trimEnd - 0.05) {
        finish();
        return;
      }
      drawCover(ctx, video, W, H);
      onElapsed(Math.max(0, video.currentTime - seg.trimStart));
      raf = requestAnimationFrame(tick);
    };
    // Wall-clock watchdog (setInterval keeps firing even when the tab is
    // backgrounded and rAF is paused): if playback stops advancing, or runs well
    // past the clip's real-time length, we've captured every frame this clip will
    // yield — finalize rather than hang "Combining…" forever.
    const checkStall = () => {
      if (settled) return;
      const now = performance.now();
      if (video.currentTime > lastCur + 0.01) {
        lastCur = video.currentTime;
        lastAdvance = now;
      }
      const stalled = now - lastAdvance > CLIP_STALL_MS;
      const overran = now - startedAt > segDuration(seg) * 1000 + CLIP_OVERRUN_MS;
      if (stalled || overran) finish();
    };
    video.onended = () => finish();
    video.onerror = () => fail(new Error("Clip playback failed during export."));
    // Paint the in-point frame immediately so the first recorded frame is correct.
    drawCover(ctx, video, W, H);
    video
      .play()
      .then(() => {
        // Start the cleaned voice in lockstep with playback, from the clip's
        // in-point for its trimmed length (the buffer holds the FULL segment).
        if (voiceSource) {
          try {
            voiceSource.start(
              audioCtx.currentTime,
              Math.max(0, seg.trimStart),
              segDuration(seg),
            );
          } catch {
            /* ignore — a failed start just means silence for this clip */
          }
        }
        lastAdvance = performance.now();
        watchdog = setInterval(checkStall, 500);
        raf = requestAnimationFrame(tick);
      })
      .catch(fail);
  });
}

// Choose recorder options that keep the exported file comfortably under the
// server's upload size cap (~50MB) for a clip of `totalSec` seconds, while never
// exceeding a sensible quality ceiling for short clips. Longer exports (up to the
// 225s cap) get a lower bitrate so they still fit. Audio is a fixed 128 kbps.
const EXPORT_AUDIO_BPS = 128_000;
function recorderOptions(mime: string, totalSec: number): MediaRecorderOptions {
  const options: MediaRecorderOptions = mime ? { mimeType: mime } : {};
  const TARGET_BYTES = 42 * 1024 * 1024; // headroom under the 50MB server cap
  const MAX_VIDEO_BPS = 8_000_000;
  const MIN_VIDEO_BPS = 1_200_000;
  const budget = Math.floor((TARGET_BYTES * 8) / Math.max(1, totalSec)) - EXPORT_AUDIO_BPS;
  options.videoBitsPerSecond = Math.max(MIN_VIDEO_BPS, Math.min(MAX_VIDEO_BPS, budget));
  options.audioBitsPerSecond = EXPORT_AUDIO_BPS;
  return options;
}

// Render the ordered, trimmed segments into a single video blob. A single,
// essentially-untrimmed clip is returned as-is (no re-encode).
export async function exportSegments(
  segs: VideoSegment[],
  opts: {
    fps?: number;
    onProgress?: (p: number) => void;
    music?: MusicMixOptions;
    // Drop each clip's own recorded audio from the mix so only the soundtrack is
    // heard. Forces a re-encode (the fast path can't strip the original audio).
    muteClipAudio?: boolean;
    // Level for each clip's own audio in the final mix (0..1, default 1 =
    // unchanged). Any value below 1 forces a re-encode so the gain lands.
    contentVolume?: number;
    // Optional AI-cleaned voice per segment id. When set for a segment, its own
    // audio is dropped and this buffer plays in its place (music still mixes on
    // top). Any override forces a re-encode, so the fast path below is skipped.
    voiceOverrides?: Map<string, AudioBuffer>;
  } = {},
): Promise<Blob> {
  const valid = segs.filter((s) => segDuration(s) > 0.05);
  if (valid.length === 0) {
    throw new Error("Nothing to export — every clip is trimmed to zero.");
  }

  const contentVol = Math.min(1, Math.max(0, opts.contentVolume ?? 1));
  const voiceFor = (s: VideoSegment): AudioBuffer | null =>
    opts.voiceOverrides?.get(s.id) ?? null;
  const anyVoice = valid.some((s) => !!voiceFor(s));

  // Fast path: one clip, no meaningful trim → upload the original recording.
  // Skipped when a soundtrack is requested, the original audio must be dropped or
  // its level lowered, or AI voice cleanup is applied — all require a re-encode.
  if (
    valid.length === 1 &&
    !opts.music &&
    !opts.muteClipAudio &&
    !anyVoice &&
    contentVol >= 0.999
  ) {
    const s = valid[0];
    if (s.trimStart <= 0.08 && s.trimEnd >= s.duration - 0.08) {
      opts.onProgress?.(1);
      return s.blob;
    }
  }

  const fps = opts.fps ?? 30;
  const W = valid[0].width || 1280;
  const H = valid[0].height || 720;

  const canvas = document.createElement("canvas");
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas not available for export.");
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, W, H);

  const canvasStream = canvas.captureStream(fps);
  const AC: typeof AudioContext =
    (window as unknown as { AudioContext: typeof AudioContext }).AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const audioCtx = new AC();
  if (audioCtx.state === "suspended") {
    try {
      await audioCtx.resume();
    } catch {
      /* ignore */
    }
  }
  const audioDest = audioCtx.createMediaStreamDestination();

  const mixed = new MediaStream();
  canvasStream.getVideoTracks().forEach((t) => mixed.addTrack(t));
  audioDest.stream.getAudioTracks().forEach((t) => mixed.addTrack(t));

  const mime = pickRecorderMime();
  // Byte-safe adaptive bitrate so a long (up to 225s) export stays under the cap.
  const rec = new MediaRecorder(mixed, recorderOptions(mime, totalTrimmedDuration(valid)));
  const chunks: Blob[] = [];
  rec.ondataavailable = (e) => {
    if (e.data.size > 0) chunks.push(e.data);
  };
  const stopped = new Promise<void>((res) => {
    rec.onstop = () => res();
  });

  const total = totalTrimmedDuration(valid);
  // Decode + wire the optional soundtrack before recording begins (so decode
  // latency isn't captured). The recorder pauses across inter-clip gaps, so we
  // also suspend/resume the AudioContext in lockstep to keep the music aligned
  // to the *recorded* timeline rather than wall-clock time.
  const musicGraph = opts.music
    ? await buildMusicGraph(audioCtx, audioDest, opts.music, total)
    : null;
  let done = 0;
  let recStarted = false;
  try {
    for (let i = 0; i < valid.length; i++) {
      // Prepare (load + seek) the next clip while the recorder is paused, so its
      // startup latency isn't captured into the output.
      const prep = await prepareSegment(valid[i], audioCtx, audioDest, opts.muteClipAudio ?? false, contentVol, voiceFor(valid[i]));
      // Paint its in-point frame before the recorder resumes, so resume captures
      // the correct frame rather than the previous clip's last frame.
      drawCover(ctx, prep.video, W, H);
      if (!recStarted) {
        rec.start(100);
        recStarted = true;
        if (musicGraph) {
          if (audioCtx.state === "suspended") {
            try {
              await audioCtx.resume();
            } catch {
              /* ignore */
            }
          }
          musicGraph.start(audioCtx.currentTime);
        }
      } else if (rec.state === "paused") {
        if (musicGraph && audioCtx.state === "suspended") {
          try {
            await audioCtx.resume();
          } catch {
            /* ignore */
          }
        }
        rec.resume();
      }
      await playPrepared(prep, ctx, W, H, (e) => {
        opts.onProgress?.(Math.min(0.99, total > 0 ? (done + e) / total : 0));
      });
      done += segDuration(valid[i]);
      // Pause across the gap before the next clip is ready (skip after the last).
      if (i < valid.length - 1 && rec.state === "recording") {
        try {
          rec.pause();
        } catch {
          /* ignore — minor gap if pause is unsupported */
        }
        // Freeze the music with the recorder so it doesn't run ahead during the gap.
        if (musicGraph) {
          try {
            await audioCtx.suspend();
          } catch {
            /* ignore */
          }
        }
      }
    }
  } finally {
    // Make sure the context is running so the recorder can flush its final frames.
    if (musicGraph && audioCtx.state === "suspended") {
      try {
        await audioCtx.resume();
      } catch {
        /* ignore */
      }
    }
    if (recStarted) {
      try {
        if (rec.state !== "inactive") rec.stop();
      } catch {
        /* ignore */
      }
      // Some browsers occasionally never fire `onstop` after stop(). Race the
      // stop against a wall-clock timeout so a stuck recorder can't hang the
      // finalize step — we already have the recorded chunks from the 100ms
      // timeslice, so flush any tail and proceed with what we have.
      await Promise.race([
        stopped,
        new Promise<void>((res) =>
          setTimeout(() => {
            try {
              if (rec.state !== "inactive") rec.requestData();
            } catch {
              /* ignore */
            }
            // requestData() fires `dataavailable` on a later macrotask; give that
            // tail chunk a beat to land in `chunks` before we assemble the blob.
            setTimeout(res, 300);
          }, FINALIZE_TIMEOUT_MS),
        ),
      ]);
    }
    if (musicGraph) musicGraph.stop();
    try {
      audioCtx.close();
    } catch {
      /* ignore */
    }
    canvasStream.getTracks().forEach((t) => t.stop());
  }

  if (chunks.length === 0) throw new Error("Export produced no data.");
  opts.onProgress?.(1);
  return new Blob(chunks, { type: rec.mimeType || mime || "video/webm" });
}

// ── Photo slideshow ─────────────────────────────────────────────────────────────
function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Couldn't load a slideshow photo."));
    img.src = src;
  });
}

// object-fit: cover for an image (mirror of drawCover for <video>).
function drawCoverImage(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  W: number,
  H: number,
) {
  const iw = img.naturalWidth;
  const ih = img.naturalHeight;
  if (!iw || !ih) return;
  const scale = Math.max(W / iw, H / ih);
  const dw = iw * scale;
  const dh = ih * scale;
  ctx.drawImage(img, (W - dw) / 2, (H - dh) / 2, dw, dh);
}

// Render an ordered set of photos into a single video blob: each photo holds for
// `perSlideSec`, with a short cross-fade into the next, and the optional soundtrack
// baked in via the same WebAudio graph as exportSegments. Returns the blob plus a
// poster (first slide) data URL for the post thumbnail. There are no recorder
// pauses here, so the music stays in sync without suspend/resume.
export async function exportSlideshow(
  sources: string[],
  opts: {
    fps?: number;
    perSlideSec?: number;
    crossfadeSec?: number;
    width?: number;
    height?: number;
    music?: MusicMixOptions;
    maxSeconds?: number;
    onProgress?: (p: number) => void;
  } = {},
): Promise<{ blob: Blob; posterDataUrl: string }> {
  const srcs = sources.filter(Boolean);
  if (srcs.length === 0) throw new Error("Add at least one photo for the slideshow.");

  const fps = opts.fps ?? 30;
  const perSlide = Math.max(0.5, opts.perSlideSec ?? 3);
  const crossfade = Math.min(perSlide / 2, Math.max(0, opts.crossfadeSec ?? 0.6));
  const total = srcs.length * perSlide;
  const cap = opts.maxSeconds ?? 300;
  if (total > cap + 1) {
    throw new Error("Slideshow is over the length limit. Use fewer photos or a shorter slide time.");
  }

  const images = await Promise.all(srcs.map(loadImage));
  const W = opts.width ?? 1080;
  const H = opts.height ?? 1350;

  const canvas = document.createElement("canvas");
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas not available for export.");
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, W, H);
  // Poster = first slide, captured before recording begins.
  drawCoverImage(ctx, images[0], W, H);
  const posterDataUrl = canvas.toDataURL("image/jpeg", 0.82);

  const canvasStream = canvas.captureStream(fps);
  const audioCtx = makeAudioContext();
  if (audioCtx.state === "suspended") {
    try {
      await audioCtx.resume();
    } catch {
      /* ignore */
    }
  }
  const audioDest = audioCtx.createMediaStreamDestination();
  const musicGraph = opts.music
    ? await buildMusicGraph(audioCtx, audioDest, opts.music, total)
    : null;

  const mixed = new MediaStream();
  canvasStream.getVideoTracks().forEach((t) => mixed.addTrack(t));
  audioDest.stream.getAudioTracks().forEach((t) => mixed.addTrack(t));

  const mime = pickRecorderMime();
  // Byte-safe adaptive bitrate so a full-length slideshow stays under the cap.
  const rec = new MediaRecorder(mixed, recorderOptions(mime, total));
  const chunks: Blob[] = [];
  rec.ondataavailable = (e) => {
    if (e.data.size > 0) chunks.push(e.data);
  };
  const stopped = new Promise<void>((res) => {
    rec.onstop = () => res();
  });

  try {
    rec.start(100);
    if (musicGraph) musicGraph.start(audioCtx.currentTime);
    const startMs = performance.now();
    await new Promise<void>((resolve) => {
      const tick = () => {
        const t = (performance.now() - startMs) / 1000;
        if (t >= total) {
          resolve();
          return;
        }
        const idx = Math.min(images.length - 1, Math.floor(t / perSlide));
        const localT = t - idx * perSlide;
        ctx.globalAlpha = 1;
        ctx.fillStyle = "#000";
        ctx.fillRect(0, 0, W, H);
        drawCoverImage(ctx, images[idx], W, H);
        // Cross-fade into the next slide during the tail of this one.
        const remaining = perSlide - localT;
        if (crossfade > 0 && remaining < crossfade && idx < images.length - 1) {
          ctx.globalAlpha = 1 - remaining / crossfade;
          drawCoverImage(ctx, images[idx + 1], W, H);
          ctx.globalAlpha = 1;
        }
        opts.onProgress?.(Math.min(0.99, t / total));
        requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    });
  } finally {
    try {
      if (rec.state !== "inactive") rec.stop();
    } catch {
      /* ignore */
    }
    // Guard against a recorder that never fires `onstop` (see exportSegments):
    // race the stop against a timeout and proceed with the chunks we already have.
    await Promise.race([
      stopped,
      new Promise<void>((res) =>
        setTimeout(() => {
          try {
            if (rec.state !== "inactive") rec.requestData();
          } catch {
            /* ignore */
          }
          // requestData() fires `dataavailable` on a later macrotask; give that
          // tail chunk a beat to land in `chunks` before we assemble the blob.
          setTimeout(res, 300);
        }, FINALIZE_TIMEOUT_MS),
      ),
    ]);
    if (musicGraph) musicGraph.stop();
    try {
      audioCtx.close();
    } catch {
      /* ignore */
    }
    canvasStream.getTracks().forEach((t) => t.stop());
  }

  if (chunks.length === 0) throw new Error("Slideshow export produced no data.");
  opts.onProgress?.(1);
  return {
    blob: new Blob(chunks, { type: rec.mimeType || mime || "video/webm" }),
    posterDataUrl,
  };
}
