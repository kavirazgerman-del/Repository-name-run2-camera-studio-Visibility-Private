// ── Beauty X ("zeroG Beauty") — face-aware beautify + underwater/space atmosphere ─
// Premium camera filter. Two cooperating layers, both BAKED into the 2D bake buffer
// (so they capture into photo/video with zero changes to videoExport.ts):
//
//   1. BEAUTY  — beautyXGL.ts reads the already-drawn bake frame as a texture and
//      returns a processed copy (face slim + eye enlarge warp, edge-preserving skin
//      smoothing, brightness, tone evenness, eye brightening, teeth whitening,
//      unsharp "ultra sharp", bloom glow). We blit it straight back over the base.
//   2. ATMOSPHERE — cached Canvas2D sprites (cosmic blue glow, rising bubbles, light
//      rays) + landmark-driven zero-G hair wisps, animated transforms/alpha only.
//      Ambient layers show even with no face; hair wisps need a tracked face.
//
// Reuses the Neon Patriot MediaPipe FaceLandmarker tracker + its cover mapping so the
// effect locks to the face with no base-video zoom/crop. intensity 0 ⇒ full no-op.

import { makeCoverMap, mapX, mapY, type CoverMap, type NeonPatriotTracking } from "./neonPatriot";
import { renderBeautyXGL, type BeautyXUniforms } from "./beautyXGL";

// ── Params (driven by the dedicated controls; intensity merged from the shared
// Filters slider so the knob scales the WHOLE effect at capture time too) ──────────
export type BXLevel = "natural" | "high" | "extreme";

export interface BeautyXParams {
  intensity: number;     // 0..100 — overall strength
  level: BXLevel;        // preset bundle (Natural / High / Extreme)
  skinSmooth: number;    // 0..100
  skinBright: number;
  skinEven: number;      // tone evenness
  faceSlim: number;
  eyeEnlarge: number;
  eyeBright: number;
  teethWhiten: number;
  sharpness: number;
  glow: number;
  hairFloat: number;     // zero-G hair float amount
  hairVolume: number;    // number/density of floating wisps
  underwaterFx: number;  // cosmic/underwater atmosphere strength
  bubbles: boolean;
  lightRays: boolean;
}

// Spec defaults — the "Extreme" zeroG Beauty look at full intensity.
export const DEFAULT_BEAUTY_X_PARAMS: BeautyXParams = {
  intensity: 100, level: "extreme",
  skinSmooth: 100, skinBright: 85, skinEven: 100,
  faceSlim: 60, eyeEnlarge: 75, eyeBright: 100, teethWhiten: 90,
  sharpness: 100, glow: 80, hairFloat: 100, hairVolume: 90, underwaterFx: 80,
  bubbles: true, lightRays: true,
};

export const BX_LEVELS: { id: BXLevel; label: string }[] = [
  { id: "natural", label: "Natural" }, { id: "high", label: "High" }, { id: "extreme", label: "Extreme" },
];

// Preset bundles applied when the Beauty Level segment is picked (intensity + the
// two toggles are left to the user; everything else is set from the bundle).
export const BX_PRESETS: Record<BXLevel, Omit<BeautyXParams, "intensity" | "level" | "bubbles" | "lightRays">> = {
  natural: { skinSmooth: 45, skinBright: 50, skinEven: 50, faceSlim: 22, eyeEnlarge: 28, eyeBright: 55, teethWhiten: 45, sharpness: 55, glow: 38, hairFloat: 45, hairVolume: 45, underwaterFx: 45 },
  high:    { skinSmooth: 75, skinBright: 70, skinEven: 80, faceSlim: 42, eyeEnlarge: 52, eyeBright: 80, teethWhiten: 70, sharpness: 80, glow: 60, hairFloat: 75, hairVolume: 70, underwaterFx: 65 },
  extreme: { skinSmooth: 100, skinBright: 85, skinEven: 100, faceSlim: 60, eyeEnlarge: 75, eyeBright: 100, teethWhiten: 90, sharpness: 100, glow: 80, hairFloat: 100, hairVolume: 90, underwaterFx: 80 },
};

// ── Landmark groups (MediaPipe FaceMesh 468) ─────────────────────────────────────
const FACE_TOP = 10, FACE_CHIN = 152, FACE_L = 234, FACE_R = 454;
const EYE_L = [33, 133, 159, 145];   // outer, inner, top, bottom
const EYE_R = [362, 263, 386, 374];
const MOUTH = [61, 291, 13, 14];     // left, right, top-inner, bottom-inner
const HAIRLINE = [10, 67, 297, 21, 251, 103, 332]; // crown + temples (wisp anchors)

const clamp01 = (v: number) => Math.max(0, Math.min(1, v));

// Final 0..1 beauty strengths (callers pre-scale by their own intensity * fade).
export interface BeautyStrengths {
  smooth: number; bright: number; even: number;
  slim: number; enlarge: number; eyeBright: number; teeth: number;
  sharp: number; glow: number;
}

// Build the full BeautyXUniforms for a tracked face: face/eye/mouth ellipse geometry
// is derived from the smoothed landmarks (mapped via the cover map, mirror baked in);
// the strengths are passed straight through. Shared by Beauty X AND the Carnival
// filter (which reuses the same GL beautify pass) so the landmark math lives ONCE.
export function buildBeautyXUniforms(
  lm: Float32Array, m: CoverMap, w: number, h: number, s: BeautyStrengths,
): BeautyXUniforms {
  const px = (i: number) => mapX(m, lm[i * 3]);
  const py = (i: number) => mapY(m, lm[i * 3 + 1]);
  const avg = (ids: number[], f: (i: number) => number) => ids.reduce((acc, i) => acc + f(i), 0) / ids.length;

  const topY = py(FACE_TOP), chinY = py(FACE_CHIN), lX = px(FACE_L), rX = px(FACE_R);
  const faceW = Math.abs(rX - lX), faceH = Math.abs(chinY - topY);
  const faceCx = ((lX + rX) / 2) / w, faceCy = ((topY + chinY) / 2) / h;
  const faceRx = clamp01((faceW / 2) * 1.06 / w), faceRy = clamp01((faceH / 2) * 1.08 / h);

  const eLx = avg(EYE_L, px) / w, eLy = avg(EYE_L, py) / h;
  const eRx = avg(EYE_R, px) / w, eRy = avg(EYE_R, py) / h;
  const eyeWpx = Math.abs(px(EYE_L[1]) - px(EYE_L[0]));        // outer→inner corner
  const eyeRad = Math.max(0.02, (eyeWpx * 0.85) / h);          // uv-y units (GL aspect-corrects x)

  const mX = avg(MOUTH, px) / w, mY = avg(MOUTH, py) / h;
  const mouthRad = Math.max(0.02, (Math.abs(px(MOUTH[1]) - px(MOUTH[0])) * 0.62) / h);

  return {
    valid: true,
    faceCx, faceCy, faceRx, faceRy,
    eyeLx: eLx, eyeLy: eLy, eyeRx: eRx, eyeRy: eRy, eyeRad,
    mouthX: mX, mouthY: mY, mouthRad,
    smooth: s.smooth, bright: s.bright, even: s.even,
    slim: s.slim, enlarge: s.enlarge, eyeBright: s.eyeBright, teeth: s.teeth,
    sharp: s.sharp, glow: s.glow,
  };
}

// ── Atmosphere sprites (built once per size, blitted each frame) ──────────────────
interface AtmoSprites { rays: HTMLCanvasElement; bubble: HTMLCanvasElement; dust: HTMLCanvasElement; }
const atmoCache = new Map<string, AtmoSprites>();
const bxOffscreen = (w: number, h: number) => { const c = document.createElement("canvas"); c.width = w; c.height = h; return c; };

const rng = (seed: number) => {
  let s = seed >>> 0;
  return () => { s = (s + 0x6d2b79f5) >>> 0; let x = s; x = Math.imul(x ^ (x >>> 15), x | 1); x ^= x + Math.imul(x ^ (x >>> 7), x | 61); return ((x ^ (x >>> 14)) >>> 0) / 4294967296; };
};

function getAtmoSprites(w: number, h: number): AtmoSprites {
  const key = `${w}x${h}`;
  const hit = atmoCache.get(key);
  if (hit) return hit;

  // Light rays — soft cyan god-rays slanting down from the top, pre-rendered so we
  // only animate a horizontal drift + alpha pulse each frame (cheap + flicker-free).
  const rays = bxOffscreen(w, h);
  const rc = rays.getContext("2d")!;
  rc.globalCompositeOperation = "screen";
  const rr = rng(40411);
  for (let i = 0; i < 9; i++) {
    const x = (0.05 + 0.95 * (i / 8)) * w + (rr() - 0.5) * 60;
    const topW = 18 + rr() * 46, botW = topW * (2.4 + rr() * 1.6);
    const a = 0.05 + rr() * 0.12;
    const slant = (rr() - 0.5) * 0.22 * w;
    rc.beginPath();
    rc.moveTo(x - topW / 2, -10);
    rc.lineTo(x + topW / 2, -10);
    rc.lineTo(x + botW / 2 + slant, h + 10);
    rc.lineTo(x - botW / 2 + slant, h + 10);
    rc.closePath();
    const g = rc.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, `rgba(150,225,255,${a})`);
    g.addColorStop(0.55, `rgba(90,180,255,${a * 0.5})`);
    g.addColorStop(1, "rgba(90,180,255,0)");
    rc.fillStyle = g; rc.fill();
  }

  // A single soft bubble sprite (refractive ring + catch-light), blitted per particle.
  const BS = 64, bubble = bxOffscreen(BS, BS), bc = bubble.getContext("2d")!;
  const body = bc.createRadialGradient(BS / 2, BS / 2, BS * 0.1, BS / 2, BS / 2, BS * 0.48);
  body.addColorStop(0, "rgba(180,235,255,0.05)");
  body.addColorStop(0.72, "rgba(150,220,255,0.10)");
  body.addColorStop(0.9, "rgba(190,240,255,0.55)");
  body.addColorStop(1, "rgba(150,220,255,0)");
  bc.fillStyle = body; bc.beginPath(); bc.arc(BS / 2, BS / 2, BS * 0.48, 0, Math.PI * 2); bc.fill();
  const hl = bc.createRadialGradient(BS * 0.36, BS * 0.34, 0, BS * 0.36, BS * 0.34, BS * 0.2);
  hl.addColorStop(0, "rgba(255,255,255,0.85)"); hl.addColorStop(1, "rgba(255,255,255,0)");
  bc.fillStyle = hl; bc.beginPath(); bc.arc(BS * 0.36, BS * 0.34, BS * 0.2, 0, Math.PI * 2); bc.fill();

  // Faint drifting cosmic dust / sparkle field (screen).
  const dust = bxOffscreen(w, h), dc = dust.getContext("2d")!;
  dc.globalCompositeOperation = "screen";
  const dr = rng(90217);
  for (let i = 0; i < 140; i++) {
    const x = dr() * w, y = dr() * h, r = 0.6 + dr() * 1.8, a = 0.12 + dr() * 0.4;
    const g = dc.createRadialGradient(x, y, 0, x, y, r * 3);
    const tint = dr() < 0.5 ? "150,225,255" : "150,170,255";
    g.addColorStop(0, `rgba(${tint},${a})`); g.addColorStop(1, `rgba(${tint},0)`);
    dc.fillStyle = g; dc.beginPath(); dc.arc(x, y, r * 3, 0, Math.PI * 2); dc.fill();
  }

  const sprites: AtmoSprites = { rays, bubble, dust };
  atmoCache.set(key, sprites);
  return sprites;
}

// Mutable particle buffer entry (structurally compatible with CameraStudio's CvParticle).
interface BXParticle { x: number; y: number; vx: number; vy: number; life: number; r: number; color: string; }

// ── Main render — beauty GL blit + atmosphere overlay ─────────────────────────────
export function renderBeautyX(
  ctx: CanvasRenderingContext2D, w: number, h: number, frame: number, p: BXParticle[],
  tracking: NeonPatriotTracking | null, vw: number, vh: number, mirror: boolean,
  params: BeautyXParams,
) {
  const t = clamp01(params.intensity / 100);
  if (t <= 0) return;                         // intensity 0 ⇒ fully neutral

  const lm = tracking?.landmarks ?? null;
  const fade = tracking?.fade ?? 0;
  const count = tracking?.count ?? 0;
  const valid = !!lm && fade > 0 && count >= 468;
  const m: CoverMap = makeCoverMap(w, h, vw, vh, mirror);

  // ── 1) Beauty pass (only with a tracked face; eases out with the tracking fade) ──
  if (valid && lm) {
    // Strengths scaled by overall intensity AND the tracking fade (so beauty eases
    // out cleanly on tracking loss rather than popping off). Geometry + uniform
    // assembly live in the shared buildBeautyXUniforms (reused by Carnival).
    const k = t * fade;
    const u = buildBeautyXUniforms(lm, m, w, h, {
      smooth: clamp01(params.skinSmooth / 100) * k * 0.95,
      bright: clamp01(params.skinBright / 100) * k,
      even: clamp01(params.skinEven / 100) * k,
      slim: clamp01(params.faceSlim / 100) * k,
      enlarge: clamp01(params.eyeEnlarge / 100) * k,
      eyeBright: clamp01(params.eyeBright / 100) * k,
      teeth: clamp01(params.teethWhiten / 100) * k,
      sharp: clamp01(params.sharpness / 100) * k * 0.8,
      glow: clamp01(params.glow / 100) * k * 0.9,
    });
    const out = renderBeautyXGL(ctx.canvas, u);
    if (out) { ctx.save(); ctx.globalAlpha = 1; ctx.drawImage(out, 0, 0, w, h); ctx.restore(); }
  }

  // ── 2) Atmosphere overlay (ambient even with no face) ────────────────────────────
  const atmo = clamp01(params.underwaterFx / 100) * t;
  const S = getAtmoSprites(w, h);

  // Cosmic blue glow — a deep-space radial wash (screen) + a cool top-down bloom.
  if (atmo > 0.01) {
    ctx.save();
    ctx.globalCompositeOperation = "screen";
    ctx.globalAlpha = atmo * 0.55;
    const halo = ctx.createRadialGradient(w * 0.5, h * 0.42, h * 0.12, w * 0.5, h * 0.5, h * 0.95);
    halo.addColorStop(0, "rgba(70,170,255,0.45)");
    halo.addColorStop(0.5, "rgba(40,90,200,0.18)");
    halo.addColorStop(1, "rgba(20,40,120,0)");
    ctx.fillStyle = halo; ctx.fillRect(0, 0, w, h);
    ctx.restore();

    // Drifting cosmic dust.
    ctx.save();
    ctx.globalCompositeOperation = "screen";
    ctx.globalAlpha = atmo * (0.5 + 0.2 * Math.sin(frame * 0.02));
    const dx = (Math.sin(frame * 0.004) * 0.02) * w;
    ctx.drawImage(S.dust, dx, (frame * 0.15) % h - h, w, h);
    ctx.drawImage(S.dust, dx, (frame * 0.15) % h, w, h);
    ctx.restore();
  }

  // Light rays — slow horizontal drift + gentle alpha breathing.
  if (params.lightRays && atmo > 0.01) {
    ctx.save();
    ctx.globalCompositeOperation = "screen";
    ctx.globalAlpha = atmo * (0.6 + 0.25 * Math.sin(frame * 0.03));
    const rx = Math.sin(frame * 0.006) * 0.03 * w;
    ctx.drawImage(S.rays, rx, 0, w, h);
    ctx.restore();
  }

  // Rising bubbles — particle field drifting upward with a slight wobble.
  if (params.bubbles) {
    const TARGET = Math.round(46 * atmo);
    const spawn = Math.max(1, Math.round(TARGET / 26));
    for (let i = 0; i < spawn && p.length < TARGET; i++) {
      const d = Math.random();                 // depth 0 far → 1 near
      p.push({
        x: Math.random(), y: 1.05 + Math.random() * 0.1,
        vx: (Math.random() - 0.5) * 0.0011, vy: -(0.004 + d * 0.012),
        life: d, r: 4 + d * 26, color: "",
      });
    }
    ctx.save();
    ctx.globalCompositeOperation = "screen";
    for (let i = p.length - 1; i >= 0; i--) {
      const s = p[i];
      s.x += s.vx + Math.sin((frame * 0.04) + s.life * 9) * 0.0007;
      s.y += s.vy;
      if (s.y < -0.1 || p.length > TARGET + 30) { p.splice(i, 1); continue; }
      ctx.globalAlpha = (0.25 + s.life * 0.5) * atmo;
      const sz = s.r * 2;
      ctx.drawImage(S.bubble, s.x * w - sz / 2, s.y * h - sz / 2, sz, sz);
    }
    ctx.restore();
  }

  // Zero-G hair wisps + rim glow — landmark-anchored ethereal strands floating UP off
  // the crown (honest approximation of the "floating hair" look on arbitrary video).
  if (valid && lm) {
    const px = (i: number) => mapX(m, lm[i * 3]);
    const py = (i: number) => mapY(m, lm[i * 3 + 1]);
    const float = clamp01(params.hairFloat / 100);
    const vol = clamp01(params.hairVolume / 100);
    const headW = Math.abs(px(FACE_R) - px(FACE_L));
    const crownY = py(FACE_TOP);

    // Soft rim glow hugging the crown.
    ctx.save();
    ctx.globalCompositeOperation = "screen";
    ctx.globalAlpha = (0.35 + 0.4 * vol) * t * fade;
    const rim = ctx.createRadialGradient(px(FACE_TOP), crownY, headW * 0.1, px(FACE_TOP), crownY, headW * 0.75);
    rim.addColorStop(0, "rgba(150,220,255,0.5)");
    rim.addColorStop(1, "rgba(120,180,255,0)");
    ctx.fillStyle = rim; ctx.beginPath(); ctx.arc(px(FACE_TOP), crownY, headW * 0.75, 0, Math.PI * 2); ctx.fill();
    ctx.restore();

    // Floating wisps from the hairline anchors.
    const strands = Math.round(3 + vol * 9);
    ctx.save();
    ctx.globalCompositeOperation = "screen";
    ctx.lineCap = "round";
    for (let a = 0; a < HAIRLINE.length; a++) {
      const ax = px(HAIRLINE[a]), ay = py(HAIRLINE[a]);
      for (let sIdx = 0; sIdx < strands / HAIRLINE.length + 1; sIdx++) {
        const seed = a * 7.13 + sIdx * 2.7;
        const phase = frame * 0.03 + seed;
        const len = headW * (0.35 + 0.6 * float) * (0.7 + 0.5 * Math.abs(Math.sin(seed)));
        const sway = (0.18 + 0.5 * float) * headW;
        const baseX = ax + (Math.sin(seed * 3.1) * 0.4) * headW * 0.3;
        ctx.globalAlpha = (0.12 + 0.18 * vol) * t * fade;
        ctx.strokeStyle = a % 2 ? "rgba(150,225,255,0.9)" : "rgba(170,200,255,0.8)";
        ctx.lineWidth = 1 + vol * 1.6;
        ctx.beginPath();
        ctx.moveTo(baseX, ay);
        const midX = baseX + Math.sin(phase) * sway * 0.5;
        const midY = ay - len * 0.55;
        const tipX = baseX + Math.sin(phase + 0.9) * sway;
        const tipY = ay - len;
        ctx.quadraticCurveTo(midX, midY, tipX, tipY);
        ctx.stroke();
      }
    }
    ctx.restore();
  }

  // Leave the context clean for any later stacked layer / Motion Ink.
  ctx.globalAlpha = 1;
  ctx.filter = "none";
  ctx.shadowBlur = 0;
  ctx.globalCompositeOperation = "source-over";
}
