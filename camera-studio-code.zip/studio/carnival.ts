// ── Carnival Vibes — face-tracked carnival/festival decoration overlay ─────────
//
// A SINGLE-FACE premium camera look: a swaying feather headdress anchored to the
// hairline, a gold tiara band, jewelled face gems (brows + cheeks), eye makeup +
// glossy lips, body/neck glitter, and ambient sparkle particles. It auto-activates
// the moment a face is detected — the decorations only draw while the shared
// MediaPipe tracker has a face, and fade out on tracking loss.
//
// Everything is plain Canvas2D landmark-anchored art (NO WebGL): the renderer
// reuses the NeonPatriotTracker landmark snapshot + makeCoverMap/mapX/mapY mapping
// (object-fit:cover + selfie mirror) EXACTLY like drawVideoCover, so decorations
// lock to the face and bake identically into the photo shutter + video recorder
// (both capture from the same compositeFrame canvas).
//
// Strength rules (see camera-studio-gl-filters memory): every alpha/size/count is
// scaled by k = clamp01(intensity/100) * tracking.fade — applied ONCE so glow does
// not fall off as k². Intensity 0 is a pixel-perfect no-op. Motion (feather sway,
// glitter/sparkle twinkle) is gated by prefers-reduced-motion.

import { makeCoverMap, mapX, mapY, type NeonPatriotTracking } from "./neonPatriot";
import { renderBeautyXGL } from "./beautyXGL";
import { buildBeautyXUniforms } from "./beautyX";

export type CarnivalStyle = "elegant" | "festival" | "glam";

export interface CarnivalParams {
  intensity: number;     // 0..100 — overall strength (density + glow + makeup)
  style: CarnivalStyle;  // density preset: Elegant · Festival (default) · Full Glam
}

export const DEFAULT_CARNIVAL_PARAMS: CarnivalParams = {
  intensity: 85,
  style: "festival",
};

export const CARNIVAL_STYLES: { id: CarnivalStyle; label: string }[] = [
  { id: "elegant", label: "Elegant" },
  { id: "festival", label: "Festival" },
  { id: "glam", label: "Full Glam" },
];

// Per-style density knobs. Festival is the approved default balance.
interface StyleCfg {
  feathers: number;    // headdress plume count
  featherLen: number;  // plume length multiplier
  spread: number;      // headdress fan half-angle (rad)
  cheekGems: boolean;  // cheekbone gem clusters
  makeup: number;      // 0..1 eyeshadow / lip-gloss strength
  glitter: number;     // neck/décolletage glitter density multiplier
  sparkle: number;     // ambient floating sparkle target count
  crownW: number;      // tiara band width multiplier
  gems: number;        // face-gem density multiplier (rails + clusters)
  wash: number;        // dark-edge + bronze face wash strength
}
const STYLE: Record<CarnivalStyle, StyleCfg> = {
  elegant:  { feathers: 5,  featherLen: 0.9,  spread: 0.66, cheekGems: false, makeup: 0.6,  glitter: 0.45, sparkle: 26, crownW: 0.78, gems: 0.6,  wash: 0.4 },
  festival: { feathers: 9,  featherLen: 1.0,  spread: 0.86, cheekGems: true,  makeup: 0.9,  glitter: 0.82, sparkle: 50, crownW: 0.95, gems: 1.0,  wash: 0.62 },
  glam:     { feathers: 13, featherLen: 1.18, spread: 1.02, cheekGems: true,  makeup: 1.0,  glitter: 1.0,  sparkle: 80, crownW: 1.1,  gems: 1.45, wash: 0.82 },
};

// ── Whole-face beautification ("photoshopped" glam) — Carnival reuses the Beauty X
// WebGL pass (beautyXGL) as a baked BASE layer BEFORE any decoration is drawn, so the
// subject's skin is smoothed/brightened/glowing under the jewels (and it bakes into
// photo/video). Per-style FINAL strengths (0..1); scaled once by k = intensity*fade. ─
interface BeautyCfg { smooth: number; bright: number; even: number; slim: number; enlarge: number; eyeBright: number; teeth: number; sharp: number; glow: number; }
const BEAUTY: Record<CarnivalStyle, BeautyCfg> = {
  elegant:  { smooth: 0.72, bright: 0.42, even: 0.66, slim: 0.18, enlarge: 0.20, eyeBright: 0.55, teeth: 0.55, sharp: 0.30, glow: 0.40 },
  festival: { smooth: 0.86, bright: 0.52, even: 0.82, slim: 0.30, enlarge: 0.32, eyeBright: 0.78, teeth: 0.72, sharp: 0.34, glow: 0.50 },
  glam:     { smooth: 0.95, bright: 0.60, even: 0.94, slim: 0.42, enlarge: 0.44, eyeBright: 0.92, teeth: 0.86, sharp: 0.40, glow: 0.60 },
};

// ── Palette — a full carnival RAINBOW (matches the glam reference: jewel-bright
// feathers + pink/cyan/gold/clear gems on a warm bronze / dark wash). ───────────
const TEAL = "#19e0d0";
const TEAL_DK = "#0b6f6a";
const MAGENTA = "#ff36c4";
const MAGENTA_DK = "#7a1063";
const GOLD = "#f6c945";
const GOLD_DK = "#9a6a12";
const ORANGE = "#ff8a1e";
const ORANGE_DK = "#9c4300";
const BLUE = "#2aa8ff";
const BLUE_DK = "#0b4f8f";
const PURPLE = "#b056ff";
const PURPLE_DK = "#5a1e8f";
const CLEAR = "#eaf6ff";       // icy diamond / clear crystal
const CLEAR_DK = "#8fb6cf";

// Feather colours indexed by RANK from the centre of the fan (rank 0 = the tall
// central plumes), so the headdress mirrors out into a symmetric rainbow.
const FEATHER_COLS: [string, string][] = [
  [TEAL, TEAL_DK], [ORANGE, ORANGE_DK], [MAGENTA, MAGENTA_DK],
  [BLUE, BLUE_DK], [PURPLE, PURPLE_DK], [GOLD, GOLD_DK],
];

const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);

// prefers-reduced-motion — read once, lazily (guard SSR / no matchMedia).
let _rm: boolean | null = null;
function reduceMotion(): boolean {
  if (_rm === null) {
    _rm = typeof window !== "undefined" && typeof window.matchMedia === "function"
      ? window.matchMedia("(prefers-reduced-motion: reduce)").matches
      : false;
  }
  return _rm;
}

// Tiny deterministic PRNG so glitter positions are STABLE across frames (only the
// twinkle alpha animates) — a per-frame Math.random would make glitter jump.
function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

// ── Cached sprites (built once, blitted per frame) ─────────────────────────────
// Feathers + gems are pre-rendered to offscreen canvases with their glow baked in,
// then drawImage'd rotated/scaled — keeps the per-frame path to a handful of cheap
// transforms even at Full Glam on mobile.
interface Sprites {
  feathers: HTMLCanvasElement[];   // one per FEATHER_COLS entry (indexed by fan rank)
  gemTeal: HTMLCanvasElement;
  gemGold: HTMLCanvasElement;
  gemMagenta: HTMLCanvasElement;
  gemClear: HTMLCanvasElement;
  dropMagenta: HTMLCanvasElement;
  dropTeal: HTMLCanvasElement;
  dropGold: HTMLCanvasElement;
  diamond: HTMLCanvasElement;      // upright faceted crystal (tiara centrepiece)
}
let _sprites: Sprites | null = null;

// ── Carnival-LOCAL landmark smoothing ──────────────────────────────────────────
// The shared NeonPatriotTracker only refreshes its mesh every few frames; between
// detections the pose is static then steps to the next value, which makes the heavy
// headdress/gems visibly judder. We add a SECOND, compositor-rate EMA here (Carnival
// ONLY — the shared tracker is untouched so neonPatriot/beautyX are unaffected) that
// eases the decorations toward each new pose. Snaps on (re)appearance + mesh-size
// change so it never lerps in from a stale pose.
const TRACK_EMA = 0.28;
let _smLM: Float32Array | null = null;
let _smCount = 0;
let _trackedLast = false;
function smoothLandmarks(lm: Float32Array, count: number, snap: boolean): Float32Array {
  const n = count * 3;
  if (snap || !_smLM || _smCount !== count || _smLM.length < n) {
    if (!_smLM || _smLM.length < n) _smLM = new Float32Array(n);
    _smLM.set(lm.subarray(0, n));
    _smCount = count;
  } else {
    const s = _smLM;
    for (let i = 0; i < n; i++) s[i] += (lm[i] - s[i]) * TRACK_EMA;
  }
  return _smLM;
}

function makeCanvas(w: number, h: number): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  return c;
}

// A single tall plume. Base (quill) sits at bottom-centre = the anchor point.
function buildFeather(col: string, dk: string): HTMLCanvasElement {
  const W = 150, H = 380;
  const c = makeCanvas(W, H);
  const g = c.getContext("2d")!;
  const cx = W / 2, baseY = H - 8, tipY = 18;
  g.save();
  g.shadowColor = col;
  g.shadowBlur = 26;
  // Plume silhouette — tapered leaf.
  g.beginPath();
  g.moveTo(cx, baseY);
  g.quadraticCurveTo(8, H * 0.52, cx, tipY);
  g.quadraticCurveTo(W - 8, H * 0.52, cx, baseY);
  const grad = g.createLinearGradient(0, baseY, 0, tipY);
  grad.addColorStop(0, dk);
  grad.addColorStop(0.45, col);
  grad.addColorStop(1, "#ffffff");
  g.fillStyle = grad;
  g.fill();
  g.restore();
  // Barbs — thin angled strokes off the central rachis for feather texture.
  g.save();
  g.strokeStyle = "rgba(255,255,255,0.5)";
  g.lineWidth = 1.2;
  g.lineCap = "round";
  for (let y = baseY - 16; y > tipY + 14; y -= 12) {
    const t = (baseY - y) / (baseY - tipY);
    const halfW = (1 - Math.abs(t - 0.5) * 1.7) * (W * 0.4);
    if (halfW <= 2) continue;
    g.globalAlpha = 0.35 + t * 0.4;
    g.beginPath(); g.moveTo(cx, y); g.lineTo(cx - halfW, y + 9); g.stroke();
    g.beginPath(); g.moveTo(cx, y); g.lineTo(cx + halfW, y + 9); g.stroke();
  }
  g.restore();
  // Central rachis.
  g.strokeStyle = dk;
  g.lineWidth = 2.2;
  g.beginPath(); g.moveTo(cx, baseY); g.lineTo(cx, tipY + 6); g.stroke();
  return c;
}

// A faceted round gem with a specular highlight, centred in the sprite.
function buildGem(col: string, dk: string): HTMLCanvasElement {
  const S = 72;
  const c = makeCanvas(S, S);
  const g = c.getContext("2d")!;
  const r = S / 2 - 6, cx = S / 2, cy = S / 2;
  g.save();
  g.shadowColor = col; g.shadowBlur = 14;
  const rad = g.createRadialGradient(cx - r * 0.3, cy - r * 0.3, r * 0.1, cx, cy, r);
  rad.addColorStop(0, "#ffffff");
  rad.addColorStop(0.35, col);
  rad.addColorStop(1, dk);
  g.fillStyle = rad;
  g.beginPath(); g.arc(cx, cy, r, 0, Math.PI * 2); g.fill();
  g.restore();
  // Facet ring + highlight.
  g.strokeStyle = "rgba(255,255,255,0.55)"; g.lineWidth = 1.4;
  g.beginPath(); g.arc(cx, cy, r * 0.66, 0, Math.PI * 2); g.stroke();
  g.fillStyle = "rgba(255,255,255,0.9)";
  g.beginPath(); g.arc(cx - r * 0.32, cy - r * 0.34, r * 0.16, 0, Math.PI * 2); g.fill();
  return c;
}

// A teardrop gem — point at the BOTTOM of the sprite, bulb at the top.
function buildDrop(col: string, dk: string): HTMLCanvasElement {
  const W = 64, H = 88;
  const c = makeCanvas(W, H);
  const g = c.getContext("2d")!;
  const cx = W / 2, r = W / 2 - 6, bulbY = r + 6, tipY = H - 6;
  g.save();
  g.shadowColor = col; g.shadowBlur = 14;
  g.beginPath();
  g.moveTo(cx, tipY);
  g.quadraticCurveTo(cx - r, bulbY + r * 0.4, cx - r, bulbY);
  g.arc(cx, bulbY, r, Math.PI, 0);
  g.quadraticCurveTo(cx + r, bulbY + r * 0.4, cx, tipY);
  const rad = g.createRadialGradient(cx - r * 0.3, bulbY - r * 0.3, r * 0.1, cx, bulbY, r * 1.4);
  rad.addColorStop(0, "#ffffff");
  rad.addColorStop(0.4, col);
  rad.addColorStop(1, dk);
  g.fillStyle = rad;
  g.fill();
  g.restore();
  g.fillStyle = "rgba(255,255,255,0.9)";
  g.beginPath(); g.arc(cx - r * 0.3, bulbY - r * 0.32, r * 0.16, 0, Math.PI * 2); g.fill();
  return c;
}

// An upright faceted crystal (marquise) — points at TOP and BOTTOM, centred in the
// sprite. Used as the tiara centrepiece.
function buildDiamond(col: string, dk: string): HTMLCanvasElement {
  const W = 60, H = 96;
  const c = makeCanvas(W, H);
  const g = c.getContext("2d")!;
  const cx = W / 2, cy = H / 2, hw = W / 2 - 6, hh = H / 2 - 6;
  g.save();
  g.shadowColor = col; g.shadowBlur = 16;
  g.beginPath();
  g.moveTo(cx, cy - hh);
  g.lineTo(cx + hw, cy);
  g.lineTo(cx, cy + hh);
  g.lineTo(cx - hw, cy);
  g.closePath();
  const rad = g.createRadialGradient(cx - hw * 0.3, cy - hh * 0.3, 2, cx, cy, hh);
  rad.addColorStop(0, "#ffffff");
  rad.addColorStop(0.4, col);
  rad.addColorStop(1, dk);
  g.fillStyle = rad;
  g.fill();
  g.restore();
  // Facet lines for sparkle.
  g.strokeStyle = "rgba(255,255,255,0.6)"; g.lineWidth = 1.1;
  g.beginPath();
  g.moveTo(cx, cy - hh); g.lineTo(cx - hw, cy); g.lineTo(cx, cy + hh); g.lineTo(cx + hw, cy); g.closePath();
  g.moveTo(cx, cy - hh); g.lineTo(cx, cy + hh);
  g.moveTo(cx - hw, cy); g.lineTo(cx + hw, cy);
  g.stroke();
  return c;
}

function getSprites(): Sprites {
  if (_sprites) return _sprites;
  _sprites = {
    feathers: FEATHER_COLS.map(([c, d]) => buildFeather(c, d)),
    gemTeal: buildGem(TEAL, TEAL_DK),
    gemGold: buildGem(GOLD, GOLD_DK),
    gemMagenta: buildGem(MAGENTA, MAGENTA_DK),
    gemClear: buildGem(CLEAR, CLEAR_DK),
    dropMagenta: buildDrop(MAGENTA, MAGENTA_DK),
    dropTeal: buildDrop(TEAL, TEAL_DK),
    dropGold: buildDrop(GOLD, GOLD_DK),
    diamond: buildDiamond(CLEAR, CLEAR_DK),
  };
  return _sprites;
}

// ── Geometry helpers ───────────────────────────────────────────────────────────
type Pt = { x: number; y: number };
const sub = (a: Pt, b: Pt): Pt => ({ x: a.x - b.x, y: a.y - b.y });
const add = (a: Pt, b: Pt): Pt => ({ x: a.x + b.x, y: a.y + b.y });
const mul = (a: Pt, s: number): Pt => ({ x: a.x * s, y: a.y * s });
const len = (a: Pt) => Math.hypot(a.x, a.y);
const norm = (a: Pt): Pt => { const l = len(a) || 1; return { x: a.x / l, y: a.y / l }; };

// Draw a sprite so its bottom-centre sits at (p), rotated by `angle` (0 = sprite
// points straight up) and scaled so its height becomes `targetH`.
function blitFromBase(ctx: CanvasRenderingContext2D, spr: HTMLCanvasElement, p: Pt, angle: number, targetH: number, alpha: number) {
  const s = targetH / spr.height;
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(p.x, p.y);
  ctx.rotate(angle);
  ctx.drawImage(spr, -spr.width * s / 2, -spr.height * s, spr.width * s, spr.height * s);
  ctx.restore();
}

// Draw a sprite centred at (p), rotated, scaled to width `targetW`.
function blitCentred(ctx: CanvasRenderingContext2D, spr: HTMLCanvasElement, p: Pt, angle: number, targetW: number, alpha: number) {
  const s = targetW / spr.width;
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(p.x, p.y);
  ctx.rotate(angle);
  ctx.drawImage(spr, -spr.width * s / 2, -spr.height * s / 2, spr.width * s, spr.height * s);
  ctx.restore();
}

const AVG_IDX = (pts: Pt[]): Pt => {
  let x = 0, y = 0;
  for (const p of pts) { x += p.x; y += p.y; }
  return { x: x / pts.length, y: y / pts.length };
};

// Lip outer ring (MediaPipe), brow rings, etc. — stable indices confirmed by the
// architect against the FACEMESH topology.
const LIPS_OUTER = [61, 185, 40, 39, 37, 0, 267, 269, 270, 409, 291, 375, 321, 405, 314, 17, 84, 181, 91, 146];
const BROW_L = [70, 63, 105, 66, 107];
const BROW_R = [336, 296, 334, 293, 300];
const CHEEK_L = [50, 101, 118];
const CHEEK_R = [280, 330, 347];
// Apple-of-cheek anchors for blush (centre of the cheekbone mound).
const BLUSH_L = [50, 205, 116];
const BLUSH_R = [280, 425, 345];
// Upper-lash rings, OUTER corner → INNER corner — used to wrap the eye makeup
// onto the real eyelid shape (FACEMESH topology, confirmed against the mesh).
const RIGHT_EYE_UPPER = [33, 246, 161, 160, 159, 158, 157, 173, 133];
const LEFT_EYE_UPPER = [263, 466, 388, 387, 386, 385, 384, 398, 362];

// ── Main renderer ──────────────────────────────────────────────────────────────
export function renderCarnival(
  ctx: CanvasRenderingContext2D,
  w: number, h: number, frame: number,
  particles: { x: number; y: number; vx: number; vy: number; life: number; r: number; color: string }[],
  tracking: NeonPatriotTracking, vw: number, vh: number, mirror: boolean,
  params: CarnivalParams,
) {
  const lm = tracking.landmarks;
  if (!lm || tracking.fade <= 0 || tracking.count < 468) { _trackedLast = false; return; }
  const k = clamp01(params.intensity / 100) * tracking.fade;
  if (k <= 0) { _trackedLast = false; return; }

  const cfg = STYLE[params.style];
  const spr = getSprites();
  const m = makeCoverMap(w, h, vw, vh, mirror);
  // Carnival-local compositor-rate smoothing: snap when the face was absent last
  // frame (re-acquire) so decorations don't lerp in from a stale pose.
  const sm = smoothLandmarks(lm, tracking.count, !_trackedLast);
  _trackedLast = true;
  const pt = (i: number): Pt => ({ x: mapX(m, sm[i * 3]), y: mapY(m, sm[i * 3 + 1]) });
  const rm = reduceMotion();
  const time = rm ? 0 : frame;

  // Face basis (all in already-mapped screen space, so mirror is baked in).
  const cheekL = pt(234), cheekR = pt(454);
  const foreheadTop = pt(10), chin = pt(152);
  const faceW = len(sub(cheekR, cheekL));
  const faceH = len(sub(foreheadTop, chin));
  if (faceW < 8 || faceH < 8) return;
  const up = norm(sub(foreheadTop, chin));            // chin → forehead
  const right = norm(sub(cheekR, cheekL));            // left cheek → right cheek
  const down = mul(up, -1);
  const rollUp = Math.atan2(up.y, up.x);              // angle of the "up" vector

  // 0) WHOLE-FACE BEAUTIFICATION — reuse the Beauty X WebGL pass on the already-drawn
  //    bake frame (skin smooth/brighten/even, subtle slim + eye-enlarge, teeth/eye
  //    brighten, glow) and blit it back BEFORE any decoration, so the jewels sit on a
  //    flawless, glowing face — and it bakes into photo/video. No-ops without WebGL2.
  {
    const b = BEAUTY[params.style];
    const u = buildBeautyXUniforms(sm, m, w, h, {
      smooth: b.smooth * k, bright: b.bright * k, even: b.even * k,
      slim: b.slim * k, enlarge: b.enlarge * k, eyeBright: b.eyeBright * k,
      teeth: b.teeth * k, sharp: b.sharp * k, glow: b.glow * k,
    });
    const beautied = renderBeautyXGL(ctx.canvas, u);
    if (beautied) {
      ctx.save();
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.globalAlpha = 1; ctx.globalCompositeOperation = "source-over";
      ctx.drawImage(beautied, 0, 0, w, h);
      ctx.restore();
    }
  }

  ctx.save();

  // 1) Dark vignette + warm key light + bronze face glow to seat the glam look on a
  //    moody, sun-kissed backdrop (all scaled by k and the per-style wash).
  const wash = cfg.wash * k;
  if (wash > 0.01) {
    ctx.save();
    ctx.globalCompositeOperation = "source-over";
    ctx.globalAlpha = 1;
    const vg = ctx.createRadialGradient(w / 2, h * 0.46, h * 0.34, w / 2, h * 0.52, h * 0.92);
    vg.addColorStop(0, "rgba(0,0,0,0)");
    vg.addColorStop(1, `rgba(18,6,20,${0.55 * wash})`);
    ctx.fillStyle = vg; ctx.fillRect(0, 0, w, h);
    ctx.restore();
  }
  ctx.save();
  ctx.globalCompositeOperation = "screen";
  ctx.globalAlpha = 0.12 * k;
  const warm = ctx.createRadialGradient(w / 2, h * 0.22, 0, w / 2, h * 0.22, h * 0.7);
  warm.addColorStop(0, "rgba(255,210,140,0.9)");
  warm.addColorStop(1, "rgba(255,210,140,0)");
  ctx.fillStyle = warm; ctx.fillRect(0, 0, w, h);
  ctx.restore();
  if (wash > 0.01) {
    ctx.save();
    ctx.globalCompositeOperation = "screen";
    ctx.globalAlpha = 0.5 * wash;
    const fc = mul(add(foreheadTop, chin), 0.5);
    const br = ctx.createRadialGradient(fc.x, fc.y, faceW * 0.1, fc.x, fc.y, faceW * 0.95);
    br.addColorStop(0, "rgba(255,186,110,0.55)");
    br.addColorStop(0.6, "rgba(214,140,70,0.22)");
    br.addColorStop(1, "rgba(214,140,70,0)");
    ctx.fillStyle = br;
    ctx.beginPath(); ctx.arc(fc.x, fc.y, faceW * 0.95, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  // 2) FEATHER HEADDRESS — fans up & out from just above the hairline. Drawn first
  //    so the crown + gems layer over the quills.
  const crownCenter = add(foreheadTop, mul(up, faceH * 0.06));
  const featherBase = add(crownCenter, mul(up, faceH * 0.04));
  const featherH = faceH * 1.15 * cfg.featherLen;
  const n = cfg.feathers;
  const centre = (n - 1) / 2;
  ctx.save();
  for (let i = 0; i < n; i++) {
    const t = n === 1 ? 0 : i / (n - 1) - 0.5;        // -0.5..0.5
    const sway = rm ? 0 : Math.sin(time * 0.045 + i * 0.9) * 0.05;
    // sprite angle 0 = straight up; rotate toward fan direction. Screen up is
    // -y, i.e. canvas angle -PI/2; rollUp is the up vector's atan2 angle.
    const ang = (rollUp + Math.PI / 2) + t * cfg.spread + sway;
    // Central plumes tallest; outer ones a touch shorter for a natural silhouette.
    const lenScale = 1 - Math.abs(t) * 0.26;
    // Colour by RANK from the centre → a symmetric rainbow fanning outward.
    const rank = Math.round(Math.abs(i - centre));
    const sprite = spr.feathers[rank % spr.feathers.length];
    const fh = featherH * lenScale;
    // Opaque base pass so the plume BODY reads SOLID — additive-only ("lighter")
    // made the headdress look see-through over hair/skin. The sheen pass on top
    // adds the festive glow without washing the body out.
    ctx.globalCompositeOperation = "source-over";
    blitFromBase(ctx, sprite, featherBase, ang, fh, Math.min(1, k * 1.12));
    ctx.globalCompositeOperation = "lighter";
    blitFromBase(ctx, sprite, featherBase, ang, fh, 0.4 * k);
  }
  ctx.restore();

  // 3) ORNATE JEWELLED TIARA — a layered gold band hugging the hairline, a row of
  //    small clear diamonds set along it, a central upright crystal on a gold
  //    sunburst, and flanking teal teardrops — matching the reference centrepiece.
  const templeL = pt(127), templeR = pt(356);
  const apex = add(crownCenter, mul(up, faceH * 0.02));
  const ctrl = add(apex, mul(up, faceH * 0.05));      // band peak control point
  // Quadratic sampler along the band (templeL → ctrl → templeR).
  const bandAt = (tt: number): Pt => {
    const it = 1 - tt;
    return {
      x: it * it * templeL.x + 2 * it * tt * ctrl.x + tt * tt * templeR.x,
      y: it * it * templeL.y + 2 * it * tt * ctrl.y + tt * tt * templeR.y,
    };
  };
  ctx.save();
  ctx.globalAlpha = k;
  ctx.shadowColor = GOLD; ctx.shadowBlur = 16 * k;
  ctx.lineCap = "round";
  const band = ctx.createLinearGradient(templeL.x, templeL.y, templeR.x, templeR.y);
  band.addColorStop(0, GOLD_DK); band.addColorStop(0.5, "#ffe9a8"); band.addColorStop(1, GOLD_DK);
  ctx.strokeStyle = band;
  ctx.lineWidth = faceW * 0.075 * cfg.crownW;
  ctx.beginPath();
  ctx.moveTo(templeL.x, templeL.y);
  ctx.quadraticCurveTo(ctrl.x, ctrl.y, templeR.x, templeR.y);
  ctx.stroke();
  // Bright top highlight.
  ctx.shadowBlur = 0;
  ctx.strokeStyle = "rgba(255,250,225,0.85)";
  ctx.lineWidth = faceW * 0.02 * cfg.crownW;
  ctx.beginPath();
  ctx.moveTo(templeL.x, templeL.y);
  ctx.quadraticCurveTo(ctrl.x + up.x * faceH * 0.012, ctrl.y + up.y * faceH * 0.012, templeR.x, templeR.y);
  ctx.stroke();
  ctx.restore();
  // Row of small clear diamonds set along the band (skip the very centre — the
  // crystal sits there). A couple of teal accents add colour.
  const setN = 9;
  for (let s = 1; s < setN; s++) {
    const tt = s / setN;
    if (Math.abs(tt - 0.5) < 0.06) continue;
    blitCentred(ctx, (s % 3 === 0) ? spr.gemTeal : spr.gemClear, bandAt(tt), 0, faceW * 0.03, k);
  }
  // Gold sunburst + central upright crystal centrepiece + flanking teal teardrops.
  const crownCtr = bandAt(0.5);
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  ctx.globalAlpha = 0.6 * k;
  const burst = ctx.createRadialGradient(crownCtr.x, crownCtr.y, 0, crownCtr.x, crownCtr.y, faceW * 0.16);
  burst.addColorStop(0, "rgba(255,231,150,0.9)");
  burst.addColorStop(1, "rgba(255,231,150,0)");
  ctx.fillStyle = burst;
  ctx.beginPath(); ctx.arc(crownCtr.x, crownCtr.y, faceW * 0.16, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
  blitCentred(ctx, spr.diamond, crownCtr, rollUp + Math.PI / 2, faceW * 0.085, k);
  blitCentred(ctx, spr.dropTeal, add(crownCtr, add(mul(right, -faceW * 0.13), mul(down, faceH * 0.012))), rollUp + Math.PI / 2, faceW * 0.06, k);
  blitCentred(ctx, spr.dropTeal, add(crownCtr, add(mul(right, faceW * 0.13), mul(down, faceH * 0.012))), rollUp + Math.PI / 2, faceW * 0.06, k);

  // 4) FACE MAKEUP — rosy cheek blush, extravagant winged eye makeup, dramatic
  //    glossy lips. Blush is laid down first so gems + contours sit on top of it.
  const mk = cfg.makeup * k;
  const faceMid = mul(add(foreheadTop, chin), 0.5);
  drawBlush(ctx, AVG_IDX(BLUSH_L.map(pt)), right, faceMid, faceW, mk);
  drawBlush(ctx, AVG_IDX(BLUSH_R.map(pt)), right, faceMid, faceW, mk);
  drawEyeMakeup(ctx, RIGHT_EYE_UPPER.map(pt), pt(33), pt(133), up, faceW, mk);
  drawEyeMakeup(ctx, LEFT_EYE_UPPER.map(pt), pt(263), pt(362), up, faceW, mk);
  drawLipGloss(ctx, LIPS_OUTER.map(pt), mk);

  // 5) DENSE FACE GEMS — rainbow jewels riding the brows, a forehead column, the
  //    signature descending arcs under the outer eyes, and cheekbone clusters, all
  //    landmark-anchored so they track the face. Density scales with the style.
  const gd = cfg.gems;
  const cyc = [spr.gemMagenta, spr.gemTeal, spr.gemGold, spr.gemClear];
  const gemAt = (p: Pt, idx: number, size: number) =>
    blitCentred(ctx, cyc[((idx % cyc.length) + cyc.length) % cyc.length], p, 0, size, k);

  // Brow rails — a jewelled line riding each brow.
  BROW_L.forEach((i, idx) => gemAt(add(pt(i), mul(up, faceH * 0.018)), idx, faceW * 0.03));
  BROW_R.forEach((i, idx) => gemAt(add(pt(i), mul(up, faceH * 0.018)), idx, faceW * 0.03));

  // Forehead centre — teal drop (pointing DOWN toward the nose) + a short column of
  // gems toward the bridge, echoing the reference's vertical centrepiece.
  const colTop = AVG_IDX([pt(107), pt(336)]);
  const browCentre = add(colTop, mul(up, faceH * 0.05));
  blitCentred(ctx, spr.dropTeal, browCentre, rollUp + Math.PI / 2, faceW * 0.05, k);
  for (let c = 0; c < 3; c++) gemAt(add(colTop, mul(down, faceH * (0.045 + c * 0.05))), c + 1, faceW * 0.032 * (1 - c * 0.12));

  // Descending arcs from under the OUTER eye corners onto the cheekbone (per side):
  // step DOWN + OUTWARD with gems tapering — the signature cluster framing the eyes.
  const arcN = Math.max(3, Math.round(5 * gd));
  const outSignOf = (idx: number) =>
    ((pt(idx).x - faceMid.x) * right.x + (pt(idx).y - faceMid.y) * right.y) >= 0 ? 1 : -1;
  const eyeArc = (outerIdx: number) => {
    const s = outSignOf(outerIdx);
    const start = add(pt(outerIdx), mul(down, faceH * 0.045));
    for (let a = 0; a < arcN; a++) {
      const p = add(start, add(mul(down, faceH * 0.04 * a), mul(right, s * faceW * 0.022 * a)));
      gemAt(p, a + outerIdx, faceW * 0.032 * (1 - a * 0.1));
    }
  };
  eyeArc(33);
  eyeArc(263);

  // Cheekbone clusters (Festival / Glam): a few gems along the cheek line.
  if (cfg.cheekGems) {
    CHEEK_L.forEach((i, idx) => gemAt(pt(i), idx, faceW * 0.034));
    CHEEK_R.forEach((i, idx) => gemAt(pt(i), idx + 1, faceW * 0.034));
  }

  // 6) BODY / NECK GLITTER — stable seeded specks below the chin, alpha twinkles.
  drawGlitter(ctx, chin, right, down, faceW, cfg.glitter * k, time, rm);

  // 7) AMBIENT SPARKLE — floating stars around the head (uses the particle buffer).
  drawSparkles(ctx, particles, { x: foreheadTop.x, y: (foreheadTop.y + chin.y) / 2 }, faceW, Math.round(cfg.sparkle * k), k, time, rm);

  // Leave the context fully clean for stacked filters + Motion Ink.
  ctx.restore();
  ctx.globalAlpha = 1;
  ctx.filter = "none";
  ctx.shadowBlur = 0;
  ctx.globalCompositeOperation = "source-over";
}

// Extravagant winged eye makeup that WRAPS the real eyelid: a smoky base + vibrant
// teal→magenta sweep + gold shimmer filling the crease above the upper lash line,
// flicked into a cat-eye wing past the outer corner, finished with a bold winged
// liner. `upper` = upper-lash points OUTER→INNER; `up` = face up unit vector.
function drawEyeMakeup(
  ctx: CanvasRenderingContext2D,
  upper: Pt[], outer: Pt, inner: Pt, up: Pt, faceW: number, strength: number,
) {
  if (strength <= 0 || upper.length < 3) return;
  const eyeW = len(sub(outer, inner));
  if (eyeW < 4) return;
  const outward = norm(sub(outer, inner));            // inner → outer (toward temple)
  const N = upper.length;

  // Crease curve: offset each lash point UP toward the brow, rising over the
  // outer half so the shadow opens up where a winged look is heaviest.
  const crease = upper.map((p, i) => {
    const t = i / (N - 1);                             // 0 outer .. 1 inner
    const lift = eyeW * (0.30 + 0.55 * (1 - t));       // outer ~0.85w, inner ~0.30w
    return add(p, mul(up, lift));
  });
  // Cat-eye flick beyond the outer corner.
  const wingTip = add(add(outer, mul(outward, eyeW * 0.42)), mul(up, eyeW * 0.55));

  // Shadow polygon: lash line (inner→outer) → wing tip → crease (outer→inner).
  const shape = () => {
    ctx.beginPath();
    ctx.moveTo(inner.x, inner.y);
    for (let i = N - 1; i >= 0; i--) ctx.lineTo(upper[i].x, upper[i].y);
    ctx.lineTo(wingTip.x, wingTip.y);
    for (let i = 0; i < N; i++) ctx.lineTo(crease[i].x, crease[i].y);
    ctx.closePath();
  };

  ctx.save();
  // 1) Smoky plum base for depth.
  shape();
  let g = ctx.createLinearGradient(inner.x, inner.y, outer.x, outer.y);
  g.addColorStop(0, `rgba(45,8,42,${0.55 * strength})`);
  g.addColorStop(1, `rgba(78,10,58,${0.7 * strength})`);
  ctx.fillStyle = g; ctx.fill();
  // 2) Vibrant teal → magenta sweep toward the wing.
  shape();
  g = ctx.createLinearGradient(inner.x, inner.y, wingTip.x, wingTip.y);
  g.addColorStop(0, `rgba(25,224,208,${0.66 * strength})`);
  g.addColorStop(0.6, `rgba(255,54,196,${0.78 * strength})`);
  g.addColorStop(1, `rgba(255,130,225,${0.88 * strength})`);
  ctx.fillStyle = g; ctx.fill();
  // 3) Gold inner-corner shimmer (additive).
  ctx.globalCompositeOperation = "lighter";
  shape();
  const sh = ctx.createLinearGradient(inner.x, inner.y, outer.x, outer.y);
  sh.addColorStop(0, `rgba(246,201,69,${0.4 * strength})`);
  sh.addColorStop(0.45, "rgba(246,201,69,0)");
  ctx.fillStyle = sh; ctx.fill();
  ctx.restore();

  // 4) Bold winged liner along the upper lash line + flick.
  ctx.save();
  ctx.lineJoin = "round"; ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(inner.x, inner.y);
  for (let i = N - 1; i >= 0; i--) ctx.lineTo(upper[i].x, upper[i].y);
  ctx.lineTo(wingTip.x, wingTip.y);
  ctx.strokeStyle = `rgba(14,4,18,${0.94 * strength})`;
  ctx.lineWidth = Math.max(1.5, eyeW * 0.075);
  ctx.stroke();
  // Gold edge highlight riding the wing.
  ctx.beginPath();
  ctx.moveTo(outer.x, outer.y);
  ctx.lineTo(wingTip.x, wingTip.y);
  ctx.strokeStyle = `rgba(246,201,69,${0.75 * strength})`;
  ctx.lineWidth = Math.max(1, eyeW * 0.03);
  ctx.stroke();
  ctx.restore();
}

// Rosy-red blush as a soft tilted ellipse hugging the cheekbone mound. The long
// axis follows the face's horizontal axis, lifted toward the temple per side.
function drawBlush(ctx: CanvasRenderingContext2D, centre: Pt, right: Pt, faceMid: Pt, faceW: number, strength: number) {
  if (strength <= 0) return;
  const rel = sub(centre, faceMid);
  const outwardSign = (rel.x * right.x + rel.y * right.y) >= 0 ? 1 : -1;
  const angle = Math.atan2(right.y, right.x) + outwardSign * 0.22; // lift toward temple
  const rx = faceW * 0.30, ry = faceW * 0.19;
  ctx.save();
  ctx.translate(centre.x, centre.y);
  ctx.rotate(angle);
  ctx.scale(1, ry / rx);
  const g = ctx.createRadialGradient(0, 0, 0, 0, 0, rx);
  g.addColorStop(0, `rgba(255,72,98,${0.55 * strength})`);
  g.addColorStop(0.55, `rgba(244,52,88,${0.3 * strength})`);
  g.addColorStop(1, "rgba(244,52,88,0)");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(0, 0, rx, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

// Glossy lips: tint the outer-lip polygon + a bright specular streak on top.
function drawLipGloss(ctx: CanvasRenderingContext2D, ring: Pt[], strength: number) {
  if (strength <= 0 || ring.length < 6) return;
  let minY = Infinity, maxY = -Infinity, minX = Infinity, maxX = -Infinity;
  for (const p of ring) { minY = Math.min(minY, p.y); maxY = Math.max(maxY, p.y); minX = Math.min(minX, p.x); maxX = Math.max(maxX, p.x); }
  const path = () => {
    ctx.beginPath();
    ctx.moveTo(ring[0].x, ring[0].y);
    for (let i = 1; i < ring.length; i++) ctx.lineTo(ring[i].x, ring[i].y);
    ctx.closePath();
  };
  ctx.save();
  // Rich, near-opaque berry-red fill for drama.
  path();
  const grad = ctx.createLinearGradient(0, minY, 0, maxY);
  grad.addColorStop(0, `rgba(255,70,150,${0.86 * strength})`);
  grad.addColorStop(0.5, `rgba(232,28,92,${0.96 * strength})`);
  grad.addColorStop(1, `rgba(150,12,60,${0.94 * strength})`);
  ctx.fillStyle = grad;
  ctx.fill();
  // Defining lip liner around the outer edge.
  path();
  ctx.strokeStyle = `rgba(120,8,48,${0.92 * strength})`;
  ctx.lineWidth = Math.max(1.2, (maxX - minX) * 0.03);
  ctx.lineJoin = "round";
  ctx.stroke();
  // Glossy specular sheen on the upper lip.
  path();
  ctx.clip();
  ctx.globalCompositeOperation = "lighter";
  ctx.fillStyle = `rgba(255,255,255,${0.62 * strength})`;
  const cx = (minX + maxX) / 2, midY = minY + (maxY - minY) * 0.30;
  ctx.beginPath();
  ctx.ellipse(cx, midY, (maxX - minX) * 0.3, (maxY - minY) * 0.1, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

// Stable seeded glitter in the neck/décolletage region (below the chin).
function drawGlitter(ctx: CanvasRenderingContext2D, chin: Pt, right: Pt, down: Pt, faceW: number, density: number, time: number, rm: boolean) {
  if (density <= 0) return;
  const count = Math.round(density * 70);
  if (count <= 0) return;
  const rand = rng(1337);
  const cols = [GOLD, TEAL, MAGENTA, "#ffffff"];
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  for (let i = 0; i < count; i++) {
    const lat = (rand() - 0.5) * 1.7 * faceW;     // along cheeks axis
    const depth = (0.45 + rand() * 1.25) * faceW;  // below the chin
    const p = add(chin, add(mul(right, lat), mul(down, depth)));
    if (p.y < chin.y) continue;                    // never over the face
    const phase = rand() * Math.PI * 2;
    const tw = rm ? 0.75 : 0.4 + 0.6 * Math.abs(Math.sin(time * 0.08 + phase));
    const r = (0.6 + rand() * 1.6) * (faceW / 160) * 2;
    ctx.globalAlpha = tw * Math.min(1, density);
    ctx.fillStyle = cols[(i + Math.floor(rand() * 4)) % cols.length];
    ctx.beginPath();
    ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

// Floating 4-point sparkles around the head, persisted in the shared buffer.
function drawSparkles(
  ctx: CanvasRenderingContext2D,
  ps: { x: number; y: number; vx: number; vy: number; life: number; r: number; color: string }[],
  centre: Pt, faceW: number, target: number, k: number, time: number, rm: boolean,
) {
  const cols = [GOLD, TEAL, MAGENTA, "#ffffff"];
  // Spawn toward target.
  let guard = 6;
  while (ps.length < target && guard-- > 0) {
    const ang = Math.random() * Math.PI * 2;
    const rad = faceW * (0.7 + Math.random() * 0.9);
    ps.push({
      x: centre.x + Math.cos(ang) * rad,
      y: centre.y + Math.sin(ang) * rad,
      vx: (Math.random() - 0.5) * 0.4,
      vy: -0.2 - Math.random() * 0.5,
      life: 0.4 + Math.random() * 0.6,
      r: (0.8 + Math.random() * 1.8) * (faceW / 160) * 3,
      color: cols[Math.floor(Math.random() * cols.length)],
    });
  }
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  for (let i = ps.length - 1; i >= 0; i--) {
    const s = ps[i];
    if (!rm) { s.x += s.vx; s.y += s.vy; s.life -= 0.006; }
    if (s.life <= 0 || ps.length > target + 24) { ps.splice(i, 1); continue; }
    const tw = rm ? 0.8 : (0.35 + 0.65 * Math.abs(Math.sin(time * 0.1 + i)));
    const a = Math.min(1, s.life) * tw * k;
    if (a <= 0.01) continue;
    ctx.globalAlpha = a;
    ctx.fillStyle = s.color;
    ctx.shadowColor = s.color; ctx.shadowBlur = s.r * 2;
    drawStar(ctx, s.x, s.y, s.r);
  }
  ctx.restore();
  ctx.shadowBlur = 0;
}

function drawStar(ctx: CanvasRenderingContext2D, x: number, y: number, r: number) {
  ctx.beginPath();
  for (let i = 0; i < 4; i++) {
    const a = (i / 4) * Math.PI * 2;
    const a2 = a + Math.PI / 4;
    ctx.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r);
    ctx.lineTo(x + Math.cos(a2) * r * 0.34, y + Math.sin(a2) * r * 0.34);
  }
  ctx.closePath();
  ctx.fill();
}
