import { describe, expect, it } from "vitest";
import {
  computePoseAngles,
  jointAngleDeg,
  jointAngleRad,
  landmarkAngleDeg,
  POSE_LANDMARKS,
  type Vec3,
} from "./poseAngles";

function set(world: Float32Array, i: number, x: number, y: number, z: number) {
  world[i * 3] = x; world[i * 3 + 1] = y; world[i * 3 + 2] = z;
}

describe("jointAngleRad / jointAngleDeg", () => {
  const b: Vec3 = [0, 0, 0];

  it("measures a straight limb as 180°", () => {
    expect(jointAngleDeg([-1, 0, 0], b, [1, 0, 0])).toBeCloseTo(180, 6);
    expect(jointAngleRad([-1, 0, 0], b, [1, 0, 0])).toBeCloseTo(Math.PI, 6);
  });

  it("measures a right angle as 90°", () => {
    expect(jointAngleDeg([1, 0, 0], b, [0, 1, 0])).toBeCloseTo(90, 6);
    expect(jointAngleDeg([0, 0, 1], b, [0, 1, 0])).toBeCloseTo(90, 6);
  });

  it("measures a fully-folded limb as 0°", () => {
    expect(jointAngleDeg([1, 0, 0], b, [2, 0, 0])).toBeCloseTo(0, 6);
  });

  it("is scale-invariant (only direction matters)", () => {
    expect(jointAngleDeg([5, 0, 0], b, [0, 9, 0])).toBeCloseTo(90, 6);
  });

  it("returns a finite defined value (0) for a degenerate zero-length segment", () => {
    // b == a → first segment has zero length; must not be NaN.
    const deg = jointAngleDeg([0, 0, 0], b, [1, 0, 0]);
    expect(Number.isFinite(deg)).toBe(true);
    expect(deg).toBe(0);
  });

  it("never produces NaN even for near-collinear vectors (clamped acos)", () => {
    const deg = jointAngleDeg([1e8, 0, 0], b, [1e8, 1e-9, 0]);
    expect(Number.isNaN(deg)).toBe(false);
    expect(deg).toBeGreaterThanOrEqual(0);
    expect(deg).toBeLessThanOrEqual(180);
  });
});

describe("landmarkAngleDeg", () => {
  const L = POSE_LANDMARKS;

  it("reads a 90° left elbow from the world buffer", () => {
    const w = new Float32Array(99);
    set(w, L.leftElbow, 0, 0, 0);    // vertex
    set(w, L.leftShoulder, 0, 1, 0); // up
    set(w, L.leftWrist, 1, 0, 0);    // right
    expect(landmarkAngleDeg(w, L.leftShoulder, L.leftElbow, L.leftWrist)).toBeCloseTo(90, 5);
  });

  it("returns null when a required landmark is out of range (short buffer)", () => {
    const w = new Float32Array(30); // only 10 landmarks; wrist(15) is missing
    set(w, L.leftShoulder, 0, 1, 0);
    set(w, L.leftElbow, 0, 0, 0);
    expect(landmarkAngleDeg(w, L.leftShoulder, L.leftElbow, L.leftWrist)).toBeNull();
  });

  it("returns null for a degenerate (coincident) joint triple", () => {
    const w = new Float32Array(99); // all zeros → every segment is zero-length
    expect(landmarkAngleDeg(w, L.leftShoulder, L.leftElbow, L.leftWrist)).toBeNull();
  });

  it("returns null when a landmark is non-finite", () => {
    const w = new Float32Array(99);
    set(w, L.leftShoulder, 0, 1, 0);
    set(w, L.leftElbow, 0, 0, 0);
    set(w, L.leftWrist, NaN, 0, 0);
    expect(landmarkAngleDeg(w, L.leftShoulder, L.leftElbow, L.leftWrist)).toBeNull();
  });
});

describe("computePoseAngles", () => {
  const L = POSE_LANDMARKS;

  it("returns all-null for an empty (all-zero) buffer", () => {
    const a = computePoseAngles(new Float32Array(99));
    expect(a).toEqual({
      leftElbow: null, rightElbow: null,
      leftKnee: null, rightKnee: null,
      leftShoulder: null, rightShoulder: null,
      leftHip: null, rightHip: null,
    });
  });

  it("returns all-null for a short buffer (no landmarks in range)", () => {
    const a = computePoseAngles(new Float32Array(6));
    expect(Object.values(a).every((v) => v === null)).toBe(true);
  });

  it("computes a straight left elbow (180°)", () => {
    const w = new Float32Array(99);
    set(w, L.leftShoulder, 0, 1, 0);
    set(w, L.leftElbow, 0, 0, 0);
    set(w, L.leftWrist, 0, -1, 0); // straight down from the elbow → 180°
    expect(computePoseAngles(w).leftElbow).toBeCloseTo(180, 5);
  });

  it("computes a bent right knee (90°)", () => {
    const w = new Float32Array(99);
    set(w, L.rightHip, 0, 1, 0);   // above the knee
    set(w, L.rightKnee, 0, 0, 0);  // vertex
    set(w, L.rightAnkle, 1, 0, 0); // forward from the knee
    expect(computePoseAngles(w).rightKnee).toBeCloseTo(90, 5);
  });

  it("computes a left shoulder opening (90°: arm out vs torso down)", () => {
    const w = new Float32Array(99);
    set(w, L.leftShoulder, 0, 0, 0); // vertex
    set(w, L.leftElbow, -1, 0, 0);   // arm out to the side
    set(w, L.leftHip, 0, -1, 0);     // torso down
    expect(computePoseAngles(w).leftShoulder).toBeCloseTo(90, 5);
  });

  it("computes a right hip opening (90°: torso up vs thigh forward)", () => {
    const w = new Float32Array(99);
    set(w, L.rightHip, 0, 0, 0);      // vertex
    set(w, L.rightShoulder, 0, 1, 0); // torso up
    set(w, L.rightKnee, 1, 0, 0);     // thigh forward
    expect(computePoseAngles(w).rightHip).toBeCloseTo(90, 5);
  });
});
