// ── Beauty X — offscreen WebGL2 face-beautify image processor ────────────────────
// Reads the ALREADY-DRAWN 1280x720 bake frame as a texture and returns an opaque
// processed copy (full frame, no zoom/crop) that the 2D compositor blits straight
// back over the base — so the beautification BAKES into photo/video export with no
// changes to the capture pipeline.
//
// Pipeline (all in one offscreen WebGL2 canvas, ping-pong FBOs):
//   1. upload bake canvas → texSrc
//   2. WARP pass  : geometric face slim + eye enlarge (inverse-sampled) → texWarp
//   3. BLUR pass  : separable Gaussian at half-res (H then V) → texBlur
//   4. COMPOSITE  : edge-preserving skin smooth (warp vs blur, masked to the face),
//                   skin brightness + tone evenness, eye brightening, teeth
//                   whitening, unsharp "ultra sharp", and a bloom/glow — to glCanvas.
//
// Everything is gated by feathered ellipse masks derived on the CPU from the tracked
// landmarks (passed as uniforms), so there is no per-pixel landmark math here and the
// effect degrades to a clean no-op when there is no face.

const W = 1280, H = 720;          // matches the studio bake buffer
const BW = 640, BH = 360;         // half-res blur (softer + cheaper)
// Sampling the uploaded 2D canvas with FLIP_Y so texture-space matches the quad's
// uv (top-left origin) end-to-end; the final glCanvas then blits back upright.
const FLIP_SRC_Y = true;

// Per-frame beauty uniforms (all positions/radii in 0..1 uv space; mirror already
// baked into the landmark→uv mapping on the CPU side).
export interface BeautyXUniforms {
  valid: boolean;            // a face is tracked → run warp + masked beauty
  faceCx: number; faceCy: number; faceRx: number; faceRy: number;
  eyeLx: number; eyeLy: number; eyeRx: number; eyeRy: number; eyeRad: number;
  mouthX: number; mouthY: number; mouthRad: number;
  // strengths 0..1 (already scaled by overall intensity on the CPU)
  smooth: number; bright: number; even: number;
  slim: number; enlarge: number; eyeBright: number; teeth: number;
  sharp: number; glow: number;
}

const QUAD = new Float32Array([-1, -1, 3, -1, -1, 3]); // oversized tri covers screen

const VERT = `#version 300 es
precision highp float;
in vec2 aPos;
out vec2 vUV;
void main() { vUV = aPos * 0.5 + 0.5; gl_Position = vec4(aPos, 0.0, 1.0); }`;

// ── WARP: face slimming (horizontal compression about the face axis) + eye
// enlargement (local radial magnification). Inverse-sampled: for each output pixel
// we compute where to read from the source. ──────────────────────────────────────
const FRAG_WARP = `#version 300 es
precision highp float;
in vec2 vUV;
uniform sampler2D uSrc;
uniform float uAspect;          // W/H, to measure radial distance in round units
uniform vec2 uFaceC; uniform vec2 uFaceR;
uniform vec2 uEyeL; uniform vec2 uEyeR; uniform float uEyeRad;
uniform float uSlim; uniform float uEnlarge; uniform float uValid;
out vec4 frag;

float ellipse(vec2 p, vec2 c, vec2 r) {
  vec2 d = (p - c) / max(r, vec2(1e-4));
  return dot(d, d);                 // <1 inside
}

void main() {
  vec2 uv = vUV;
  if (uValid > 0.5) {
    // Face slim — compress horizontally toward the face axis, strongest across the
    // cheeks (mid/lower face), feathered out at the oval edge.
    float e = ellipse(uv, uFaceC, uFaceR);
    float faceMask = smoothstep(1.15, 0.45, e);
    float vy = (uv.y - uFaceC.y) / max(uFaceR.y, 1e-4);   // -1 top .. +1 chin
    float cheek = smoothstep(-0.55, 0.15, vy) * smoothstep(0.95, 0.25, vy);
    float s = 1.0 - uSlim * 0.16 * faceMask * cheek;       // <1 => narrower
    uv.x = uFaceC.x + (uv.x - uFaceC.x) / max(s, 0.5);

    // Eye enlarge — magnify a soft disc around each eye (sample toward centre).
    for (int i = 0; i < 2; i++) {
      vec2 ec = i == 0 ? uEyeL : uEyeR;
      vec2 d = uv - ec; d.x *= uAspect;
      float dist = length(d);
      float fall = smoothstep(uEyeRad, 0.0, dist);
      uv -= (uv - ec) * uEnlarge * 0.45 * fall;
    }
  }
  frag = vec4(texture(uSrc, clamp(uv, 0.0, 1.0)).rgb, 1.0);
}`;

// ── BLUR: separable 9-tap Gaussian. ─────────────────────────────────────────────
const FRAG_BLUR = `#version 300 es
precision highp float;
in vec2 vUV;
uniform sampler2D uTex;
uniform vec2 uDir;              // texel step along one axis
out vec4 frag;
void main() {
  float w0 = 0.227027, w1 = 0.316216, w2 = 0.070270, w3 = 0.0089;
  vec3 c = texture(uTex, vUV).rgb * w0;
  c += texture(uTex, vUV + uDir * 1.0).rgb * w1 * 0.5;
  c += texture(uTex, vUV - uDir * 1.0).rgb * w1 * 0.5;
  c += texture(uTex, vUV + uDir * 2.0).rgb * w2;
  c += texture(uTex, vUV - uDir * 2.0).rgb * w2;
  c += texture(uTex, vUV + uDir * 3.5).rgb * w3;
  c += texture(uTex, vUV - uDir * 3.5).rgb * w3;
  frag = vec4(c / (w0 + w1 + 2.0 * w2 + 2.0 * w3), 1.0);
}`;

// ── COMPOSITE: the beauty look. ──────────────────────────────────────────────────
const FRAG_COMP = `#version 300 es
precision highp float;
in vec2 vUV;
uniform sampler2D uWarp;        // sharp warped frame
uniform sampler2D uBlur;        // smoothed (half-res) frame
uniform float uAspect;
uniform vec2 uFaceC; uniform vec2 uFaceR;
uniform vec2 uEyeL; uniform vec2 uEyeR; uniform float uEyeRad;
uniform vec2 uMouth; uniform float uMouthRad;
uniform float uSmooth; uniform float uBright; uniform float uEven;
uniform float uEyeBright; uniform float uTeeth; uniform float uSharp; uniform float uGlow;
uniform float uValid;
out vec4 frag;

float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
float ellipseMask(vec2 p, vec2 c, vec2 r) {
  vec2 d = (p - c) / max(r, vec2(1e-4));
  return smoothstep(1.0, 0.55, dot(d, d));
}
float discMask(vec2 p, vec2 c, float rad) {
  vec2 d = p - c; d.x *= uAspect;
  return smoothstep(rad, rad * 0.35, length(d));
}

void main() {
  vec3 detail = texture(uWarp, vUV).rgb;
  vec3 blur = texture(uBlur, vUV).rgb;
  vec3 high = detail - blur;            // high-frequency band
  vec3 col = detail;

  float faceMask = uValid > 0.5 ? ellipseMask(vUV, uFaceC, uFaceR) : 0.0;

  // 1) Edge-preserving skin smoothing — blend toward the blur on flat skin, but
  // keep detail where the high-freq band is strong (eyes, brows, lips, hair edge).
  float edge = smoothstep(0.05, 0.20, length(high));
  float smoothAmt = uSmooth * faceMask * (1.0 - edge);
  col = mix(col, blur, smoothAmt);

  // 2) Tone evenness — gently pull skin chroma toward its local mean (the blur) and
  // very slightly desaturate to even out redness/blotches, luma preserved.
  float lC = luma(col);
  vec3 evened = mix(col, blur, 0.6);
  evened = mix(evened, vec3(luma(evened)), 0.12);
  evened += (lC - luma(evened));        // restore brightness
  col = mix(col, evened, uEven * faceMask * 0.7);

  // 3) Skin brightness — lift the face, warm it a touch for a healthy glow.
  col += vec3(0.20, 0.17, 0.15) * uBright * faceMask;

  // 4) Ultra-sharp — unsharp mask (stronger on the face, light everywhere else).
  col += high * uSharp * (0.45 + 0.75 * faceMask);

  // 5) Eye brightening — open up the eyes.
  if (uValid > 0.5) {
    float em = max(discMask(vUV, uEyeL, uEyeRad * 1.1), discMask(vUV, uEyeR, uEyeRad * 1.1));
    col += vec3(0.16, 0.18, 0.22) * uEyeBright * em;

    // 6) Teeth whitening — brighten only the bright, low-saturation pixels (teeth)
    // inside the mouth disc; leaves lips alone.
    float tm = discMask(vUV, uMouth, uMouthRad);
    float l = luma(col);
    float sat = length(col - vec3(l));
    float toothy = smoothstep(0.32, 0.62, l) * smoothstep(0.30, 0.12, sat);
    vec3 white = mix(col, vec3(min(l * 1.18 + 0.06, 1.0)), 0.7);
    col = mix(col, white, uTeeth * tm * toothy);
  }

  // 7) Bloom / glow — screen a soft bright-pass of the blur for the dreamy sheen.
  vec3 bp = max(blur - 0.62, 0.0);
  col = 1.0 - (1.0 - col) * (1.0 - bp * uGlow * 1.6);

  frag = vec4(clamp(col, 0.0, 1.0), 1.0);
}`;

interface Prog { p: WebGLProgram; loc: Record<string, WebGLUniformLocation | null>; }
interface GLState {
  cv: HTMLCanvasElement; gl: WebGL2RenderingContext;
  vao: WebGLVertexArrayObject;
  warp: Prog; blur: Prog; comp: Prog;
  texSrc: WebGLTexture; texWarp: WebGLTexture; texBlurA: WebGLTexture; texBlurB: WebGLTexture;
  fboWarp: WebGLFramebuffer; fboBlurA: WebGLFramebuffer; fboBlurB: WebGLFramebuffer;
}

let S: GLState | null = null;
let failed = false;

function compile(gl: WebGL2RenderingContext, type: number, src: string): WebGLShader {
  const sh = gl.createShader(type)!;
  gl.shaderSource(sh, src); gl.compileShader(sh);
  if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS))
    throw new Error("[BeautyX] shader: " + gl.getShaderInfoLog(sh));
  return sh;
}
function link(gl: WebGL2RenderingContext, fragSrc: string, uniforms: string[]): Prog {
  const p = gl.createProgram()!;
  gl.attachShader(p, compile(gl, gl.VERTEX_SHADER, VERT));
  gl.attachShader(p, compile(gl, gl.FRAGMENT_SHADER, fragSrc));
  gl.bindAttribLocation(p, 0, "aPos");
  gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS))
    throw new Error("[BeautyX] link: " + gl.getProgramInfoLog(p));
  const loc: Record<string, WebGLUniformLocation | null> = {};
  for (const u of uniforms) loc[u] = gl.getUniformLocation(p, u);
  return { p, loc };
}
function makeTex(gl: WebGL2RenderingContext, w: number, h: number): WebGLTexture {
  const t = gl.createTexture()!;
  gl.bindTexture(gl.TEXTURE_2D, t);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  return t;
}
function makeFBO(gl: WebGL2RenderingContext, tex: WebGLTexture): WebGLFramebuffer {
  const f = gl.createFramebuffer()!;
  gl.bindFramebuffer(gl.FRAMEBUFFER, f);
  gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
  return f;
}

function init(): GLState | null {
  if (failed) return null;
  try {
    const cv = document.createElement("canvas");
    cv.width = W; cv.height = H;
    const gl = cv.getContext("webgl2", { alpha: false, premultipliedAlpha: false, antialias: false, depth: false, preserveDrawingBuffer: false });
    if (!gl) { failed = true; return null; }
    cv.addEventListener("webglcontextlost", (e) => { e.preventDefault(); S = null; }, false);

    const vao = gl.createVertexArray()!;
    gl.bindVertexArray(vao);
    const buf = gl.createBuffer()!;
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, QUAD, gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    gl.bindVertexArray(null);

    const warp = link(gl, FRAG_WARP, ["uSrc", "uAspect", "uFaceC", "uFaceR", "uEyeL", "uEyeR", "uEyeRad", "uSlim", "uEnlarge", "uValid"]);
    const blur = link(gl, FRAG_BLUR, ["uTex", "uDir"]);
    const comp = link(gl, FRAG_COMP, ["uWarp", "uBlur", "uAspect", "uFaceC", "uFaceR", "uEyeL", "uEyeR", "uEyeRad", "uMouth", "uMouthRad", "uSmooth", "uBright", "uEven", "uEyeBright", "uTeeth", "uSharp", "uGlow", "uValid"]);

    const texSrc = makeTex(gl, W, H);
    const texWarp = makeTex(gl, W, H);
    const texBlurA = makeTex(gl, BW, BH);
    const texBlurB = makeTex(gl, BW, BH);
    const fboWarp = makeFBO(gl, texWarp);
    const fboBlurA = makeFBO(gl, texBlurA);
    const fboBlurB = makeFBO(gl, texBlurB);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);

    S = { cv, gl, vao, warp, blur, comp, texSrc, texWarp, texBlurA, texBlurB, fboWarp, fboBlurA, fboBlurB };
    return S;
  } catch (err) {
    console.error(err);
    failed = true;
    return null;
  }
}

const ASPECT = W / H;

// Process the bake frame; returns the opaque processed offscreen canvas to blit, or
// null if WebGL2 is unavailable (caller leaves the base frame untouched).
export function renderBeautyXGL(source: TexImageSource, u: BeautyXUniforms): HTMLCanvasElement | null {
  const s = S ?? init();
  if (!s) return null;
  const { gl } = s;

  gl.bindVertexArray(s.vao);
  gl.disable(gl.BLEND);

  // Upload the current bake frame.
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, s.texSrc);
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, FLIP_SRC_Y);
  gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source);

  // 1) WARP → texWarp
  gl.bindFramebuffer(gl.FRAMEBUFFER, s.fboWarp);
  gl.viewport(0, 0, W, H);
  gl.useProgram(s.warp.p);
  gl.uniform1i(s.warp.loc.uSrc, 0);
  gl.uniform1f(s.warp.loc.uAspect, ASPECT);
  gl.uniform2f(s.warp.loc.uFaceC, u.faceCx, u.faceCy);
  gl.uniform2f(s.warp.loc.uFaceR, u.faceRx, u.faceRy);
  gl.uniform2f(s.warp.loc.uEyeL, u.eyeLx, u.eyeLy);
  gl.uniform2f(s.warp.loc.uEyeR, u.eyeRx, u.eyeRy);
  gl.uniform1f(s.warp.loc.uEyeRad, u.eyeRad);
  gl.uniform1f(s.warp.loc.uSlim, u.slim);
  gl.uniform1f(s.warp.loc.uEnlarge, u.enlarge);
  gl.uniform1f(s.warp.loc.uValid, u.valid ? 1 : 0);
  gl.drawArrays(gl.TRIANGLES, 0, 3);

  // 2) BLUR (H: warp→A, V: A→B) at half res
  gl.useProgram(s.blur.p);
  gl.uniform1i(s.blur.loc.uTex, 0);
  // H
  gl.bindFramebuffer(gl.FRAMEBUFFER, s.fboBlurA);
  gl.viewport(0, 0, BW, BH);
  gl.bindTexture(gl.TEXTURE_2D, s.texWarp);
  gl.uniform2f(s.blur.loc.uDir, 1 / BW, 0);
  gl.drawArrays(gl.TRIANGLES, 0, 3);
  // V
  gl.bindFramebuffer(gl.FRAMEBUFFER, s.fboBlurB);
  gl.viewport(0, 0, BW, BH);
  gl.bindTexture(gl.TEXTURE_2D, s.texBlurA);
  gl.uniform2f(s.blur.loc.uDir, 0, 1 / BH);
  gl.drawArrays(gl.TRIANGLES, 0, 3);

  // 3) COMPOSITE → glCanvas
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  gl.viewport(0, 0, W, H);
  gl.useProgram(s.comp.p);
  gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, s.texWarp); gl.uniform1i(s.comp.loc.uWarp, 0);
  gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, s.texBlurB); gl.uniform1i(s.comp.loc.uBlur, 1);
  gl.uniform1f(s.comp.loc.uAspect, ASPECT);
  gl.uniform2f(s.comp.loc.uFaceC, u.faceCx, u.faceCy);
  gl.uniform2f(s.comp.loc.uFaceR, u.faceRx, u.faceRy);
  gl.uniform2f(s.comp.loc.uEyeL, u.eyeLx, u.eyeLy);
  gl.uniform2f(s.comp.loc.uEyeR, u.eyeRx, u.eyeRy);
  gl.uniform1f(s.comp.loc.uEyeRad, u.eyeRad);
  gl.uniform2f(s.comp.loc.uMouth, u.mouthX, u.mouthY);
  gl.uniform1f(s.comp.loc.uMouthRad, u.mouthRad);
  gl.uniform1f(s.comp.loc.uSmooth, u.smooth);
  gl.uniform1f(s.comp.loc.uBright, u.bright);
  gl.uniform1f(s.comp.loc.uEven, u.even);
  gl.uniform1f(s.comp.loc.uEyeBright, u.eyeBright);
  gl.uniform1f(s.comp.loc.uTeeth, u.teeth);
  gl.uniform1f(s.comp.loc.uSharp, u.sharp);
  gl.uniform1f(s.comp.loc.uGlow, u.glow);
  gl.uniform1f(s.comp.loc.uValid, u.valid ? 1 : 0);
  gl.drawArrays(gl.TRIANGLES, 0, 3);

  gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, null);
  gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, null);
  gl.bindVertexArray(null);
  return s.cv;
}
