/*  backgrounds.ts — Run2TCoM Camera Studio blank-canvas backgrounds
 *  Procedural backgrounds drawn straight onto the 1280×720 compositor canvas so
 *  the chosen "paper" bakes into photos and recordings exactly like the camera
 *  feed would. Used by CameraStudio when Source === "canvas". The UI `swatch`
 *  strings are CSS-only previews (they never touch the canvas).
 */

export type CanvasBgId = "white" | "black" | "cream" | "ruled" | "grid" | "dots" | "chalk";

export interface CanvasBgDef {
  id: CanvasBgId;
  label: string;
  /** CSS `background` shorthand used only for the swatch preview in the panel. */
  swatch: string;
}

export const CANVAS_BACKGROUNDS: CanvasBgDef[] = [
  { id: "white", label: "White", swatch: "#FFFFFF" },
  { id: "black", label: "Black", swatch: "#0B0B0C" },
  { id: "cream", label: "Cream Paper", swatch: "#F4ECD8" },
  {
    id: "ruled",
    label: "Ruled",
    swatch:
      "linear-gradient(#E7A6A6,#E7A6A6) 7px 0/1px 100% no-repeat, repeating-linear-gradient(180deg,#FCFBF7 0 6px,#A9C3E0 6px 7px)",
  },
  {
    id: "grid",
    label: "Grid",
    swatch:
      "linear-gradient(#D9DEE7 1px,transparent 1px) 0 0/7px 7px, linear-gradient(90deg,#D9DEE7 1px,transparent 1px) 0 0/7px 7px, #FFFFFF",
  },
  {
    id: "dots",
    label: "Dot Grid",
    swatch: "radial-gradient(#C6CCD6 1.3px,transparent 1.6px) 0 0/8px 8px, #FFFFFF",
  },
  { id: "chalk", label: "Chalkboard", swatch: "#22382E" },
];

function fill(ctx: CanvasRenderingContext2D, color: string, W: number, H: number) {
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, W, H);
}

// Deterministic pseudo-random so the chalk speckle is a stable texture (no
// per-frame flicker) yet still looks scattered.
function seed(n: number): number {
  const v = Math.sin(n * 127.1) * 43758.5453;
  return v - Math.floor(v);
}

/**
 * Paint the chosen blank background onto the compositor canvas, scaled to W×H.
 * Call this in place of the camera frame when drawing on a blank canvas.
 */
export function drawCanvasBackground(
  ctx: CanvasRenderingContext2D,
  bgId: string,
  W: number,
  H: number,
): void {
  ctx.save();
  ctx.globalAlpha = 1;

  switch (bgId) {
    case "black":
      fill(ctx, "#0B0B0C", W, H);
      break;

    case "cream":
      fill(ctx, "#F4ECD8", W, H);
      break;

    case "ruled": {
      fill(ctx, "#FCFBF7", W, H);
      const gap = H / 15;
      ctx.strokeStyle = "#A9C3E0";
      ctx.lineWidth = 1.5;
      for (let y = gap; y < H; y += gap) {
        ctx.beginPath();
        ctx.moveTo(0, y + 0.5);
        ctx.lineTo(W, y + 0.5);
        ctx.stroke();
      }
      // Single vertical margin line ~90px in.
      ctx.strokeStyle = "#E7A6A6";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(90, 0);
      ctx.lineTo(90, H);
      ctx.stroke();
      break;
    }

    case "grid": {
      fill(ctx, "#FFFFFF", W, H);
      const cell = W / 26;
      ctx.strokeStyle = "#D9DEE7";
      ctx.lineWidth = 1;
      for (let x = 0; x <= W; x += cell) {
        ctx.beginPath();
        ctx.moveTo(Math.round(x) + 0.5, 0);
        ctx.lineTo(Math.round(x) + 0.5, H);
        ctx.stroke();
      }
      for (let y = 0; y <= H; y += cell) {
        ctx.beginPath();
        ctx.moveTo(0, Math.round(y) + 0.5);
        ctx.lineTo(W, Math.round(y) + 0.5);
        ctx.stroke();
      }
      break;
    }

    case "dots": {
      fill(ctx, "#FFFFFF", W, H);
      const cell = W / 26;
      ctx.fillStyle = "#C6CCD6";
      for (let x = cell; x < W; x += cell) {
        for (let y = cell; y < H; y += cell) {
          ctx.beginPath();
          ctx.arc(x, y, 2.5, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      break;
    }

    case "chalk": {
      fill(ctx, "#22382E", W, H);
      // Faint, static chalk-dust speckle.
      ctx.fillStyle = "#CFE3D8";
      for (let i = 0; i < 1100; i++) {
        const x = seed(i * 1.3 + 0.5) * W;
        const y = seed(i * 2.7 + 11.2) * H;
        const r = 0.8 + seed(i * 4.9 + 2.1) * 1.4;
        ctx.globalAlpha = 0.02 + seed(i * 3.1 + 5.3) * 0.05;
        ctx.fillRect(x, y, r, r);
      }
      ctx.globalAlpha = 1;
      break;
    }

    case "white":
    default:
      fill(ctx, "#FFFFFF", W, H);
      break;
  }

  ctx.restore();
}
