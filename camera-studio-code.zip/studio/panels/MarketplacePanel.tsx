import React from "react";
import { cn } from "@/lib/utils";
import { Star, Download, BadgeCent, Flame } from "lucide-react";

interface MarketplaceFilter {
  id: string;
  name: string;
  creator: string;
  category: string;
  emoji: string;
  downloads: number;
  rating: number;
  revenue: number;
  price: "free" | number;
  gradient: string;
  css: string;
  tags: string[];
  isFeatured?: boolean;
  isNew?: boolean;
}

const MARKETPLACE_FILTERS: MarketplaceFilter[] = [
  {
    id: "industrial_blueprint", name: "Industrial Blueprint", creator: "SafetyNerd87",
    category: "Industrial", emoji: "📐", downloads: 12500, rating: 4.8, revenue: 127.44,
    price: "free", gradient: "linear-gradient(135deg,#0a1929,#0d2137,#1a3a5c)",
    css: "grayscale(1) sepia(1) hue-rotate(190deg) saturate(4) brightness(0.9)",
    tags: ["industrial","blueprint","technical"], isFeatured: true,
  },
  {
    id: "confined_space_hud", name: "Confined Space HUD", creator: "SafetyNerd87",
    category: "Safety", emoji: "⚠️", downloads: 8320, rating: 4.9, revenue: 89.12,
    price: "free", gradient: "linear-gradient(135deg,#1a1a0a,#2a2a0f,#3a3a15)",
    css: "saturate(0.4) hue-rotate(200deg) contrast(1.2)",
    tags: ["safety","hud","confined space"], isFeatured: true,
  },
  {
    id: "dragon_fire_pro", name: "Dragon Fire PRO", creator: "FantasyForge",
    category: "Fantasy", emoji: "🐉", downloads: 34100, rating: 4.7, revenue: 412.88,
    price: 0.99, gradient: "linear-gradient(135deg,#1a0505,#3d0a0a,#6b1010)",
    css: "sepia(0.4) hue-rotate(350deg) saturate(2) contrast(1.3) brightness(0.9)",
    tags: ["fantasy","dragon","fire"],
  },
  {
    id: "plant_operator", name: "Plant Operator", creator: "BuildMaster",
    category: "Industrial", emoji: "🏭", downloads: 5670, rating: 4.6, revenue: 62.30,
    price: "free", gradient: "linear-gradient(135deg,#0f1f0f,#1a2a1a,#253525)",
    css: "sepia(0.3) contrast(1.15) saturate(1.4) hue-rotate(80deg)",
    tags: ["industrial","operator","plant"], isNew: true,
  },
  {
    id: "neon_city_nights", name: "Neon City Nights", creator: "UrbanCreator",
    category: "Fun", emoji: "🌆", downloads: 67200, rating: 4.5, revenue: 891.45,
    price: 0.49, gradient: "linear-gradient(135deg,#0a0a1a,#1a0a2a,#2d1060)",
    css: "saturate(2.5) hue-rotate(270deg) contrast(1.15)",
    tags: ["neon","city","nightlife"],
  },
  {
    id: "welding_pro", name: "Weld Sparks Pro", creator: "SafetyNerd87",
    category: "Industrial", emoji: "⚡", downloads: 9100, rating: 4.7, revenue: 143.22,
    price: 0.99, gradient: "linear-gradient(135deg,#1a1000,#2a1800,#3a2000)",
    css: "brightness(1.2) saturate(1.8) contrast(1.3) hue-rotate(10deg)",
    tags: ["welding","industrial","sparks"],
  },
  {
    id: "golden_portrait", name: "Golden Portrait", creator: "LightMaster",
    category: "Beauty", emoji: "✨", downloads: 128400, rating: 4.9, revenue: 1820.50,
    price: 1.99, gradient: "linear-gradient(135deg,#1a1000,#2a1f00,#3d2e00)",
    css: "sepia(0.3) saturate(1.6) brightness(1.15) contrast(1.05)",
    tags: ["beauty","portrait","golden"], isFeatured: true,
  },
  {
    id: "hazard_hunt_pack", name: "Hazard Hunt Pack", creator: "HSECreator",
    category: "Safety", emoji: "🎯", downloads: 3200, rating: 4.8, revenue: 44.80,
    price: "free", gradient: "linear-gradient(135deg,#1a1000,#2a2000,#333300)",
    css: "saturate(1.3) contrast(1.1) brightness(1.0)",
    tags: ["safety","game","education"], isNew: true,
  },
];

const CATS = ["All", "Featured", "Safety", "Industrial", "Beauty", "Fun", "Fantasy"];

interface Props {
  onApplyFilter: (css: string, label: string) => void;
}

export function MarketplacePanel({ onApplyFilter }: Props) {
  const [cat, setCat] = React.useState("All");
  const [applied, setApplied] = React.useState<string | null>(null);

  const visible = cat === "All" ? MARKETPLACE_FILTERS
    : cat === "Featured" ? MARKETPLACE_FILTERS.filter(f => f.isFeatured)
    : MARKETPLACE_FILTERS.filter(f => f.category === cat);

  function handleApply(f: MarketplaceFilter) {
    setApplied(f.id);
    onApplyFilter(f.css, f.name);
  }

  return (
    <div className="space-y-3">
      <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {CATS.map(c => (
          <button key={c} onClick={() => setCat(c)}
            className={cn("flex-shrink-0 text-xs font-medium px-3 py-1.5 rounded-full border transition-all",
              cat === c ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:text-foreground")}>
            {c === "Featured" ? "⭐ Featured" : c}
          </button>
        ))}
      </div>

      <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
        {visible.map(f => (
          <div key={f.id}
            className={cn(
              "flex items-center gap-3 p-3 rounded-xl border transition-all",
              applied === f.id ? "border-primary bg-primary/8" : "border-border bg-card"
            )}>
            {/* Preview swatch */}
            <div className="relative flex-shrink-0">
              <div className="w-14 h-12 rounded-xl flex items-center justify-center text-2xl flex-shrink-0 overflow-hidden"
                style={{ background: f.gradient, filter: f.css }}>
                {f.emoji}
              </div>
              {f.isFeatured && (
                <div className="absolute -top-1 -right-1 bg-r2c-gold text-[#0a0f1e] text-[8px] font-black px-1 rounded leading-tight">⭐</div>
              )}
              {f.isNew && (
                <div className="absolute -top-1 -right-1 bg-r2c-green text-[#0a0f1e] text-[8px] font-black px-1 rounded leading-tight">NEW</div>
              )}
            </div>

            {/* Info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-sm font-medium">{f.name}</span>
                {f.price !== "free" && (
                  <span className="text-[10px] font-bold bg-r2c-gold/20 text-r2c-gold border border-r2c-gold/30 px-1.5 py-0.5 rounded-full">
                    ${f.price}
                  </span>
                )}
              </div>
              <div className="text-[11px] text-muted-foreground">by {f.creator}</div>
              <div className="flex items-center gap-3 mt-1">
                <span className="flex items-center gap-0.5 text-[10px] text-yellow-400">
                  <Star className="w-2.5 h-2.5 fill-yellow-400" /> {f.rating}
                </span>
                <span className="flex items-center gap-0.5 text-[10px] text-muted-foreground">
                  <Download className="w-2.5 h-2.5" /> {(f.downloads / 1000).toFixed(1)}k
                </span>
                <span className="flex items-center gap-0.5 text-[10px] text-r2c-green">
                  <BadgeCent className="w-2.5 h-2.5" /> ${f.revenue.toFixed(2)}
                </span>
              </div>
            </div>

            {/* Action */}
            <button onClick={() => handleApply(f)}
              className={cn("flex-shrink-0 text-xs font-medium px-3 py-1.5 rounded-lg border transition-all",
                applied === f.id
                  ? "bg-primary text-primary-foreground border-primary"
                  : "border-border hover:border-primary hover:text-primary"
              )}>
              {applied === f.id ? "✓ On" : "Use"}
            </button>
          </div>
        ))}
      </div>

      {/* Creator earnings banner */}
      <div className="flex items-center gap-2 bg-gradient-to-r from-r2c-gold/10 to-transparent border border-r2c-gold/20 rounded-xl p-3">
        <Flame className="w-4 h-4 text-r2c-gold flex-shrink-0" />
        <div>
          <p className="text-xs font-medium text-r2c-gold">Earn from your filters</p>
          <p className="text-[11px] text-muted-foreground">Creators earn 70% of every premium filter download. <span className="text-primary cursor-pointer underline">Create a filter →</span></p>
        </div>
      </div>
    </div>
  );
}
