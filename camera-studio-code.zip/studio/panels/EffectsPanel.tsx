import React from "react";
import { cn } from "@/lib/utils";
import { Star, Users, Sparkles, Zap, Shield, Swords, Gamepad2, MessageSquare } from "lucide-react";
import { EXPERIENCES, type Experience } from "../ExperienceRenderer";

type TabId = "style" | "worlds" | "safety" | "gaming" | "all";

const TABS: { id: TabId; label: string; icon: React.ElementType; desc: string }[] = [
  { id: "style",  label: "✦ Styles", icon: Sparkles, desc: "Visual transformations" },
  { id: "worlds", label: "AR Worlds", icon: Swords,   desc: "Immersive environments" },
  { id: "safety", label: "Safety",   icon: Shield,   desc: "Professional tools" },
  { id: "gaming", label: "Gaming",   icon: Gamepad2, desc: "Play-along effects" },
  { id: "all",    label: "All",      icon: Users,    desc: "Everything" },
];

// Map UI tabs → experience categories
const TAB_CATS: Record<TabId, string[]> = {
  style:  ["Trending"],
  worlds: ["Fantasy"],
  safety: ["Safety", "Industrial"],
  gaming: ["Gaming"],
  all:    ["Trending","Fantasy","Safety","Industrial","Gaming","AI","Comedy"],
};

// Full-height cinematic card (for style worlds)
function StyleCard({ exp, isActive, onSelect }: { exp: Experience; isActive: boolean; onSelect: () => void }) {
  return (
    <button
      onClick={onSelect}
      className={cn(
        "relative w-full overflow-hidden rounded-2xl flex-shrink-0 transition-all duration-200",
        isActive ? "ring-2 ring-white ring-offset-1 ring-offset-black" : "opacity-85 hover:opacity-100"
      )}
      style={{ aspectRatio: "3/4", background: exp.previewGradient }}
    >
      {/* Scan shimmer */}
      <div className="absolute inset-0" style={{ animation: "studioScan 2.8s ease-in-out infinite",
        background: "linear-gradient(180deg,rgba(255,255,255,0.08) 0%,transparent 50%,rgba(255,255,255,0.04) 100%)" }} />

      {/* Bottom text gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-3/5"
        style={{ background: "linear-gradient(to top,rgba(0,0,0,0.88) 0%,transparent 100%)" }} />

      {/* Active pill */}
      {isActive && (
        <div className="absolute top-2.5 left-2.5 bg-white text-black text-[8px] font-black px-2 py-0.5 rounded-full uppercase tracking-widest">
          LIVE
        </div>
      )}

      {/* Uses badge */}
      <div className="absolute top-2.5 right-2.5 bg-black/60 backdrop-blur-sm text-[8px] font-bold text-white/80 px-1.5 py-0.5 rounded-full">
        {exp.uses}
      </div>

      {/* Center emoji */}
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-5xl" style={{ animation: "studioBob 2.2s ease-in-out infinite", filter: "drop-shadow(0 0 10px rgba(255,255,255,0.4))" }}>
          {exp.previewEmoji}
        </span>
      </div>

      {/* Bottom content */}
      <div className="absolute bottom-0 left-0 right-0 p-3">
        <p className="text-white font-display font-bold text-sm leading-tight">{exp.label}</p>
        <p className="text-white/55 text-[10px] mt-0.5 leading-snug line-clamp-2">{exp.tagline}</p>
        <div className="flex items-center gap-2 mt-1.5">
          <span className="flex items-center gap-0.5 text-yellow-400 text-[9px]">
            <Star className="w-2.5 h-2.5 fill-yellow-400" /> {exp.rating}
          </span>
          {exp.onTap && (
            <span className="text-white/40 text-[9px]">👆 interactive</span>
          )}
        </div>
      </div>
    </button>
  );
}

// Compact 3-up card (for AR worlds / safety / gaming)
function CompactCard({ exp, isActive, onSelect }: { exp: Experience; isActive: boolean; onSelect: () => void }) {
  return (
    <button
      onClick={onSelect}
      className={cn(
        "flex flex-col w-full overflow-hidden rounded-xl transition-all duration-200",
        isActive ? "ring-2 ring-white ring-offset-1 ring-offset-black" : "opacity-85 hover:opacity-100"
      )}
    >
      <div className="relative w-full overflow-hidden rounded-xl" style={{ aspectRatio: "9/14", background: exp.previewGradient }}>
        <div className="absolute inset-0" style={{ animation: "studioScan 2.4s ease-in-out infinite",
          background: "linear-gradient(180deg,rgba(255,255,255,0.07) 0%,transparent 50%,rgba(255,255,255,0.04) 100%)" }} />
        <div className="absolute bottom-0 left-0 right-0 h-2/3"
          style={{ background: "linear-gradient(to top,rgba(0,0,0,0.78) 0%,transparent 100%)" }} />
        {isActive && (
          <div className="absolute top-1.5 left-1.5 bg-white text-black text-[7px] font-black px-1.5 py-0.5 rounded-full uppercase">ON</div>
        )}
        <div className="absolute top-1.5 right-1.5 bg-black/60 text-[8px] text-white/70 px-1.5 py-0.5 rounded-full">{exp.uses}</div>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-3xl" style={{ animation: "studioBob 2s ease-in-out infinite" }}>{exp.previewEmoji}</span>
        </div>
        <div className="absolute bottom-2 left-2 right-2">
          <p className="text-white text-[10px] font-bold leading-tight line-clamp-1">{exp.label}</p>
          <p className="text-white/50 text-[8px] leading-tight">{exp.creator}</p>
        </div>
      </div>
    </button>
  );
}

interface Props {
  activeExperienceId: string | null;
  onActivate: (id: string | null) => void;
}

export function EffectsPanel({ activeExperienceId, onActivate }: Props) {
  const [tab, setTab] = React.useState<TabId>("style");

  const cats = TAB_CATS[tab];
  const visible = EXPERIENCES.filter(e => cats.includes(e.category));
  const isStyle = tab === "style";

  const activeExp = EXPERIENCES.find(e => e.id === activeExperienceId);

  function toggle(exp: Experience) {
    onActivate(activeExperienceId === exp.id ? null : exp.id);
  }

  return (
    <div className="space-y-3">
      {/* Tab bar */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {TABS.map(({ id, label, icon: Icon }) => (
          <button key={id} onClick={() => setTab(id)}
            className={cn(
              "flex-shrink-0 flex items-center gap-1 text-[10px] font-semibold px-3 py-1.5 rounded-full border transition-all",
              tab === id ? "bg-white text-black border-white" : "border-white/15 text-white/60 hover:text-white"
            )}>
            <Icon className="w-3 h-3" />
            {label}
          </button>
        ))}
      </div>

      {/* Active experience pill */}
      {activeExp && (
        <div className="flex items-center gap-2 bg-white/8 border border-white/15 rounded-xl px-3 py-2">
          <span className="text-base">{activeExp.previewEmoji}</span>
          <div className="flex-1 min-w-0">
            <p className="text-white text-xs font-semibold leading-none">{activeExp.label}</p>
            <p className="text-white/40 text-[10px] mt-0.5">{activeExp.tagline}</p>
          </div>
          {activeExp.onTap && (
            <span className="text-[9px] text-white/40 flex-shrink-0">👆 tap camera</span>
          )}
          <button onClick={() => onActivate(null)}
            className="flex-shrink-0 text-[10px] text-white/40 hover:text-white/80 border border-white/15 rounded-full px-2 py-0.5 transition-all">
            Remove
          </button>
        </div>
      )}

      {/* Style worlds: 2-column wide cards */}
      {isStyle && (
        <div>
          <p className="text-white/40 text-[9px] uppercase tracking-widest mb-2.5">Visual Transformations · Tap to apply</p>
          <div className="grid grid-cols-2 gap-2.5">
            {visible.map(exp => (
              <StyleCard key={exp.id} exp={exp} isActive={activeExperienceId === exp.id} onSelect={() => toggle(exp)} />
            ))}
          </div>
        </div>
      )}

      {/* Other categories: 3-column compact grid */}
      {!isStyle && (
        <div>
          <p className="text-white/40 text-[9px] uppercase tracking-widest mb-2.5">{visible.length} effects available</p>
          <div className="grid grid-cols-3 gap-2">
            {visible.map(exp => (
              <CompactCard key={exp.id} exp={exp} isActive={activeExperienceId === exp.id} onSelect={() => toggle(exp)} />
            ))}
          </div>
        </div>
      )}

      {visible.length === 0 && (
        <div className="text-center py-8">
          <p className="text-3xl mb-2">🎭</p>
          <p className="text-white/40 text-sm">Nothing here yet. Check another tab.</p>
        </div>
      )}

      <style>{`
        @keyframes studioScan { 0%,100%{transform:translateY(-100%);opacity:.8} 50%{transform:translateY(100%);opacity:.4} }
        @keyframes studioBob  { 0%,100%{transform:translateY(0) scale(1)} 50%{transform:translateY(-6px) scale(1.07)} }
      `}</style>
    </div>
  );
}
