import React from "react";
import { cn } from "@/lib/utils";
import { CheckCircle2 } from "lucide-react";

export interface StudioFilter {
  id: string;
  label: string;
  category: string;
  css: string;
  emoji?: string;
  creator?: string;
  isPremium?: boolean;
}

export const STUDIO_FILTERS: StudioFilter[] = [
  // Beauty
  { id: "none",       category: "All",      label: "Original",     css: "none",                                                         emoji: "✨" },
  { id: "soft_light", category: "Beauty",   label: "Soft Light",   css: "brightness(1.1) saturate(0.9) contrast(0.95)",                 emoji: "🌸" },
  { id: "portrait",   category: "Beauty",   label: "Portrait Pro", css: "contrast(1.05) brightness(1.08) saturate(1.2)",                emoji: "💎" },
  { id: "hdr",        category: "Beauty",   label: "HDR+",         css: "contrast(1.4) saturate(1.6) brightness(0.95)",                 emoji: "📸" },
  // Cinematic
  { id: "cinematic",  category: "Cinematic",label: "Cinematic",    css: "contrast(1.25) brightness(0.88) saturate(1.1)",               emoji: "🎞️" },
  { id: "golden",     category: "Cinematic",label: "Golden Hour",  css: "sepia(0.45) saturate(1.8) brightness(1.1)",                   emoji: "🌅" },
  { id: "noir",       category: "Cinematic",label: "Noir",         css: "grayscale(1) contrast(1.5) brightness(0.85)",                 emoji: "🖤" },
  { id: "dreamy",     category: "Cinematic",label: "Dream State",  css: "saturate(1.6) brightness(1.15) contrast(0.9) hue-rotate(10deg)", emoji: "☁️" },
  { id: "retro",      category: "Cinematic",label: "Retro 90s",    css: "sepia(0.3) contrast(1.1) saturate(1.4) hue-rotate(340deg)",   emoji: "📼" },
  // Fun
  { id: "viral",      category: "Fun",      label: "Viral Pop",    css: "saturate(2.2) contrast(1.2) brightness(1.05)",                emoji: "🔥" },
  { id: "neon",       category: "Fun",      label: "Neon Pulse",   css: "saturate(2.5) hue-rotate(270deg) contrast(1.15)",             emoji: "💜" },
  { id: "arctic",     category: "Fun",      label: "Arctic Cool",  css: "saturate(0.7) hue-rotate(190deg) brightness(1.1) contrast(1.1)", emoji: "❄️" },
  { id: "cartoon",    category: "Fun",      label: "Cartoon",      css: "saturate(2.8) contrast(1.5) brightness(1.1)",                 emoji: "🎨" },
  // Fantasy
  { id: "dragon",     category: "Fantasy",  label: "Dragon Fire",  css: "sepia(0.4) hue-rotate(350deg) saturate(2) contrast(1.3) brightness(0.9)", emoji: "🐉" },
  { id: "wizard",     category: "Fantasy",  label: "Wizard",       css: "hue-rotate(260deg) saturate(1.8) contrast(1.2) brightness(0.9)", emoji: "🧙" },
  { id: "angel",      category: "Fantasy",  label: "Angel Wings",  css: "brightness(1.3) saturate(0.6) contrast(0.9)",                 emoji: "👼" },
  { id: "demon",      category: "Fantasy",  label: "Demon King",   css: "hue-rotate(330deg) saturate(2.5) contrast(1.6) brightness(0.7)", emoji: "😈" },
  // Industrial (unique to R2TCoM)
  { id: "blueprint",  category: "Industrial",label: "Blueprint",   css: "grayscale(1) sepia(1) hue-rotate(190deg) saturate(4) brightness(0.9) contrast(1.3)", emoji: "📐" },
  { id: "weld",       category: "Industrial",label: "Weld Sparks", css: "brightness(1.2) saturate(1.8) contrast(1.3) hue-rotate(10deg)", emoji: "⚡" },
  { id: "process",    category: "Industrial",label: "Control Room",css: "saturate(0.5) hue-rotate(180deg) contrast(1.4) brightness(0.85)", emoji: "🖥️" },
  { id: "hardhat",    category: "Industrial",label: "Hard Hat",    css: "sepia(0.3) contrast(1.15) saturate(1.4)",                     emoji: "🪖", creator: "SafetyNerd87", isPremium: false },
  { id: "construct",  category: "Industrial",label: "Construction",css: "sepia(0.5) saturate(1.6) contrast(1.2) brightness(0.95)",     emoji: "🏗️", creator: "BuildMaster", isPremium: false },
  // Safety-Themed
  { id: "confined",   category: "Safety",   label: "Confined Space",css: "saturate(0.4) hue-rotate(200deg) contrast(1.2)",            emoji: "⚠️", creator: "SafetyNerd87" },
  { id: "permit",     category: "Safety",   label: "Permit Vision", css: "sepia(0.6) contrast(1.2) brightness(1.1)",                   emoji: "📋", creator: "HSECreator" },
  { id: "incident",   category: "Safety",   label: "Investigation", css: "grayscale(0.7) contrast(1.3) brightness(0.9)",               emoji: "🔍", creator: "SafetyNerd87", isPremium: true },
];

const CATEGORIES = ["All", "Beauty", "Cinematic", "Fun", "Fantasy", "Industrial", "Safety"];

interface Props {
  selected: string;
  onSelect: (id: string) => void;
  previewBg?: string;
}

export function FiltersPanel({ selected, onSelect, previewBg }: Props) {
  const [cat, setCat] = React.useState("All");
  const visible = cat === "All" ? STUDIO_FILTERS : STUDIO_FILTERS.filter(f => f.category === cat);

  return (
    <div className="space-y-3">
      {/* Category tabs */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {CATEGORIES.map(c => (
          <button
            key={c}
            onClick={() => setCat(c)}
            className={cn(
              "flex-shrink-0 text-xs font-medium px-3 py-1.5 rounded-full border transition-all",
              cat === c
                ? "bg-primary text-primary-foreground border-primary"
                : "border-border text-muted-foreground hover:text-foreground hover:border-foreground/30"
            )}
          >
            {c === "Safety" ? "🦺 " + c : c === "Industrial" ? "🏭 " + c : c}
          </button>
        ))}
      </div>

      {/* Filter grid */}
      <div className="grid grid-cols-4 gap-2 max-h-52 overflow-y-auto pr-1">
        {visible.map(f => (
          <button
            key={f.id}
            onClick={() => onSelect(f.id)}
            className={cn(
              "relative flex flex-col items-center gap-1 p-1.5 rounded-xl border text-center transition-all",
              selected === f.id
                ? "border-primary bg-primary/15 ring-1 ring-primary"
                : "border-border bg-card/50 hover:border-foreground/20"
            )}
          >
            <div
              className="w-full h-12 rounded-lg flex items-center justify-center text-xl"
              style={{
                filter: f.css,
                background: previewBg ?? "linear-gradient(135deg,#1a1a2e 0%,#16213e 50%,#0f3460 100%)",
              }}
            >
              {f.emoji}
            </div>
            <span className="text-[10px] font-medium leading-tight line-clamp-1">{f.label}</span>
            {f.creator && (
              <span className="text-[9px] text-muted-foreground leading-none">{f.creator}</span>
            )}
            {f.isPremium && (
              <span className="absolute top-1 right-1 text-[8px] bg-r2c-gold text-[#0a0f1e] font-bold px-1 rounded leading-tight">PRO</span>
            )}
            {selected === f.id && (
              <CheckCircle2 className="absolute top-1 left-1 w-3 h-3 text-primary" />
            )}
          </button>
        ))}
      </div>
    </div>
  );
}
