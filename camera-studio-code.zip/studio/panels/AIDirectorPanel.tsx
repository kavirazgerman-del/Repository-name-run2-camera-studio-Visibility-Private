import React from "react";
import {
  useGenerateCreativePackage,
  useGetCreativeJob,
  useGetCreativeLimits,
  getGetCreativeJobQueryKey,
  CreativeBriefInputMood,
  CreativeBriefInputStyle,
  CreativeBriefInputPalette,
  CreativeBriefInputMusicStyle,
  CreativeBriefInputIntensity,
  CreativeBriefInputMotion,
  type CreativeBriefInput,
  type CreativeJob,
  type CreativeMusicTrack,
  type AiFilterConfig,
} from "@workspace/api-client-react";
import { Sparkles, Wand2, Loader2, AlertTriangle, Check, RefreshCw, ChevronRight, Music2 } from "lucide-react";
import { cn } from "@/lib/utils";

// ── AI Creative Director (CORE) ────────────────────────────────────────────────
// A guided brief (Mood / Style / Palette / Music / Intensity / Motion + an
// optional theme hint) is sent to the server, which builds ONE governed, safety-
// constrained prompt, asks the model for a strict-JSON creative package, and
// returns a reusable config-driven filter. This panel owns only the UI: the form,
// the async job progress, and applying the returned look to the studio compositor.
// Music generation, posting, sharing, and admin live in later phases.

const THEME_MAX = 120;

type Phase = "form" | "working" | "ready" | "error";
const IN_FLIGHT: CreativeJob["status"][] = [
  "queued",
  "generating_filter",
  "generating_music",
  "building_preview",
];

interface Option<T extends string> {
  value: T;
  label: string;
  hint: string;
}

const MOODS: Option<CreativeBriefInput["mood"]>[] = [
  { value: CreativeBriefInputMood.hype, label: "Hype", hint: "⚡" },
  { value: CreativeBriefInputMood.calm, label: "Calm", hint: "🌿" },
  { value: CreativeBriefInputMood.dreamy, label: "Dreamy", hint: "💭" },
  { value: CreativeBriefInputMood.gritty, label: "Gritty", hint: "🪨" },
  { value: CreativeBriefInputMood.joyful, label: "Joyful", hint: "✨" },
  { value: CreativeBriefInputMood.mysterious, label: "Mystery", hint: "🌑" },
  { value: CreativeBriefInputMood.nostalgic, label: "Nostalgic", hint: "📼" },
  { value: CreativeBriefInputMood.bold, label: "Bold", hint: "🔥" },
];

const STYLES: Option<CreativeBriefInput["style"]>[] = [
  { value: CreativeBriefInputStyle.cinematic, label: "Cinematic", hint: "🎬" },
  { value: CreativeBriefInputStyle.retro, label: "Retro", hint: "🕹️" },
  { value: CreativeBriefInputStyle.neon, label: "Neon", hint: "🌈" },
  { value: CreativeBriefInputStyle.minimal, label: "Minimal", hint: "◻️" },
  { value: CreativeBriefInputStyle.vibrant, label: "Vibrant", hint: "🎨" },
  { value: CreativeBriefInputStyle.mono, label: "Mono", hint: "⚫" },
  { value: CreativeBriefInputStyle.film, label: "Film", hint: "📷" },
  { value: CreativeBriefInputStyle.glossy, label: "Glossy", hint: "💎" },
];

const PALETTES: Option<CreativeBriefInput["palette"]>[] = [
  { value: CreativeBriefInputPalette.warm, label: "Warm", hint: "#f59e0b" },
  { value: CreativeBriefInputPalette.cool, label: "Cool", hint: "#38bdf8" },
  { value: CreativeBriefInputPalette.neutral, label: "Neutral", hint: "#a8a29e" },
  { value: CreativeBriefInputPalette.vivid, label: "Vivid", hint: "#ec4899" },
  { value: CreativeBriefInputPalette.pastel, label: "Pastel", hint: "#f9a8d4" },
  { value: CreativeBriefInputPalette.dark, label: "Dark", hint: "#1e293b" },
  { value: CreativeBriefInputPalette.golden, label: "Golden", hint: "#eab308" },
  { value: CreativeBriefInputPalette.ocean, label: "Ocean", hint: "#0ea5e9" },
];

const MUSIC_STYLES: Option<CreativeBriefInput["musicStyle"]>[] = [
  { value: CreativeBriefInputMusicStyle.auto, label: "Auto", hint: "✨" },
  { value: CreativeBriefInputMusicStyle.upbeat, label: "Upbeat", hint: "🎉" },
  { value: CreativeBriefInputMusicStyle.chill, label: "Chill", hint: "🌊" },
  { value: CreativeBriefInputMusicStyle.epic, label: "Epic", hint: "🏔️" },
  { value: CreativeBriefInputMusicStyle.lofi, label: "Lo-fi", hint: "🎧" },
  { value: CreativeBriefInputMusicStyle.electronic, label: "Electro", hint: "🔊" },
  { value: CreativeBriefInputMusicStyle.acoustic, label: "Acoustic", hint: "🎸" },
  { value: CreativeBriefInputMusicStyle.none, label: "None", hint: "🔇" },
];

const INTENSITIES: Option<CreativeBriefInput["intensity"]>[] = [
  { value: CreativeBriefInputIntensity.subtle, label: "Subtle", hint: "Gentle touch" },
  { value: CreativeBriefInputIntensity.balanced, label: "Balanced", hint: "Just right" },
  { value: CreativeBriefInputIntensity.bold, label: "Bold", hint: "Turn it up" },
];

const MOTIONS: Option<CreativeBriefInput["motion"]>[] = [
  { value: CreativeBriefInputMotion.still, label: "Still", hint: "No movement" },
  { value: CreativeBriefInputMotion.gentle, label: "Gentle", hint: "Soft drift" },
  { value: CreativeBriefInputMotion.dynamic, label: "Dynamic", hint: "Lively" },
];

const PROGRESS_COPY: Record<string, string> = {
  queued: "Reading your brief…",
  generating_filter: "Directing your look…",
  generating_music: "Composing original music…",
  building_preview: "Mixing the final grade…",
};

const DEFAULT_BRIEF: CreativeBriefInput = {
  mood: CreativeBriefInputMood.joyful,
  style: CreativeBriefInputStyle.cinematic,
  palette: CreativeBriefInputPalette.warm,
  musicStyle: CreativeBriefInputMusicStyle.auto,
  intensity: CreativeBriefInputIntensity.balanced,
  motion: CreativeBriefInputMotion.gentle,
  theme: "",
};

interface Props {
  onApply: (
    config: AiFilterConfig,
    title: string | null,
    music: CreativeMusicTrack | null,
    experienceId: number,
  ) => void;
  appliedName?: string | null;
}

function OptionGrid<T extends string>({
  options, value, onChange, cols = 4,
}: { options: Option<T>[]; value: T; onChange: (v: T) => void; cols?: 3 | 4 }) {
  const isColor = (h: string) => h.startsWith("#");
  return (
    <div className={cn("grid gap-1.5", cols === 3 ? "grid-cols-3" : "grid-cols-4")}>
      {options.map(o => {
        const sel = o.value === value;
        return (
          <button
            key={o.value}
            type="button"
            onClick={() => onChange(o.value)}
            className="flex flex-col items-center justify-center gap-1 rounded-xl border px-1 py-2 transition-all text-center"
            style={sel
              ? { background: "rgba(34,199,242,.14)", borderColor: "rgba(34,199,242,.6)", color: "#22C7F2" }
              : { background: "rgba(255,255,255,.04)", borderColor: "rgba(255,255,255,.1)", color: "#A9B8CA" }}
          >
            {isColor(o.hint)
              ? <span className="w-5 h-5 rounded-full border border-white/20" style={{ background: o.hint }} />
              : <span className="text-base leading-none">{o.hint}</span>}
            <span className="text-[10px] font-semibold leading-tight">{o.label}</span>
          </button>
        );
      })}
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="text-white/40 text-[10px] uppercase tracking-widest mb-2">{title}</p>
      {children}
    </div>
  );
}

export function AIDirectorPanel({ onApply, appliedName }: Props) {
  const [brief, setBrief] = React.useState<CreativeBriefInput>(DEFAULT_BRIEF);
  const [jobId, setJobId] = React.useState(0);
  const [errorMsg, setErrorMsg] = React.useState<string | null>(null);

  const limits = useGetCreativeLimits();
  const generate = useGenerateCreativePackage();
  const job = useGetCreativeJob(jobId, {
    query: {
      queryKey: getGetCreativeJobQueryKey(jobId),
      // Poll only while the job is still working; stop once it reaches a terminal
      // state so we don't hammer the server after ready/blocked/failed.
      refetchInterval: (q) => {
        const s = q.state.data?.status;
        return s && IN_FLIGHT.includes(s) ? 1500 : false;
      },
    },
  });

  const data = job.data;
  const phase: Phase = !jobId
    ? "form"
    : data?.status === "ready"
      ? "ready"
      : data?.status === "blocked" || data?.status === "failed"
        ? "error"
        : "working";

  const set = <K extends keyof CreativeBriefInput>(k: K, v: CreativeBriefInput[K]) =>
    setBrief(prev => ({ ...prev, [k]: v }));

  function startOver() {
    setJobId(0);
    setErrorMsg(null);
  }

  async function submit() {
    setErrorMsg(null);
    const payload: CreativeBriefInput = {
      ...brief,
      theme: brief.theme?.trim() ? brief.theme.trim().slice(0, THEME_MAX) : null,
    };
    try {
      const created = await generate.mutateAsync({ data: payload });
      setJobId(created.id);
    } catch (err: any) {
      // 429 (rate limit) and 400 (rejected brief) surface here. The server copy is
      // already user-safe and generic.
      const msg =
        err?.data?.error ??
        err?.message ??
        "We couldn't start that right now. Please try again.";
      setErrorMsg(typeof msg === "string" ? msg : "We couldn't start that right now.");
      void limits.refetch();
    }
  }

  // Refresh remaining-attempts once a job reaches a terminal state (a blocked
  // attempt counts; a technical failure is refunded — both reconcile here).
  React.useEffect(() => {
    if (phase === "ready" || phase === "error") void limits.refetch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);

  const remaining = limits.data?.remaining;
  const outOfAttempts = remaining === 0;

  return (
    <div className="space-y-4">
      {/* Hero */}
      <div className="rounded-2xl p-3.5 text-center" style={{ background: "linear-gradient(135deg,#0b1120,#13243a)", border: "1px solid rgba(34,199,242,.33)" }}>
        <p className="text-white font-display font-bold text-sm flex items-center justify-center gap-1.5">
          <Wand2 className="w-4 h-4 text-cyan-300" /> AI Creative Director
        </p>
        <p className="text-white/50 text-[11px] mt-1 leading-relaxed">
          Describe the vibe you're after and the director crafts a one-of-a-kind look —
          colour grade, glow, and motion — that bakes right into your photo &amp; video.
        </p>
      </div>

      {/* Remaining attempts */}
      {limits.data && (
        <div className="flex items-center justify-between rounded-xl px-3 py-2 text-[11px]"
          style={{ background: "rgba(255,255,255,.04)", border: "1px solid rgba(255,255,255,.1)" }}>
          <span className="text-white/55">Creations left</span>
          <span className="font-mono font-bold" style={{ color: outOfAttempts ? "#f87171" : "#22C7F2" }}>
            {remaining} / {limits.data.limit}
          </span>
        </div>
      )}

      {/* ── FORM ─────────────────────────────────────────────────────────────── */}
      {phase === "form" && (
        <div className="space-y-4">
          {errorMsg && (
            <div className="rounded-xl px-3 py-2 text-[11px] flex items-start gap-2"
              style={{ background: "rgba(248,113,113,.1)", border: "1px solid rgba(248,113,113,.35)", color: "#fca5a5" }}>
              <AlertTriangle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <Section title="Mood">
            <OptionGrid options={MOODS} value={brief.mood} onChange={v => set("mood", v)} />
          </Section>
          <Section title="Style">
            <OptionGrid options={STYLES} value={brief.style} onChange={v => set("style", v)} />
          </Section>
          <Section title="Palette">
            <OptionGrid options={PALETTES} value={brief.palette} onChange={v => set("palette", v)} />
          </Section>
          <Section title="Music vibe">
            <OptionGrid options={MUSIC_STYLES} value={brief.musicStyle} onChange={v => set("musicStyle", v)} />
          </Section>
          <Section title="Intensity">
            <OptionGrid options={INTENSITIES} value={brief.intensity} onChange={v => set("intensity", v)} cols={3} />
          </Section>
          <Section title="Motion">
            <OptionGrid options={MOTIONS} value={brief.motion} onChange={v => set("motion", v)} cols={3} />
          </Section>

          <Section title="Theme (optional)">
            <textarea
              value={brief.theme ?? ""}
              onChange={e => set("theme", e.target.value.slice(0, THEME_MAX))}
              maxLength={THEME_MAX}
              rows={2}
              placeholder="e.g. golden hour on the boardwalk"
              className="w-full resize-none rounded-xl px-3 py-2 text-[12px] text-white placeholder:text-white/30 outline-none focus:border-cyan-400/60"
              style={{ background: "rgba(255,255,255,.04)", border: "1px solid rgba(255,255,255,.1)" }}
            />
            <p className="text-right text-white/30 text-[10px] mt-1">{(brief.theme ?? "").length}/{THEME_MAX}</p>
          </Section>

          <button
            type="button"
            onClick={submit}
            disabled={generate.isPending || outOfAttempts}
            className="w-full flex items-center justify-center gap-2 rounded-2xl py-3 text-sm font-bold transition-all disabled:opacity-50"
            style={{ background: "linear-gradient(135deg,#22C7F2,#3b82f6)", color: "#04121e" }}
          >
            {generate.isPending
              ? <><Loader2 className="w-4 h-4 animate-spin" /> Starting…</>
              : <><Sparkles className="w-4 h-4" /> {outOfAttempts ? "No creations left" : "Direct my look"}</>}
          </button>
          {outOfAttempts && limits.data?.resetAt && (
            <p className="text-center text-white/40 text-[10px]">
              More unlock {new Date(limits.data.resetAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}.
            </p>
          )}
        </div>
      )}

      {/* ── WORKING ──────────────────────────────────────────────────────────── */}
      {phase === "working" && (
        <div className="rounded-2xl p-6 flex flex-col items-center gap-3 text-center"
          style={{ background: "rgba(255,255,255,.03)", border: "1px solid rgba(34,199,242,.25)" }}>
          <Loader2 className="w-8 h-8 animate-spin text-cyan-300" />
          <p className="text-white text-sm font-semibold">
            {PROGRESS_COPY[data?.status ?? "queued"] ?? "Working…"}
          </p>
          <p className="text-white/45 text-[11px] leading-relaxed">
            Your creative director is composing something original. This usually takes a few seconds.
          </p>
        </div>
      )}

      {/* ── ERROR (blocked or technical failure) ─────────────────────────────── */}
      {phase === "error" && (
        <div className="space-y-3">
          <div className="rounded-2xl p-5 flex flex-col items-center gap-2 text-center"
            style={{ background: "rgba(248,113,113,.08)", border: "1px solid rgba(248,113,113,.3)" }}>
            <AlertTriangle className="w-7 h-7 text-red-300" />
            <p className="text-white text-sm font-semibold">
              {data?.status === "blocked" ? "Let's try a different direction" : "That didn't go through"}
            </p>
            <p className="text-white/55 text-[11px] leading-relaxed">
              {data?.errorReason ??
                (data?.status === "blocked"
                  ? "We couldn't create that particular look. Try adjusting your settings or theme."
                  : "Something went wrong on our end. This one didn't count against your creations — please try again.")}
            </p>
          </div>
          <button
            type="button"
            onClick={startOver}
            className="w-full flex items-center justify-center gap-2 rounded-2xl py-3 text-sm font-bold"
            style={{ background: "rgba(34,199,242,.14)", border: "1px solid rgba(34,199,242,.5)", color: "#22C7F2" }}
          >
            <RefreshCw className="w-4 h-4" /> Try again
          </button>
        </div>
      )}

      {/* ── READY (package preview + apply) ──────────────────────────────────── */}
      {phase === "ready" && data?.package && (
        <ReadyView
          pkg={data.package}
          music={data.music ?? null}
          moderationState={data.filterModerationState ?? null}
          applied={appliedName === (data.package.filter.name ?? data.title ?? null)}
          onApply={() => onApply(data.package!.filter, data.title ?? null, data.music ?? null, data.id)}
          onStartOver={startOver}
        />
      )}
    </div>
  );
}

function ReadyView({
  pkg, music, moderationState, applied, onApply, onStartOver,
}: {
  pkg: NonNullable<CreativeJob["package"]>;
  music: CreativeMusicTrack | null;
  moderationState: string | null;
  applied: boolean;
  onApply: () => void;
  onStartOver: () => void;
}) {
  const accents = pkg.filter.accentColors ?? [];
  return (
    <div className="space-y-3">
      {moderationState && moderationState !== "active" && (
        <div className="rounded-2xl px-3 py-2 text-[11px] flex items-start gap-2"
          style={{ background: "rgba(248,113,113,.1)", border: "1px solid rgba(248,113,113,.35)", color: "#fca5a5" }}>
          <AlertTriangle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
          <span>Our team paused this look from public reuse. You can still use it on your own posts, but it can't be shared as a challenge.</span>
        </div>
      )}
      {/* Look identity */}
      <div className="rounded-2xl p-3.5" style={{ background: "linear-gradient(135deg,#0b1120,#13243a)", border: "1px solid rgba(34,199,242,.33)" }}>
        <div className="flex items-center justify-between gap-2">
          <p className="text-cyan-200 text-sm font-display font-bold flex items-center gap-1.5">
            <Sparkles className="w-4 h-4" /> {pkg.filter.name || pkg.title || "Your look"}
          </p>
          {accents.length > 0 && (
            <div className="flex -space-x-1">
              {accents.slice(0, 4).map((c, i) => (
                <span key={i} className="w-4 h-4 rounded-full border border-white/30" style={{ background: c }} />
              ))}
            </div>
          )}
        </div>
        {pkg.description && <p className="text-white/55 text-[11px] mt-1.5 leading-relaxed">{pkg.description}</p>}
      </div>

      {/* What's in the look */}
      {pkg.filter.overlays?.length > 0 && (
        <Section title="In this look">
          <div className="flex flex-wrap gap-1.5">
            {pkg.filter.overlays.map((o, i) => (
              <span key={i} className="rounded-full px-2.5 py-1 text-[10px] font-semibold capitalize"
                style={{ background: "rgba(255,255,255,.06)", border: "1px solid rgba(255,255,255,.12)", color: "#cbd5e1" }}>
                {o.type.replace(/_/g, " ")}
              </span>
            ))}
          </div>
        </Section>
      )}

      {/* Original soundtrack — composed instrumental bed, plays same-origin so the
          studio can both preview and bake it. Falls back to the text vibe when no
          track was generated (e.g. the brief asked for no music). */}
      {music ? (
        <Section title="Original soundtrack">
          <div className="rounded-xl px-3 py-2.5 space-y-2"
            style={{ background: "rgba(34,199,242,.08)", border: "1px solid rgba(34,199,242,.3)" }}>
            <p className="text-cyan-200 text-[11px] font-semibold flex items-center gap-1.5">
              <Music2 className="w-3.5 h-3.5" /> {music.title}
            </p>
            <audio controls preload="none" src={music.audioUrl} className="w-full h-8" />
            {(music.genre || music.bpm || music.mood) && (
              <p className="text-cyan-300/70 text-[10px] capitalize">
                {[music.genre, music.mood, music.bpm ? `${music.bpm} BPM` : null]
                  .filter(Boolean)
                  .join(" · ")}
              </p>
            )}
          </div>
        </Section>
      ) : pkg.musicSuggestion?.descriptor ? (
        <Section title="Music vibe">
          <div className="rounded-xl px-3 py-2"
            style={{ background: "rgba(255,255,255,.04)", border: "1px solid rgba(255,255,255,.1)" }}>
            <p className="text-white/55 text-[11px] leading-relaxed">{pkg.musicSuggestion.descriptor}</p>
            {(pkg.musicSuggestion.style || pkg.musicSuggestion.mood) && (
              <p className="text-cyan-300/70 text-[10px] mt-1 capitalize">
                {[pkg.musicSuggestion.style, pkg.musicSuggestion.mood].filter(Boolean).join(" · ")}
              </p>
            )}
          </div>
        </Section>
      ) : null}

      {/* Caption ideas */}
      {pkg.captionIdeas?.length > 0 && (
        <Section title="Caption ideas">
          <ul className="space-y-1.5">
            {pkg.captionIdeas.slice(0, 3).map((c, i) => (
              <li key={i} className="text-white/65 text-[11px] flex items-start gap-1.5">
                <ChevronRight className="w-3 h-3 mt-0.5 shrink-0 text-cyan-400/70" /> {c}
              </li>
            ))}
          </ul>
        </Section>
      )}

      <button
        type="button"
        onClick={onApply}
        className="w-full flex items-center justify-center gap-2 rounded-2xl py-3 text-sm font-bold transition-all"
        style={applied
          ? { background: "rgba(34,199,242,.14)", border: "1px solid rgba(34,199,242,.5)", color: "#22C7F2" }
          : { background: "linear-gradient(135deg,#22C7F2,#3b82f6)", color: "#04121e" }}
      >
        {applied ? <><Check className="w-4 h-4" /> Applied to studio</> : <><Sparkles className="w-4 h-4" /> Apply this look</>}
      </button>
      <button
        type="button"
        onClick={onStartOver}
        className="w-full flex items-center justify-center gap-2 rounded-2xl py-2.5 text-xs font-semibold text-white/60 hover:text-white transition-colors"
      >
        <RefreshCw className="w-3.5 h-3.5" /> Create another
      </button>
    </div>
  );
}
