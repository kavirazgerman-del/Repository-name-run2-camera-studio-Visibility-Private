import React from "react";
import { cn } from "@/lib/utils";

export interface AIBackground {
  id: string;
  label: string;
  gradient: string;
  accent: string;
}

const PRESET_BACKGROUNDS: AIBackground[] = [
  { id:"space",    label: "Deep Space",     gradient: "linear-gradient(135deg,#000005,#05001a,#0a0530)", accent: "#8b5cf6" },
  { id:"refinery", label: "Control Room",   gradient: "linear-gradient(135deg,#050d14,#0a1929,#0d2137)", accent: "#0080ff" },
  { id:"forest",   label: "Forest",         gradient: "linear-gradient(135deg,#0a1a0a,#1a3a1a,#2d5a27)", accent: "#4ade80" },
  { id:"neon_city",label: "Neon City",      gradient: "linear-gradient(135deg,#0a0a0a,#1a0a2a,#2d0e5a)", accent: "#e879f9" },
  { id:"sunset",   label: "Golden Sunset",  gradient: "linear-gradient(135deg,#ff6b35,#f7c59f,#ffe0b2)", accent: "#ff9800" },
  { id:"volcano",  label: "Volcanic",       gradient: "linear-gradient(135deg,#1a0000,#3d0500,#6b1800)", accent: "#ff4500" },
  { id:"castle",   label: "Ancient Castle", gradient: "linear-gradient(135deg,#1a0f0f,#2d1b1b,#3d2020)", accent: "#8b4513" },
  { id:"arctic",   label: "Arctic Tundra",  gradient: "linear-gradient(135deg,#e8f4f8,#b3d9e8,#87bfce)", accent: "#00bcd4" },
];

interface Props {
  selectedBg: AIBackground | null;
  onSelectBg: (bg: AIBackground | null) => void;
  gsThreshold: number;
  onGsThreshold: (v: number) => void;
}

// Backgrounds tool — swaps your real background for a preset scene using the
// green-screen compositor already wired into compositeFrame (aiBg + gsThreshold).
// No "AI generation" and no voice effects — those were never real.
export function BackgroundsPanel({ selectedBg, onSelectBg, gsThreshold, onGsThreshold }: Props) {
  return (
    <div className="space-y-3">
      <p className="text-xs text-muted-foreground leading-snug">
        Replace your background with a preset scene. Works best against a solid, evenly-lit
        backdrop — use the sensitivity slider to fine-tune how much of it is removed.
      </p>

      {/* Background removal sensitivity — only relevant when a scene is active */}
      {selectedBg && (
        <div>
          <div className="flex justify-between text-xs text-muted-foreground mb-1">
            <span>Background removal sensitivity</span>
            <span className="font-mono">{gsThreshold}</span>
          </div>
          <input type="range" min={20} max={140} value={gsThreshold}
            onChange={e => onGsThreshold(Number(e.target.value))}
            className="w-full accent-primary" />
        </div>
      )}

      {/* Preset grid (first cell clears the background) */}
      <div className="grid grid-cols-4 gap-2 max-h-60 overflow-y-auto pr-1">
        <button onClick={() => onSelectBg(null)}
          className={cn("flex flex-col items-center gap-1 p-1.5 rounded-xl border transition-all",
            !selectedBg ? "border-primary bg-primary/10 ring-1 ring-primary" : "border-border bg-card hover:border-foreground/20")}>
          <div className="w-full h-10 rounded-lg bg-transparent border border-dashed border-border flex items-center justify-center text-lg">📷</div>
          <span className="text-[10px]">None</span>
        </button>
        {PRESET_BACKGROUNDS.map(bg => (
          <button key={bg.id} onClick={() => onSelectBg(bg)}
            className={cn("flex flex-col items-center gap-1 p-1.5 rounded-xl border transition-all",
              selectedBg?.id === bg.id ? "border-primary bg-primary/10 ring-1 ring-primary" : "border-border bg-card hover:border-foreground/20")}>
            <div className="w-full h-10 rounded-lg" style={{ background: bg.gradient, boxShadow: `0 0 8px ${bg.accent}40` }} />
            <span className="text-[10px] leading-tight line-clamp-1">{bg.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

export { PRESET_BACKGROUNDS };
