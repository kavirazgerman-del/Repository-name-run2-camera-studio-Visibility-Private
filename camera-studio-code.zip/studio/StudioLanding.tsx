import React from "react";
import {
  ChevronLeft, MoreHorizontal, Camera, Video, Images,
  Paintbrush, LayoutTemplate, SlidersHorizontal, Image as ImageIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";
import hero1 from "@/assets/studio-hero-1.png";
import hero2 from "@/assets/studio-hero-2.png";
import hero3 from "@/assets/studio-hero-3.png";

interface Props {
  onBack: () => void;
  onMenu: () => void;
  onVideo: () => void;
  onSlideshow: () => void;
  onCanvas: () => void;
  onTemplates: () => void;
  onSettings: () => void;
  onRecord: () => void;
  onGallery: () => void;
  permissionError?: string | null;
}

const HEROES = [hero1, hero2, hero3];

interface CreateCard {
  key: string;
  label: string;
  sub: string;
  Icon: typeof Video;
  color: string;
  glow: string;
  onClick: () => void;
}

export function StudioLanding({
  onBack, onMenu, onVideo, onSlideshow, onCanvas, onTemplates,
  onSettings, onRecord, onGallery, permissionError,
}: Props) {
  const [slide, setSlide] = React.useState(0);

  // Gentle auto-advancing hero carousel (the 3 dots in the design are real).
  React.useEffect(() => {
    const t = setInterval(() => setSlide(s => (s + 1) % HEROES.length), 5000);
    return () => clearInterval(t);
  }, []);

  const cards: CreateCard[] = [
    { key: "video", label: "Video", sub: "Record a clip", Icon: Video,
      color: "#b084ff", glow: "rgba(176,132,255,0.45)", onClick: onVideo },
    { key: "slides", label: "Slide Show", sub: "Create a story", Icon: Images,
      color: "#3da5ff", glow: "rgba(61,165,255,0.45)", onClick: onSlideshow },
    { key: "canvas", label: "Canvas Art", sub: "Draw or paint", Icon: Paintbrush,
      color: "#ff5fa2", glow: "rgba(255,95,162,0.45)", onClick: onCanvas },
    { key: "templates", label: "Templates", sub: "Start with a template", Icon: LayoutTemplate,
      color: "#33d6c0", glow: "rgba(51,214,192,0.45)", onClick: onTemplates },
  ];

  return (
    <div className="absolute inset-0 z-[60] overflow-y-auto bg-[#06070d]">
      {/* Ambient neon wash behind everything */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(120% 60% at 12% 0%, rgba(40,90,200,0.18), transparent 55%)," +
            "radial-gradient(120% 60% at 88% 4%, rgba(220,110,40,0.16), transparent 55%)," +
            "linear-gradient(180deg,#06070d 0%,#08090f 60%,#06070d 100%)",
        }}
      />

      <div
        className="relative mx-auto flex min-h-full w-full max-w-lg flex-col px-4"
        style={{
          paddingTop: "max(1rem, env(safe-area-inset-top))",
          paddingBottom: "max(1.25rem, env(safe-area-inset-bottom))",
        }}
      >
        {/* ── Header ─────────────────────────────────────────────────────────── */}
        <div className="flex items-center justify-between">
          <button
            onClick={onBack}
            aria-label="Close Camera Studio"
            className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/[0.04] text-white/90 backdrop-blur-sm transition active:scale-95"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>

          <div className="select-none text-lg font-extrabold tracking-[0.22em] text-white">
            RUN<span style={{ color: "#3da5ff" }}>2</span>TCOM
          </div>

          <button
            onClick={onMenu}
            aria-label="Studio options"
            className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/[0.04] text-white/90 backdrop-blur-sm transition active:scale-95"
          >
            <MoreHorizontal className="h-5 w-5" />
          </button>
        </div>

        {/* CAMERA STUDIO pill */}
        <div className="mt-3 flex justify-center">
          <div
            className="flex items-center gap-2 rounded-full border px-4 py-1.5 text-sm font-semibold tracking-[0.18em] text-white"
            style={{
              borderColor: "rgba(125,99,255,0.55)",
              background: "rgba(125,99,255,0.10)",
              boxShadow: "0 0 18px rgba(125,99,255,0.25)",
            }}
          >
            <Camera className="h-4 w-4" style={{ color: "#b084ff" }} />
            CAMERA STUDIO
          </div>
        </div>

        {/* ── Hero carousel ─────────────────────────────────────────────────── */}
        <div className="mt-4">
          <div
            className="relative aspect-[4/3] w-full overflow-hidden rounded-[28px] border border-white/10"
            style={{
              boxShadow:
                "0 0 0 1px rgba(255,255,255,0.04) inset," +
                "0 22px 70px rgba(0,0,0,0.65)," +
                "inset 0 30px 60px rgba(2,6,16,0.55)," +
                "inset 0 -26px 60px rgba(2,6,16,0.5)",
            }}
          >
            {HEROES.map((src, i) => (
              <img
                key={src}
                src={src}
                alt="Run2TCoM studio stage"
                className="absolute inset-0 h-full w-full object-cover transition-opacity duration-700 ease-out"
                style={{ opacity: i === slide ? 1 : 0 }}
                draggable={false}
              />
            ))}
            {/* readability vignette */}
            <div className="pointer-events-none absolute inset-0 rounded-[28px] ring-1 ring-inset ring-white/5" />
          </div>

          {/* dots */}
          <div className="mt-3 flex items-center justify-center gap-2">
            {HEROES.map((_, i) => (
              <button
                key={i}
                onClick={() => setSlide(i)}
                aria-label={`Show studio view ${i + 1}`}
                className="h-1.5 rounded-full transition-all"
                style={{
                  width: i === slide ? 22 : 6,
                  background: i === slide
                    ? "linear-gradient(90deg,#3da5ff,#f97316)"
                    : "rgba(255,255,255,0.25)",
                }}
              />
            ))}
          </div>
        </div>

        {permissionError && (
          <div className="mt-4 flex items-start gap-2 rounded-2xl border border-red-500/40 bg-red-900/40 p-3 text-xs text-red-200 backdrop-blur-sm">
            <span className="leading-none">⚠</span>
            {permissionError}
          </div>
        )}

        {/* ── Create panel ──────────────────────────────────────────────────── */}
        <div
          className="mt-5 rounded-[28px] border border-white/10 p-4"
          style={{ background: "rgba(13,16,26,0.72)", backdropFilter: "blur(8px)" }}
        >
          <p className="mb-3 text-center text-xs font-bold tracking-[0.28em] text-white/55">
            CREATE SOMETHING
          </p>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {cards.map(({ key, label, sub, Icon, color, glow, onClick }) => (
              <button
                key={key}
                onClick={onClick}
                className="group flex flex-col items-center gap-2 rounded-2xl border border-white/10 bg-white/[0.03] p-3 text-center transition active:scale-[0.97]"
                style={{ minHeight: 116 }}
              >
                <span
                  className="flex h-11 w-11 items-center justify-center rounded-xl border transition group-hover:-translate-y-0.5"
                  style={{
                    borderColor: color + "66",
                    background: color + "1a",
                    boxShadow: `0 0 16px ${glow}`,
                  }}
                >
                  <Icon className="h-5 w-5" style={{ color }} />
                </span>
                <span className="text-sm font-semibold leading-tight text-white">{label}</span>
                <span className="text-[10px] leading-tight text-white/45">{sub}</span>
              </button>
            ))}
          </div>

          {/* ── Bottom controls ─────────────────────────────────────────────── */}
          <div className="mt-5 flex items-center justify-between px-2">
            <BottomAction label="Settings" onClick={onSettings}>
              <SlidersHorizontal className="h-5 w-5" />
            </BottomAction>

            {/* Record ring */}
            <button
              onClick={onRecord}
              aria-label="Start recording"
              className="relative flex h-[78px] w-[78px] items-center justify-center rounded-full transition active:scale-95"
              style={{
                background: "conic-gradient(from 220deg,#3da5ff,#7d63ff,#f97316,#3da5ff)",
                padding: 4,
                boxShadow: "0 0 26px rgba(61,165,255,0.4), 0 0 26px rgba(249,115,22,0.3)",
              }}
            >
              <span className="flex h-full w-full items-center justify-center rounded-full bg-[#06070d]">
                <span className="h-[54px] w-[54px] rounded-full border border-white/15 bg-white/[0.06]" />
              </span>
            </button>

            <BottomAction label="Gallery" onClick={onGallery}>
              <ImageIcon className="h-5 w-5" />
            </BottomAction>
          </div>
        </div>
      </div>
    </div>
  );
}

function BottomAction({
  label, onClick, children,
}: { label: string; onClick: () => void; children: React.ReactNode }) {
  return (
    <button onClick={onClick} className={cn("flex w-16 flex-col items-center gap-1.5 transition active:scale-95")}>
      <span className="flex h-11 w-11 items-center justify-center rounded-full border border-white/12 bg-white/[0.05] text-white/85">
        {children}
      </span>
      <span className="text-[11px] font-medium text-white/55">{label}</span>
    </button>
  );
}
