import React from "react";
import { Plus, Trash2, ChevronLeft, ChevronRight, Play, Pause, Scissors } from "lucide-react";
import { cn } from "@/lib/utils";
import { type VideoSegment, segDuration, totalTrimmedDuration } from "./videoExport";

const fmt = (s: number) =>
  `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(Math.floor(s % 60)).padStart(2, "0")}`;
const fmtFine = (s: number) => {
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  const t = Math.floor((s * 10) % 10);
  return `${m}:${String(sec).padStart(2, "0")}.${t}`;
};

const MIN_CLIP = 0.5; // seconds — keep a sliver so a clip can't trim to nothing

interface Props {
  segments: VideoSegment[];
  onChange: (next: VideoSegment[]) => void;
  onAddClip: () => void;
  maxSeconds: number;
  // Mute the preview playback so it matches a "soundtrack only" export.
  muteAudio?: boolean;
}

export function VideoEditor({ segments, onChange, onAddClip, maxSeconds, muteAudio }: Props) {
  const [sel, setSel] = React.useState(0);
  const [playing, setPlaying] = React.useState(false);
  const previewRef = React.useRef<HTMLVideoElement>(null);
  const stopAtRef = React.useRef<number | null>(null);

  const selIdx = Math.min(sel, segments.length - 1);
  const selected = segments[selIdx];
  const total = totalTrimmedDuration(segments);
  const over = total > maxSeconds;

  React.useEffect(() => {
    if (sel > segments.length - 1) setSel(Math.max(0, segments.length - 1));
  }, [segments.length, sel]);

  // Park the preview on the in-point whenever the selection or trim changes.
  React.useEffect(() => {
    const v = previewRef.current;
    if (!v || !selected) return;
    stopAtRef.current = null;
    setPlaying(false);
    const seek = () => {
      try {
        v.currentTime = selected.trimStart;
      } catch {
        /* ignore */
      }
    };
    if (v.readyState >= 1) seek();
    else v.onloadedmetadata = seek;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected?.id, selected?.trimStart]);

  if (!selected) return null;

  const patch = (p: Partial<VideoSegment>) =>
    onChange(segments.map((s, i) => (i === selIdx ? { ...s, ...p } : s)));

  const setStart = (v: number) =>
    patch({ trimStart: Math.max(0, Math.min(v, selected.trimEnd - MIN_CLIP)) });
  const setEnd = (v: number) =>
    patch({ trimEnd: Math.min(selected.duration, Math.max(v, selected.trimStart + MIN_CLIP)) });

  const remove = (i: number) => {
    URL.revokeObjectURL(segments[i].url);
    onChange(segments.filter((_, idx) => idx !== i));
  };
  const move = (i: number, dir: -1 | 1) => {
    const j = i + dir;
    if (j < 0 || j >= segments.length) return;
    const next = segments.slice();
    [next[i], next[j]] = [next[j], next[i]];
    onChange(next);
    setSel(j);
  };

  const togglePlay = () => {
    const v = previewRef.current;
    if (!v) return;
    if (playing) {
      v.pause();
      setPlaying(false);
      stopAtRef.current = null;
      return;
    }
    if (v.currentTime < selected.trimStart || v.currentTime >= selected.trimEnd - 0.02) {
      v.currentTime = selected.trimStart;
    }
    stopAtRef.current = selected.trimEnd;
    v.play()
      .then(() => setPlaying(true))
      .catch(() => setPlaying(false));
  };

  const onTimeUpdate = () => {
    const v = previewRef.current;
    if (v && stopAtRef.current != null && v.currentTime >= stopAtRef.current) {
      v.pause();
      setPlaying(false);
      stopAtRef.current = null;
    }
  };

  return (
    <div className="flex h-full w-full flex-col gap-2 p-2">
      {/* Preview */}
      <div className="relative flex-1 min-h-0 overflow-hidden rounded-2xl bg-black">
        <video
          key={selected.id}
          ref={previewRef}
          src={selected.url}
          playsInline
          muted={muteAudio}
          onTimeUpdate={onTimeUpdate}
          onEnded={() => setPlaying(false)}
          className="h-full w-full object-contain"
        />
        <button
          onClick={togglePlay}
          className="absolute inset-0 flex items-center justify-center"
          aria-label={playing ? "Pause" : "Play trimmed clip"}
        >
          {!playing && (
            <span className="flex h-14 w-14 items-center justify-center rounded-full bg-black/50 backdrop-blur-sm border border-white/20">
              <Play className="ml-0.5 h-6 w-6 text-white" />
            </span>
          )}
        </button>
        <div className="absolute left-2 top-2 rounded-full bg-black/55 px-2.5 py-1 text-[11px] font-semibold text-white backdrop-blur-sm">
          Clip {selIdx + 1} of {segments.length}
        </div>
        {playing && (
          <button
            onClick={togglePlay}
            className="absolute right-2 top-2 flex h-8 w-8 items-center justify-center rounded-full bg-black/55 text-white backdrop-blur-sm"
            aria-label="Pause"
          >
            <Pause className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Trim controls for the selected clip */}
      <div className="rounded-2xl bg-black/55 p-3 backdrop-blur-xl border border-white/10">
        <div className="mb-1.5 flex items-center justify-between text-[11px] font-semibold text-white/70">
          <span className="flex items-center gap-1.5">
            <Scissors className="h-3.5 w-3.5" /> Trim clip {selIdx + 1}
          </span>
          <span className="font-mono text-white">{fmtFine(segDuration(selected))}</span>
        </div>

        <div className="space-y-2">
          <div>
            <div className="flex items-center justify-between text-[10px] text-white/50">
              <span>Start</span>
              <span className="font-mono">{fmtFine(selected.trimStart)}</span>
            </div>
            <input
              type="range"
              min={0}
              max={selected.duration}
              step={0.1}
              value={selected.trimStart}
              onChange={(e) => setStart(Number(e.target.value))}
              className="w-full accent-white"
            />
          </div>
          <div>
            <div className="flex items-center justify-between text-[10px] text-white/50">
              <span>End</span>
              <span className="font-mono">{fmtFine(selected.trimEnd)}</span>
            </div>
            <input
              type="range"
              min={0}
              max={selected.duration}
              step={0.1}
              value={selected.trimEnd}
              onChange={(e) => setEnd(Number(e.target.value))}
              className="w-full accent-white"
            />
          </div>
        </div>
      </div>

      {/* Clip strip + total */}
      <div>
        <div className="mb-1 flex items-center justify-between px-1 text-[11px] font-semibold">
          <span className="text-white/60">Clips</span>
          <span className={cn("font-mono", over ? "text-red-400" : "text-white/70")}>
            {fmt(total)} / {fmt(maxSeconds)}
          </span>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {segments.map((s, i) => (
            <div
              key={s.id}
              className={cn(
                "relative shrink-0 rounded-xl border p-2 transition-all",
                i === selIdx ? "border-white bg-white/15" : "border-white/15 bg-white/5",
              )}
            >
              <button onClick={() => setSel(i)} className="block text-left">
                <div className="text-[11px] font-bold text-white">Clip {i + 1}</div>
                <div className="font-mono text-[10px] text-white/60">{fmtFine(segDuration(s))}</div>
              </button>
              <div className="mt-1.5 flex items-center gap-1">
                <button
                  onClick={() => move(i, -1)}
                  disabled={i === 0}
                  className="flex h-6 w-6 items-center justify-center rounded-md bg-white/10 text-white disabled:opacity-30"
                  aria-label="Move clip earlier"
                >
                  <ChevronLeft className="h-3.5 w-3.5" />
                </button>
                <button
                  onClick={() => move(i, 1)}
                  disabled={i === segments.length - 1}
                  className="flex h-6 w-6 items-center justify-center rounded-md bg-white/10 text-white disabled:opacity-30"
                  aria-label="Move clip later"
                >
                  <ChevronRight className="h-3.5 w-3.5" />
                </button>
                <button
                  onClick={() => remove(i)}
                  className="flex h-6 w-6 items-center justify-center rounded-md bg-red-500/20 text-red-300"
                  aria-label="Delete clip"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ))}

          {/* Add another clip (splice) */}
          <button
            onClick={onAddClip}
            className="flex shrink-0 flex-col items-center justify-center gap-1 rounded-xl border border-dashed border-white/25 bg-white/5 px-4 text-white/70 hover:text-white"
          >
            <Plus className="h-5 w-5" />
            <span className="text-[10px] font-semibold">Add clip</span>
          </button>
        </div>
        {over && (
          <p className="mt-1 px-1 text-[11px] font-medium text-red-400">
            Over 3:45 — trim or remove a clip to publish.
          </p>
        )}
      </div>
    </div>
  );
}
