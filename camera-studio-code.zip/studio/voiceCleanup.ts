// voiceCleanup.ts — optional AI voice cleanup for the Camera Studio.
//
// Extracts a recorded clip's audio in the browser (decode → mono → 16-bit PCM
// WAV, no ffmpeg.wasm), sends it to our server which runs ElevenLabs voice
// isolation (background noise + music removed), and decodes the cleaned MP3 back
// into an AudioBuffer. That buffer is substituted for the clip's own audio at
// export time — so cleanup MUST run BEFORE any soundtrack is mixed in, or the
// isolation would strip the music too.

function makeAudioContext(): AudioContext {
  const AC: typeof AudioContext =
    (window as unknown as { AudioContext: typeof AudioContext }).AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext })
      .webkitAudioContext;
  return new AC();
}

// decodeAudioData via the callback form for the widest Safari support.
function decode(ctx: AudioContext, data: ArrayBuffer): Promise<AudioBuffer> {
  return new Promise((resolve, reject) => {
    ctx.decodeAudioData(data, resolve, reject);
  });
}

// Downmix every channel to a single mono Float32 track (simple average).
function downmixMono(buffer: AudioBuffer): Float32Array {
  const chs = buffer.numberOfChannels;
  const len = buffer.length;
  if (chs === 1) return buffer.getChannelData(0).slice();
  const out = new Float32Array(len);
  for (let c = 0; c < chs; c++) {
    const data = buffer.getChannelData(c);
    for (let i = 0; i < len; i++) out[i] += data[i];
  }
  for (let i = 0; i < len; i++) out[i] /= chs;
  return out;
}

// Encode a mono Float32 PCM signal as a 16-bit little-endian WAV.
function encodeWavMono(samples: Float32Array, sampleRate: number): ArrayBuffer {
  const bytesPerSample = 2;
  const dataSize = samples.length * bytesPerSample;
  const buffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buffer);
  const writeStr = (offset: number, s: string) => {
    for (let i = 0; i < s.length; i++) view.setUint8(offset + i, s.charCodeAt(i));
  };
  writeStr(0, "RIFF");
  view.setUint32(4, 36 + dataSize, true);
  writeStr(8, "WAVE");
  writeStr(12, "fmt ");
  view.setUint32(16, 16, true); // PCM chunk size
  view.setUint16(20, 1, true); // PCM format
  view.setUint16(22, 1, true); // channels = mono
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * bytesPerSample, true); // byte rate
  view.setUint16(32, bytesPerSample, true); // block align
  view.setUint16(34, 16, true); // bits per sample
  writeStr(36, "data");
  view.setUint32(40, dataSize, true);
  let offset = 44;
  for (let i = 0; i < samples.length; i++) {
    const clamped = Math.max(-1, Math.min(1, samples[i]));
    view.setInt16(offset, clamped < 0 ? clamped * 0x8000 : clamped * 0x7fff, true);
    offset += bytesPerSample;
  }
  return buffer;
}

export class VoiceCleanupError extends Error {
  status?: number;
  constructor(message: string, status?: number) {
    super(message);
    this.name = "VoiceCleanupError";
    this.status = status;
  }
}

/**
 * Extract → isolate → decode. Returns the cleaned voice as an AudioBuffer ready
 * to substitute at export time. Throws VoiceCleanupError (with the server's
 * user-facing message and status when available) on any failure.
 */
export async function cleanClipVoice(blob: Blob): Promise<AudioBuffer> {
  const ctx = makeAudioContext();
  try {
    const raw = await blob.arrayBuffer();
    let decoded: AudioBuffer;
    try {
      // slice(0) so decodeAudioData can't detach the caller's buffer.
      decoded = await decode(ctx, raw.slice(0));
    } catch {
      throw new VoiceCleanupError("We couldn't read this clip's audio.");
    }
    if (!decoded || decoded.length === 0 || decoded.duration <= 0) {
      throw new VoiceCleanupError("This clip has no audio to clean up.");
    }

    const mono = downmixMono(decoded);
    const wav = encodeWavMono(mono, Math.round(decoded.sampleRate));

    let res: Response;
    try {
      res = await fetch("/api/studio/voice-cleanup", {
        method: "POST",
        headers: { "Content-Type": "audio/wav" },
        body: wav,
      });
    } catch {
      throw new VoiceCleanupError("Network error during voice cleanup.");
    }
    if (!res.ok) {
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      throw new VoiceCleanupError(
        data.error || "We couldn't clean up that audio.",
        res.status,
      );
    }

    const cleaned = await res.arrayBuffer();
    if (cleaned.byteLength === 0) {
      throw new VoiceCleanupError("Voice cleanup returned no audio.");
    }
    try {
      return await decode(ctx, cleaned);
    } catch {
      throw new VoiceCleanupError("We couldn't read the cleaned audio.");
    }
  } finally {
    try {
      await ctx.close();
    } catch {
      /* ignore */
    }
  }
}
