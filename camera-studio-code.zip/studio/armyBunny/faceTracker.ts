// ── Army Bunny — mouth-open face tracker (FaceLandmarker, blendshapes only) ──────
// A SECOND MediaPipe model that runs ALONGSIDE the PoseLandmarker (poseTracker.ts) on
// the same <video>. Running two Tasks-Vision models at once is already proven on the
// user's iPhone (NeonMood runs FaceLandmarker + ImageSegmenter together), so this is a
// safe pattern. We only need one number — the `jawOpen` blendshape — to drive the
// synthetic jaw morph, so numFaces:1 and we read a single category.
//
// Same lifecycle contract as the pose tracker: throttled async detection on its own
// strictly-increasing timestamp clock, EMA smoothing, hold-then-fade on tracking loss,
// and a clean no-op (getJawOpen()===0) if GL/model load fails so the filter degrades
// gracefully rather than crashing.
import { FaceLandmarker, FilesetResolver, type FaceLandmarkerResult } from "@mediapipe/tasks-vision";

const DETECT_MS = 66;  // ~15fps — offset-phased from the pose timer to spread CPU spikes
const EMA = 0.4;       // smoothing toward each new detection (stable but responsive)
const HOLD_MS = 140;   // keep the last value briefly after a dropped frame
const FADE_MS = 280;   // then relax jawOpen back to 0 over this long

export class ArmyBunnyFaceTracker {
  private video: HTMLVideoElement;
  private landmarker: FaceLandmarker | null = null;
  private starting = false;
  private disposed = false;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private lastTs = 0;

  private jaw = 0;        // smoothed jawOpen 0..1
  private has = false;
  private lastSeen = 0;

  constructor(video: HTMLVideoElement) { this.video = video; }

  async start() {
    if (this.disposed || this.starting || this.landmarker) return;
    this.starting = true;
    try {
      const base = import.meta.env.BASE_URL || "/";
      const fileset = await FilesetResolver.forVisionTasks(`${base}mediapipe/wasm`);
      if (this.disposed) return;
      const make = (delegate: "GPU" | "CPU") => FaceLandmarker.createFromOptions(fileset, {
        baseOptions: { modelAssetPath: `${base}mediapipe/face_landmarker.task`, delegate },
        runningMode: "VIDEO",
        numFaces: 1,
        outputFaceBlendshapes: true,
      });
      try { this.landmarker = await make("GPU"); }
      catch { this.landmarker = await make("CPU"); }
      if (this.disposed) { this.landmarker?.close(); this.landmarker = null; return; }
      // Phase-offset the first tick so face + pose detection rarely land on the same frame.
      this.timer = setTimeout(this.loop, DETECT_MS / 2);
    } catch (err) {
      console.error("[armyBunny] face tracker init failed", err);
    } finally {
      this.starting = false;
    }
  }

  private loop = () => {
    if (this.disposed) return;
    this.detectOnce();
    this.timer = setTimeout(this.loop, DETECT_MS);
  };

  private detectOnce() {
    const v = this.video, lm = this.landmarker;
    if (!lm || !v || v.readyState < 2 || v.videoWidth === 0) return;
    let ts = performance.now();
    if (ts <= this.lastTs) ts = this.lastTs + 1; // strictly increasing (required)
    this.lastTs = ts;
    let res: FaceLandmarkerResult;
    try { res = lm.detectForVideo(v, ts); } catch { return; }

    const cats = res.faceBlendshapes?.[0]?.categories;
    if (!cats || !cats.length) return;
    let open = 0;
    for (const c of cats) if (c.categoryName === "jawOpen") { open = c.score; break; }

    if (!this.has) { this.jaw = open; this.has = true; }
    else this.jaw += (open - this.jaw) * EMA;
    this.lastSeen = performance.now();
  }

  /** Latest smoothed jawOpen (0..1). Fades to 0 on tracking loss; 0 when no face. */
  getJawOpen(): number {
    if (!this.has) return 0;
    const dt = performance.now() - this.lastSeen;
    let fade = 1;
    if (dt > HOLD_MS) fade = Math.max(0, 1 - (dt - HOLD_MS) / FADE_MS);
    return this.jaw * fade;
  }

  dispose() {
    this.disposed = true;
    if (this.timer) { clearTimeout(this.timer); this.timer = null; }
    this.landmarker?.close();
    this.landmarker = null;
  }
}
