// Standalone, unlisted dev preview for the in-development Army Bunny filter.
// No AppLayout / auth. Renders the rigged mascot driven by the LIVE webcam so the
// body tracking + hands-to-head head-off reveal can be verified on a real device
// (this environment has no WebGL2 / no camera, so on-device is the only way to see it).
//
// PLACEMENT (2D similarity blit): the model is rendered at a FIXED transform framed on
// the upper body; the compositor then anchors the rendered sprite onto the user by
// mapping the bunny's NECK joint onto the user's neck and scaling to the user's
// shoulder span. Anchoring the head over the real head makes the head-off reveal line
// up by construction. Left/right + up/down of the ARMS is the AxisMap's job, exposed
// as live controls + URL params (?sx=-1&sy=-1&sz=-1&swapLR=1&mirror=1&roll=1
// &headOffsetY=0&scalePad=1.15&combo=0). Calibration overlay draws the bunny's OWN
// wrist positions as cyan(L)/magenta(R) RINGS over the user's cyan/magenta wrist DOTS —
// the correct axis combo is the one where the ring sits on the dot in every pose.
import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { ArmyBunnyEngine } from "./engine";
import { ArmyBunnyPoseTracker } from "./poseTracker";
import { buildRigDef, applyPose, poseBufferLength } from "./rigDef";
import {
  DEFAULT_AXIS_MAP, mapLandmarks, solvePose, type AxisMap, type RigDef,
} from "./retargetCore";
import { initialReveal, revealStep, type RevealState } from "./reveal";
import { ArmyBunnyFaceTracker } from "./faceTracker";
import type { JawParams } from "./jawMorph";
import ModelViewer from "../modelGen/ModelViewer";

const btn: React.CSSProperties = {
  background: "#2f4a2f", color: "#eafcea", border: "1px solid #4c7a4c",
  borderRadius: 8, padding: "6px 10px", fontSize: 12, cursor: "pointer",
};

// The 4 most-plausible arm-axis combos to cycle through in one calibration recording:
// left/right (swapLR) × horizontal arm direction (sx). Up/down (sy) and depth (sz)
// stay tunable via the individual buttons.
const COMBOS: AxisMap[] = [
  { sx: 1, sy: -1, sz: -1, swapLR: false },
  { sx: 1, sy: -1, sz: -1, swapLR: true },
  { sx: -1, sy: -1, sz: -1, swapLR: false },
  { sx: -1, sy: -1, sz: -1, swapLR: true },
];

interface Cfg {
  map: AxisMap;
  mirror: boolean;
  overlay: boolean;
  roll: boolean;
  headOffsetY: number;
  scalePad: number;
  comboIdx: number;
  // ── mouth tracking ──
  mouthTest: boolean; // drive the jaw with a sine oscillator (verify morph shape, no face)
  gain: number;       // influence = gain·(jawOpen − deadzone), clamped 0..1
  deadzone: number;   // ignore tiny jawOpen so a closed mouth stays fully shut
  jawDy: number;      // world-Y offset added to the default mouth-line (hinge height)
  jawDrop: number;    // multiplier on the default max jaw drop
}

function readParams(): Cfg {
  const q = new URLSearchParams(window.location.search);
  const sign = (k: string, d: number) => (q.get(k) === null ? d : Number(q.get(k)) < 0 ? -1 : 1);
  const bool = (k: string, d: boolean) => (q.get(k) === null ? d : q.get(k) === "1" || q.get(k) === "true");
  const num = (k: string, d: number) => { const v = q.get(k); return v === null || v === "" ? d : Number(v); };
  return {
    map: {
      sx: sign("sx", DEFAULT_AXIS_MAP.sx),
      sy: sign("sy", DEFAULT_AXIS_MAP.sy),
      sz: sign("sz", DEFAULT_AXIS_MAP.sz),
      swapLR: bool("swapLR", DEFAULT_AXIS_MAP.swapLR),
    },
    mirror: bool("mirror", true),
    overlay: bool("overlay", true),
    roll: bool("roll", false),
    headOffsetY: num("headOffsetY", 0),
    scalePad: num("scalePad", 1.15),
    comboIdx: Math.max(0, Math.min(COMBOS.length - 1, Math.round(num("combo", 0)))),
    mouthTest: bool("mouthTest", false),
    gain: num("gain", 1.6),
    deadzone: num("deadzone", 0.05),
    jawDy: num("jawDy", 0),
    jawDrop: num("jawDrop", 1),
  };
}

// left-side landmark indices get cyan, right-side get magenta (mirrored screen space).
const LEFT_IDX = [7, 11, 13, 15];
const RIGHT_IDX = [8, 12, 14, 16];
const BONES2D: [number, number][] = [[11, 13], [13, 15], [12, 14], [14, 16], [11, 12], [11, 23], [12, 24]];
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

// The fancy NON-talking showpiece: a static, textured GLB authored offline via
// Meshy image-to-3d (api-server scripts/showpieceStep.ts) from the samurai concept art.
// Unlike the live rig above there is no webcam / tracking / jaw morph — just an
// orbitable showcase. Reached via /army-bunny-preview?model=showpiece.
function ShowpieceBunny() {
  const url = `${import.meta.env.BASE_URL}models/showpiece-bunny.glb`;
  return (
    <div style={{
      position: "fixed", inset: 0, background: "#0a0a12", display: "flex",
      flexDirection: "column", alignItems: "center", justifyContent: "center",
      gap: 12, fontFamily: "system-ui, sans-serif", color: "#eee", padding: 12,
    }}>
      <div style={{ fontSize: 12, letterSpacing: 2, opacity: 0.7, textTransform: "uppercase" }}>
        Showpiece Bunny — orbit to view
      </div>
      <div style={{
        width: "min(92vw, 520px)", aspectRatio: "1 / 1", background: "#000",
        borderRadius: 18, overflow: "hidden", boxShadow: "0 0 60px rgba(230,180,60,0.22)",
      }}>
        <ModelViewer url={url} className="h-full w-full" />
      </div>
      <div style={{ fontSize: 11, opacity: 0.6, textAlign: "center", maxWidth: 380 }}>
        Drag to rotate · scroll or pinch to zoom
      </div>
    </div>
  );
}

// Route dispatcher: ?model=showpiece renders the static showpiece; otherwise the
// live webcam rig preview. Decided once at mount (URL never changes here) so each
// branch's hooks run unconditionally.
export default function ArmyBunnyPreview() {
  const showpiece =
    typeof window !== "undefined" &&
    new URLSearchParams(window.location.search).get("model") === "showpiece";
  return showpiece ? <ShowpieceBunny /> : <ArmyBunnyLivePreview />;
}

function ArmyBunnyLivePreview() {
  const wrapRef = useRef<HTMLDivElement>(null);
  const cfgRef = useRef(readParams());
  const [cfg, setCfg] = useState(cfgRef.current);
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");
  const [msg, setMsg] = useState("");
  const [phase, setPhase] = useState<RevealState["phase"]>("off");

  useEffect(() => { cfgRef.current = cfg; }, [cfg]);

  useEffect(() => {
    let raf = 0;
    let disposed = false;
    let stream: MediaStream | null = null;
    const engine = new ArmyBunnyEngine(720, 960);
    const video = document.createElement("video");
    video.playsInline = true; video.muted = true;
    const tracker = new ArmyBunnyPoseTracker(video);
    const faceTracker = new ArmyBunnyFaceTracker(video);

    const display = document.createElement("canvas");
    display.width = 720; display.height = 960;
    display.style.width = "100%"; display.style.height = "100%"; display.style.display = "block";
    const ctx = display.getContext("2d")!;
    wrapRef.current?.appendChild(display);

    if (!engine.ok) {
      setStatus("error");
      setMsg("WebGL2 unavailable in this browser.");
      return;
    }

    let rig: RigDef | null = null;
    let outLocal = new Float32Array(0);
    const charBuf = new Float32Array(99);
    let reveal = initialReveal();
    let lastT = performance.now();

    // bind-pose anchors (constant once loaded) in engine-canvas px.
    let bindNeck = { x: 360, y: 300 };
    let bindShoulderSpan = 1;
    let bindReady = false;
    const tmpA = new THREE.Vector3(), tmpB = new THREE.Vector3(), tmpC = new THREE.Vector3();

    // smoothed placement (EMA) — anchor(ax,ay), uniform scale s, roll r.
    const ema = { init: false, ax: 360, ay: 300, s: 1, r: 0 };

    // mouth: default jaw params captured at load; live knobs rebuild the morph only
    // when they actually change. lastJawOpen/lastMouth are for the on-canvas HUD.
    let baseJaw: JawParams | null = null;
    const jawApplied = { dy: NaN, drop: NaN };
    let lastJawOpen = 0; // raw signal (sine in test mode, else FaceLandmarker jawOpen)
    let lastMouth = 0;   // applied morph influence 0..1

    const drawCover = (src: CanvasImageSource, sw: number, sh: number) => {
      const cw = display.width, ch = display.height;
      const scale = Math.max(cw / sw, ch / sh);
      const dw = sw * scale, dh = sh * scale;
      const dx = (cw - dw) / 2, dy = (ch - dh) / 2;
      ctx.save();
      if (cfgRef.current.mirror) { ctx.translate(cw, 0); ctx.scale(-1, 1); }
      ctx.drawImage(src, dx, dy, dw, dh);
      ctx.restore();
      return { scale, dx, dy, sw };
    };

    const start = async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "user", width: 720, height: 960 }, audio: false,
        });
        if (disposed) return;
        video.srcObject = stream;
        await video.play();
        await tracker.start();
        await faceTracker.start();

        const url = `${import.meta.env.BASE_URL}models/army-bunny.glb`;
        const ok = await engine.load(url);
        if (disposed) return;
        if (!ok || !engine.bunny) { setStatus("error"); setMsg("model failed to load"); return; }
        const model = engine.bunny;
        rig = buildRigDef(model);
        outLocal = new Float32Array(poseBufferLength(rig));
        baseJaw = model.getJawParams(); // reference for live jaw-shape tuning

        // capture bind-pose anchors ONCE (neck + shoulder origins are pose-invariant).
        engine.render();
        model.root.updateMatrixWorld(true);
        const nb = model.bones["neck"], la = model.bones["LeftArm"], ra = model.bones["RightArm"];
        if (nb && la && ra) {
          bindNeck = engine.project(nb.getWorldPosition(tmpA));
          const sl = engine.project(la.getWorldPosition(tmpB));
          const sr = engine.project(ra.getWorldPosition(tmpC));
          bindShoulderSpan = Math.hypot(sl.x - sr.x, sl.y - sr.y) || 1;
          bindReady = true;
        }
        setStatus("ready");
        loop();
      } catch (e: unknown) {
        if (disposed) return;
        setStatus("error");
        setMsg(e instanceof Error ? e.message : String(e));
      }
    };

    const loop = () => {
      raf = requestAnimationFrame(loop);
      const now = performance.now();
      const dt = Math.min(64, now - lastT); lastT = now;
      const t = tracker.getTracking();
      const model = engine.bunny;

      if (t && rig && model) {
        mapLandmarks(t.world, cfgRef.current.map, charBuf);
        solvePose(charBuf, rig, outLocal);
        applyPose(model, rig, outLocal);
        reveal = revealStep(reveal, t.norm, dt);
        engine.setHeadReveal(reveal.hidden);
        if (reveal.phase !== phase) setPhase(reveal.phase);
      }

      // ── mouth: drive the synthetic jaw morph every frame (independent of pose) ──
      if (model && baseJaw) {
        const c = cfgRef.current;
        // rebuild the morph shape only when a knob actually changed (rebuild is cheap
        // but not free — it touches every head vertex).
        if (c.jawDy !== jawApplied.dy || c.jawDrop !== jawApplied.drop) {
          model.setJawParams({
            mouthLineY: baseJaw.mouthLineY + c.jawDy,
            maxDrop: baseJaw.maxDrop * c.jawDrop,
          });
          jawApplied.dy = c.jawDy;
          jawApplied.drop = c.jawDrop;
        }
        // raw signal → clamped influence. Test mode swings a full 0..1 sine so the
        // morph shape is verifiable without a face; live mode maps FaceLandmarker
        // jawOpen through deadzone + gain.
        const raw = c.mouthTest ? 0.5 - 0.5 * Math.cos(now / 450) : faceTracker.getJawOpen();
        lastJawOpen = raw;
        const mouth = c.mouthTest ? raw : Math.min(1, Math.max(0, (raw - c.deadzone) * c.gain));
        lastMouth = mouth;
        model.setMouthOpen(mouth);
      }

      engine.render();

      // composite: mirrored video first, then the anchored bunny sprite over it.
      ctx.clearRect(0, 0, display.width, display.height);
      const geo = video.videoWidth > 0 ? drawCover(video, video.videoWidth, video.videoHeight) : null;
      if (t && model && geo && bindReady) placeBunny(t.norm, geo, model);
      if (cfgRef.current.overlay && t && geo) drawSkeleton(t.norm, geo);
      burnConfig();
    };

    // Map a normalized landmark to DISPLAY px through the same video cover + mirror.
    const mapper = (geo: { scale: number; dx: number; dy: number; sw: number }) => {
      const cw = display.width;
      const mir = cfgRef.current.mirror;
      const vh = video.videoHeight || geo.sw;
      const px = (nx: number) => { const x = geo.dx + nx * geo.sw * geo.scale; return mir ? cw - x : x; };
      const py = (ny: number) => geo.dy + ny * vh * geo.scale;
      return { px, py };
    };

    const placeBunny = (
      norm: Float32Array,
      geo: { scale: number; dx: number; dy: number; sw: number },
      model: NonNullable<ReturnType<() => typeof engine.bunny>>,
    ) => {
      const { px, py } = mapper(geo);
      const P = (i: number) => ({ x: px(norm[i * 3]), y: py(norm[i * 3 + 1]) });
      const s11 = P(11), s12 = P(12), e7 = P(7), e8 = P(8);
      const shMid = { x: (s11.x + s12.x) / 2, y: (s11.y + s12.y) / 2 };
      const earMid = { x: (e7.x + e8.x) / 2, y: (e7.y + e8.y) / 2 };
      const neck = { x: shMid.x + (earMid.x - shMid.x) * 0.25, y: shMid.y + (earMid.y - shMid.y) * 0.25 };
      const userSpan = Math.hypot(s11.x - s12.x, s11.y - s12.y);
      if (!isFinite(userSpan) || userSpan < 4 || !isFinite(neck.x) || !isFinite(neck.y)) return;

      const c = cfgRef.current;
      const targetS = (c.scalePad * userSpan) / bindShoulderSpan;
      let rollDelta = 0;
      if (c.roll) rollDelta = Math.atan2(s12.y - s11.y, s12.x - s11.x); // bunny bind line ≈ horizontal

      const k = 0.3;
      ema.ax = ema.init ? lerp(ema.ax, neck.x, k) : neck.x;
      ema.ay = ema.init ? lerp(ema.ay, neck.y, k) : neck.y;
      ema.s = ema.init ? lerp(ema.s, targetS, k) : targetS;
      ema.r = ema.init ? lerp(ema.r, rollDelta, k) : rollDelta;
      ema.init = true;

      const ax = ema.ax, ay = ema.ay + c.headOffsetY, s = ema.s, r = c.roll ? ema.r : 0;

      ctx.save();
      ctx.translate(ax, ay);
      if (r) ctx.rotate(r);
      ctx.scale(s, s);
      ctx.translate(-bindNeck.x, -bindNeck.y);
      ctx.drawImage(engine.canvas, 0, 0);
      ctx.restore();

      if (!c.overlay) return;
      // Same transform applied to points, so bunny wrist rings land where the sprite's
      // wrists actually render: map(engine px) → display px.
      const cosr = Math.cos(r), sinr = Math.sin(r);
      const mapPt = (ex: number, ey: number) => {
        let x = (ex - bindNeck.x) * s, y = (ey - bindNeck.y) * s;
        if (r) { const nx = x * cosr - y * sinr, ny = x * sinr + y * cosr; x = nx; y = ny; }
        return { x: x + ax, y: y + ay };
      };
      const lh = model.bones["LeftHand"], rh = model.bones["RightHand"];
      if (lh && rh) {
        const wl = engine.project(lh.getWorldPosition(tmpA));
        const wr = engine.project(rh.getWorldPosition(tmpB));
        ring(mapPt(wl.x, wl.y), "#28e0ff"); // bunny LEFT wrist ring (cyan)
        ring(mapPt(wr.x, wr.y), "#ff4fd8"); // bunny RIGHT wrist ring (magenta)
      }
    };

    const ring = (p: { x: number; y: number }, color: string) => {
      ctx.lineWidth = 5; ctx.strokeStyle = color;
      ctx.beginPath(); ctx.arc(p.x, p.y, 16, 0, Math.PI * 2); ctx.stroke();
    };

    const drawSkeleton = (
      norm: Float32Array,
      geo: { scale: number; dx: number; dy: number; sw: number },
    ) => {
      const { px, py } = mapper(geo);
      ctx.lineWidth = 4; ctx.strokeStyle = "rgba(255,255,255,0.45)";
      for (const [a, b] of BONES2D) {
        ctx.beginPath(); ctx.moveTo(px(norm[a * 3]), py(norm[a * 3 + 1]));
        ctx.lineTo(px(norm[b * 3]), py(norm[b * 3 + 1])); ctx.stroke();
      }
      const dot = (idx: number[], color: string) => {
        ctx.fillStyle = color;
        for (const i of idx) {
          ctx.beginPath(); ctx.arc(px(norm[i * 3]), py(norm[i * 3 + 1]), 9, 0, Math.PI * 2); ctx.fill();
        }
      };
      dot(LEFT_IDX, "#28e0ff");   // MediaPipe LEFT (cyan)
      dot(RIGHT_IDX, "#ff4fd8");  // MediaPipe RIGHT (magenta)
    };

    const burnConfig = () => {
      const c = cfgRef.current;
      const sgn = (n: number) => (n > 0 ? "+" : "−");
      const line = `#${c.comboIdx}  x${sgn(c.map.sx)} y${sgn(c.map.sy)} z${sgn(c.map.sz)}  LR:${c.map.swapLR ? "on" : "off"}  mir:${c.mirror ? "on" : "off"}  roll:${c.roll ? "on" : "off"}`;
      // live mouth readout: raw signal → applied influence, plus the current knobs.
      const dyTxt = `${c.jawDy >= 0 ? "+" : "−"}${Math.abs(c.jawDy).toFixed(3)}`;
      const line2 = `mouth ${lastMouth.toFixed(2)} (raw ${lastJawOpen.toFixed(2)})  g${c.gain} dz${c.deadzone} dy${dyTxt} drop${c.jawDrop}${c.mouthTest ? "  [TEST]" : ""}`;
      ctx.font = "600 22px system-ui, sans-serif";
      ctx.textBaseline = "top";
      ctx.fillStyle = "rgba(0,0,0,0.55)";
      ctx.fillRect(8, 8, ctx.measureText(line).width + 20, 32);
      ctx.fillStyle = "#ffec5a";
      ctx.fillText(line, 18, 12);
      // second row — highlight when the mouth is meaningfully open
      ctx.font = "600 20px system-ui, sans-serif";
      ctx.fillStyle = "rgba(0,0,0,0.55)";
      ctx.fillRect(8, 46, ctx.measureText(line2).width + 20, 30);
      ctx.fillStyle = lastMouth > 0.15 ? "#7dffb0" : "#cfe8cf";
      ctx.fillText(line2, 18, 50);
    };

    start();

    return () => {
      disposed = true;
      cancelAnimationFrame(raf);
      tracker.dispose();
      faceTracker.dispose();
      engine.dispose();
      stream?.getTracks().forEach((tr) => tr.stop());
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const flip = (k: keyof AxisMap) =>
    setCfg((c) => ({ ...c, map: { ...c.map, [k]: k === "swapLR" ? !c.map.swapLR : -(c.map[k] as number) } }));
  const nextCombo = () =>
    setCfg((c) => { const i = (c.comboIdx + 1) % COMBOS.length; return { ...c, comboIdx: i, map: { ...COMBOS[i] } }; });
  const nudge = (k: "headOffsetY" | "scalePad", d: number) =>
    setCfg((c) => ({ ...c, [k]: Math.round((c[k] + d) * 100) / 100 }));
  const nudgeMouth = (k: "gain" | "deadzone" | "jawDy" | "jawDrop", d: number, min = -Infinity, max = Infinity) =>
    setCfg((c) => ({ ...c, [k]: Math.min(max, Math.max(min, Math.round((c[k] + d) * 1000) / 1000)) }));

  return (
    <div style={{
      position: "fixed", inset: 0, background: "#0a0a0a", display: "flex",
      flexDirection: "column", alignItems: "center", justifyContent: "center",
      gap: 10, fontFamily: "system-ui, sans-serif", color: "#eee", padding: 12,
    }}>
      <div style={{ fontSize: 12, letterSpacing: 2, opacity: 0.7, textTransform: "uppercase" }}>
        Army Bunny — live dev preview
      </div>
      <div ref={wrapRef} style={{
        width: "min(90vw, 460px)", aspectRatio: "3 / 4", background: "#000",
        borderRadius: 14, overflow: "hidden", boxShadow: "0 0 44px rgba(90,170,90,0.18)",
      }} />
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "center", maxWidth: 460 }}>
        <button style={{ ...btn, background: "#3a5f3a", fontWeight: 700 }} onClick={nextCombo}>
          ▶ next combo (#{cfg.comboIdx})
        </button>
        <button style={btn} onClick={() => flip("sx")}>x {cfg.map.sx > 0 ? "+" : "−"}</button>
        <button style={btn} onClick={() => flip("sy")}>y {cfg.map.sy > 0 ? "+" : "−"}</button>
        <button style={btn} onClick={() => flip("sz")}>z {cfg.map.sz > 0 ? "+" : "−"}</button>
        <button style={btn} onClick={() => flip("swapLR")}>swapLR {cfg.map.swapLR ? "on" : "off"}</button>
        <button style={btn} onClick={() => setCfg((c) => ({ ...c, mirror: !c.mirror }))}>
          mirror {cfg.mirror ? "on" : "off"}
        </button>
        <button style={btn} onClick={() => setCfg((c) => ({ ...c, roll: !c.roll }))}>
          roll {cfg.roll ? "on" : "off"}
        </button>
        <button style={btn} onClick={() => setCfg((c) => ({ ...c, overlay: !c.overlay }))}>
          overlay {cfg.overlay ? "on" : "off"}
        </button>
      </div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "center", maxWidth: 460 }}>
        <button style={btn} onClick={() => nudge("headOffsetY", -12)}>head ↑</button>
        <button style={btn} onClick={() => nudge("headOffsetY", 12)}>head ↓</button>
        <button style={btn} onClick={() => nudge("scalePad", -0.05)}>smaller</button>
        <button style={btn} onClick={() => nudge("scalePad", 0.05)}>bigger</button>
      </div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "center", maxWidth: 460 }}>
        <button
          style={{ ...btn, background: cfg.mouthTest ? "#6a4a1f" : "#2f4a2f" }}
          onClick={() => setCfg((c) => ({ ...c, mouthTest: !c.mouthTest }))}
        >
          mouth test {cfg.mouthTest ? "on" : "off"}
        </button>
        <button style={btn} onClick={() => nudgeMouth("gain", -0.1, 0.1, 5)}>gain −</button>
        <button style={btn} onClick={() => nudgeMouth("gain", 0.1, 0.1, 5)}>gain +</button>
        <button style={btn} onClick={() => nudgeMouth("deadzone", -0.01, 0, 0.5)}>dz −</button>
        <button style={btn} onClick={() => nudgeMouth("deadzone", 0.01, 0, 0.5)}>dz +</button>
        <button style={btn} onClick={() => nudgeMouth("jawDy", 0.01)}>line ↑</button>
        <button style={btn} onClick={() => nudgeMouth("jawDy", -0.01)}>line ↓</button>
        <button style={btn} onClick={() => nudgeMouth("jawDrop", -0.1, 0.1, 3)}>drop −</button>
        <button style={btn} onClick={() => nudgeMouth("jawDrop", 0.1, 0.1, 3)}>drop +</button>
      </div>
      <div style={{ fontSize: 11, opacity: 0.6, textAlign: "center", maxWidth: 380 }}>
        status: {status}{msg ? ` — ${msg}` : ""} · reveal: {phase} · pad {cfg.scalePad} · headY {cfg.headOffsetY}
        <br />
        Cyan RING = bunny's left wrist, cyan DOT = your left. Line them up. Raise BOTH hands to
        your head to lift the mask. Open your mouth — the bunny's jaw follows (turn on
        "mouth test" to verify the jaw shape with no face).
      </div>
    </div>
  );
}
