// ── Army Bunny — procedural camo "skin" (TEMPORARY) ─────────────────────────────
// The delivered GLB ships with NO texture, so until the user's textured re-export
// arrives we paint the suit with a generated 4-colour army camo. This is a stand-in
// for the real "skin" and is swapped out in the finalize phase. Deterministic
// (seeded) so the pattern is stable across reloads.
import * as THREE from "three";

const ARMY = {
  base: "#4b5320", // army green
  dark: "#33401a", // dark olive
  tan: "#8a7f5c", // khaki / sand
  black: "#26241c", // brown-black
};

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Build a seamless-ish army camo CanvasTexture for the suit. */
export function createCamoTexture(size = 512, seed = 0xa11ce): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = size;
  const ctx = canvas.getContext("2d")!;
  const rng = mulberry32(seed);

  ctx.fillStyle = ARMY.base;
  ctx.fillRect(0, 0, size, size);

  const blob = (color: string, count: number, min: number, max: number) => {
    ctx.fillStyle = color;
    for (let i = 0; i < count; i++) {
      const cx = rng() * size;
      const cy = rng() * size;
      const r = min + rng() * (max - min);
      ctx.beginPath();
      // irregular rounded blob from a few arcs
      const steps = 7 + ((rng() * 4) | 0);
      for (let s = 0; s <= steps; s++) {
        const ang = (s / steps) * Math.PI * 2;
        const rr = r * (0.65 + rng() * 0.5);
        const x = cx + Math.cos(ang) * rr;
        const y = cy + Math.sin(ang) * rr;
        if (s === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.fill();
      // wrap-around copies so the texture tiles without hard seams
      for (const [dx, dy] of [[size, 0], [-size, 0], [0, size], [0, -size]] as const) {
        ctx.save(); ctx.translate(dx, dy); ctx.fill(); ctx.restore();
      }
    }
  };

  blob(ARMY.dark, 26, size * 0.06, size * 0.16);
  blob(ARMY.tan, 20, size * 0.05, size * 0.13);
  blob(ARMY.black, 16, size * 0.03, size * 0.09);

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}
