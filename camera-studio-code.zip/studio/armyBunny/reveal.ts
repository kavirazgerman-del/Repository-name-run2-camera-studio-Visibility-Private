// ── Army Bunny — PURE hands-to-head reveal gesture (no three, no DOM) ────────────
// Detects the "lift my head off" gesture (both wrists brought up to the head) and
// runs a small hysteretic state machine so the mascot head lifts smoothly and does
// not flicker on the threshold. Pure + deterministic → unit-tested (reveal.test.ts).
//
// The reveal itself is robust-by-construction: the CameraStudio compositor draws the
// mirrored camera frame FIRST and overlays the bunny after, so simply hiding the
// mascot head exposes the user's real head from the video underneath. No
// segmentation is required for the effect to work (that is optional polish).

// MediaPipe pose landmark indices used here.
const L_EAR = 7, R_EAR = 8, L_SHOULDER = 11, R_SHOULDER = 12, L_WRIST = 15, R_WRIST = 16;

function dist2D(norm: Float32Array, a: number, b: number): number {
  return Math.hypot(norm[a * 3] - norm[b * 3], norm[a * 3 + 1] - norm[b * 3 + 1]);
}

/** Shoulder width in normalized units — the scale-invariant yardstick for thresholds. */
export function shoulderWidth(norm: Float32Array): number {
  return dist2D(norm, L_SHOULDER, R_SHOULDER);
}

/**
 * True when BOTH wrists are within `k · shoulderWidth` of their same-side ear.
 * Using shoulder width makes the trigger invariant to how close the user is.
 */
export function bothWristsNearHead(norm: Float32Array, k: number): boolean {
  const w = shoulderWidth(norm);
  if (w < 1e-4) return false; // no reliable pose
  const dL = dist2D(norm, L_WRIST, L_EAR);
  const dR = dist2D(norm, R_WRIST, R_EAR);
  return dL < k * w && dR < k * w;
}

export type RevealPhase = "off" | "lifting" | "revealed" | "lowering";

export interface RevealCfg {
  enterK: number; // wrists must come this close (× shoulder width) to engage
  exitK: number;  // …and move out past this (larger) to disengage — hysteresis
  liftMs: number; // time to fully lift the head
  lowerMs: number; // time to lower it back
}
export const DEFAULT_REVEAL_CFG: RevealCfg = { enterK: 0.9, exitK: 1.3, liftMs: 300, lowerMs: 250 };

export interface RevealState {
  phase: RevealPhase;
  t: number; // ms elapsed within lifting/lowering
  /** 0 = head fully on, 1 = head fully lifted (real head revealed). */
  hidden: number;
}
export function initialReveal(): RevealState { return { phase: "off", t: 0, hidden: 0 }; }

/**
 * Advance the reveal FSM by `dtMs`. Pure: same (state, norm, dt, cfg) → same result.
 * Engage uses the tight enterK; disengage uses the looser exitK (hysteresis).
 */
export function revealStep(
  prev: RevealState,
  norm: Float32Array,
  dtMs: number,
  cfg: RevealCfg = DEFAULT_REVEAL_CFG,
): RevealState {
  const engaged = bothWristsNearHead(norm, cfg.enterK);
  const disengaged = !bothWristsNearHead(norm, cfg.exitK);
  let { phase, t } = prev;

  switch (phase) {
    case "off":
      if (engaged) { phase = "lifting"; t = 0; }
      break;
    case "lifting":
      t += dtMs;
      if (disengaged) { phase = "lowering"; t = 0; }
      else if (t >= cfg.liftMs) { phase = "revealed"; t = cfg.liftMs; }
      break;
    case "revealed":
      if (disengaged) { phase = "lowering"; t = 0; }
      break;
    case "lowering":
      t += dtMs;
      if (engaged) { phase = "lifting"; t = 0; }
      else if (t >= cfg.lowerMs) { phase = "off"; t = 0; }
      break;
  }

  let hidden = 0;
  if (phase === "revealed") hidden = 1;
  else if (phase === "lifting") hidden = Math.min(1, t / Math.max(1, cfg.liftMs));
  else if (phase === "lowering") hidden = Math.max(0, 1 - t / Math.max(1, cfg.lowerMs));
  return { phase, t, hidden };
}
