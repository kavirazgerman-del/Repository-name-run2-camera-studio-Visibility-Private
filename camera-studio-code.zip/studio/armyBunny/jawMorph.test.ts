// Validates the synthetic jaw morph against the REAL army-bunny.glb buffers, so we can
// trust the deformer before spending an (expensive) on-device recording. Parses the GLB
// accessors directly (three-free) → computes the head vertex set exactly like
// splitHeadTriangles → runs buildJawMorph and asserts it is bounded, tapered, seam-safe.
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, it, expect } from "vitest";
import { computeJawBox, defaultJawParams, buildJawMorph } from "./jawMorph";

function loadGlb() {
  const buf = readFileSync(resolve(process.cwd(), "public/models/army-bunny.glb"));
  let off = 12, json: any = null, binOff = 0;
  while (off < buf.length) {
    const len = buf.readUInt32LE(off), type = buf.readUInt32LE(off + 4); off += 8;
    if (type === 0x4e4f534a) json = JSON.parse(buf.slice(off, off + len).toString("utf8"));
    else if (type === 0x004e4942) binOff = off;
    off += len;
  }
  const CT: Record<number, any> = { 5121: Uint8Array, 5123: Uint16Array, 5125: Uint32Array, 5126: Float32Array };
  const NC: Record<string, number> = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4 };
  const acc = (i: number) => {
    const a = json.accessors[i], bv = json.bufferViews[a.bufferView];
    const start = binOff + (bv.byteOffset || 0) + (a.byteOffset || 0);
    return new CT[a.componentType](buf.buffer, start, a.count * NC[a.type]);
  };
  const prim = json.meshes[0].primitives[0];
  const position = acc(prim.attributes.POSITION) as Float32Array;
  const joints = acc(prim.attributes.JOINTS_0);
  const weights = acc(prim.attributes.WEIGHTS_0) as Float32Array;
  const index = acc(prim.indices);
  const skin = json.skins[0];
  const headJoints = new Set<number>();
  skin.joints.forEach((node: number, local: number) => {
    if (/^head/i.test(json.nodes[node].name || "")) headJoints.add(local);
  });
  return { position, joints, weights, index, headJoints };
}

function headVertexSet(g: ReturnType<typeof loadGlb>): Set<number> {
  const hw = (v: number) => {
    let w = 0;
    for (let k = 0; k < 4; k++) if (g.headJoints.has(g.joints[v * 4 + k])) w += g.weights[v * 4 + k];
    return w;
  };
  const set = new Set<number>();
  for (let t = 0; t < g.index.length / 3; t++) {
    const a = g.index[t * 3], b = g.index[t * 3 + 1], c = g.index[t * 3 + 2];
    if ((hw(a) + hw(b) + hw(c)) / 3 > 0.5) { set.add(a); set.add(b); set.add(c); }
  }
  return set;
}

describe("jawMorph (real GLB)", () => {
  const g = loadGlb();
  const head = headVertexSet(g);
  const nVert = g.position.length / 3;
  const box = computeJawBox(g.position, head);
  const params = defaultJawParams(box);
  const delta = buildJawMorph(g.position, head, params);

  it("isolates a plausible head region", () => {
    expect(head.size).toBeGreaterThan(0.05 * nVert);
    expect(head.size).toBeLessThan(0.25 * nVert);
    expect(box.frontPlusZ).toBe(true); // muzzle protrudes +Z on this export
  });

  it("moves a bounded, non-trivial jaw region", () => {
    let moved = 0;
    for (let v = 0; v < nVert; v++) if (delta[v * 3 + 1] !== 0) moved++;
    expect(moved).toBeGreaterThan(0.02 * head.size);
    expect(moved).toBeLessThan(0.60 * head.size); // lower jaw is a big share, but not all
  });

  it("keeps displacement bounded (no blow-ups) and finite", () => {
    const spanY = box.hi[1] - box.lo[1];
    let maxAbs = 0;
    for (let i = 0; i < delta.length; i++) {
      expect(Number.isFinite(delta[i])).toBe(true);
      maxAbs = Math.max(maxAbs, Math.abs(delta[i]));
    }
    expect(maxAbs).toBeGreaterThan(0);
    expect(maxAbs).toBeLessThan(0.15 * spanY);
  });

  it("only the drop is downward, and only head verts move (seam-safe body)", () => {
    for (let v = 0; v < nVert; v++) {
      if (!head.has(v)) {
        expect(delta[v * 3]).toBe(0);
        expect(delta[v * 3 + 1]).toBe(0);
        expect(delta[v * 3 + 2]).toBe(0);
      }
    }
    // the jaw drops (negative Y) — never lifts
    for (let v = 0; v < nVert; v++) expect(delta[v * 3 + 1]).toBeLessThanOrEqual(0);
  });

  it("tapers smoothly (partial weights exist → no hard tear edge)", () => {
    const full = params.maxDrop;
    let partial = 0;
    for (const v of head) {
      const d = -delta[v * 3 + 1];
      if (d > 1e-5 && d < full - 1e-5) partial++;
    }
    expect(partial).toBeGreaterThan(20); // a real ramp, not an on/off cliff
  });
});
