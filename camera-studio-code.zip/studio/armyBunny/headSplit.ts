// ── Army Bunny — head/body triangle partition (pure, three-free) ────────────────
// The Meshy model is a SINGLE fused skinned mesh, but the head-off reveal needs the
// mascot head separable from the body suit. Since the head geometry is skinned to the
// {Head, headfront, head_end} joints, we can partition triangles by skin weight:
//
//   • a vertex's "head weight" = the sum of its (up to 4) skin weights whose joint is
//     in the head-joint set,
//   • a triangle joins the HEAD group when the average head-weight across its three
//     vertices exceeds `threshold`; otherwise it stays with the BODY suit.
//
// This is a PURE function over plain typed arrays (no three.js) so it can be unit
// tested in Node against the raw GLB buffers AND reused at runtime on a
// THREE.BufferGeometry (index / skinIndex / skinWeight are the same shapes).

export interface HeadSplitInput {
  /** Triangle vertex indices, length a multiple of 3. */
  index: Uint16Array | Uint32Array | readonly number[];
  /** 4 joint indices per vertex (local indices into skin.joints). */
  skinIndex: Uint8Array | Uint16Array;
  /** 4 skin weights per vertex, parallel to skinIndex. */
  skinWeight: Float32Array;
  /** LOCAL joint indices (positions in skin.joints) that make up the head. */
  headJoints: ReadonlySet<number>;
  /** Average per-triangle head-weight required to classify as head. Default 0.5. */
  threshold?: number;
}

export interface HeadSplitResult {
  /** Triangle vertex indices belonging to the mascot head. */
  headIndex: number[];
  /** Triangle vertex indices belonging to the body suit. */
  bodyIndex: number[];
  /** Distinct vertices touched by head triangles. */
  headVertexCount: number;
}

/** Sum of vertex `v`'s skin weights whose joint is in `headJoints` (0..1). */
export function vertexHeadWeight(
  v: number,
  skinIndex: Uint8Array | Uint16Array,
  skinWeight: Float32Array,
  headJoints: ReadonlySet<number>,
): number {
  let w = 0;
  const base = v * 4;
  for (let k = 0; k < 4; k++) {
    if (headJoints.has(skinIndex[base + k])) w += skinWeight[base + k];
  }
  return w;
}

/** Partition triangles into head vs body by average per-triangle head weight. */
export function splitHeadTriangles(inp: HeadSplitInput): HeadSplitResult {
  const { index, skinIndex, skinWeight, headJoints } = inp;
  const threshold = inp.threshold ?? 0.5;
  const headIndex: number[] = [];
  const bodyIndex: number[] = [];
  const headVerts = new Set<number>();
  const triCount = (index.length / 3) | 0;
  for (let t = 0; t < triCount; t++) {
    const a = index[t * 3], b = index[t * 3 + 1], c = index[t * 3 + 2];
    const wa = vertexHeadWeight(a, skinIndex, skinWeight, headJoints);
    const wb = vertexHeadWeight(b, skinIndex, skinWeight, headJoints);
    const wc = vertexHeadWeight(c, skinIndex, skinWeight, headJoints);
    if ((wa + wb + wc) / 3 > threshold) {
      headIndex.push(a, b, c);
      headVerts.add(a); headVerts.add(b); headVerts.add(c);
    } else {
      bodyIndex.push(a, b, c);
    }
  }
  return { headIndex, bodyIndex, headVertexCount: headVerts.size };
}
