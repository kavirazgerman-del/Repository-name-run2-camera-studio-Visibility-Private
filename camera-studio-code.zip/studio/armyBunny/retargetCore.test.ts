import { describe, expect, it } from "vitest";
import {
  DEFAULT_AXIS_MAP,
  mapLandmarks,
  qFromUnitVectors,
  qMul,
  qRotV3,
  solvePose,
  torsoMetrics,
  type Quat,
  type RigDef,
  type V3,
} from "./retargetCore";

const IDENT: Quat = [0, 0, 0, 1];

function setLm(lm: Float32Array, idx: number, x: number, y: number, z: number) {
  lm[idx * 3] = x; lm[idx * 3 + 1] = y; lm[idx * 3 + 2] = z;
}
function approxV(a: V3, b: V3, eps = 1e-4) {
  for (let i = 0; i < 3; i++) expect(Math.abs(a[i] - b[i])).toBeLessThan(eps);
}
function quatAngle(a: Quat, b: Quat): number {
  const d = Math.abs(a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3]);
  return 2 * Math.acos(Math.min(1, d));
}

/** One driven bone at index 0: origin=landmark 0, child=landmark 1, rest aims +X. */
function oneBoneRig(restDirParent: V3 = [1, 0, 0]): RigDef {
  return { bones: [{ name: "b", parentWorld: IDENT, restLocal: IDENT, restDirParent, originIdx: 0, childIdx: 1 }] };
}

describe("qFromUnitVectors", () => {
  it("returns identity for identical vectors", () => {
    const q = qFromUnitVectors([1, 0, 0], [1, 0, 0]);
    expect(quatAngle(q, IDENT)).toBeLessThan(1e-5);
  });

  it("rotates +X to -Y with a 90° turn about Z", () => {
    const q = qFromUnitVectors([1, 0, 0], [0, -1, 0]);
    approxV(qRotV3(q, [1, 0, 0]), [0, -1, 0]);
  });

  it("handles the antipodal case without NaN and yields a valid 180°", () => {
    const q = qFromUnitVectors([1, 0, 0], [-1, 0, 0]);
    for (const c of q) expect(Number.isFinite(c)).toBe(true);
    expect(Math.hypot(q[0], q[1], q[2], q[3])).toBeCloseTo(1, 5);
    approxV(qRotV3(q, [1, 0, 0]), [-1, 0, 0], 1e-3);
  });
});

describe("solvePose (swing solver)", () => {
  it("holds rest when the target direction equals the rest direction", () => {
    const rig = oneBoneRig([1, 0, 0]);
    const lm = new Float32Array(99);
    setLm(lm, 0, 0, 0, 0); setLm(lm, 1, 1, 0, 0); // dir = +X == restDir
    const out = new Float32Array(4);
    solvePose(lm, rig, out);
    expect(quatAngle([out[0], out[1], out[2], out[3]], IDENT)).toBeLessThan(1e-4);
  });

  it("aims the bone at its landmark child", () => {
    const rig = oneBoneRig([1, 0, 0]); // rest points +X
    const lm = new Float32Array(99);
    setLm(lm, 0, 0, 0, 0); setLm(lm, 1, 0, -1, 0); // want to aim straight down
    const out = new Float32Array(4);
    solvePose(lm, rig, out);
    const local: Quat = [out[0], out[1], out[2], out[3]];
    // applying local to the rest direction must reproduce the target direction.
    approxV(qRotV3(local, [1, 0, 0]), [0, -1, 0]);
  });

  it("respects a non-identity parentWorld frame", () => {
    // parent rotated 90° about Z: parent's local +X points to world +Y.
    const pw = qFromUnitVectors([1, 0, 0], [0, 1, 0]); // maps +X->+Y
    const rig: RigDef = {
      bones: [{ name: "b", parentWorld: pw, restLocal: IDENT, restDirParent: [1, 0, 0], originIdx: 0, childIdx: 1 }],
    };
    const lm = new Float32Array(99);
    setLm(lm, 0, 0, 0, 0); setLm(lm, 1, 0, 1, 0); // target world +Y == parent local +X == restDir
    const out = new Float32Array(4);
    solvePose(lm, rig, out);
    // target already matches rest in parent space → swing identity → local == rest.
    expect(quatAngle([out[0], out[1], out[2], out[3]], IDENT)).toBeLessThan(1e-4);
  });

  it("is continuous under small perturbations (no sign flips)", () => {
    const rig = oneBoneRig([1, 0, 0]);
    const lm = new Float32Array(99);
    const out = new Float32Array(4);
    setLm(lm, 0, 0, 0, 0); setLm(lm, 1, 0.2, -1, 0.1);
    solvePose(lm, rig, out);
    const prev: Quat = [out[0], out[1], out[2], out[3]];
    setLm(lm, 1, 0.21, -1, 0.09); // tiny nudge
    solvePose(lm, rig, out);
    const next: Quat = [out[0], out[1], out[2], out[3]];
    expect(prev[0] * next[0] + prev[1] * next[1] + prev[2] * next[2] + prev[3] * next[3]).toBeGreaterThan(0);
    expect(quatAngle(prev, next)).toBeLessThan(0.1);
  });

  it("holds rest for a degenerate (zero-length) target", () => {
    const rig = oneBoneRig([1, 0, 0]);
    const lm = new Float32Array(99);
    setLm(lm, 0, 0.5, 0.5, 0.5); setLm(lm, 1, 0.5, 0.5, 0.5); // origin == child
    const out = new Float32Array(4);
    solvePose(lm, rig, out);
    expect(quatAngle([out[0], out[1], out[2], out[3]], IDENT)).toBeLessThan(1e-6);
  });
});

describe("mapLandmarks", () => {
  it("applies axis signs", () => {
    const w = new Float32Array(99);
    setLm(w, 5, 1, 2, 3);
    const out = new Float32Array(99);
    mapLandmarks(w, { sx: 1, sy: -1, sz: -1, swapLR: false }, out);
    approxV([out[15], out[16], out[17]], [1, -2, -3]);
  });

  it("swaps left/right indices when swapLR is set", () => {
    const w = new Float32Array(99);
    setLm(w, 11, 9, 9, 9); // left shoulder
    setLm(w, 12, -9, -9, -9); // right shoulder
    const out = new Float32Array(99);
    mapLandmarks(w, { sx: 1, sy: 1, sz: 1, swapLR: true }, out);
    // index 11 should now carry index 12's data and vice versa.
    approxV([out[11 * 3], out[11 * 3 + 1], out[11 * 3 + 2]], [-9, -9, -9]);
    approxV([out[12 * 3], out[12 * 3 + 1], out[12 * 3 + 2]], [9, 9, 9]);
  });

  it("leaves the nose (index 0) in place under swapLR", () => {
    const w = new Float32Array(99);
    setLm(w, 0, 4, 5, 6);
    const out = new Float32Array(99);
    mapLandmarks(w, { ...DEFAULT_AXIS_MAP, swapLR: true, sx: 1, sy: 1, sz: 1 }, out);
    approxV([out[0], out[1], out[2]], [4, 5, 6]);
  });
});

describe("mirror invariance", () => {
  it("mirroring the input (swapLR + flip x) mirrors the solved arm quaternions", () => {
    // A symmetric two-arm rig, arms aiming +X (left) and -X (right) at rest.
    const rig: RigDef = {
      bones: [
        { name: "LeftArm", parentWorld: IDENT, restLocal: IDENT, restDirParent: [1, 0, 0], originIdx: 11, childIdx: 13 },
        { name: "RightArm", parentWorld: IDENT, restLocal: IDENT, restDirParent: [-1, 0, 0], originIdx: 12, childIdx: 14 },
      ],
    };
    // Pose: left arm up-and-out, right arm down. Landmarks in char space.
    const a = new Float32Array(99);
    setLm(a, 11, 1, 0, 0); setLm(a, 13, 2, 1, 0);   // left shoulder→elbow: +X,+Y
    setLm(a, 12, -1, 0, 0); setLm(a, 14, -2, -1, 0); // right shoulder→elbow: -X,-Y
    const outA = new Float32Array(8);
    solvePose(a, rig, outA);

    // Mirror across X: swapLR then negate x. The left result should equal the
    // right result of the original with x/... mirrored — concretely, the mirrored
    // solve's LeftArm quat equals the original RightArm quat reflected.
    const b = new Float32Array(99);
    mapLandmarks(a, { sx: -1, sy: 1, sz: 1, swapLR: true }, b);
    const outB = new Float32Array(8);
    solvePose(b, rig, outB);
    // After mirroring, LeftArm now carries what RightArm did (up-and-out on the
    // other side): its rotation angle must match the original LeftArm's angle.
    const leftA: Quat = [outA[0], outA[1], outA[2], outA[3]];
    const leftB: Quat = [outB[0], outB[1], outB[2], outB[3]];
    expect(Math.abs(quatAngle(leftA, IDENT) - quatAngle(leftB, IDENT))).toBeLessThan(1e-3);
  });
});

describe("torsoMetrics", () => {
  it("computes midpoints and torso length", () => {
    const n = new Float32Array(99);
    setLm(n, 11, 0.6, 0.3, 0); setLm(n, 12, 0.4, 0.3, 0); // shoulders
    setLm(n, 23, 0.55, 0.6, 0); setLm(n, 24, 0.45, 0.6, 0); // hips
    const m = torsoMetrics(n);
    expect(m.shoulderMid[0]).toBeCloseTo(0.5, 5);
    expect(m.shoulderMid[1]).toBeCloseTo(0.3, 5);
    expect(m.hipMid[1]).toBeCloseTo(0.6, 5);
    expect(m.torsoLen).toBeCloseTo(0.3, 5);
  });
});

describe("qMul", () => {
  it("multiplies by identity as a no-op", () => {
    const q: Quat = qFromUnitVectors([1, 0, 0], [0, 0, 1]);
    const r = qMul(q, IDENT);
    expect(quatAngle(q, r)).toBeLessThan(1e-6);
  });
});
