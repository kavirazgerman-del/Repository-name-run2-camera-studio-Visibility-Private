import { describe, expect, it } from "vitest";
import {
  bothWristsNearHead,
  DEFAULT_REVEAL_CFG,
  initialReveal,
  revealStep,
  shoulderWidth,
  type RevealState,
} from "./reveal";

const L_EAR = 7, R_EAR = 8, L_SHOULDER = 11, R_SHOULDER = 12, L_WRIST = 15, R_WRIST = 16;

function set(n: Float32Array, i: number, x: number, y: number) { n[i * 3] = x; n[i * 3 + 1] = y; }

/** Build a normalized-landmark frame with shoulder width 0.2 and wrists placed at
 *  a chosen distance `d` (in the same units) from their ears. */
function frame(d: number): Float32Array {
  const n = new Float32Array(99);
  set(n, L_SHOULDER, 0.6, 0.5);
  set(n, R_SHOULDER, 0.4, 0.5); // shoulder width = 0.2
  set(n, L_EAR, 0.55, 0.35);
  set(n, R_EAR, 0.45, 0.35);
  set(n, L_WRIST, 0.55, 0.35 + d); // straight below the ear by d
  set(n, R_WRIST, 0.45, 0.35 + d);
  return n;
}

describe("shoulderWidth / bothWristsNearHead", () => {
  it("measures shoulder width", () => {
    expect(shoulderWidth(frame(0.5))).toBeCloseTo(0.2, 6);
  });

  it("is true only when both wrists are within k·shoulderWidth of the ears", () => {
    // shoulder width 0.2, enterK 0.9 → threshold 0.18.
    expect(bothWristsNearHead(frame(0.1), DEFAULT_REVEAL_CFG.enterK)).toBe(true);
    expect(bothWristsNearHead(frame(0.25), DEFAULT_REVEAL_CFG.enterK)).toBe(false);
  });

  it("returns false when there is no reliable pose (zero shoulder width)", () => {
    expect(bothWristsNearHead(new Float32Array(99), DEFAULT_REVEAL_CFG.enterK)).toBe(false);
  });

  it("requires BOTH wrists, not one", () => {
    const n = frame(0.5); // both far
    set(n, L_WRIST, 0.55, 0.35 + 0.05); // bring only the left in
    expect(bothWristsNearHead(n, DEFAULT_REVEAL_CFG.enterK)).toBe(false);
  });
});

describe("revealStep FSM", () => {
  const near = frame(0.1); // inside enter threshold
  const far = frame(0.5); // outside exit threshold

  it("starts off and hidden = 0", () => {
    const s = initialReveal();
    expect(s.phase).toBe("off");
    expect(s.hidden).toBe(0);
  });

  it("lifts over liftMs then holds revealed", () => {
    let s = initialReveal();
    s = revealStep(s, near, 0); // off → lifting
    expect(s.phase).toBe("lifting");
    s = revealStep(s, near, 150); // half way
    expect(s.hidden).toBeGreaterThan(0.4);
    expect(s.hidden).toBeLessThan(0.6);
    s = revealStep(s, near, 200); // past liftMs
    expect(s.phase).toBe("revealed");
    expect(s.hidden).toBe(1);
  });

  it("lowers back to off when wrists leave", () => {
    let s: RevealState = { phase: "revealed", t: DEFAULT_REVEAL_CFG.liftMs, hidden: 1 };
    s = revealStep(s, far, 0); // revealed → lowering
    expect(s.phase).toBe("lowering");
    s = revealStep(s, far, 300); // past lowerMs
    expect(s.phase).toBe("off");
    expect(s.hidden).toBe(0);
  });

  it("hysteresis: staying between enterK and exitK does NOT disengage once revealed", () => {
    // frame at d=0.22 → dist 0.22 > enter(0.18) but < exit(0.26). Should hold revealed.
    const between = frame(0.22);
    let s: RevealState = { phase: "revealed", t: DEFAULT_REVEAL_CFG.liftMs, hidden: 1 };
    s = revealStep(s, between, 16);
    expect(s.phase).toBe("revealed");
  });

  it("hysteresis: the same in-between frame does NOT engage from off", () => {
    const between = frame(0.22);
    let s = initialReveal();
    s = revealStep(s, between, 16);
    expect(s.phase).toBe("off");
  });

  it("survives a single flicker frame during lift without resetting to off", () => {
    let s = initialReveal();
    s = revealStep(s, near, 0); // lifting
    s = revealStep(s, near, 100);
    s = revealStep(s, far, 16); // one bad frame → lowering (not off)
    expect(s.phase).toBe("lowering");
    s = revealStep(s, near, 16); // recovers → lifting again
    expect(s.phase).toBe("lifting");
  });
});
