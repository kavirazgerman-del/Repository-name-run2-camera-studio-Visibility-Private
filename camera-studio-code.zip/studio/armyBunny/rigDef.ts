// ── Army Bunny — rig definition builder (impure: reads the live three skeleton) ──
// Runs ONCE after the model loads. Walks the bind pose to capture, per driven bone,
// the constant parent world orientation, the bind local orientation, and the bind
// aim-direction in parent space — everything solvePose() needs as plain numbers.
// After this, the per-frame solver is fully pure (see retargetCore.ts).
import * as THREE from "three";
import type { ArmyBunnyModel } from "./loader";
import type { DrivenBone, LmRef, Quat, RigDef, V3 } from "./retargetCore";

// Which bones we drive, the child bone that defines their bind aim direction, and
// the MediaPipe landmark(s) at the joint (origin) and aim-child. Legs are left in
// their rest pose (fixed slight bend) for robustness; the head follows `neck`.
interface Spec { name: string; childBone: string; origin: LmRef; child: LmRef; }
const SPEC: Spec[] = [
  { name: "LeftArm", childBone: "LeftForeArm", origin: 11, child: 13 },
  { name: "LeftForeArm", childBone: "LeftHand", origin: 13, child: 15 },
  { name: "RightArm", childBone: "RightForeArm", origin: 12, child: 14 },
  { name: "RightForeArm", childBone: "RightHand", origin: 14, child: 16 },
  { name: "neck", childBone: "Head", origin: [11, 12], child: [7, 8] },
];

const q2a = (q: THREE.Quaternion): Quat => [q.x, q.y, q.z, q.w];
const v2a = (v: THREE.Vector3): V3 => [v.x, v.y, v.z];

export function buildRigDef(model: ArmyBunnyModel): RigDef {
  model.root.updateMatrixWorld(true);
  const tmpParentQ = new THREE.Quaternion();
  const bonePos = new THREE.Vector3();
  const childPos = new THREE.Vector3();
  const bones: DrivenBone[] = [];

  for (const spec of SPEC) {
    const bone = model.bones[spec.name];
    const childBone = model.bones[spec.childBone];
    if (!bone || !childBone || !bone.parent) {
      console.warn(`[armyBunny] rigDef: missing bone ${spec.name}/${spec.childBone}`);
      continue;
    }
    bone.parent.getWorldQuaternion(tmpParentQ);
    bone.getWorldPosition(bonePos);
    childBone.getWorldPosition(childPos);

    // bind aim direction (bone → child) expressed in the parent's world frame.
    const worldDir = childPos.clone().sub(bonePos).normalize();
    const restDirParent = v2a(
      worldDir.clone().applyQuaternion(tmpParentQ.clone().invert()).normalize(),
    );
    const restLocal = q2a(model.restQuats[spec.name] ?? bone.quaternion);

    bones.push({
      name: spec.name,
      parentWorld: q2a(tmpParentQ),
      restLocal,
      restDirParent,
      originIdx: spec.origin,
      childIdx: spec.child,
    });
  }
  return { bones };
}

/** Number of quaternion slots the solver writes for this rig. */
export function poseBufferLength(rig: RigDef): number { return rig.bones.length * 4; }

/** Copy solved LOCAL quaternions back onto the live skeleton (impure). */
export function applyPose(model: ArmyBunnyModel, rig: RigDef, outLocal: Float32Array): void {
  for (let i = 0; i < rig.bones.length; i++) {
    const bone = model.bones[rig.bones[i].name];
    if (!bone) continue;
    const j = i * 4;
    bone.quaternion.set(outLocal[j], outLocal[j + 1], outLocal[j + 2], outLocal[j + 3]);
  }
}
