// ── Army Bunny — synthetic "jaw open" morph target (pure, three-free) ────────────
// The Meshy mascot has NO jaw bone and ZERO morph targets (verified against the GLB),
// so the mouth cannot open on its own. We author a morph target procedurally: pick the
// lower-front vertices of the (already isolated) head mesh and drop them like a hinged
// lower jaw, tapering the displacement to zero at every edge of the region so the mesh
// can never tear. three.js then blends this target by `morphTargetInfluences[0]`, which
// the compositor drives from the user's real `jawOpen` (MediaPipe FaceLandmarker).
//
// A straight, monotonic "drop the chin most, the mouth line least" translation is used
// instead of a true hinge rotation: it is unambiguous to author BLIND (this env has no
// WebGL2, so the shape can only be seen on a real device) and reads cleanly as a mouth
// opening on a stylized mascot. Pure typed-array math → unit-tested in Node against the
// real GLB buffers (jawMorph.test.ts), mirroring headSplit.ts.

export interface JawBox {
  lo: [number, number, number];
  hi: [number, number, number];
  /** Y of the most-protruding muzzle vertex (the nose tip) — the mouth sits below it. */
  noseY: number;
  /** Depth midplane of the head — the front/back divider. */
  zMid: number;
  /** True when the muzzle protrudes toward +Z (Meshy export orientation). */
  frontPlusZ: boolean;
}

/** Measure the head region (bbox + muzzle direction) from the split head vertices. */
export function computeJawBox(position: Float32Array, headVertices: Iterable<number>): JawBox {
  const lo: [number, number, number] = [Infinity, Infinity, Infinity];
  const hi: [number, number, number] = [-Infinity, -Infinity, -Infinity];
  let cz = 0, n = 0;
  for (const v of headVertices) {
    for (let d = 0; d < 3; d++) {
      const x = position[v * 3 + d];
      if (x < lo[d]) lo[d] = x;
      if (x > hi[d]) hi[d] = x;
    }
    cz += position[v * 3 + 2];
    n++;
  }
  cz = n ? cz / n : 0;
  const zMid = (lo[2] + hi[2]) / 2;
  const frontPlusZ = Math.abs(hi[2] - cz) >= Math.abs(lo[2] - cz);
  // muzzle tip = head vertex with the most extreme Z toward the front
  let noseY = (lo[1] + hi[1]) / 2, best = -Infinity;
  for (const v of headVertices) {
    const z = position[v * 3 + 2];
    const score = frontPlusZ ? z : -z;
    if (score > best) { best = score; noseY = position[v * 3 + 1]; }
  }
  return { lo, hi, noseY, zMid, frontPlusZ };
}

export interface JawParams {
  /** Verts below this Y are the movable jaw (default: the nose tip → mouth is below it). */
  mouthLineY: number;
  /** Bottom of the jaw (chin) — the drop scales to full here. */
  jawBottomY: number;
  /** Depth midplane; only the front side of it moves. */
  zMid: number;
  /** Soft band (world units) over which the front taper ramps in past zMid. */
  zBand: number;
  frontPlusZ: boolean;
  /** Fraction of the head half-width where the lateral taper starts (keeps corners on). */
  xTaperFrac: number;
  /** Max downward drop at the chin, at full open (world units, head ≈ unit-ish). */
  maxDrop: number;
  /** Slight forward tuck at full open (world units). */
  maxTuck: number;
}

/** Sensible defaults derived purely from the measured head box. */
export function defaultJawParams(box: JawBox): JawParams {
  const spanZ = box.hi[2] - box.lo[2];
  // Anchor the drop to the actual jaw height (nose→chin), NOT the full head box —
  // the tall ears inflate head height and would make a % of it wildly too large.
  const jawSpan = Math.max(1e-4, box.noseY - box.lo[1]);
  return {
    mouthLineY: box.noseY,
    jawBottomY: box.lo[1],
    zMid: box.zMid,
    zBand: Math.max(1e-4, spanZ * 0.18),
    frontPlusZ: box.frontPlusZ,
    xTaperFrac: 0.82,
    maxDrop: jawSpan * 0.45,
    maxTuck: jawSpan * 0.12,
  };
}

function smooth(edge0: number, edge1: number, x: number): number {
  if (edge0 === edge1) return x < edge0 ? 0 : 1;
  const t = Math.min(1, Math.max(0, (x - edge0) / (edge1 - edge0)));
  return t * t * (3 - 2 * t);
}

/**
 * Build a RELATIVE morph delta (full length = position.length, zeros outside the jaw).
 * Feed the result into `geometry.morphAttributes.position` with `morphTargetsRelative`.
 * Deterministic and allocation-simple so it can be rebuilt live when a param is tuned.
 */
export function buildJawMorph(
  position: Float32Array,
  headVertices: Iterable<number>,
  params: JawParams,
): Float32Array {
  const { mouthLineY, jawBottomY, zMid, zBand, frontPlusZ, xTaperFrac, maxDrop, maxTuck } = params;
  const delta = new Float32Array(position.length);

  // head half-width for the lateral taper
  let maxAbsX = 1e-4;
  for (const v of headVertices) maxAbsX = Math.max(maxAbsX, Math.abs(position[v * 3]));
  const xStart = xTaperFrac * maxAbsX;

  const jawSpan = Math.max(1e-4, mouthLineY - jawBottomY);

  for (const v of headVertices) {
    const x = position[v * 3], y = position[v * 3 + 1], z = position[v * 3 + 2];

    // vertical gradient: 0 at/above the mouth line, 1 at the chin
    const dropFactor = Math.min(1, Math.max(0, (mouthLineY - y) / jawSpan));
    if (dropFactor <= 0) continue;

    // front-of-head taper (0 behind zMid, 1 well in front)
    const wZ = frontPlusZ ? smooth(zMid, zMid + zBand, z) : smooth(zMid, zMid - zBand, z);
    if (wZ <= 0) continue;

    // lateral taper (1 near centre → 0 at the head edge) keeps the mouth corners attached
    const wX = 1 - smooth(xStart, maxAbsX, Math.abs(x));

    const w = dropFactor * wZ * wX;
    if (w <= 0) continue;

    delta[v * 3] = 0;
    delta[v * 3 + 1] = -maxDrop * w;
    delta[v * 3 + 2] = (frontPlusZ ? maxTuck : -maxTuck) * w;
  }
  return delta;
}
