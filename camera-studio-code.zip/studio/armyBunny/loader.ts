// ── Army Bunny — GLB loader / normalizer / head-body splitter ───────────────────
// Loads the rigged Meshy mascot, normalizes it to a canonical space (unit height,
// feet at y=0, centred on x/z), and splits the single fused SkinnedMesh into a
// separate HEAD mesh and BODY mesh that share ONE skeleton. Keeping the head as its
// own mesh lets the hands-to-head gesture hide/lift it to reveal the user's real head
// while the body suit stays on. A temporary procedural camo skin is applied until the
// user's textured re-export lands.
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { splitHeadTriangles } from "./headSplit";
import { computeJawBox, defaultJawParams, buildJawMorph, type JawParams } from "./jawMorph";
import { createCamoTexture } from "./camo";

export interface ArmyBunnyModel {
  /** Add this to the scene. Already normalized (unit height, feet at origin). */
  root: THREE.Group;
  bodyMesh: THREE.SkinnedMesh;
  headMesh: THREE.SkinnedMesh;
  skeleton: THREE.Skeleton;
  /** Bones keyed by name for retargeting. */
  bones: Record<string, THREE.Bone>;
  /** Rest-pose local quaternion per bone name (retarget applies swing on top). */
  restQuats: Record<string, THREE.Quaternion>;
  /** Normalized rendered height in world units (== TARGET_HEIGHT). */
  height: number;
  /** Set the mouth-open morph influence 0..1 (0 = rest). Driven by the face tracker. */
  setMouthOpen(v: number): void;
  /** Rebuild the synthetic jaw morph with new params (live tuning); returns the merged set. */
  setJawParams(p: Partial<JawParams>): JawParams;
  /** Current jaw-morph params (for HUD / on-device tuning readout). */
  getJawParams(): JawParams;
  dispose(): void;
}

export const TARGET_HEIGHT = 1.0;

const HEAD_BONE_RE = /^head/i; // matches Head, headfront, head_end (NOT Neck)

function findSkinnedMesh(root: THREE.Object3D): THREE.SkinnedMesh | null {
  let found: THREE.SkinnedMesh | null = null;
  root.traverse((o) => {
    if (!found && (o as THREE.SkinnedMesh).isSkinnedMesh) found = o as THREE.SkinnedMesh;
  });
  return found;
}

/** Build a geometry that reuses the source attributes but a new index subset. */
function geometryFromIndex(src: THREE.BufferGeometry, indices: number[]): THREE.BufferGeometry {
  const g = new THREE.BufferGeometry();
  for (const name of ["position", "normal", "uv", "skinIndex", "skinWeight"]) {
    const attr = src.getAttribute(name);
    if (attr) g.setAttribute(name, attr); // shared by reference — no duplication
  }
  g.setIndex(new THREE.BufferAttribute(new Uint32Array(indices), 1));
  g.computeBoundingSphere();
  return g;
}

export async function loadArmyBunny(
  url: string,
  opts: { camoSeed?: number } = {},
): Promise<ArmyBunnyModel> {
  const loader = new GLTFLoader();
  const gltf = await loader.loadAsync(url);
  const source = findSkinnedMesh(gltf.scene);
  if (!source) throw new Error("[armyBunny] no SkinnedMesh in GLB");

  const skeleton = source.skeleton;
  const geom = source.geometry;
  const indexAttr = geom.index;
  const skinIndexAttr = geom.getAttribute("skinIndex");
  const skinWeightAttr = geom.getAttribute("skinWeight");
  if (!indexAttr || !skinIndexAttr || !skinWeightAttr) {
    throw new Error("[armyBunny] geometry missing index/skinIndex/skinWeight");
  }

  // head joints = LOCAL indices (position in skeleton.bones) whose bone is a head bone
  const headJoints = new Set<number>();
  const bones: Record<string, THREE.Bone> = {};
  const restQuats: Record<string, THREE.Quaternion> = {};
  skeleton.bones.forEach((b, i) => {
    bones[b.name] = b;
    restQuats[b.name] = b.quaternion.clone();
    if (HEAD_BONE_RE.test(b.name)) headJoints.add(i);
  });

  const { headIndex, bodyIndex } = splitHeadTriangles({
    index: indexAttr.array as Uint16Array | Uint32Array,
    skinIndex: skinIndexAttr.array as Uint8Array | Uint16Array,
    skinWeight: skinWeightAttr.array as Float32Array,
    headJoints,
  });

  // Prefer the GLB's OWN baked texture (the real ARMY skin from the Meshy export).
  // Only fall back to the procedural camo when the source mesh has no base texture
  // (e.g. the old texture-stripped GLB). Head + body share the one material so the
  // split is seamless.
  const srcMat = (Array.isArray(source.material) ? source.material[0] : source.material) as
    | THREE.MeshStandardMaterial
    | undefined;
  const usedFallbackCamo = !srcMat?.map;
  const material: THREE.Material = usedFallbackCamo
    ? new THREE.MeshStandardMaterial({
        map: createCamoTexture(512, opts.camoSeed ?? 0xa11ce),
        roughness: 0.85,
        metalness: 0.0,
      })
    : srcMat!;

  // The head gets its OWN (cloned) material so the renderer compiles a stable morph
  // program for it, instead of thrashing one shared program between the morph-having
  // head and the morph-free body. The clone shares the same base texture map.
  const headMaterial = material.clone();
  const bodyMesh = new THREE.SkinnedMesh(geometryFromIndex(geom, bodyIndex), material);
  const headMesh = new THREE.SkinnedMesh(geometryFromIndex(geom, headIndex), headMaterial);
  bodyMesh.name = "armyBunnyBody";
  headMesh.name = "armyBunnyHead";
  for (const m of [bodyMesh, headMesh]) {
    m.bind(skeleton, source.bindMatrix);
    m.frustumCulled = false;
  }

  // ── Synthetic jaw-open morph ────────────────────────────────────────────────
  // The GLB has NO jaw bone and NO morph targets (the `headfront` joint owns 0 verts),
  // so bone rotation is impossible. Instead we author a single morph target that drops
  // the lower-front head vertices like a hinged jaw (see jawMorph.ts). The delta is
  // full-length (parallel to the shared position attribute) but zero everywhere outside
  // the head vertex set, and it lives on the HEAD geometry only — the body shares the
  // base position attribute by reference but has no morph attribute, so it never moves.
  const posArr = geom.getAttribute("position").array as Float32Array;
  const headVertexSet = new Set<number>(headIndex);
  const jawBox = computeJawBox(posArr, headVertexSet);
  let jawParams = defaultJawParams(jawBox);
  const jawAttr = new THREE.BufferAttribute(buildJawMorph(posArr, headVertexSet, jawParams), 3);
  headMesh.geometry.morphAttributes.position = [jawAttr];
  headMesh.geometry.morphTargetsRelative = true;
  headMesh.updateMorphTargets();
  if (headMesh.morphTargetInfluences) headMesh.morphTargetInfluences[0] = 0;

  const setMouthOpen = (v: number) => {
    const infl = headMesh.morphTargetInfluences;
    if (infl && infl.length) infl[0] = v < 0 ? 0 : v > 1 ? 1 : v;
  };
  const setJawParams = (p: Partial<JawParams>): JawParams => {
    jawParams = { ...jawParams, ...p };
    (jawAttr.array as Float32Array).set(buildJawMorph(posArr, headVertexSet, jawParams));
    jawAttr.needsUpdate = true;
    // three bakes morph targets into a per-geometry texture cached by morph-target COUNT
    // (WebGLMorphtargets), so `needsUpdate` alone is IGNORED — the texture would keep the
    // stale delta and live tuning would silently no-op. Disposing the geometry fires the
    // 'dispose' event that drops that cached morph texture, forcing a rebuild from the
    // updated attribute next frame. Cost: a one-frame lazy GL re-upload, fine for the
    // rare tuning button presses this is called from.
    headMesh.geometry.dispose();
    return jawParams;
  };
  const getJawParams = (): JawParams => jawParams;

  // Hide the original fused mesh, keep the armature (bones) in place, and mount the
  // two split meshes alongside it so they deform with the same skeleton.
  source.visible = false;
  const parent = source.parent ?? gltf.scene;
  parent.add(bodyMesh);
  parent.add(headMesh);

  // Normalize the whole scene: scale to TARGET_HEIGHT, drop feet to y=0, centre x/z.
  const root = new THREE.Group();
  root.name = "armyBunnyRoot";
  root.add(gltf.scene);
  const box = new THREE.Box3().setFromObject(gltf.scene);
  const size = new THREE.Vector3();
  const center = new THREE.Vector3();
  box.getSize(size);
  box.getCenter(center);
  const scale = size.y > 1e-6 ? TARGET_HEIGHT / size.y : 1;
  gltf.scene.scale.setScalar(scale);
  gltf.scene.position.set(-center.x * scale, -box.min.y * scale, -center.z * scale);
  root.updateMatrixWorld(true);

  const dispose = () => {
    bodyMesh.geometry.dispose();
    headMesh.geometry.dispose();
    (material as THREE.MeshStandardMaterial).map?.dispose(); // shared base texture
    material.dispose();
    headMaterial.dispose(); // clone shares the (already-disposed) map
    // shared source attributes belong to the original geometry
    geom.dispose();
  };

  return {
    root, bodyMesh, headMesh, skeleton, bones, restQuats, height: TARGET_HEIGHT,
    setMouthOpen, setJawParams, getJawParams, dispose,
  };
}
