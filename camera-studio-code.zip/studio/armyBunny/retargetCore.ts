// ── Army Bunny — PURE retarget core (no three, no DOM) ──────────────────────────
// Turns MediaPipe pose landmarks into per-bone LOCAL quaternions using a swing
// solver (aim each driven bone from its landmark origin toward its landmark child).
//
// This file is deliberately dependency-free so the hard math is unit-testable in
// Node — which matters because this environment has NO WebGL2 and NO webcam, so the
// render itself can only be checked on a real device. See retargetCore.test.ts.
//
// Key simplification (verified from the rig): NONE of the driven bones (arms,
// forearms, neck) has a driven ANCESTOR, so each bone's parent world orientation is
// a constant taken from the bind pose. That means every driven bone is solved
// INDEPENDENTLY — no hierarchy accumulation, no ordering constraints — which is both
// simpler and far more robust for a blind build. If a spine/hips bone ever becomes
// driven, this assumption breaks and accumulation must be reintroduced.

export type V3 = [number, number, number];
export type Quat = [number, number, number, number]; // x, y, z, w

// ── tiny vec3 / quat helpers ────────────────────────────────────────────────────
function v3sub(a: V3, b: V3): V3 { return [a[0] - b[0], a[1] - b[1], a[2] - b[2]]; }
function v3len(a: V3): number { return Math.hypot(a[0], a[1], a[2]); }
function v3normalize(a: V3): V3 { const l = v3len(a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; }
function v3cross(a: V3, b: V3): V3 {
  return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
}
function v3dot(a: V3, b: V3): number { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }

export function qNormalize(q: Quat): Quat {
  const l = Math.hypot(q[0], q[1], q[2], q[3]) || 1;
  return [q[0] / l, q[1] / l, q[2] / l, q[3] / l];
}
export function qDot(a: Quat, b: Quat): number { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3]; }
export function qNeg(q: Quat): Quat { return [-q[0], -q[1], -q[2], -q[3]]; }
export function qConj(q: Quat): Quat { return [-q[0], -q[1], -q[2], q[3]]; }

/** Hamilton product a*b (three.js convention: parent * child). */
export function qMul(a: Quat, b: Quat): Quat {
  const [ax, ay, az, aw] = a; const [bx, by, bz, bw] = b;
  return [
    aw * bx + ax * bw + ay * bz - az * by,
    aw * by - ax * bz + ay * bw + az * bx,
    aw * bz + ax * by - ay * bx + az * bw,
    aw * bw - ax * bx - ay * by - az * bz,
  ];
}

/** Rotate vector v by quaternion q. */
export function qRotV3(q: Quat, v: V3): V3 {
  const [x, y, z, w] = q;
  // t = 2 * cross(q.xyz, v)
  const tx = 2 * (y * v[2] - z * v[1]);
  const ty = 2 * (z * v[0] - x * v[2]);
  const tz = 2 * (x * v[1] - y * v[0]);
  // v' = v + w*t + cross(q.xyz, t)
  return [
    v[0] + w * tx + (y * tz - z * ty),
    v[1] + w * ty + (z * tx - x * tz),
    v[2] + w * tz + (x * ty - y * tx),
  ];
}

/**
 * Shortest-arc quaternion that rotates unit vector `from` onto unit vector `to`.
 * Mirrors THREE.Quaternion.setFromUnitVectors, including the antipodal guard so a
 * fully-reversed direction returns a valid 180° rotation instead of NaN.
 */
export function qFromUnitVectors(from: V3, to: V3): Quat {
  let r = v3dot(from, to) + 1;
  let x: number, y: number, z: number;
  if (r < 1e-6) {
    // `from` and `to` are opposite — pick any axis orthogonal to `from`.
    r = 0;
    if (Math.abs(from[0]) > Math.abs(from[2])) { x = -from[1]; y = from[0]; z = 0; }
    else { x = 0; y = -from[2]; z = from[1]; }
  } else {
    const c = v3cross(from, to);
    x = c[0]; y = c[1]; z = c[2];
  }
  return qNormalize([x, y, z, r]);
}

// ── landmark helpers ────────────────────────────────────────────────────────────
export type LmRef = number | [number, number];

/** World position of a landmark index, or the midpoint of two indices. */
export function lmPoint(lm: Float32Array, ref: LmRef): V3 {
  if (typeof ref === "number") return [lm[ref * 3], lm[ref * 3 + 1], lm[ref * 3 + 2]];
  const [a, b] = ref;
  return [
    (lm[a * 3] + lm[b * 3]) * 0.5,
    (lm[a * 3 + 1] + lm[b * 3 + 1]) * 0.5,
    (lm[a * 3 + 2] + lm[b * 3 + 2]) * 0.5,
  ];
}

// ── coordinate mapping: MediaPipe world space → character space ───────────────────
// MediaPipe pose world landmarks are metres, origin at the hip midpoint, with y
// pointing DOWN (image convention); three.js is y-up. The exact x/z signs and
// whether left/right must be swapped depend on the camera + selfie mirroring, which
// CANNOT be seen in this environment. So the mapping is ONE explicit, overridable
// config: the /army-bunny-preview route exposes it as URL params so the user can
// confirm the correct combo on their iPhone in seconds, and then it gets baked in.
export interface AxisMap { sx: number; sy: number; sz: number; swapLR: boolean; }
export const DEFAULT_AXIS_MAP: AxisMap = { sx: 1, sy: -1, sz: -1, swapLR: false };

// MediaPipe left↔right landmark index pairs (0 = nose, stays put).
const LR_SWAP: number[] = (() => {
  const map = Array.from({ length: 33 }, (_, i) => i);
  const pairs = [[1, 4], [2, 5], [3, 6], [7, 8], [9, 10], [11, 12], [13, 14], [15, 16],
    [17, 18], [19, 20], [21, 22], [23, 24], [25, 26], [27, 28], [29, 30], [31, 32]];
  for (const [a, b] of pairs) { map[a] = b; map[b] = a; }
  return map;
})();

/** Apply the axis map into `out` (both Float32Array of 33*3). */
export function mapLandmarks(world: Float32Array, cfg: AxisMap, out: Float32Array): Float32Array {
  const { sx, sy, sz, swapLR } = cfg;
  for (let i = 0; i < 33; i++) {
    const s = swapLR ? LR_SWAP[i] : i;
    out[i * 3] = world[s * 3] * sx;
    out[i * 3 + 1] = world[s * 3 + 1] * sy;
    out[i * 3 + 2] = world[s * 3 + 2] * sz;
  }
  return out;
}

// ── the rig + solver ──────────────────────────────────────────────────────────
export interface DrivenBone {
  name: string;
  /** Constant bind world orientation of this bone's PARENT (see file header). */
  parentWorld: Quat;
  /** This bone's bind LOCAL orientation. */
  restLocal: Quat;
  /** Bind direction (bone → aim-child) in the parent's world space, unit length. */
  restDirParent: V3;
  /** Landmark(s) at this bone's joint. */
  originIdx: LmRef;
  /** Landmark(s) at the aim-child joint. */
  childIdx: LmRef;
}
export interface RigDef { bones: DrivenBone[]; }

/**
 * Solve every driven bone's LOCAL quaternion from `char` (33×3, already mapped into
 * character space). Writes bones.length*4 quats into `outLocal`, which is REUSED
 * across frames and also read back as the previous frame for sign-continuity — so
 * the hot path allocates nothing beyond a few tiny tuples.
 */
export function solvePose(char: Float32Array, rig: RigDef, outLocal: Float32Array): void {
  const bones = rig.bones;
  for (let i = 0; i < bones.length; i++) {
    const b = bones[i];
    const origin = lmPoint(char, b.originIdx);
    const child = lmPoint(char, b.childIdx);
    const dir = v3sub(child, origin);
    const len = v3len(dir);
    let local: Quat;
    if (len < 1e-6) {
      local = b.restLocal; // degenerate/missing landmark → hold rest
    } else {
      const dirWorld: V3 = [dir[0] / len, dir[1] / len, dir[2] / len];
      const dirParent = v3normalize(qRotV3(qConj(b.parentWorld), dirWorld));
      const swing = qFromUnitVectors(b.restDirParent, dirParent);
      local = qMul(swing, b.restLocal);
    }
    local = qNormalize(local);
    // sign-canonicalize against the previous frame for smooth interpolation.
    const j = i * 4;
    const prev: Quat = [outLocal[j], outLocal[j + 1], outLocal[j + 2], outLocal[j + 3]];
    if (qDot(prev, local) < 0) local = qNeg(local);
    outLocal[j] = local[0]; outLocal[j + 1] = local[1]; outLocal[j + 2] = local[2]; outLocal[j + 3] = local[3];
  }
}

// ── screen placement helpers (normalized image space, [0..1]) ─────────────────────
export interface TorsoMetrics { hipMid: [number, number]; shoulderMid: [number, number]; torsoLen: number; }

/** Pure 2D torso metrics from normalized landmarks — drives root placement/scale. */
export function torsoMetrics(norm: Float32Array): TorsoMetrics {
  const sx = (norm[11 * 3] + norm[12 * 3]) * 0.5;
  const sy = (norm[11 * 3 + 1] + norm[12 * 3 + 1]) * 0.5;
  const hx = (norm[23 * 3] + norm[24 * 3]) * 0.5;
  const hy = (norm[23 * 3 + 1] + norm[24 * 3 + 1]) * 0.5;
  return { shoulderMid: [sx, sy], hipMid: [hx, hy], torsoLen: Math.hypot(hx - sx, hy - sy) };
}
