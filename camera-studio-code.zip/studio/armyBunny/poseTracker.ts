// ── Army Bunny — body pose tracker (thin re-export) ─────────────────────────────
// The pose tracker used to live here. It has been generalized into the shared studio
// module (../poseTracking) so any consumer can reuse it and exactly ONE PoseLandmarker
// implementation exists. This re-export keeps Army Bunny's imports + behavior unchanged.
export { StudioPoseTracker as ArmyBunnyPoseTracker } from "../poseTracking";
export type { PoseSnapshot as PoseTracking } from "../poseTracking";
