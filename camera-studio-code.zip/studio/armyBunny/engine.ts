// ── Army Bunny — offscreen render engine ────────────────────────────────────────
// A self-contained three.js scene that renders the rigged mascot to a TRANSPARENT
// canvas (premultiplied alpha, clear alpha 0) so the CameraStudio compositor can
// drawImage() it straight over the video frame — exactly like the NeonPatriot GL
// overlay. GL creation is null-safe: if WebGL is unavailable the engine reports
// `ok === false` and the compositor simply skips the overlay (video passes through).
import * as THREE from "three";
import { loadArmyBunny, type ArmyBunnyModel } from "./loader";

export class ArmyBunnyEngine {
  readonly ok: boolean;
  readonly canvas: HTMLCanvasElement;
  private renderer: THREE.WebGLRenderer | null = null;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private model: ArmyBunnyModel | null = null;
  private width: number;
  private height: number;

  constructor(width = 720, height = 960) {
    this.width = width;
    this.height = height;
    this.canvas = document.createElement("canvas");
    this.canvas.width = width;
    this.canvas.height = height;

    this.scene = new THREE.Scene();
    // Framed on the UPPER BODY (waist-up) so the sprite is ~full-res at the size we
    // blit it — placement is done in 2D by the compositor (anchor neck→neck, scale to
    // shoulder span), NOT by moving the model. Legs fall off the bottom of the canvas,
    // which is exactly what we want for a selfie costume. z is pulled back enough that
    // fully-raised arms + the hands-to-head reveal stay inside the frame.
    this.camera = new THREE.PerspectiveCamera(35, width / height, 0.05, 50);
    this.camera.position.set(0, 0.82, 1.4);
    this.camera.lookAt(0, 0.74, 0);

    // lighting: soft ambient wrap + key + gentle rim for form
    const hemi = new THREE.HemisphereLight(0xdfe8ff, 0x2a2a1e, 1.05);
    this.scene.add(hemi);
    const key = new THREE.DirectionalLight(0xffffff, 1.35);
    key.position.set(1.2, 2.0, 1.6);
    this.scene.add(key);
    const rim = new THREE.DirectionalLight(0x88b0ff, 0.6);
    rim.position.set(-1.5, 1.0, -1.2);
    this.scene.add(rim);

    let ok = false;
    try {
      this.renderer = new THREE.WebGLRenderer({
        canvas: this.canvas,
        alpha: true,
        premultipliedAlpha: true,
        antialias: true,
      });
      this.renderer.setPixelRatio(1);
      this.renderer.setSize(width, height, false);
      this.renderer.setClearColor(0x000000, 0);
      this.renderer.outputColorSpace = THREE.SRGBColorSpace;
      ok = true;
    } catch {
      this.renderer = null;
    }
    this.ok = ok;
  }

  async load(url: string, opts?: { camoSeed?: number }): Promise<boolean> {
    if (!this.ok) return false;
    this.model = await loadArmyBunny(url, opts);
    this.scene.add(this.model.root);
    return true;
  }

  get loaded(): boolean {
    return !!this.model;
  }

  /** The loaded model (bones/meshes) for retargeting — null until load() succeeds. */
  get bunny(): ArmyBunnyModel | null {
    return this.model;
  }

  /** Show/hide the mascot head (body suit stays). Used by the reveal gesture. */
  setHeadVisible(visible: number | boolean): void {
    if (!this.model) return;
    const v = typeof visible === "number" ? visible >= 0.5 : visible;
    this.model.headMesh.visible = v;
  }

  /** Reveal amount 0..1 (1 = head lifted off, real head shows through underneath). */
  setHeadReveal(hidden: number): void {
    if (this.model) this.model.headMesh.visible = hidden < 0.5;
  }

  /** Position + scale the whole mascot in the scene (screen-overlay placement). */
  setRootTransform(x: number, y: number, scale: number): void {
    if (!this.model) return;
    this.model.root.position.set(x, y, 0);
    this.model.root.scale.setScalar(scale);
  }

  /** Rotate the whole mascot about Y (radians) — preview convenience. */
  setYaw(rad: number): void {
    if (this.model) this.model.root.rotation.y = rad;
  }

  /**
   * Project a world-space point to canvas pixels (top-left origin). Used by the
   * compositor to read where the bunny's neck/shoulders/wrists land in the rendered
   * sprite so it can anchor the sprite onto the user (see ArmyBunnyPreview placement).
   */
  project(v: THREE.Vector3): { x: number; y: number } {
    const p = v.clone().project(this.camera);
    return {
      x: (p.x * 0.5 + 0.5) * this.width,
      y: (1 - (p.y * 0.5 + 0.5)) * this.height,
    };
  }

  resize(width: number, height: number): void {
    if (width === this.width && height === this.height) return;
    this.width = width;
    this.height = height;
    this.canvas.width = width;
    this.canvas.height = height;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer?.setSize(width, height, false);
  }

  render(): void {
    if (!this.renderer) return;
    this.renderer.render(this.scene, this.camera);
  }

  dispose(): void {
    this.model?.dispose();
    this.model = null;
    this.renderer?.dispose();
    this.renderer = null;
  }
}
